

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave '.swan' file compiled runtime js
 * @author houyu(houyu01@baidu.com)
 */
(function (global, san) {
    global.errorMsg = [];

    // 自定义模板区域

    var templateComponents = Object.assign({}, {});

    var param = {};
    var filterArr = JSON.parse('[]');

    function processTemplateModule(filterTemplateArrs, filterModule) {
        eval(filterModule);
        var modules = {};
        var templateFiltersObj = {};
        filterTemplateArrs && filterTemplateArrs.forEach(function (element) {
            var filterName = element.filterName,
                func = element.func,
                module = element.module;

            modules[module] = eval(module);
            templateFiltersObj[filterName] = function () {
                var _modules$module;

                return (_modules$module = modules[module])[func].apply(_modules$module, arguments);
            };
        });
        return templateFiltersObj;
    }

    try {

        filterArr && filterArr.forEach(function (item) {
            param[item.module] = eval(item.module);
        });

        var pageContent = '<view class="login"><view class="logo"><image class="img" src="/assets/login/login-logo.png" /></view><view class="box"><view class="section"><view class="area"><picker value="{{area_idx}}" range="{{area_range}}" range-key="name" on-bindchange="eventHappen(\'change\', $event, \'areaChange\', \'\', \'bind\')"><view class="picker-text">{{area_range[area_idx].name}}</view></picker><image class="picker-icon" src="/assets/login/arrow-down.png" /></view><view class="right"><input class="input" data-type="username" type="number" value="{{username}}" placeholder-style="color:#c8c8c8" placeholder="\u8F93\u5165\u624B\u673A\u53F7" on-bindinput="eventHappen(\'input\', $event, \'inputChange\', \'\', \'bind\')" on-bindblur="eventHappen(\'blur\', $event, \'inputBlur\', \'\', \'bind\')" /></view></view><view class="section" s-if="{{img_code.show}}"><view class="left"><input class="input" placeholder-style="color:#c8c8c8" placeholder="\u8BF7\u8F93\u5165\u9A8C\u8BC1\u7801" on-bindinput="eventHappen(\'input\', $event, \'codeInput\', \'\', \'bind\')" on-bindblur="eventHappen(\'blur\', $event, \'inputBlur\', \'\', \'bind\')" /></view><view class="img-code"><image class="code_pic" src="{{img_code.code}}" on-bindtap="eventHappen(\'tap\', $event, \'getVerifyCode\', \'\', \'bind\')" /></view></view><view class="error"><text hidden="{{!error.show}}">{{error.msg}}</text></view><view class="btn" on-bindtap="eventHappen(\'tap\', $event, \'getMessage\', \'\', \'bind\')"><view class="login-btn {{login_disabled ? \'disabled\' : \'\'}}">\u83B7\u53D6\u77ED\u4FE1\u9A8C\u8BC1\u7801</view></view><view class="info">\u767B\u5F55\u5373\u4EE3\u8868\u60A8\u540C\u610F\n            <text data-url="subPackage/pages/login/loginProtocol" on-bindtap="eventHappen(\'tap\', $event, \'jump\', \'\', \'bind\')">\u300A\u7528\u6237\u534F\u8BAE\u300B</text>\u548C\n            <text data-url="subPackage/pages/login/privateH5" on-bindtap="eventHappen(\'tap\', $event, \'jump\', \'\', \'bind\')">\u300A\u9690\u79C1\u653F\u7B56\u300B</text></view></view></view>';

        // 新的渲染逻辑
        var renderPage = function renderPage(filters, modules) {
            var componentFactory = global.componentFactory;
            // 获取所有内置组件 + 自定义组件的fragment
            var componentFragments = componentFactory.getAllComponents();

            // 所有的自定义组件
            ;

            // 路径与该组件映射
            var customAbsolutePathMap = {};

            // 当前页面使用的自定义组件
            var pageUsingComponentMap = JSON.parse('{}');

            // 生成该页面引用的自定义组件
            var customComponents = Object.keys(pageUsingComponentMap).reduce(function (customComponents, customName) {
                customComponents[customName] = customAbsolutePathMap[pageUsingComponentMap[customName]];
                return customComponents;
            }, {});

            // 启动页面渲染逻辑
            global.pageRender(pageContent, templateComponents, customComponents, filters, modules);
        };

        // 兼容旧的swan-core
        var oldPatch = function oldPatch(PageComponent) {
            Object.assign(PageComponent.components, {});
            // 渲染整个页面的顶层组件，template会在编译时被替换为用户的swan模板

            var Index = function (_PageComponent) {
                _inherits(Index, _PageComponent);

                function Index(options) {
                    _classCallCheck(this, Index);

                    var _this = _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));

                    _this.components = PageComponent.components;
                    return _this;
                }

                return Index;
            }(PageComponent);
            // 初始化页面对象


            Index.template = '<swan-wrapper tabindex="-1">' + pageContent + '</swan-wrapper>';
            var index = new Index();
            // 调用页面对象的加载完成通知
            index.slaveLoaded();
            // 监听等待initData，进行渲染
            index.communicator.onMessage('initData', function (params) {
                // 根据master传递的data，设定初始数据，并进行渲染
                index.setInitData(params);
                // 真正的页面渲染，发生在initData之后
                index.attach(document.body);
            }, { listenPreviousEvent: true });
        };

        if (global.pageRender) {
            renderPage(filterArr, param);
        } else {
            oldPatch(window.PageComponent);
        }
    } catch (e) {
        global.errorMsg['execError'] = e;
        throw e;
    }
})(window, window.san);

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvbG9naW4vbG9naW4uc3dhbiJdLCJuYW1lcyI6WyJnbG9iYWwiLCJzYW4iLCJlcnJvck1zZyIsInRlbXBsYXRlQ29tcG9uZW50cyIsIk9iamVjdCIsImFzc2lnbiIsInBhcmFtIiwiZmlsdGVyQXJyIiwiSlNPTiIsInBhcnNlIiwicHJvY2Vzc1RlbXBsYXRlTW9kdWxlIiwiZmlsdGVyVGVtcGxhdGVBcnJzIiwiZmlsdGVyTW9kdWxlIiwiZXZhbCIsIm1vZHVsZXMiLCJ0ZW1wbGF0ZUZpbHRlcnNPYmoiLCJmb3JFYWNoIiwiZmlsdGVyTmFtZSIsImVsZW1lbnQiLCJmdW5jIiwibW9kdWxlIiwiaXRlbSIsInBhZ2VDb250ZW50IiwicmVuZGVyUGFnZSIsImZpbHRlcnMiLCJjb21wb25lbnRGYWN0b3J5IiwiY29tcG9uZW50RnJhZ21lbnRzIiwiZ2V0QWxsQ29tcG9uZW50cyIsImN1c3RvbUFic29sdXRlUGF0aE1hcCIsInBhZ2VVc2luZ0NvbXBvbmVudE1hcCIsImN1c3RvbUNvbXBvbmVudHMiLCJrZXlzIiwicmVkdWNlIiwiY3VzdG9tTmFtZSIsInBhZ2VSZW5kZXIiLCJvbGRQYXRjaCIsIlBhZ2VDb21wb25lbnQiLCJjb21wb25lbnRzIiwiSW5kZXgiLCJvcHRpb25zIiwidGVtcGxhdGUiLCJpbmRleCIsInNsYXZlTG9hZGVkIiwiY29tbXVuaWNhdG9yIiwib25NZXNzYWdlIiwic2V0SW5pdERhdGEiLCJwYXJhbXMiLCJhdHRhY2giLCJkb2N1bWVudCIsImJvZHkiLCJsaXN0ZW5QcmV2aW91c0V2ZW50Iiwid2luZG93IiwiZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQTs7OztBQUlBLENBQUMsVUFBQ0EsTUFBRCxFQUFTQyxHQUFULEVBQWdCO0FBQ2JELFdBQU9FLFFBQVAsR0FBa0IsRUFBbEI7O0FBRUE7O0FBRUEsUUFBTUMscUJBQXFCQyxPQUFPQyxNQUFQLENBQWMsRUFBZCxFQUFrQixFQUFsQixDQUEzQjs7QUFFQSxRQUFJQyxRQUFRLEVBQVo7QUFDQSxRQUFNQyxZQUFZQyxLQUFLQyxLQUFMLENBQVcsSUFBWCxDQUFsQjs7QUFHQSxhQUFTQyxxQkFBVCxDQUErQkMsa0JBQS9CLEVBQW1EQyxZQUFuRCxFQUFpRTtBQUM3REMsYUFBS0QsWUFBTDtBQUNBLFlBQUlFLFVBQVUsRUFBZDtBQUNBLFlBQUlDLHFCQUFxQixFQUF6QjtBQUNBSiw4QkFBc0JBLG1CQUFtQkssT0FBbkIsQ0FBMkIsbUJBQVU7QUFBQSxnQkFDbERDLFVBRGtELEdBQ3RCQyxPQURzQixDQUNsREQsVUFEa0Q7QUFBQSxnQkFDdENFLElBRHNDLEdBQ3RCRCxPQURzQixDQUN0Q0MsSUFEc0M7QUFBQSxnQkFDaENDLE1BRGdDLEdBQ3RCRixPQURzQixDQUNoQ0UsTUFEZ0M7O0FBRXZETixvQkFBUU0sTUFBUixJQUFrQlAsS0FBS08sTUFBTCxDQUFsQjtBQUNBTCwrQkFBbUJFLFVBQW5CLElBQWlDO0FBQUE7O0FBQUEsdUJBQVksMkJBQVFHLE1BQVIsR0FBZ0JELElBQWhCLG1DQUFaO0FBQUEsYUFBakM7QUFDSCxTQUpxQixDQUF0QjtBQUtBLGVBQU9KLGtCQUFQO0FBQ0g7O0FBRUQsUUFBSTs7QUFFQVIscUJBQWFBLFVBQVVTLE9BQVYsQ0FBa0IsZ0JBQU87QUFDbENWLGtCQUFNZSxLQUFLRCxNQUFYLElBQXFCUCxLQUFLUSxLQUFLRCxNQUFWLENBQXJCO0FBQ0gsU0FGWSxDQUFiOztBQUlBLFlBQU1FLGtnRUFBTjs7QUFJQTtBQUNBLFlBQU1DLGFBQWEsU0FBYkEsVUFBYSxDQUFDQyxPQUFELEVBQVVWLE9BQVYsRUFBcUI7QUFDcEMsZ0JBQU1XLG1CQUFtQnpCLE9BQU95QixnQkFBaEM7QUFDQTtBQUNBLGdCQUFNQyxxQkFBcUJELGlCQUFpQkUsZ0JBQWpCLEVBQTNCOztBQUVBO0FBQ0E7O0FBRUE7QUFDQSxnQkFBSUMsd0JBQXdCLEVBQTVCOztBQUVBO0FBQ0EsZ0JBQU1DLHdCQUF3QnJCLEtBQUtDLEtBQUwsTUFBOUI7O0FBRUE7QUFDQSxnQkFBTXFCLG1CQUFtQjFCLE9BQU8yQixJQUFQLENBQVlGLHFCQUFaLEVBQW1DRyxNQUFuQyxDQUEwQyxVQUFDRixnQkFBRCxFQUFtQkcsVUFBbkIsRUFBaUM7QUFDaEdILGlDQUFpQkcsVUFBakIsSUFBK0JMLHNCQUFzQkMsc0JBQXNCSSxVQUF0QixDQUF0QixDQUEvQjtBQUNBLHVCQUFPSCxnQkFBUDtBQUNILGFBSHdCLEVBR3RCLEVBSHNCLENBQXpCOztBQUtBO0FBQ0E5QixtQkFBT2tDLFVBQVAsQ0FBa0JaLFdBQWxCLEVBQStCbkIsa0JBQS9CLEVBQW1EMkIsZ0JBQW5ELEVBQXFFTixPQUFyRSxFQUE4RVYsT0FBOUU7QUFDSCxTQXRCRDs7QUF3QkE7QUFDQSxZQUFNcUIsV0FBVyxTQUFYQSxRQUFXLGdCQUFnQjtBQUM3Qi9CLG1CQUFPQyxNQUFQLENBQWMrQixjQUFjQyxVQUE1QixFQUF3QyxFQUF4QztBQUNBOztBQUY2QixnQkFHdkJDLEtBSHVCO0FBQUE7O0FBSXpCLCtCQUFZQyxPQUFaLEVBQXFCO0FBQUE7O0FBQUEsOEhBQ1hBLE9BRFc7O0FBRWpCLDBCQUFLRixVQUFMLEdBQWtCRCxjQUFjQyxVQUFoQztBQUZpQjtBQUdwQjs7QUFQd0I7QUFBQSxjQUdURCxhQUhTO0FBVTdCOzs7QUFQTUUsaUJBSHVCLENBUWxCRSxRQVJrQixvQ0FRd0JsQixXQVJ4QjtBQVc3QixnQkFBTW1CLFFBQVEsSUFBSUgsS0FBSixFQUFkO0FBQ0E7QUFDQUcsa0JBQU1DLFdBQU47QUFDQTtBQUNBRCxrQkFBTUUsWUFBTixDQUFtQkMsU0FBbkIsQ0FBNkIsVUFBN0IsRUFBeUMsa0JBQVM7QUFDOUM7QUFDQUgsc0JBQU1JLFdBQU4sQ0FBa0JDLE1BQWxCO0FBQ0E7QUFDQUwsc0JBQU1NLE1BQU4sQ0FBYUMsU0FBU0MsSUFBdEI7QUFDSCxhQUxELEVBS0csRUFBQ0MscUJBQXFCLElBQXRCLEVBTEg7QUFNSCxTQXJCRDs7QUF1QkEsWUFBSWxELE9BQU9rQyxVQUFYLEVBQXVCO0FBQ25CWCx1QkFBV2hCLFNBQVgsRUFBc0JELEtBQXRCO0FBQ0gsU0FGRCxNQUdLO0FBQ0Q2QixxQkFBU2dCLE9BQU9mLGFBQWhCO0FBQ0g7QUFDSixLQWpFRCxDQWtFQSxPQUFPZ0IsQ0FBUCxFQUFVO0FBQ05wRCxlQUFPRSxRQUFQLENBQWdCLFdBQWhCLElBQStCa0QsQ0FBL0I7QUFDQSxjQUFNQSxDQUFOO0FBQ0g7QUFDSixDQTdGRCxFQTZGR0QsTUE3RkgsRUE2RldBLE9BQU9sRCxHQTdGbEIsRSIsImZpbGUiOiJwYWdlcy9sb2dpbi9sb2dpbi5zd2FuLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAZmlsZSBzd2FuJ3Mgc2xhdmUgJy5zd2FuJyBmaWxlIGNvbXBpbGVkIHJ1bnRpbWUganNcbiAqIEBhdXRob3IgaG91eXUoaG91eXUwMUBiYWlkdS5jb20pXG4gKi9cbigoZ2xvYmFsLCBzYW4pID0+e1xuICAgIGdsb2JhbC5lcnJvck1zZyA9IFtdO1xuXG4gICAgLy8g6Ieq5a6a5LmJ5qih5p2/5Yy65Z+fXG4gICAgXG4gICAgY29uc3QgdGVtcGxhdGVDb21wb25lbnRzID0gT2JqZWN0LmFzc2lnbih7fSwge30pO1xuXG4gICAgbGV0IHBhcmFtID0ge307XG4gICAgY29uc3QgZmlsdGVyQXJyID0gSlNPTi5wYXJzZSgnW10nKTtcbiAgICBcblxuICAgIGZ1bmN0aW9uIHByb2Nlc3NUZW1wbGF0ZU1vZHVsZShmaWx0ZXJUZW1wbGF0ZUFycnMsIGZpbHRlck1vZHVsZSkge1xuICAgICAgICBldmFsKGZpbHRlck1vZHVsZSk7XG4gICAgICAgIGxldCBtb2R1bGVzID0ge307XG4gICAgICAgIGxldCB0ZW1wbGF0ZUZpbHRlcnNPYmogPSB7fTtcbiAgICAgICAgZmlsdGVyVGVtcGxhdGVBcnJzICYmIGZpbHRlclRlbXBsYXRlQXJycy5mb3JFYWNoKGVsZW1lbnQgPT57XG4gICAgICAgICAgICBsZXQge2ZpbHRlck5hbWUsIGZ1bmMsIG1vZHVsZX0gPSBlbGVtZW50O1xuICAgICAgICAgICAgbW9kdWxlc1ttb2R1bGVdID0gZXZhbChtb2R1bGUpO1xuICAgICAgICAgICAgdGVtcGxhdGVGaWx0ZXJzT2JqW2ZpbHRlck5hbWVdID0gKC4uLmFyZ3MpID0+bW9kdWxlc1ttb2R1bGVdW2Z1bmNdKC4uLmFyZ3MpO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHRlbXBsYXRlRmlsdGVyc09iajtcbiAgICB9XG5cbiAgICB0cnkge1xuXG4gICAgICAgIGZpbHRlckFyciAmJiBmaWx0ZXJBcnIuZm9yRWFjaChpdGVtID0+e1xuICAgICAgICAgICAgcGFyYW1baXRlbS5tb2R1bGVdID0gZXZhbChpdGVtLm1vZHVsZSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGNvbnN0IHBhZ2VDb250ZW50ID0gYDx2aWV3IGNsYXNzPVwibG9naW5cIj48dmlldyBjbGFzcz1cImxvZ29cIj48aW1hZ2UgY2xhc3M9XCJpbWdcIiBzcmM9XCIvYXNzZXRzL2xvZ2luL2xvZ2luLWxvZ28ucG5nXCIgLz48L3ZpZXc+PHZpZXcgY2xhc3M9XCJib3hcIj48dmlldyBjbGFzcz1cInNlY3Rpb25cIj48dmlldyBjbGFzcz1cImFyZWFcIj48cGlja2VyIHZhbHVlPVwie3thcmVhX2lkeH19XCIgcmFuZ2U9XCJ7e2FyZWFfcmFuZ2V9fVwiIHJhbmdlLWtleT1cIm5hbWVcIiBvbi1iaW5kY2hhbmdlPVwiZXZlbnRIYXBwZW4oJ2NoYW5nZScsICRldmVudCwgJ2FyZWFDaGFuZ2UnLCAnJywgJ2JpbmQnKVwiPjx2aWV3IGNsYXNzPVwicGlja2VyLXRleHRcIj57e2FyZWFfcmFuZ2VbYXJlYV9pZHhdLm5hbWV9fTwvdmlldz48L3BpY2tlcj48aW1hZ2UgY2xhc3M9XCJwaWNrZXItaWNvblwiIHNyYz1cIi9hc3NldHMvbG9naW4vYXJyb3ctZG93bi5wbmdcIiAvPjwvdmlldz48dmlldyBjbGFzcz1cInJpZ2h0XCI+PGlucHV0IGNsYXNzPVwiaW5wdXRcIiBkYXRhLXR5cGU9XCJ1c2VybmFtZVwiIHR5cGU9XCJudW1iZXJcIiB2YWx1ZT1cInt7dXNlcm5hbWV9fVwiIHBsYWNlaG9sZGVyLXN0eWxlPVwiY29sb3I6I2M4YzhjOFwiIHBsYWNlaG9sZGVyPVwi6L6T5YWl5omL5py65Y+3XCIgb24tYmluZGlucHV0PVwiZXZlbnRIYXBwZW4oJ2lucHV0JywgJGV2ZW50LCAnaW5wdXRDaGFuZ2UnLCAnJywgJ2JpbmQnKVwiIG9uLWJpbmRibHVyPVwiZXZlbnRIYXBwZW4oJ2JsdXInLCAkZXZlbnQsICdpbnB1dEJsdXInLCAnJywgJ2JpbmQnKVwiIC8+PC92aWV3Pjwvdmlldz48dmlldyBjbGFzcz1cInNlY3Rpb25cIiBzLWlmPVwie3tpbWdfY29kZS5zaG93fX1cIj48dmlldyBjbGFzcz1cImxlZnRcIj48aW5wdXQgY2xhc3M9XCJpbnB1dFwiIHBsYWNlaG9sZGVyLXN0eWxlPVwiY29sb3I6I2M4YzhjOFwiIHBsYWNlaG9sZGVyPVwi6K+36L6T5YWl6aqM6K+B56CBXCIgb24tYmluZGlucHV0PVwiZXZlbnRIYXBwZW4oJ2lucHV0JywgJGV2ZW50LCAnY29kZUlucHV0JywgJycsICdiaW5kJylcIiBvbi1iaW5kYmx1cj1cImV2ZW50SGFwcGVuKCdibHVyJywgJGV2ZW50LCAnaW5wdXRCbHVyJywgJycsICdiaW5kJylcIiAvPjwvdmlldz48dmlldyBjbGFzcz1cImltZy1jb2RlXCI+PGltYWdlIGNsYXNzPVwiY29kZV9waWNcIiBzcmM9XCJ7e2ltZ19jb2RlLmNvZGV9fVwiIG9uLWJpbmR0YXA9XCJldmVudEhhcHBlbigndGFwJywgJGV2ZW50LCAnZ2V0VmVyaWZ5Q29kZScsICcnLCAnYmluZCcpXCIgLz48L3ZpZXc+PC92aWV3Pjx2aWV3IGNsYXNzPVwiZXJyb3JcIj48dGV4dCBoaWRkZW49XCJ7eyFlcnJvci5zaG93fX1cIj57e2Vycm9yLm1zZ319PC90ZXh0Pjwvdmlldz48dmlldyBjbGFzcz1cImJ0blwiIG9uLWJpbmR0YXA9XCJldmVudEhhcHBlbigndGFwJywgJGV2ZW50LCAnZ2V0TWVzc2FnZScsICcnLCAnYmluZCcpXCI+PHZpZXcgY2xhc3M9XCJsb2dpbi1idG4ge3tsb2dpbl9kaXNhYmxlZCA/ICdkaXNhYmxlZCcgOiAnJ319XCI+6I635Y+W55+t5L+h6aqM6K+B56CBPC92aWV3Pjwvdmlldz48dmlldyBjbGFzcz1cImluZm9cIj7nmbvlvZXljbPku6PooajmgqjlkIzmhI9cbiAgICAgICAgICAgIDx0ZXh0IGRhdGEtdXJsPVwic3ViUGFja2FnZS9wYWdlcy9sb2dpbi9sb2dpblByb3RvY29sXCIgb24tYmluZHRhcD1cImV2ZW50SGFwcGVuKCd0YXAnLCAkZXZlbnQsICdqdW1wJywgJycsICdiaW5kJylcIj7jgIrnlKjmiLfljY/orq7jgIs8L3RleHQ+5ZKMXG4gICAgICAgICAgICA8dGV4dCBkYXRhLXVybD1cInN1YlBhY2thZ2UvcGFnZXMvbG9naW4vcHJpdmF0ZUg1XCIgb24tYmluZHRhcD1cImV2ZW50SGFwcGVuKCd0YXAnLCAkZXZlbnQsICdqdW1wJywgJycsICdiaW5kJylcIj7jgIrpmpDnp4HmlL/nrZbjgIs8L3RleHQ+PC92aWV3Pjwvdmlldz48L3ZpZXc+YDtcblxuICAgICAgICAvLyDmlrDnmoTmuLLmn5PpgLvovpFcbiAgICAgICAgY29uc3QgcmVuZGVyUGFnZSA9IChmaWx0ZXJzLCBtb2R1bGVzKSA9PntcbiAgICAgICAgICAgIGNvbnN0IGNvbXBvbmVudEZhY3RvcnkgPSBnbG9iYWwuY29tcG9uZW50RmFjdG9yeTtcbiAgICAgICAgICAgIC8vIOiOt+WPluaJgOacieWGhee9rue7hOS7tiArIOiHquWumuS5iee7hOS7tueahGZyYWdtZW50XG4gICAgICAgICAgICBjb25zdCBjb21wb25lbnRGcmFnbWVudHMgPSBjb21wb25lbnRGYWN0b3J5LmdldEFsbENvbXBvbmVudHMoKTtcblxuICAgICAgICAgICAgLy8g5omA5pyJ55qE6Ieq5a6a5LmJ57uE5Lu2XG4gICAgICAgICAgICA7XG5cbiAgICAgICAgICAgIC8vIOi3r+W+hOS4juivpee7hOS7tuaYoOWwhFxuICAgICAgICAgICAgdmFyIGN1c3RvbUFic29sdXRlUGF0aE1hcCA9IHt9O1xuXG4gICAgICAgICAgICAvLyDlvZPliY3pobXpnaLkvb/nlKjnmoToh6rlrprkuYnnu4Tku7ZcbiAgICAgICAgICAgIGNvbnN0IHBhZ2VVc2luZ0NvbXBvbmVudE1hcCA9IEpTT04ucGFyc2UoYHt9YCk7XG5cbiAgICAgICAgICAgIC8vIOeUn+aIkOivpemhtemdouW8leeUqOeahOiHquWumuS5iee7hOS7tlxuICAgICAgICAgICAgY29uc3QgY3VzdG9tQ29tcG9uZW50cyA9IE9iamVjdC5rZXlzKHBhZ2VVc2luZ0NvbXBvbmVudE1hcCkucmVkdWNlKChjdXN0b21Db21wb25lbnRzLCBjdXN0b21OYW1lKSA9PntcbiAgICAgICAgICAgICAgICBjdXN0b21Db21wb25lbnRzW2N1c3RvbU5hbWVdID0gY3VzdG9tQWJzb2x1dGVQYXRoTWFwW3BhZ2VVc2luZ0NvbXBvbmVudE1hcFtjdXN0b21OYW1lXV07XG4gICAgICAgICAgICAgICAgcmV0dXJuIGN1c3RvbUNvbXBvbmVudHM7XG4gICAgICAgICAgICB9LCB7fSk7XG5cbiAgICAgICAgICAgIC8vIOWQr+WKqOmhtemdoua4suafk+mAu+i+kVxuICAgICAgICAgICAgZ2xvYmFsLnBhZ2VSZW5kZXIocGFnZUNvbnRlbnQsIHRlbXBsYXRlQ29tcG9uZW50cywgY3VzdG9tQ29tcG9uZW50cywgZmlsdGVycywgbW9kdWxlcyk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8g5YW85a655pen55qEc3dhbi1jb3JlXG4gICAgICAgIGNvbnN0IG9sZFBhdGNoID0gUGFnZUNvbXBvbmVudCA9PntcbiAgICAgICAgICAgIE9iamVjdC5hc3NpZ24oUGFnZUNvbXBvbmVudC5jb21wb25lbnRzLCB7fSk7XG4gICAgICAgICAgICAvLyDmuLLmn5PmlbTkuKrpobXpnaLnmoTpobblsYLnu4Tku7bvvIx0ZW1wbGF0ZeS8muWcqOe8luivkeaXtuiiq+abv+aNouS4uueUqOaIt+eahHN3YW7mqKHmnb9cbiAgICAgICAgICAgIGNsYXNzIEluZGV4IGV4dGVuZHMgUGFnZUNvbXBvbmVudCB7XG4gICAgICAgICAgICAgICAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgICAgICAgICAgICAgICAgICBzdXBlcihvcHRpb25zKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jb21wb25lbnRzID0gUGFnZUNvbXBvbmVudC5jb21wb25lbnRzO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBzdGF0aWMgdGVtcGxhdGUgPSBgPHN3YW4td3JhcHBlciB0YWJpbmRleD1cIi0xXCI+JHtwYWdlQ29udGVudH08L3N3YW4td3JhcHBlcj5gO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8g5Yid5aeL5YyW6aG16Z2i5a+56LGhXG4gICAgICAgICAgICBjb25zdCBpbmRleCA9IG5ldyBJbmRleCgpO1xuICAgICAgICAgICAgLy8g6LCD55So6aG16Z2i5a+56LGh55qE5Yqg6L295a6M5oiQ6YCa55+lXG4gICAgICAgICAgICBpbmRleC5zbGF2ZUxvYWRlZCgpO1xuICAgICAgICAgICAgLy8g55uR5ZCs562J5b6FaW5pdERhdGHvvIzov5vooYzmuLLmn5NcbiAgICAgICAgICAgIGluZGV4LmNvbW11bmljYXRvci5vbk1lc3NhZ2UoJ2luaXREYXRhJywgcGFyYW1zID0+e1xuICAgICAgICAgICAgICAgIC8vIOagueaNrm1hc3RlcuS8oOmAkueahGRhdGHvvIzorr7lrprliJ3lp4vmlbDmja7vvIzlubbov5vooYzmuLLmn5NcbiAgICAgICAgICAgICAgICBpbmRleC5zZXRJbml0RGF0YShwYXJhbXMpO1xuICAgICAgICAgICAgICAgIC8vIOecn+ato+eahOmhtemdoua4suafk++8jOWPkeeUn+WcqGluaXREYXRh5LmL5ZCOXG4gICAgICAgICAgICAgICAgaW5kZXguYXR0YWNoKGRvY3VtZW50LmJvZHkpO1xuICAgICAgICAgICAgfSwge2xpc3RlblByZXZpb3VzRXZlbnQ6IHRydWV9KTtcbiAgICAgICAgfTtcblxuICAgICAgICBpZiAoZ2xvYmFsLnBhZ2VSZW5kZXIpIHtcbiAgICAgICAgICAgIHJlbmRlclBhZ2UoZmlsdGVyQXJyLCBwYXJhbSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBvbGRQYXRjaCh3aW5kb3cuUGFnZUNvbXBvbmVudCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgZ2xvYmFsLmVycm9yTXNnWydleGVjRXJyb3InXSA9IGU7XG4gICAgICAgIHRocm93IGU7XG4gICAgfVxufSkod2luZG93LCB3aW5kb3cuc2FuKTtcblxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAvVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9wYWdlcy9sb2dpbi9sb2dpbi5zd2FuIl0sInNvdXJjZVJvb3QiOiIifQ==