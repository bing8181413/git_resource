window.define('120', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _userInfo = __webpack_require__(36);

var user = _interopRequireWildcard(_userInfo);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

var _phonenumberLib = __webpack_require__(121);

var _phonenumberLib2 = _interopRequireDefault(_phonenumberLib);

var _reqService = __webpack_require__(122);

var req = _interopRequireWildcard(_reqService);

var _rsaUtil = __webpack_require__(42);

var _rsaUtil2 = _interopRequireDefault(_rsaUtil);

var _session = __webpack_require__(32);

var _session2 = _interopRequireDefault(_session);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
// import actions from "./actions/index"


var app = getApp();

var isPhone = function isPhone(username) {
    var font = /[\u4E00-\u9FA5]/;
    var char = /[A-Za-z]/;
    return !(char.test(username) || font.test(username));
};

var page = {
    data: {
        area_idx: 0,
        area_range: req.getDefaultArea(),
        curpage: 'swan_zhlogin',
        error: {
            show: false,
            msg: ''
        },
        login_disabled: true,
        username: '', //17621037089
        img_code: {
            show: false,
            code: '',
            value: ''
        },
        userInfo: {}
    },

    onShow: function onShow() {},
    onReady: function onReady() {},
    onLoad: function onLoad() {
        this.loadPage();
    },
    loadPage: function loadPage() {
        this._getAreaInfo({ local: 1, enable_oversea: 1 });
    },
    _loadedPage: function _loadedPage(data) {
        // 渲染后回调
        _util2.default.seo(); //默认 SEO
    },
    jump: function jump(event) {
        // swan.switchTab({url:'/pages/my/my'});
        // _.jump(`pages/my/my`);
        // return;
        var target = event.currentTarget;
        var url = target.dataset.url;
        _util2.default.jump(url);
    },

    // init area range
    _getAreaInfo: function _getAreaInfo(params) {
        var _this = this;

        req.getAreaCode(params).then(function (data) {
            // console.log(req.formatArea(data));
            _this.setData(Object.assign({}, req.formatArea(data)), function () {
                _this.validate();
            });
        });
    },
    // hanle area change
    areaChange: function areaChange(e) {
        var area_idx = e.detail.value;

        this.setData({ area_idx: area_idx });
    },
    // handle input change
    inputChange: function inputChange(e) {
        var _setData;

        // console.log(e);
        var type = e.currentTarget.dataset.type,
            _e$detail$value = e.detail.value,
            value = _e$detail$value === undefined ? '' : _e$detail$value;
        var error = this.data.error;
        // 输入时取消错误提示

        error.show && (error.show = false);
        this.setData((_setData = {}, _defineProperty(_setData, type, value), _defineProperty(_setData, "error", error), _setData));
        this.validate();
    },
    // handle input blur
    inputBlur: function inputBlur(e) {
        var _data = this.data,
            error = _data.error,
            login_disabled = _data.login_disabled;

        if (!login_disabled) return;
        error.show = true;
        this.setData({ error: error });
    },
    // validate username & pwd
    validate: function validate() {
        var _data2 = this.data,
            username = _data2.username,
            area_range = _data2.area_range,
            area_idx = _data2.area_idx,
            error = _data2.error;
        var acode = area_range[area_idx].acode;

        var login_disabled = false;

        if (!username) {
            login_disabled = true;
            error.msg = '手机号不能为空';
        } else {
            if (isPhone(username)) {
                var _phonenumberLib$phone = _phonenumberLib2.default.phoneNumberParser(username.replace(/[^0-9]+/g, ''), acode),
                    reason = _phonenumberLib$phone.reason,
                    isPossible = _phonenumberLib$phone.isPossible,
                    isNumberValid = _phonenumberLib$phone.isNumberValid;

                if (!!reason || !isPossible || !isNumberValid) {
                    login_disabled = true;
                    error.msg = '手机号格式错误,请重新输入';
                }
            }
        }
        this.setData({ error: error, login_disabled: login_disabled });
        return { error: error, login_disabled: login_disabled };
    },
    // goto login
    getMessage: function getMessage() {
        var _this2 = this;

        var _data3 = this.data,
            username = _data3.username,
            area_range = _data3.area_range,
            area_idx = _data3.area_idx,
            error = _data3.error;
        var acode = area_range[area_idx].acode;


        var tokens = this.data.tokens || '';
        var pagefrom = this.data.pagefrom || '';
        var delta = this.data.delta || '';

        var phoneNum = this.data.username || '';

        var login_disabled = this.data.login_disabled;

        if (login_disabled) {
            return;
        }

        var phoneType = this.data.phoneType || '';
        var requestType = 22;
        var params = {
            requestType: requestType,
            // qd_sc:// 加密函数
            // agenttype
            // ptid
            cellphoneNumber: _rsaUtil2.default.RSAEncryption(phoneNum),
            area_code: acode,
            serviceId: 1,
            dfp: user.getDeviceId(),
            QC005: user.getDeviceId(),
            nr: 1
        };

        if (this.getMessage.requesting) {
            return;
        }
        this.getMessage.requesting = true;

        if (swan.showLoading) {
            swan.showLoading({
                title: '加载中',
                mask: true
            });
        }

        var messageCodeInputUrl = "pages/messageCodeInput/messageCodeInput?tokens=" + tokens + "&area_code=" + acode + "&phone=" + phoneNum + "&requestType=" + requestType + "&pagefrom=" + pagefrom + "&delta=" + delta + "&phoneType=" + phoneType;

        // swan.hideLoading();//TODO 测试不获取验证码 直接跳转过去
        // _.jump(messageCodeInputUrl)
        // return;

        req.getPhoneCodeInfo(params).then(function (data) {
            console.log(data);
            if (swan.hideLoading) {
                swan.hideLoading();
            }
            if (data.code === 'A00000') {
                _util2.default.jump(messageCodeInputUrl);
            } else {
                if (data.code === 'P00223') {
                    swan.showToast({
                        title: "\u8D26\u53F7\u5B58\u5728\u5B89\u5168\u98CE\u9669\uFF0C\u8BF7\u5C3D\u5FEB\u9000\u767B\u5176\u4ED6\u8BBE\u5907\u6216\u7ACB\u5373\u4FEE\u6539\u5BC6\u7801",
                        icon: 'none'
                    });
                } else {
                    swan.showToast({
                        title: "" + data.msg,
                        icon: 'none'
                    });
                }
            }

            //改变按钮状态
            _this2.data.login_disabled = false;
            _this2.setData({ login_disabled: _this2.data.login_disabled });
            setTimeout(function () {
                _this2.getMessage.requesting = false;
            }, 0);
        }, function (error) {
            console.error(error);
            _this2.getMessage.requesting = false;
            swan.showToast({
                title: "" + error.msg,
                icon: 'none'
            });
            //改变按钮状态
            _this2.data.login_disabled = false;
            _this2.setData({ login_disabled: _this2.data.login_disabled });
        });
    }

};

Page(Object.assign({}, page));
});
window.__swanRoute='pages/login/login';window.usingComponents=[];require('120');

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvbG9naW4vbG9naW4uanMiXSwibmFtZXMiOlsidXNlciIsInJlcSIsImFwcCIsImdldEFwcCIsImlzUGhvbmUiLCJ1c2VybmFtZSIsImZvbnQiLCJjaGFyIiwidGVzdCIsInBhZ2UiLCJkYXRhIiwiYXJlYV9pZHgiLCJhcmVhX3JhbmdlIiwiZ2V0RGVmYXVsdEFyZWEiLCJjdXJwYWdlIiwiZXJyb3IiLCJzaG93IiwibXNnIiwibG9naW5fZGlzYWJsZWQiLCJpbWdfY29kZSIsImNvZGUiLCJ2YWx1ZSIsInVzZXJJbmZvIiwib25TaG93Iiwib25SZWFkeSIsIm9uTG9hZCIsImxvYWRQYWdlIiwiX2dldEFyZWFJbmZvIiwibG9jYWwiLCJlbmFibGVfb3ZlcnNlYSIsIl9sb2FkZWRQYWdlIiwiXyIsInNlbyIsImp1bXAiLCJldmVudCIsInRhcmdldCIsImN1cnJlbnRUYXJnZXQiLCJ1cmwiLCJkYXRhc2V0IiwicGFyYW1zIiwiZ2V0QXJlYUNvZGUiLCJ0aGVuIiwic2V0RGF0YSIsImZvcm1hdEFyZWEiLCJ2YWxpZGF0ZSIsImFyZWFDaGFuZ2UiLCJlIiwiZGV0YWlsIiwiaW5wdXRDaGFuZ2UiLCJ0eXBlIiwiaW5wdXRCbHVyIiwiYWNvZGUiLCJwaG9uZW51bWJlckxpYiIsInBob25lTnVtYmVyUGFyc2VyIiwicmVwbGFjZSIsInJlYXNvbiIsImlzUG9zc2libGUiLCJpc051bWJlclZhbGlkIiwiZ2V0TWVzc2FnZSIsInRva2VucyIsInBhZ2Vmcm9tIiwiZGVsdGEiLCJwaG9uZU51bSIsInBob25lVHlwZSIsInJlcXVlc3RUeXBlIiwiY2VsbHBob25lTnVtYmVyIiwicnNhVXRpbCIsIlJTQUVuY3J5cHRpb24iLCJhcmVhX2NvZGUiLCJzZXJ2aWNlSWQiLCJkZnAiLCJnZXREZXZpY2VJZCIsIlFDMDA1IiwibnIiLCJyZXF1ZXN0aW5nIiwic3dhbiIsInNob3dMb2FkaW5nIiwidGl0bGUiLCJtYXNrIiwibWVzc2FnZUNvZGVJbnB1dFVybCIsImdldFBob25lQ29kZUluZm8iLCJjb25zb2xlIiwibG9nIiwiaGlkZUxvYWRpbmciLCJzaG93VG9hc3QiLCJpY29uIiwic2V0VGltZW91dCIsIlBhZ2UiLCJPYmplY3QiLCJhc3NpZ24iXSwibWFwcGluZ3MiOiI7OztBQUFBOztJQUFZQSxJOztBQUVaOzs7O0FBQ0E7Ozs7QUFDQTs7SUFBWUMsRzs7QUFDWjs7OztBQUNBOzs7Ozs7Ozs7QUFMQTs7O0FBUUEsSUFBTUMsTUFBTUMsUUFBWjs7QUFFQSxJQUFNQyxVQUFVLFNBQVZBLE9BQVUsQ0FBQ0MsUUFBRCxFQUFjO0FBQzFCLFFBQUlDLE9BQU8saUJBQVg7QUFDQSxRQUFJQyxPQUFPLFVBQVg7QUFDQSxXQUFPLEVBQUVBLEtBQUtDLElBQUwsQ0FBVUgsUUFBVixLQUF1QkMsS0FBS0UsSUFBTCxDQUFVSCxRQUFWLENBQXpCLENBQVA7QUFDSCxDQUpEOztBQU1BLElBQU1JLE9BQU87QUFDVEMsVUFBTTtBQUNGQyxrQkFBVSxDQURSO0FBRUZDLG9CQUFZWCxJQUFJWSxjQUFKLEVBRlY7QUFHRkMsaUJBQVMsY0FIUDtBQUlGQyxlQUFPO0FBQ0hDLGtCQUFNLEtBREg7QUFFSEMsaUJBQUs7QUFGRixTQUpMO0FBUUZDLHdCQUFnQixJQVJkO0FBU0ZiLGtCQUFVLEVBVFIsRUFTVztBQUNiYyxrQkFBVTtBQUNOSCxrQkFBTSxLQURBO0FBRU5JLGtCQUFNLEVBRkE7QUFHTkMsbUJBQU87QUFIRCxTQVZSO0FBZUZDLGtCQUFVO0FBZlIsS0FERzs7QUFtQlRDLFVBbkJTLG9CQW1CQSxDQUVSLENBckJRO0FBc0JUQyxXQXRCUyxxQkFzQkMsQ0FDVCxDQXZCUTtBQXdCVEMsVUF4QlMsb0JBd0JBO0FBQ0wsYUFBS0MsUUFBTDtBQUNILEtBMUJRO0FBMkJUQSxZQTNCUyxzQkEyQkU7QUFDUCxhQUFLQyxZQUFMLENBQWtCLEVBQUVDLE9BQU8sQ0FBVCxFQUFZQyxnQkFBZ0IsQ0FBNUIsRUFBbEI7QUFDSCxLQTdCUTtBQThCVEMsZUE5QlMsdUJBOEJHcEIsSUE5QkgsRUE4QlM7QUFDZDtBQUNBcUIsdUJBQUVDLEdBQUYsR0FGYyxDQUVMO0FBQ1osS0FqQ1E7QUFrQ1RDLFFBbENTLGdCQWtDSkMsS0FsQ0ksRUFrQ0c7QUFDUjtBQUNBO0FBQ0E7QUFDQSxZQUFNQyxTQUFTRCxNQUFNRSxhQUFyQjtBQUNBLFlBQU1DLE1BQU1GLE9BQU9HLE9BQVAsQ0FBZUQsR0FBM0I7QUFDQU4sdUJBQUVFLElBQUYsQ0FBT0ksR0FBUDtBQUNILEtBekNROztBQTBDVDtBQUNBVixrQkFBYyxzQkFBVVksTUFBVixFQUFrQjtBQUFBOztBQUM1QnRDLFlBQUl1QyxXQUFKLENBQWdCRCxNQUFoQixFQUF3QkUsSUFBeEIsQ0FBNkIsZ0JBQVE7QUFDakM7QUFDQSxrQkFBS0MsT0FBTCxtQkFBa0J6QyxJQUFJMEMsVUFBSixDQUFlakMsSUFBZixDQUFsQixHQUEwQyxZQUFNO0FBQzVDLHNCQUFLa0MsUUFBTDtBQUNILGFBRkQ7QUFHSCxTQUxEO0FBTUgsS0FsRFE7QUFtRFQ7QUFDQUMsZ0JBQVksb0JBQVVDLENBQVYsRUFBYTtBQUFBLFlBQ0VuQyxRQURGLEdBQ2lCbUMsQ0FEakIsQ0FDZkMsTUFEZSxDQUNMMUIsS0FESzs7QUFFckIsYUFBS3FCLE9BQUwsQ0FBYSxFQUFFL0Isa0JBQUYsRUFBYjtBQUNILEtBdkRRO0FBd0RUO0FBQ0FxQyxpQkFBYSxxQkFBVUYsQ0FBVixFQUFhO0FBQUE7O0FBQ3RCO0FBRHNCLFlBRVlHLElBRlosR0FFaURILENBRmpELENBRWhCVixhQUZnQixDQUVDRSxPQUZELENBRVlXLElBRlo7QUFBQSw4QkFFaURILENBRmpELENBRXNCQyxNQUZ0QixDQUVnQzFCLEtBRmhDO0FBQUEsWUFFZ0NBLEtBRmhDLG1DQUV3QyxFQUZ4QztBQUFBLFlBR2hCTixLQUhnQixHQUdOLEtBQUtMLElBSEMsQ0FHaEJLLEtBSGdCO0FBSXRCOztBQUNBQSxjQUFNQyxJQUFOLEtBQWVELE1BQU1DLElBQU4sR0FBYSxLQUE1QjtBQUNBLGFBQUswQixPQUFMLDJDQUFnQk8sSUFBaEIsRUFBdUI1QixLQUF2QixzQ0FBOEJOLEtBQTlCO0FBQ0EsYUFBSzZCLFFBQUw7QUFDSCxLQWpFUTtBQWtFVDtBQUNBTSxlQUFXLG1CQUFVSixDQUFWLEVBQWE7QUFBQSxvQkFDWSxLQUFLcEMsSUFEakI7QUFBQSxZQUNkSyxLQURjLFNBQ2RBLEtBRGM7QUFBQSxZQUNQRyxjQURPLFNBQ1BBLGNBRE87O0FBRXBCLFlBQUcsQ0FBQ0EsY0FBSixFQUFvQjtBQUNwQkgsY0FBTUMsSUFBTixHQUFhLElBQWI7QUFDQSxhQUFLMEIsT0FBTCxDQUFhLEVBQUUzQixZQUFGLEVBQWI7QUFDSCxLQXhFUTtBQXlFVDtBQUNBNkIsY0FBVSxvQkFBWTtBQUFBLHFCQUM4QixLQUFLbEMsSUFEbkM7QUFBQSxZQUNaTCxRQURZLFVBQ1pBLFFBRFk7QUFBQSxZQUNGTyxVQURFLFVBQ0ZBLFVBREU7QUFBQSxZQUNVRCxRQURWLFVBQ1VBLFFBRFY7QUFBQSxZQUNvQkksS0FEcEIsVUFDb0JBLEtBRHBCO0FBQUEsWUFFWm9DLEtBRlksR0FFRnZDLFdBQVdELFFBQVgsQ0FGRSxDQUVad0MsS0FGWTs7QUFHbEIsWUFBSWpDLGlCQUFpQixLQUFyQjs7QUFFQSxZQUFHLENBQUNiLFFBQUosRUFBYztBQUNWYSw2QkFBaUIsSUFBakI7QUFDQUgsa0JBQU1FLEdBQU4sR0FBWSxTQUFaO0FBQ0gsU0FIRCxNQUdPO0FBQ0gsZ0JBQUdiLFFBQVFDLFFBQVIsQ0FBSCxFQUFzQjtBQUFBLDRDQUMwQitDLHlCQUFlQyxpQkFBZixDQUFpQ2hELFNBQVNpRCxPQUFULENBQWlCLFVBQWpCLEVBQTZCLEVBQTdCLENBQWpDLEVBQW1FSCxLQUFuRSxDQUQxQjtBQUFBLG9CQUNaSSxNQURZLHlCQUNaQSxNQURZO0FBQUEsb0JBQ0pDLFVBREkseUJBQ0pBLFVBREk7QUFBQSxvQkFDUUMsYUFEUix5QkFDUUEsYUFEUjs7QUFFbEIsb0JBQUcsQ0FBQyxDQUFDRixNQUFGLElBQVksQ0FBQ0MsVUFBYixJQUEyQixDQUFDQyxhQUEvQixFQUE4QztBQUMxQ3ZDLHFDQUFpQixJQUFqQjtBQUNBSCwwQkFBTUUsR0FBTixHQUFZLGVBQVo7QUFDSDtBQUNKO0FBQ0o7QUFDRCxhQUFLeUIsT0FBTCxDQUFhLEVBQUUzQixZQUFGLEVBQVNHLDhCQUFULEVBQWI7QUFDQSxlQUFPLEVBQUVILFlBQUYsRUFBU0csOEJBQVQsRUFBUDtBQUNILEtBN0ZRO0FBOEZUO0FBQ0F3QyxnQkFBWSxzQkFBWTtBQUFBOztBQUFBLHFCQUM0QixLQUFLaEQsSUFEakM7QUFBQSxZQUNkTCxRQURjLFVBQ2RBLFFBRGM7QUFBQSxZQUNKTyxVQURJLFVBQ0pBLFVBREk7QUFBQSxZQUNRRCxRQURSLFVBQ1FBLFFBRFI7QUFBQSxZQUNrQkksS0FEbEIsVUFDa0JBLEtBRGxCO0FBQUEsWUFFZG9DLEtBRmMsR0FFSnZDLFdBQVdELFFBQVgsQ0FGSSxDQUVkd0MsS0FGYzs7O0FBSXBCLFlBQU1RLFNBQVMsS0FBS2pELElBQUwsQ0FBVWlELE1BQVYsSUFBb0IsRUFBbkM7QUFDQSxZQUFNQyxXQUFXLEtBQUtsRCxJQUFMLENBQVVrRCxRQUFWLElBQXNCLEVBQXZDO0FBQ0EsWUFBTUMsUUFBUSxLQUFLbkQsSUFBTCxDQUFVbUQsS0FBVixJQUFtQixFQUFqQzs7QUFFQSxZQUFJQyxXQUFXLEtBQUtwRCxJQUFMLENBQVVMLFFBQVYsSUFBc0IsRUFBckM7O0FBRUEsWUFBTWEsaUJBQWlCLEtBQUtSLElBQUwsQ0FBVVEsY0FBakM7O0FBRUEsWUFBR0EsY0FBSCxFQUFtQjtBQUNmO0FBQ0g7O0FBRUQsWUFBSTZDLFlBQVksS0FBS3JELElBQUwsQ0FBVXFELFNBQVYsSUFBdUIsRUFBdkM7QUFDQSxZQUFJQyxjQUFjLEVBQWxCO0FBQ0EsWUFBSXpCLFNBQVM7QUFDVHlCLHlCQUFhQSxXQURKO0FBRVQ7QUFDQTtBQUNBO0FBQ0FDLDZCQUFpQkMsa0JBQVFDLGFBQVIsQ0FBc0JMLFFBQXRCLENBTFI7QUFNVE0sdUJBQVdqQixLQU5GO0FBT1RrQix1QkFBVyxDQVBGO0FBUVRDLGlCQUFLdEUsS0FBS3VFLFdBQUwsRUFSSTtBQVNUQyxtQkFBT3hFLEtBQUt1RSxXQUFMLEVBVEU7QUFVVEUsZ0JBQUk7QUFWSyxTQUFiOztBQWFBLFlBQUcsS0FBS2YsVUFBTCxDQUFnQmdCLFVBQW5CLEVBQStCO0FBQzNCO0FBQ0g7QUFDRCxhQUFLaEIsVUFBTCxDQUFnQmdCLFVBQWhCLEdBQTZCLElBQTdCOztBQUVBLFlBQUdDLEtBQUtDLFdBQVIsRUFBcUI7QUFDakJELGlCQUFLQyxXQUFMLENBQWlCO0FBQ2JDLHVCQUFPLEtBRE07QUFFYkMsc0JBQU07QUFGTyxhQUFqQjtBQUlIOztBQUVELFlBQUlDLDBFQUF3RXBCLE1BQXhFLG1CQUE0RlIsS0FBNUYsZUFBMkdXLFFBQTNHLHFCQUFtSUUsV0FBbkksa0JBQTJKSixRQUEzSixlQUE2S0MsS0FBN0ssbUJBQWdNRSxTQUFwTTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE5RCxZQUFJK0UsZ0JBQUosQ0FBcUJ6QyxNQUFyQixFQUE2QkUsSUFBN0IsQ0FBa0MsVUFBQy9CLElBQUQsRUFBVTtBQUN4Q3VFLG9CQUFRQyxHQUFSLENBQVl4RSxJQUFaO0FBQ0EsZ0JBQUdpRSxLQUFLUSxXQUFSLEVBQXFCO0FBQ2pCUixxQkFBS1EsV0FBTDtBQUNIO0FBQ0QsZ0JBQUd6RSxLQUFLVSxJQUFMLEtBQWMsUUFBakIsRUFBMkI7QUFDdkJXLCtCQUFFRSxJQUFGLENBQU84QyxtQkFBUDtBQUNILGFBRkQsTUFFTztBQUNILG9CQUFHckUsS0FBS1UsSUFBTCxLQUFjLFFBQWpCLEVBQTJCO0FBQ3ZCdUQseUJBQUtTLFNBQUwsQ0FBZTtBQUNYUCx1TEFEVztBQUVYUSw4QkFBTTtBQUZLLHFCQUFmO0FBSUgsaUJBTEQsTUFLTztBQUNIVix5QkFBS1MsU0FBTCxDQUFlO0FBQ1hQLG9DQUFVbkUsS0FBS08sR0FESjtBQUVYb0UsOEJBQU07QUFGSyxxQkFBZjtBQUlIO0FBQ0o7O0FBRUQ7QUFDQSxtQkFBSzNFLElBQUwsQ0FBVVEsY0FBVixHQUEyQixLQUEzQjtBQUNBLG1CQUFLd0IsT0FBTCxDQUFhLEVBQUV4QixnQkFBZ0IsT0FBS1IsSUFBTCxDQUFVUSxjQUE1QixFQUFiO0FBQ0FvRSx1QkFBVyxZQUFNO0FBQ2IsdUJBQUs1QixVQUFMLENBQWdCZ0IsVUFBaEIsR0FBNkIsS0FBN0I7QUFDSCxhQUZELEVBRUcsQ0FGSDtBQUdILFNBM0JELEVBMkJHLFVBQUMzRCxLQUFELEVBQVc7QUFDVmtFLG9CQUFRbEUsS0FBUixDQUFjQSxLQUFkO0FBQ0EsbUJBQUsyQyxVQUFMLENBQWdCZ0IsVUFBaEIsR0FBNkIsS0FBN0I7QUFDQUMsaUJBQUtTLFNBQUwsQ0FBZTtBQUNYUCw0QkFBVTlELE1BQU1FLEdBREw7QUFFWG9FLHNCQUFNO0FBRkssYUFBZjtBQUlBO0FBQ0EsbUJBQUszRSxJQUFMLENBQVVRLGNBQVYsR0FBMkIsS0FBM0I7QUFDQSxtQkFBS3dCLE9BQUwsQ0FBYSxFQUFFeEIsZ0JBQWdCLE9BQUtSLElBQUwsQ0FBVVEsY0FBNUIsRUFBYjtBQUNILFNBckNEO0FBc0NIOztBQXRMUSxDQUFiOztBQTRMQXFFLEtBQUtDLE9BQU9DLE1BQVAsQ0FBYyxFQUFkLEVBQWtCaEYsSUFBbEIsQ0FBTCxFIiwiZmlsZSI6InBhZ2VzL2xvZ2luL2xvZ2luLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgdXNlciBmcm9tIFwiLi4vLi4vY29tbW9uL3VzZXIvdXNlckluZm9cIlxuLy8gaW1wb3J0IGFjdGlvbnMgZnJvbSBcIi4vYWN0aW9ucy9pbmRleFwiXG5pbXBvcnQgXyBmcm9tIFwiLi4vLi4vY29tbW9uL3V0aWxzL3V0aWxcIlxuaW1wb3J0IHBob25lbnVtYmVyTGliIGZyb20gJy4uLy4uL2NvbW1vbi91dGlscy9waG9uZW51bWJlckxpYidcbmltcG9ydCAqIGFzIHJlcSBmcm9tIFwiLi9zZXJ2aWNlL3JlcVNlcnZpY2VcIjtcbmltcG9ydCByc2FVdGlsIGZyb20gXCIuLi8uLi9jb21tb24vdXRpbHMvUlNBL3JzYVV0aWxcIjtcbmltcG9ydCBzZXNzaW9uIGZyb20gXCIuLi8uLi9jb21tb24vbG9naW4vc2Vzc2lvblwiO1xuXG5cbmNvbnN0IGFwcCA9IGdldEFwcCgpO1xuXG5jb25zdCBpc1Bob25lID0gKHVzZXJuYW1lKSA9PiB7XG4gICAgdmFyIGZvbnQgPSAvW1xcdTRFMDAtXFx1OUZBNV0vXG4gICAgdmFyIGNoYXIgPSAvW0EtWmEtel0vXG4gICAgcmV0dXJuICEoY2hhci50ZXN0KHVzZXJuYW1lKSB8fCBmb250LnRlc3QodXNlcm5hbWUpKVxufVxuXG5jb25zdCBwYWdlID0ge1xuICAgIGRhdGE6IHtcbiAgICAgICAgYXJlYV9pZHg6IDAsXG4gICAgICAgIGFyZWFfcmFuZ2U6IHJlcS5nZXREZWZhdWx0QXJlYSgpLFxuICAgICAgICBjdXJwYWdlOiAnc3dhbl96aGxvZ2luJyxcbiAgICAgICAgZXJyb3I6IHtcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgbXNnOiAnJ1xuICAgICAgICB9LFxuICAgICAgICBsb2dpbl9kaXNhYmxlZDogdHJ1ZSxcbiAgICAgICAgdXNlcm5hbWU6ICcnLC8vMTc2MjEwMzcwODlcbiAgICAgICAgaW1nX2NvZGU6IHtcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgY29kZTogJycsXG4gICAgICAgICAgICB2YWx1ZTogJydcbiAgICAgICAgfSxcbiAgICAgICAgdXNlckluZm86IHt9XG4gICAgfSxcblxuICAgIG9uU2hvdygpIHtcblxuICAgIH0sXG4gICAgb25SZWFkeSgpIHtcbiAgICB9LFxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5sb2FkUGFnZSgpO1xuICAgIH0sXG4gICAgbG9hZFBhZ2UoKSB7XG4gICAgICAgIHRoaXMuX2dldEFyZWFJbmZvKHsgbG9jYWw6IDEsIGVuYWJsZV9vdmVyc2VhOiAxIH0pO1xuICAgIH0sXG4gICAgX2xvYWRlZFBhZ2UoZGF0YSkge1xuICAgICAgICAvLyDmuLLmn5PlkI7lm57osINcbiAgICAgICAgXy5zZW8oKTsgLy/pu5jorqQgU0VPXG4gICAgfSxcbiAgICBqdW1wKGV2ZW50KSB7XG4gICAgICAgIC8vIHN3YW4uc3dpdGNoVGFiKHt1cmw6Jy9wYWdlcy9teS9teSd9KTtcbiAgICAgICAgLy8gXy5qdW1wKGBwYWdlcy9teS9teWApO1xuICAgICAgICAvLyByZXR1cm47XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LmN1cnJlbnRUYXJnZXQ7XG4gICAgICAgIGNvbnN0IHVybCA9IHRhcmdldC5kYXRhc2V0LnVybDtcbiAgICAgICAgXy5qdW1wKHVybCk7XG4gICAgfSxcbiAgICAvLyBpbml0IGFyZWEgcmFuZ2VcbiAgICBfZ2V0QXJlYUluZm86IGZ1bmN0aW9uIChwYXJhbXMpIHtcbiAgICAgICAgcmVxLmdldEFyZWFDb2RlKHBhcmFtcykudGhlbihkYXRhID0+IHtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHJlcS5mb3JtYXRBcmVhKGRhdGEpKTtcbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7IC4uLnJlcS5mb3JtYXRBcmVhKGRhdGEpIH0sICgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnZhbGlkYXRlKClcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0pXG4gICAgfSxcbiAgICAvLyBoYW5sZSBhcmVhIGNoYW5nZVxuICAgIGFyZWFDaGFuZ2U6IGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIGxldCB7IGRldGFpbDogeyB2YWx1ZTogYXJlYV9pZHggfSB9ID0gZVxuICAgICAgICB0aGlzLnNldERhdGEoeyBhcmVhX2lkeCB9KVxuICAgIH0sXG4gICAgLy8gaGFuZGxlIGlucHV0IGNoYW5nZVxuICAgIGlucHV0Q2hhbmdlOiBmdW5jdGlvbiAoZSkge1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgbGV0IHsgY3VycmVudFRhcmdldDogeyBkYXRhc2V0OiB7IHR5cGUgfSB9LCBkZXRhaWw6IHsgdmFsdWUgPSAnJyB9IH0gPSBlXG4gICAgICAgIGxldCB7IGVycm9yIH0gPSB0aGlzLmRhdGFcbiAgICAgICAgLy8g6L6T5YWl5pe25Y+W5raI6ZSZ6K+v5o+Q56S6XG4gICAgICAgIGVycm9yLnNob3cgJiYgKGVycm9yLnNob3cgPSBmYWxzZSlcbiAgICAgICAgdGhpcy5zZXREYXRhKHsgW3R5cGVdOiB2YWx1ZSwgZXJyb3IgfSlcbiAgICAgICAgdGhpcy52YWxpZGF0ZSgpXG4gICAgfSxcbiAgICAvLyBoYW5kbGUgaW5wdXQgYmx1clxuICAgIGlucHV0Qmx1cjogZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgbGV0IHsgZXJyb3IsIGxvZ2luX2Rpc2FibGVkIH0gPSB0aGlzLmRhdGFcbiAgICAgICAgaWYoIWxvZ2luX2Rpc2FibGVkKSByZXR1cm5cbiAgICAgICAgZXJyb3Iuc2hvdyA9IHRydWVcbiAgICAgICAgdGhpcy5zZXREYXRhKHsgZXJyb3IgfSlcbiAgICB9LFxuICAgIC8vIHZhbGlkYXRlIHVzZXJuYW1lICYgcHdkXG4gICAgdmFsaWRhdGU6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgbGV0IHsgdXNlcm5hbWUsIGFyZWFfcmFuZ2UsIGFyZWFfaWR4LCBlcnJvciB9ID0gdGhpcy5kYXRhXG4gICAgICAgIGxldCB7IGFjb2RlIH0gPSBhcmVhX3JhbmdlW2FyZWFfaWR4XVxuICAgICAgICBsZXQgbG9naW5fZGlzYWJsZWQgPSBmYWxzZVxuXG4gICAgICAgIGlmKCF1c2VybmFtZSkge1xuICAgICAgICAgICAgbG9naW5fZGlzYWJsZWQgPSB0cnVlXG4gICAgICAgICAgICBlcnJvci5tc2cgPSAn5omL5py65Y+35LiN6IO95Li656m6J1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYoaXNQaG9uZSh1c2VybmFtZSkpIHtcbiAgICAgICAgICAgICAgICBsZXQgeyByZWFzb24sIGlzUG9zc2libGUsIGlzTnVtYmVyVmFsaWQgfSA9IHBob25lbnVtYmVyTGliLnBob25lTnVtYmVyUGFyc2VyKHVzZXJuYW1lLnJlcGxhY2UoL1teMC05XSsvZywgJycpLCBhY29kZSlcbiAgICAgICAgICAgICAgICBpZighIXJlYXNvbiB8fCAhaXNQb3NzaWJsZSB8fCAhaXNOdW1iZXJWYWxpZCkge1xuICAgICAgICAgICAgICAgICAgICBsb2dpbl9kaXNhYmxlZCA9IHRydWVcbiAgICAgICAgICAgICAgICAgICAgZXJyb3IubXNnID0gJ+aJi+acuuWPt+agvOW8j+mUmeivryzor7fph43mlrDovpPlhaUnXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHRoaXMuc2V0RGF0YSh7IGVycm9yLCBsb2dpbl9kaXNhYmxlZCB9KVxuICAgICAgICByZXR1cm4geyBlcnJvciwgbG9naW5fZGlzYWJsZWQgfVxuICAgIH0sXG4gICAgLy8gZ290byBsb2dpblxuICAgIGdldE1lc3NhZ2U6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgbGV0IHsgdXNlcm5hbWUsIGFyZWFfcmFuZ2UsIGFyZWFfaWR4LCBlcnJvciB9ID0gdGhpcy5kYXRhXG4gICAgICAgIGxldCB7IGFjb2RlIH0gPSBhcmVhX3JhbmdlW2FyZWFfaWR4XTtcblxuICAgICAgICBjb25zdCB0b2tlbnMgPSB0aGlzLmRhdGEudG9rZW5zIHx8ICcnO1xuICAgICAgICBjb25zdCBwYWdlZnJvbSA9IHRoaXMuZGF0YS5wYWdlZnJvbSB8fCAnJztcbiAgICAgICAgY29uc3QgZGVsdGEgPSB0aGlzLmRhdGEuZGVsdGEgfHwgJyc7XG5cbiAgICAgICAgbGV0IHBob25lTnVtID0gdGhpcy5kYXRhLnVzZXJuYW1lIHx8ICcnO1xuXG4gICAgICAgIGNvbnN0IGxvZ2luX2Rpc2FibGVkID0gdGhpcy5kYXRhLmxvZ2luX2Rpc2FibGVkO1xuXG4gICAgICAgIGlmKGxvZ2luX2Rpc2FibGVkKSB7XG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBwaG9uZVR5cGUgPSB0aGlzLmRhdGEucGhvbmVUeXBlIHx8ICcnXG4gICAgICAgIGxldCByZXF1ZXN0VHlwZSA9IDIyO1xuICAgICAgICBsZXQgcGFyYW1zID0ge1xuICAgICAgICAgICAgcmVxdWVzdFR5cGU6IHJlcXVlc3RUeXBlLFxuICAgICAgICAgICAgLy8gcWRfc2M6Ly8g5Yqg5a+G5Ye95pWwXG4gICAgICAgICAgICAvLyBhZ2VudHR5cGVcbiAgICAgICAgICAgIC8vIHB0aWRcbiAgICAgICAgICAgIGNlbGxwaG9uZU51bWJlcjogcnNhVXRpbC5SU0FFbmNyeXB0aW9uKHBob25lTnVtKSxcbiAgICAgICAgICAgIGFyZWFfY29kZTogYWNvZGUsXG4gICAgICAgICAgICBzZXJ2aWNlSWQ6IDEsXG4gICAgICAgICAgICBkZnA6IHVzZXIuZ2V0RGV2aWNlSWQoKSxcbiAgICAgICAgICAgIFFDMDA1OiB1c2VyLmdldERldmljZUlkKCksXG4gICAgICAgICAgICBucjogMVxuICAgICAgICB9O1xuXG4gICAgICAgIGlmKHRoaXMuZ2V0TWVzc2FnZS5yZXF1ZXN0aW5nKSB7XG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgfVxuICAgICAgICB0aGlzLmdldE1lc3NhZ2UucmVxdWVzdGluZyA9IHRydWU7XG5cbiAgICAgICAgaWYoc3dhbi5zaG93TG9hZGluZykge1xuICAgICAgICAgICAgc3dhbi5zaG93TG9hZGluZyh7XG4gICAgICAgICAgICAgICAgdGl0bGU6ICfliqDovb3kuK0nLFxuICAgICAgICAgICAgICAgIG1hc2s6IHRydWVcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgbGV0IG1lc3NhZ2VDb2RlSW5wdXRVcmwgPSBgcGFnZXMvbWVzc2FnZUNvZGVJbnB1dC9tZXNzYWdlQ29kZUlucHV0P3Rva2Vucz0ke3Rva2Vuc30mYXJlYV9jb2RlPSR7YWNvZGV9JnBob25lPSR7cGhvbmVOdW19JnJlcXVlc3RUeXBlPSR7cmVxdWVzdFR5cGV9JnBhZ2Vmcm9tPSR7cGFnZWZyb219JmRlbHRhPSR7ZGVsdGF9JnBob25lVHlwZT0ke3Bob25lVHlwZX1gO1xuXG4gICAgICAgIC8vIHN3YW4uaGlkZUxvYWRpbmcoKTsvL1RPRE8g5rWL6K+V5LiN6I635Y+W6aqM6K+B56CBIOebtOaOpei3s+i9rOi/h+WOu1xuICAgICAgICAvLyBfLmp1bXAobWVzc2FnZUNvZGVJbnB1dFVybClcbiAgICAgICAgLy8gcmV0dXJuO1xuXG4gICAgICAgIHJlcS5nZXRQaG9uZUNvZGVJbmZvKHBhcmFtcykudGhlbigoZGF0YSkgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2coZGF0YSk7XG4gICAgICAgICAgICBpZihzd2FuLmhpZGVMb2FkaW5nKSB7XG4gICAgICAgICAgICAgICAgc3dhbi5oaWRlTG9hZGluZygpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZihkYXRhLmNvZGUgPT09ICdBMDAwMDAnKSB7XG4gICAgICAgICAgICAgICAgXy5qdW1wKG1lc3NhZ2VDb2RlSW5wdXRVcmwpXG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGlmKGRhdGEuY29kZSA9PT0gJ1AwMDIyMycpIHtcbiAgICAgICAgICAgICAgICAgICAgc3dhbi5zaG93VG9hc3Qoe1xuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IGDotKblj7flrZjlnKjlronlhajpo47pmanvvIzor7flsL3lv6vpgIDnmbvlhbbku5borr7lpIfmiJbnq4vljbPkv67mlLnlr4bnoIFgLFxuICAgICAgICAgICAgICAgICAgICAgICAgaWNvbjogJ25vbmUnXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHN3YW4uc2hvd1RvYXN0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBgJHtkYXRhLm1zZ31gLFxuICAgICAgICAgICAgICAgICAgICAgICAgaWNvbjogJ25vbmUnXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy/mlLnlj5jmjInpkq7nirbmgIFcbiAgICAgICAgICAgIHRoaXMuZGF0YS5sb2dpbl9kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgICAgICAgdGhpcy5zZXREYXRhKHsgbG9naW5fZGlzYWJsZWQ6IHRoaXMuZGF0YS5sb2dpbl9kaXNhYmxlZCB9KVxuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5nZXRNZXNzYWdlLnJlcXVlc3RpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgIH0sIDApXG4gICAgICAgIH0sIChlcnJvcikgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgICAgICAgICB0aGlzLmdldE1lc3NhZ2UucmVxdWVzdGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgc3dhbi5zaG93VG9hc3Qoe1xuICAgICAgICAgICAgICAgIHRpdGxlOiBgJHtlcnJvci5tc2d9YCxcbiAgICAgICAgICAgICAgICBpY29uOiAnbm9uZSdcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgLy/mlLnlj5jmjInpkq7nirbmgIFcbiAgICAgICAgICAgIHRoaXMuZGF0YS5sb2dpbl9kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgICAgICAgdGhpcy5zZXREYXRhKHsgbG9naW5fZGlzYWJsZWQ6IHRoaXMuZGF0YS5sb2dpbl9kaXNhYmxlZCB9KVxuICAgICAgICB9KVxuICAgIH1cblxuXG59XG5cblxuUGFnZShPYmplY3QuYXNzaWduKHt9LCBwYWdlKSlcblxuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC9Vc2Vycy9ob3ViaW5nYmluZy9jb2RlL2lxaXlpL3FsaXZlX21pbmlwcm9ncmFtL2JhaWR1L3BhZ2VzL2xvZ2luL2xvZ2luLmpzIl0sInNvdXJjZVJvb3QiOiIifQ==