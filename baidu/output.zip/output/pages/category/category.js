window.define('95', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _index = __webpack_require__(96);

var _index2 = _interopRequireDefault(_index);

var _user = __webpack_require__(29);

var _user2 = _interopRequireDefault(_user);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

var _switchCateAction = __webpack_require__(97);

var _switchCateAction2 = _interopRequireDefault(_switchCateAction);

var _promise = __webpack_require__(30);

var _promise2 = _interopRequireDefault(_promise);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var app = getApp(); // global object
var page = {
    data: {
        list: [],
        hotSubList: [], // hot 前几个热门分类
        categoryList: [], // 所有:一二级总分类 
        currentPage: 0,
        currOption: {
            liveTypeId: 4,
            liveChannelName: '游戏直播',
            liveSubTypeId: 0
        },
        openCateStatus: 0, // 打开分类按钮 0 :未打开; 1: 打开
        changeSearchStatus: false, // 是否改变了分类查询条件 确定是否从第一页加载
        pullDownRefreshStatus: false // 下拉刷新状态 false :非下拉刷新  true : 是下拉刷新
    },
    _getGlobalSelectCate: function _getGlobalSelectCate() {
        var _this = this;

        // :: 小程序直接到当前页面时,可能会有 categoryList 未获取到,需要二次获取 防止延迟导致的数据不显示
        var categoryList = app.globalData.categoryList;
        // console.log(new Date().getTime());
        if (categoryList && categoryList.length > 0) {
            return new _promise2.default(function (resolve, reject) {
                console.log(categoryList.length + " \u6761\u5206\u7C7B\u6570\u636E");
                _this.setData({ 'categoryList': categoryList }, function () {
                    resolve('success');
                });
            });
        } else {
            return new _promise2.default(function (resolve, reject) {
                app._getCategory(false, function (categoryList) {
                    console.log(categoryList.length + " \u6761\u5206\u7C7B\u6570\u636E  \u4E8C\u6B21\u8BF7\u6C42");
                    _this.setData({ 'categoryList': categoryList }, function () {
                        resolve('success');
                    });
                });
            });
        }
    },
    _setQuery: function _setQuery() {
        // 获取最新参数
        this.setData({
            'query': app.globalData.tabCategory
        });
    },

    // onPullDownRefresh() {
    //     this.data.pullDownRefreshStatus = true;
    //     this.onShow();
    // },
    onShow: function onShow() {
        // console.log('onShow==');
        // setTimeout(() => {
        //     // 筛选当前全局 cate 的 type
        //     this._getGlobalSelectCate();
        //     let globCateOption = app.globalData.tabCategory;
        //     let currOption = this.data.currOption;
        //     if(currOption.liveTypeId !== globCateOption.liveTypeId || currOption.liveSubTypeId !== globCateOption.liveSubTypeId || this.data.pullDownRefreshStatus) {
        //         this.data.pullDownRefreshStatus = false; // 恢复下拉刷新的状态为 false
        //         this.data.changeSearchStatus = true;
        //         this.data.currentPage = 0;
        //         this.loadPage();
        //     }
        // }, 1000);
        if (this.switchCateComponents && this.switchCateComponents.initStatus) {
            // 组件初始化后 执行
            this.switchSubCateHandle();
        }
    },
    myCatchTouch: function myCatchTouch(e) {
        if (this.data.openCateStatus === 1) {
            return false;
        }
    },
    _setScrollTop: function _setScrollTop() {
        swan.pageScrollTo({
            scrollTop: 0,
            duration: 300
        });
    },
    onReady: function onReady() {},
    onHide: function onHide() {},
    onTabItemTap: function onTabItemTap(item) {
        console.log('onTabItemTap:\t', item);
    },
    onLoad: function onLoad() {
        _util2.default.seo();
        this.switchCateComponents = new _switchCateAction2.default(this);
        // setTimeout(() => {
        //     this.switchCateComponents = new switchCateControl(this);
        // }, 200)
    },
    loadPage: function loadPage() {
        var _this2 = this;

        var isLogin = _user2.default.isLogin();
        _index2.default.getIndexData(this, isLogin);
        this.loadPage = function () {
            swan.showLoading({ title: "\u52A0\u8F7D\u4E2D..", mask: true });
            var isLogin = _user2.default.isLogin();
            _index2.default.getIndexData(_this2, isLogin);
        };
    },
    _loadedPage: function _loadedPage(data) {
        this.updateCateOption();
        this.data.changeSearchStatus = false;
        swan.hideLoading();
        // console.log('_loadedPage:\t', data.list[0]);
    },
    updateCateOption: function updateCateOption() {
        var cateOption = {
            liveTypeId: app.globalData.tabCategory.liveTypeId,
            liveChannelName: app.globalData.tabCategory.liveChannelName,
            liveSubTypeId: app.globalData.tabCategory.liveSubTypeId
        };
        this.setData({
            currOption: cateOption
        });
    },
    bindscrolltolower: function bindscrolltolower() {
        console.log('bindscrolltolower');
        var isLogin = _user2.default.isLogin();
        _index2.default.getIndexData(this, isLogin);
    },
    onReachBottom: function onReachBottom() {
        // console.log('onReachBottom');
        var isLogin = _user2.default.isLogin();
        if (this.data.openCateStatus === 1) {
            return false;
        } else {
            _index2.default.getIndexData(this, isLogin);
        }
    },
    openCateHandle: function openCateHandle(status) {
        var _openCateStatus = this.getData('openCateStatus');
        this.setData('openCateStatus', Object.prototype.toString.call(status) === '[object Number]' ? status : _openCateStatus === 1 ? 0 : 1);
    },
    playVideo: function playVideo(event) {
        var target = event.currentTarget;
        var roomId = target.dataset.roomId;
        if (!roomId) {
            return false;
        }
        var url = "pages/w/room?roomId=" + roomId;
        _util2.default.jump(url);
    }
};

Page(Object.assign({}, page));
});
window.__swanRoute='pages/category/category';window.usingComponents=[];require('95');

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvY2F0ZWdvcnkvY2F0ZWdvcnkuanMiXSwibmFtZXMiOlsiYXBwIiwiZ2V0QXBwIiwicGFnZSIsImRhdGEiLCJsaXN0IiwiaG90U3ViTGlzdCIsImNhdGVnb3J5TGlzdCIsImN1cnJlbnRQYWdlIiwiY3Vyck9wdGlvbiIsImxpdmVUeXBlSWQiLCJsaXZlQ2hhbm5lbE5hbWUiLCJsaXZlU3ViVHlwZUlkIiwib3BlbkNhdGVTdGF0dXMiLCJjaGFuZ2VTZWFyY2hTdGF0dXMiLCJwdWxsRG93blJlZnJlc2hTdGF0dXMiLCJfZ2V0R2xvYmFsU2VsZWN0Q2F0ZSIsImdsb2JhbERhdGEiLCJsZW5ndGgiLCJQcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsImNvbnNvbGUiLCJsb2ciLCJzZXREYXRhIiwiX2dldENhdGVnb3J5IiwiX3NldFF1ZXJ5IiwidGFiQ2F0ZWdvcnkiLCJvblNob3ciLCJzd2l0Y2hDYXRlQ29tcG9uZW50cyIsImluaXRTdGF0dXMiLCJzd2l0Y2hTdWJDYXRlSGFuZGxlIiwibXlDYXRjaFRvdWNoIiwiZSIsIl9zZXRTY3JvbGxUb3AiLCJzd2FuIiwicGFnZVNjcm9sbFRvIiwic2Nyb2xsVG9wIiwiZHVyYXRpb24iLCJvblJlYWR5Iiwib25IaWRlIiwib25UYWJJdGVtVGFwIiwiaXRlbSIsIm9uTG9hZCIsIl8iLCJzZW8iLCJzd2l0Y2hDYXRlQ29udHJvbCIsImxvYWRQYWdlIiwiaXNMb2dpbiIsInVzZXIiLCJhY3Rpb25zIiwiZ2V0SW5kZXhEYXRhIiwic2hvd0xvYWRpbmciLCJ0aXRsZSIsIm1hc2siLCJfbG9hZGVkUGFnZSIsInVwZGF0ZUNhdGVPcHRpb24iLCJoaWRlTG9hZGluZyIsImNhdGVPcHRpb24iLCJiaW5kc2Nyb2xsdG9sb3dlciIsIm9uUmVhY2hCb3R0b20iLCJvcGVuQ2F0ZUhhbmRsZSIsInN0YXR1cyIsIl9vcGVuQ2F0ZVN0YXR1cyIsImdldERhdGEiLCJPYmplY3QiLCJwcm90b3R5cGUiLCJ0b1N0cmluZyIsImNhbGwiLCJwbGF5VmlkZW8iLCJldmVudCIsInRhcmdldCIsImN1cnJlbnRUYXJnZXQiLCJyb29tSWQiLCJkYXRhc2V0IiwidXJsIiwianVtcCIsIlBhZ2UiLCJhc3NpZ24iXSwibWFwcGluZ3MiOiI7OztBQUFBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7OztBQUVBLElBQU1BLE1BQU1DLFFBQVosQyxDQUFzQjtBQUN0QixJQUFNQyxPQUFPO0FBQ1RDLFVBQU07QUFDRkMsY0FBTSxFQURKO0FBRUZDLG9CQUFZLEVBRlYsRUFFYTtBQUNmQyxzQkFBYyxFQUhaLEVBR2dCO0FBQ2xCQyxxQkFBYSxDQUpYO0FBS0ZDLG9CQUFZO0FBQ1JDLHdCQUFZLENBREo7QUFFUkMsNkJBQWlCLE1BRlQ7QUFHUkMsMkJBQWU7QUFIUCxTQUxWO0FBVUZDLHdCQUFnQixDQVZkLEVBVWlCO0FBQ25CQyw0QkFBb0IsS0FYbEIsRUFXeUI7QUFDM0JDLCtCQUF1QixLQVpyQixDQVkyQjtBQVozQixLQURHO0FBZVRDLHdCQWZTLGtDQWVjO0FBQUE7O0FBQ25CO0FBQ0EsWUFBSVQsZUFBZU4sSUFBSWdCLFVBQUosQ0FBZVYsWUFBbEM7QUFDQTtBQUNBLFlBQUdBLGdCQUFnQkEsYUFBYVcsTUFBYixHQUFzQixDQUF6QyxFQUE0QztBQUN4QyxtQkFBTyxJQUFJQyxpQkFBSixDQUFZLFVBQUNDLE9BQUQsRUFBVUMsTUFBVixFQUFxQjtBQUNwQ0Msd0JBQVFDLEdBQVIsQ0FBZWhCLGFBQWFXLE1BQTVCO0FBQ0Esc0JBQUtNLE9BQUwsQ0FBYSxFQUFFLGdCQUFnQmpCLFlBQWxCLEVBQWIsRUFBK0MsWUFBTTtBQUNqRGEsNEJBQVEsU0FBUjtBQUNILGlCQUZEO0FBR0gsYUFMTSxDQUFQO0FBTUgsU0FQRCxNQU9PO0FBQ0gsbUJBQU8sSUFBSUQsaUJBQUosQ0FBWSxVQUFDQyxPQUFELEVBQVVDLE1BQVYsRUFBcUI7QUFDcENwQixvQkFBSXdCLFlBQUosQ0FBaUIsS0FBakIsRUFBd0IsVUFBQ2xCLFlBQUQsRUFBa0I7QUFDdENlLDRCQUFRQyxHQUFSLENBQWVoQixhQUFhVyxNQUE1QjtBQUNBLDBCQUFLTSxPQUFMLENBQWEsRUFBRSxnQkFBZ0JqQixZQUFsQixFQUFiLEVBQStDLFlBQU07QUFDakRhLGdDQUFRLFNBQVI7QUFDSCxxQkFGRDtBQUdILGlCQUxEO0FBTUgsYUFQTSxDQUFQO0FBUUg7QUFDSixLQXBDUTtBQXFDVE0sYUFyQ1MsdUJBcUNHO0FBQ1I7QUFDQSxhQUFLRixPQUFMLENBQWE7QUFDVCxxQkFBU3ZCLElBQUlnQixVQUFKLENBQWVVO0FBRGYsU0FBYjtBQUdILEtBMUNROztBQTJDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBQyxVQS9DUyxvQkErQ0E7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQUcsS0FBS0Msb0JBQUwsSUFBNkIsS0FBS0Esb0JBQUwsQ0FBMEJDLFVBQTFELEVBQXNFO0FBQ2xFO0FBQ0EsaUJBQUtDLG1CQUFMO0FBQ0g7QUFDSixLQWpFUTtBQWtFVEMsZ0JBbEVTLHdCQWtFSUMsQ0FsRUosRUFrRU87QUFDWixZQUFHLEtBQUs3QixJQUFMLENBQVVTLGNBQVYsS0FBNkIsQ0FBaEMsRUFBbUM7QUFDL0IsbUJBQU8sS0FBUDtBQUNIO0FBQ0osS0F0RVE7QUF1RVRxQixpQkF2RVMsMkJBdUVPO0FBQ1pDLGFBQUtDLFlBQUwsQ0FBa0I7QUFDZEMsdUJBQVcsQ0FERztBQUVkQyxzQkFBVTtBQUZJLFNBQWxCO0FBSUgsS0E1RVE7QUE2RVRDLFdBN0VTLHFCQTZFQyxDQUNULENBOUVRO0FBK0VUQyxVQS9FUyxvQkErRUEsQ0FDUixDQWhGUTtBQWlGVEMsZ0JBakZTLHdCQWlGSUMsSUFqRkosRUFpRlU7QUFDZnBCLGdCQUFRQyxHQUFSLENBQVksaUJBQVosRUFBK0JtQixJQUEvQjtBQUNILEtBbkZRO0FBb0ZUQyxVQXBGUyxvQkFvRkE7QUFDTEMsdUJBQUVDLEdBQUY7QUFDQSxhQUFLaEIsb0JBQUwsR0FBNEIsSUFBSWlCLDBCQUFKLENBQXNCLElBQXRCLENBQTVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0gsS0ExRlE7QUEyRlRDLFlBM0ZTLHNCQTJGRTtBQUFBOztBQUNQLFlBQUlDLFVBQVVDLGVBQUtELE9BQUwsRUFBZDtBQUNBRSx3QkFBUUMsWUFBUixDQUFxQixJQUFyQixFQUEyQkgsT0FBM0I7QUFDQSxhQUFLRCxRQUFMLEdBQWdCLFlBQU07QUFDbEJaLGlCQUFLaUIsV0FBTCxDQUFpQixFQUFFQyw2QkFBRixFQUFrQkMsTUFBTSxJQUF4QixFQUFqQjtBQUNBLGdCQUFJTixVQUFVQyxlQUFLRCxPQUFMLEVBQWQ7QUFDQUUsNEJBQVFDLFlBQVIsQ0FBcUIsTUFBckIsRUFBMkJILE9BQTNCO0FBQ0gsU0FKRDtBQUtILEtBbkdRO0FBb0dUTyxlQXBHUyx1QkFvR0duRCxJQXBHSCxFQW9HUztBQUNkLGFBQUtvRCxnQkFBTDtBQUNBLGFBQUtwRCxJQUFMLENBQVVVLGtCQUFWLEdBQStCLEtBQS9CO0FBQ0FxQixhQUFLc0IsV0FBTDtBQUNBO0FBQ0gsS0F6R1E7QUEwR1RELG9CQTFHUyw4QkEwR1U7QUFDZixZQUFJRSxhQUFhO0FBQ2JoRCx3QkFBWVQsSUFBSWdCLFVBQUosQ0FBZVUsV0FBZixDQUEyQmpCLFVBRDFCO0FBRWJDLDZCQUFpQlYsSUFBSWdCLFVBQUosQ0FBZVUsV0FBZixDQUEyQmhCLGVBRi9CO0FBR2JDLDJCQUFlWCxJQUFJZ0IsVUFBSixDQUFlVSxXQUFmLENBQTJCZjtBQUg3QixTQUFqQjtBQUtBLGFBQUtZLE9BQUwsQ0FBYTtBQUNUZix3QkFBWWlEO0FBREgsU0FBYjtBQUdILEtBbkhRO0FBb0hUQyxxQkFwSFMsK0JBb0hXO0FBQ2hCckMsZ0JBQVFDLEdBQVIsQ0FBWSxtQkFBWjtBQUNBLFlBQUl5QixVQUFVQyxlQUFLRCxPQUFMLEVBQWQ7QUFDQUUsd0JBQVFDLFlBQVIsQ0FBcUIsSUFBckIsRUFBMkJILE9BQTNCO0FBQ0gsS0F4SFE7QUF5SFRZLGlCQXpIUywyQkF5SE87QUFDWjtBQUNBLFlBQUlaLFVBQVVDLGVBQUtELE9BQUwsRUFBZDtBQUNBLFlBQUcsS0FBSzVDLElBQUwsQ0FBVVMsY0FBVixLQUE2QixDQUFoQyxFQUFtQztBQUMvQixtQkFBTyxLQUFQO0FBQ0gsU0FGRCxNQUVPO0FBQ0hxQyw0QkFBUUMsWUFBUixDQUFxQixJQUFyQixFQUEyQkgsT0FBM0I7QUFDSDtBQUNKLEtBaklRO0FBa0lUYSxrQkFsSVMsMEJBa0lNQyxNQWxJTixFQWtJYztBQUNuQixZQUFJQyxrQkFBa0IsS0FBS0MsT0FBTCxDQUFhLGdCQUFiLENBQXRCO0FBQ0EsYUFBS3hDLE9BQUwsQ0FBYSxnQkFBYixFQUErQnlDLE9BQU9DLFNBQVAsQ0FBaUJDLFFBQWpCLENBQTBCQyxJQUExQixDQUErQk4sTUFBL0IsTUFBMkMsaUJBQTNDLEdBQStEQSxNQUEvRCxHQUF5RUMsb0JBQW9CLENBQXBCLEdBQXdCLENBQXhCLEdBQTRCLENBQXBJO0FBQ0gsS0FySVE7QUFzSVRNLGFBdElTLHFCQXNJQ0MsS0F0SUQsRUFzSVE7QUFDYixZQUFNQyxTQUFTRCxNQUFNRSxhQUFyQjtBQUNBLFlBQU1DLFNBQVNGLE9BQU9HLE9BQVAsQ0FBZUQsTUFBOUI7QUFDQSxZQUFHLENBQUNBLE1BQUosRUFBWTtBQUNSLG1CQUFPLEtBQVA7QUFDSDtBQUNELFlBQUlFLCtCQUE2QkYsTUFBakM7QUFDQTdCLHVCQUFFZ0MsSUFBRixDQUFPRCxHQUFQO0FBQ0g7QUE5SVEsQ0FBYjs7QUFpSkFFLEtBQUtaLE9BQU9hLE1BQVAsQ0FBYyxFQUFkLEVBQWtCM0UsSUFBbEIsQ0FBTCxFIiwiZmlsZSI6InBhZ2VzL2NhdGVnb3J5L2NhdGVnb3J5LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGFjdGlvbnMgZnJvbSBcIi4vYWN0aW9ucy9pbmRleFwiO1xuaW1wb3J0IHVzZXIgZnJvbSBcIi4uLy4uL2NvbW1vbi91c2VyL3VzZXJcIjtcbmltcG9ydCBfIGZyb20gXCIuLi8uLi9jb21tb24vdXRpbHMvdXRpbFwiO1xuaW1wb3J0IHN3aXRjaENhdGVDb250cm9sIGZyb20gXCIuL2FjdGlvbnMvc3dpdGNoQ2F0ZUFjdGlvblwiXG5pbXBvcnQgUHJvbWlzZSBmcm9tIFwiLi4vLi4vY29tbW9uL3BvbHlmaWxsL3Byb21pc2VcIjtcblxuY29uc3QgYXBwID0gZ2V0QXBwKCk7IC8vIGdsb2JhbCBvYmplY3RcbmNvbnN0IHBhZ2UgPSB7XG4gICAgZGF0YToge1xuICAgICAgICBsaXN0OiBbXSxcbiAgICAgICAgaG90U3ViTGlzdDogW10sLy8gaG90IOWJjeWHoOS4queDremXqOWIhuexu1xuICAgICAgICBjYXRlZ29yeUxpc3Q6IFtdLCAvLyDmiYDmnIk65LiA5LqM57qn5oC75YiG57G7IFxuICAgICAgICBjdXJyZW50UGFnZTogMCxcbiAgICAgICAgY3Vyck9wdGlvbjoge1xuICAgICAgICAgICAgbGl2ZVR5cGVJZDogNCxcbiAgICAgICAgICAgIGxpdmVDaGFubmVsTmFtZTogJ+a4uOaIj+ebtOaSrScsXG4gICAgICAgICAgICBsaXZlU3ViVHlwZUlkOiAwXG4gICAgICAgIH0sXG4gICAgICAgIG9wZW5DYXRlU3RhdHVzOiAwLCAvLyDmiZPlvIDliIbnsbvmjInpkq4gMCA65pyq5omT5byAOyAxOiDmiZPlvIBcbiAgICAgICAgY2hhbmdlU2VhcmNoU3RhdHVzOiBmYWxzZSwgLy8g5piv5ZCm5pS55Y+Y5LqG5YiG57G75p+l6K+i5p2h5Lu2IOehruWumuaYr+WQpuS7juesrOS4gOmhteWKoOi9vVxuICAgICAgICBwdWxsRG93blJlZnJlc2hTdGF0dXM6IGZhbHNlIC8vIOS4i+aLieWIt+aWsOeKtuaAgSBmYWxzZSA66Z2e5LiL5ouJ5Yi35pawICB0cnVlIDog5piv5LiL5ouJ5Yi35pawXG4gICAgfSxcbiAgICBfZ2V0R2xvYmFsU2VsZWN0Q2F0ZSgpIHtcbiAgICAgICAgLy8gOjog5bCP56iL5bqP55u05o6l5Yiw5b2T5YmN6aG16Z2i5pe2LOWPr+iDveS8muaciSBjYXRlZ29yeUxpc3Qg5pyq6I635Y+W5YiwLOmcgOimgeS6jOasoeiOt+WPliDpmLLmraLlu7bov5/lr7zoh7TnmoTmlbDmja7kuI3mmL7npLpcbiAgICAgICAgbGV0IGNhdGVnb3J5TGlzdCA9IGFwcC5nbG9iYWxEYXRhLmNhdGVnb3J5TGlzdDtcbiAgICAgICAgLy8gY29uc29sZS5sb2cobmV3IERhdGUoKS5nZXRUaW1lKCkpO1xuICAgICAgICBpZihjYXRlZ29yeUxpc3QgJiYgY2F0ZWdvcnlMaXN0Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coYCR7Y2F0ZWdvcnlMaXN0Lmxlbmd0aH0g5p2h5YiG57G75pWw5o2uYCk7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKHsgJ2NhdGVnb3J5TGlzdCc6IGNhdGVnb3J5TGlzdCB9LCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHJlc29sdmUoJ3N1Y2Nlc3MnKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgICAgICAgIGFwcC5fZ2V0Q2F0ZWdvcnkoZmFsc2UsIChjYXRlZ29yeUxpc3QpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coYCR7Y2F0ZWdvcnlMaXN0Lmxlbmd0aH0g5p2h5YiG57G75pWw5o2uICDkuozmrKHor7fmsYJgKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKHsgJ2NhdGVnb3J5TGlzdCc6IGNhdGVnb3J5TGlzdCB9LCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKCdzdWNjZXNzJyk7XG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICB9LFxuICAgIF9zZXRRdWVyeSgpIHtcbiAgICAgICAgLy8g6I635Y+W5pyA5paw5Y+C5pWwXG4gICAgICAgIHRoaXMuc2V0RGF0YSh7XG4gICAgICAgICAgICAncXVlcnknOiBhcHAuZ2xvYmFsRGF0YS50YWJDYXRlZ29yeVxuICAgICAgICB9KTtcbiAgICB9LFxuICAgIC8vIG9uUHVsbERvd25SZWZyZXNoKCkge1xuICAgIC8vICAgICB0aGlzLmRhdGEucHVsbERvd25SZWZyZXNoU3RhdHVzID0gdHJ1ZTtcbiAgICAvLyAgICAgdGhpcy5vblNob3coKTtcbiAgICAvLyB9LFxuICAgIG9uU2hvdygpIHtcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29uU2hvdz09Jyk7XG4gICAgICAgIC8vIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAvLyAgICAgLy8g562b6YCJ5b2T5YmN5YWo5bGAIGNhdGUg55qEIHR5cGVcbiAgICAgICAgLy8gICAgIHRoaXMuX2dldEdsb2JhbFNlbGVjdENhdGUoKTtcbiAgICAgICAgLy8gICAgIGxldCBnbG9iQ2F0ZU9wdGlvbiA9IGFwcC5nbG9iYWxEYXRhLnRhYkNhdGVnb3J5O1xuICAgICAgICAvLyAgICAgbGV0IGN1cnJPcHRpb24gPSB0aGlzLmRhdGEuY3Vyck9wdGlvbjtcbiAgICAgICAgLy8gICAgIGlmKGN1cnJPcHRpb24ubGl2ZVR5cGVJZCAhPT0gZ2xvYkNhdGVPcHRpb24ubGl2ZVR5cGVJZCB8fCBjdXJyT3B0aW9uLmxpdmVTdWJUeXBlSWQgIT09IGdsb2JDYXRlT3B0aW9uLmxpdmVTdWJUeXBlSWQgfHwgdGhpcy5kYXRhLnB1bGxEb3duUmVmcmVzaFN0YXR1cykge1xuICAgICAgICAvLyAgICAgICAgIHRoaXMuZGF0YS5wdWxsRG93blJlZnJlc2hTdGF0dXMgPSBmYWxzZTsgLy8g5oGi5aSN5LiL5ouJ5Yi35paw55qE54q25oCB5Li6IGZhbHNlXG4gICAgICAgIC8vICAgICAgICAgdGhpcy5kYXRhLmNoYW5nZVNlYXJjaFN0YXR1cyA9IHRydWU7XG4gICAgICAgIC8vICAgICAgICAgdGhpcy5kYXRhLmN1cnJlbnRQYWdlID0gMDtcbiAgICAgICAgLy8gICAgICAgICB0aGlzLmxvYWRQYWdlKCk7XG4gICAgICAgIC8vICAgICB9XG4gICAgICAgIC8vIH0sIDEwMDApO1xuICAgICAgICBpZih0aGlzLnN3aXRjaENhdGVDb21wb25lbnRzICYmIHRoaXMuc3dpdGNoQ2F0ZUNvbXBvbmVudHMuaW5pdFN0YXR1cykge1xuICAgICAgICAgICAgLy8g57uE5Lu25Yid5aeL5YyW5ZCOIOaJp+ihjFxuICAgICAgICAgICAgdGhpcy5zd2l0Y2hTdWJDYXRlSGFuZGxlKCk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIG15Q2F0Y2hUb3VjaChlKSB7XG4gICAgICAgIGlmKHRoaXMuZGF0YS5vcGVuQ2F0ZVN0YXR1cyA9PT0gMSkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgfSxcbiAgICBfc2V0U2Nyb2xsVG9wKCkge1xuICAgICAgICBzd2FuLnBhZ2VTY3JvbGxUbyh7XG4gICAgICAgICAgICBzY3JvbGxUb3A6IDAsXG4gICAgICAgICAgICBkdXJhdGlvbjogMzAwXG4gICAgICAgIH0pO1xuICAgIH0sXG4gICAgb25SZWFkeSgpIHtcbiAgICB9LFxuICAgIG9uSGlkZSgpIHtcbiAgICB9LFxuICAgIG9uVGFiSXRlbVRhcChpdGVtKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdvblRhYkl0ZW1UYXA6XFx0JywgaXRlbSk7XG4gICAgfSxcbiAgICBvbkxvYWQoKSB7XG4gICAgICAgIF8uc2VvKCk7XG4gICAgICAgIHRoaXMuc3dpdGNoQ2F0ZUNvbXBvbmVudHMgPSBuZXcgc3dpdGNoQ2F0ZUNvbnRyb2wodGhpcyk7XG4gICAgICAgIC8vIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAvLyAgICAgdGhpcy5zd2l0Y2hDYXRlQ29tcG9uZW50cyA9IG5ldyBzd2l0Y2hDYXRlQ29udHJvbCh0aGlzKTtcbiAgICAgICAgLy8gfSwgMjAwKVxuICAgIH0sXG4gICAgbG9hZFBhZ2UoKSB7XG4gICAgICAgIGxldCBpc0xvZ2luID0gdXNlci5pc0xvZ2luKCk7XG4gICAgICAgIGFjdGlvbnMuZ2V0SW5kZXhEYXRhKHRoaXMsIGlzTG9naW4pO1xuICAgICAgICB0aGlzLmxvYWRQYWdlID0gKCkgPT4ge1xuICAgICAgICAgICAgc3dhbi5zaG93TG9hZGluZyh7IHRpdGxlOiBg5Yqg6L295LitLi5gLCBtYXNrOiB0cnVlIH0pO1xuICAgICAgICAgICAgbGV0IGlzTG9naW4gPSB1c2VyLmlzTG9naW4oKTtcbiAgICAgICAgICAgIGFjdGlvbnMuZ2V0SW5kZXhEYXRhKHRoaXMsIGlzTG9naW4pO1xuICAgICAgICB9XG4gICAgfSxcbiAgICBfbG9hZGVkUGFnZShkYXRhKSB7XG4gICAgICAgIHRoaXMudXBkYXRlQ2F0ZU9wdGlvbigpO1xuICAgICAgICB0aGlzLmRhdGEuY2hhbmdlU2VhcmNoU3RhdHVzID0gZmFsc2U7XG4gICAgICAgIHN3YW4uaGlkZUxvYWRpbmcoKTtcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ19sb2FkZWRQYWdlOlxcdCcsIGRhdGEubGlzdFswXSk7XG4gICAgfSxcbiAgICB1cGRhdGVDYXRlT3B0aW9uKCkge1xuICAgICAgICBsZXQgY2F0ZU9wdGlvbiA9IHtcbiAgICAgICAgICAgIGxpdmVUeXBlSWQ6IGFwcC5nbG9iYWxEYXRhLnRhYkNhdGVnb3J5LmxpdmVUeXBlSWQsXG4gICAgICAgICAgICBsaXZlQ2hhbm5lbE5hbWU6IGFwcC5nbG9iYWxEYXRhLnRhYkNhdGVnb3J5LmxpdmVDaGFubmVsTmFtZSxcbiAgICAgICAgICAgIGxpdmVTdWJUeXBlSWQ6IGFwcC5nbG9iYWxEYXRhLnRhYkNhdGVnb3J5LmxpdmVTdWJUeXBlSWRcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5zZXREYXRhKHtcbiAgICAgICAgICAgIGN1cnJPcHRpb246IGNhdGVPcHRpb25cbiAgICAgICAgfSk7XG4gICAgfSxcbiAgICBiaW5kc2Nyb2xsdG9sb3dlcigpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ2JpbmRzY3JvbGx0b2xvd2VyJyk7XG4gICAgICAgIGxldCBpc0xvZ2luID0gdXNlci5pc0xvZ2luKCk7XG4gICAgICAgIGFjdGlvbnMuZ2V0SW5kZXhEYXRhKHRoaXMsIGlzTG9naW4pO1xuICAgIH0sXG4gICAgb25SZWFjaEJvdHRvbSgpIHtcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29uUmVhY2hCb3R0b20nKTtcbiAgICAgICAgbGV0IGlzTG9naW4gPSB1c2VyLmlzTG9naW4oKTtcbiAgICAgICAgaWYodGhpcy5kYXRhLm9wZW5DYXRlU3RhdHVzID09PSAxKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBhY3Rpb25zLmdldEluZGV4RGF0YSh0aGlzLCBpc0xvZ2luKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgb3BlbkNhdGVIYW5kbGUoc3RhdHVzKSB7XG4gICAgICAgIGxldCBfb3BlbkNhdGVTdGF0dXMgPSB0aGlzLmdldERhdGEoJ29wZW5DYXRlU3RhdHVzJyk7XG4gICAgICAgIHRoaXMuc2V0RGF0YSgnb3BlbkNhdGVTdGF0dXMnLCBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwoc3RhdHVzKSA9PT0gJ1tvYmplY3QgTnVtYmVyXScgPyBzdGF0dXMgOiAoX29wZW5DYXRlU3RhdHVzID09PSAxID8gMCA6IDEpKTtcbiAgICB9LFxuICAgIHBsYXlWaWRlbyhldmVudCkge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgICAgICBjb25zdCByb29tSWQgPSB0YXJnZXQuZGF0YXNldC5yb29tSWQ7XG4gICAgICAgIGlmKCFyb29tSWQpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgdXJsID0gYHBhZ2VzL3cvcm9vbT9yb29tSWQ9JHtyb29tSWR9YDtcbiAgICAgICAgXy5qdW1wKHVybCk7XG4gICAgfVxufVxuXG5QYWdlKE9iamVjdC5hc3NpZ24oe30sIHBhZ2UpKVxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAvVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9wYWdlcy9jYXRlZ29yeS9jYXRlZ29yeS5qcyJdLCJzb3VyY2VSb290IjoiIn0=