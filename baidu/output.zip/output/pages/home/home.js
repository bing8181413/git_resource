window.define('77', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _user = __webpack_require__(29);

var _user2 = _interopRequireDefault(_user);

var _index = __webpack_require__(93);

var _index2 = _interopRequireDefault(_index);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var app = getApp(); // import searchLayout from "../../components/searchLayout/searchLayout";

var page = {
    data: {
        load: 'none',
        bannerIndex: 1,
        selectedLiveSubtypeId: 0,
        // banner: [],
        channels_a_other: {},
        channels_a_roomList: [],
        channels_b_roomList: []
        // channels: []
    },
    onPullDownRefresh: function onPullDownRefresh() {
        // 下拉刷新
        this.onLoad();
    },
    onShow: function onShow() {
        // let _channels = this.getData('channels');
        // if (!_channels) {
        //     this.onLoad();
        // }
        // console.log('onShow...');
    },
    onReady: function onReady() {
        // swan.showToast({ title: 'onReady ! ' });
        // console.log('onReady...');
    },
    onLoad: function onLoad() {
        // console.error(JSON.stringify(this.data));
        // user.init();
        this.loadPage();
        // console.log('onLoad...');
    },
    loadPage: function loadPage() {
        var _this = this;

        setTimeout(function () {
            var isLogin = _user2.default.isLogin();
            _index2.default.getIndexData(isLogin, _this);
            _this.loadPage = function () {
                var isLogin = _user2.default.isLogin();
                _index2.default.getIndexData(isLogin, _this);
            };
        }, 0);
    },
    _loadedPage: function _loadedPage(data) {
        // 渲染后回调
        swan.stopPullDownRefresh && swan.stopPullDownRefresh();
        swan.hideLoading();
        _util2.default.seo(); //默认 SEO
    },
    swiperChange: function swiperChange(event) {
        var banner = this.getData('banner')[event.detail.current];
        // console.log('banner', banner);
        // 点亮 swiper-dot
        this.setData({
            bannerIndex: event.detail.current + 1
        });
    },
    selectedBtnRoom: function selectedBtnRoom(event) {
        var target = event.currentTarget;
        // swan.showToast({ title: target.dataset.liveSubtypeName });
        this.setData('selectedLiveSubtypeId', target.dataset.liveSubtypeId);
    },
    redirectCateMore: function redirectCateMore(event) {
        var target = event.currentTarget;
        var obj = target.dataset.obj;
        // console.log(obj.liveChannelName, obj.channelType, obj.liveTypeId);
        app.globalData.tabCategory = {
            liveTypeId: obj.liveTypeId,
            liveChannelName: obj.liveChannelName,
            channelType: obj.channelType,
            liveSubTypeId: obj.liveSubTypeId || 0
        };
        // console.log(app.globalData.tabCategory);
        _util2.default.jump('/pages/category/category');
    },
    playVideo: function playVideo(event) {
        var target = event.currentTarget;
        var roomId = target.dataset.roomId;
        var liveType = target.dataset.liveType;
        // const obj = target.dataset.obj;
        // console.log(obj);
        // _.record({ ...obj, recordTime: new Date().getTime() });
        if (!roomId) {
            swan.showToast({
                icon: 'none',
                title: '数据异常'
            });
            return false;
        }
        var url = "pages/w/room?roomId=" + roomId;
        if (liveType == 2) {
            url = "pages/s/room?roomId=" + roomId;
        }
        _util2.default.jump(url);
    },
    updateVersion: function updateVersion() {
        // const updateManager = swan.getUpdateManager();
        // console.log(updateManager);
        // updateManager.onCheckForUpdate(function(res) {
        //     // 请求完新版本信息的回调
        //     console.log(res);
        //     console.log(res.hasUpdate);
        //     swan.showModal({ title: '更新提示', content: JSON.stringify(res) });
        // });
        // updateManager.onUpdateReady(function(res) {
        //     swan.showModal({
        //         title: '更新提示',
        //         content: '新版本已经准备好，是否重启应用？',
        //         success(res) {
        //             console.log(res);
        //             if (res.confirm) {
        //                 // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
        //                 updateManager.applyUpdate();
        //             }
        //         }
        //     });

        // });
        // updateManager.onUpdateFailed(function(res) {
        //     // 新的版本下载失败
        //     console.log(res);
        // });
    }
};

Page(Object.assign({}, page));
});
window.__swanRoute='pages/home/home';window.usingComponents=[];require('77');

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvaG9tZS9ob21lLmpzIl0sIm5hbWVzIjpbImFwcCIsImdldEFwcCIsInBhZ2UiLCJkYXRhIiwibG9hZCIsImJhbm5lckluZGV4Iiwic2VsZWN0ZWRMaXZlU3VidHlwZUlkIiwiY2hhbm5lbHNfYV9vdGhlciIsImNoYW5uZWxzX2Ffcm9vbUxpc3QiLCJjaGFubmVsc19iX3Jvb21MaXN0Iiwib25QdWxsRG93blJlZnJlc2giLCJvbkxvYWQiLCJvblNob3ciLCJvblJlYWR5IiwibG9hZFBhZ2UiLCJzZXRUaW1lb3V0IiwiaXNMb2dpbiIsInVzZXIiLCJhY3Rpb25zIiwiZ2V0SW5kZXhEYXRhIiwiX2xvYWRlZFBhZ2UiLCJzd2FuIiwic3RvcFB1bGxEb3duUmVmcmVzaCIsImhpZGVMb2FkaW5nIiwiXyIsInNlbyIsInN3aXBlckNoYW5nZSIsImV2ZW50IiwiYmFubmVyIiwiZ2V0RGF0YSIsImRldGFpbCIsImN1cnJlbnQiLCJzZXREYXRhIiwic2VsZWN0ZWRCdG5Sb29tIiwidGFyZ2V0IiwiY3VycmVudFRhcmdldCIsImRhdGFzZXQiLCJsaXZlU3VidHlwZUlkIiwicmVkaXJlY3RDYXRlTW9yZSIsIm9iaiIsImdsb2JhbERhdGEiLCJ0YWJDYXRlZ29yeSIsImxpdmVUeXBlSWQiLCJsaXZlQ2hhbm5lbE5hbWUiLCJjaGFubmVsVHlwZSIsImxpdmVTdWJUeXBlSWQiLCJqdW1wIiwicGxheVZpZGVvIiwicm9vbUlkIiwibGl2ZVR5cGUiLCJzaG93VG9hc3QiLCJpY29uIiwidGl0bGUiLCJ1cmwiLCJ1cGRhdGVWZXJzaW9uIiwiUGFnZSIsIk9iamVjdCIsImFzc2lnbiJdLCJtYXBwaW5ncyI6Ijs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7QUFFQSxJQUFNQSxNQUFNQyxRQUFaLEMsQ0FMQTs7QUFNQSxJQUFNQyxPQUFPO0FBQ1RDLFVBQU07QUFDRkMsY0FBTSxNQURKO0FBRUZDLHFCQUFhLENBRlg7QUFHRkMsK0JBQXVCLENBSHJCO0FBSUY7QUFDQUMsMEJBQWtCLEVBTGhCO0FBTUZDLDZCQUFxQixFQU5uQjtBQU9GQyw2QkFBcUI7QUFDckI7QUFSRSxLQURHO0FBV1RDLHFCQVhTLCtCQVdXO0FBQ2hCO0FBQ0EsYUFBS0MsTUFBTDtBQUNILEtBZFE7QUFlVEMsVUFmUyxvQkFlQTtBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSCxLQXJCUTtBQXNCVEMsV0F0QlMscUJBc0JDO0FBQ047QUFDQTtBQUNILEtBekJRO0FBMEJURixVQTFCUyxvQkEwQkE7QUFDTDtBQUNBO0FBQ0EsYUFBS0csUUFBTDtBQUNBO0FBQ0gsS0EvQlE7QUFnQ1RBLFlBaENTLHNCQWdDRTtBQUFBOztBQUNQQyxtQkFBVyxZQUFNO0FBQ2IsZ0JBQUlDLFVBQVVDLGVBQUtELE9BQUwsRUFBZDtBQUNBRSw0QkFBUUMsWUFBUixDQUFxQkgsT0FBckIsRUFBOEIsS0FBOUI7QUFDQSxrQkFBS0YsUUFBTCxHQUFnQixZQUFNO0FBQ2xCLG9CQUFJRSxVQUFVQyxlQUFLRCxPQUFMLEVBQWQ7QUFDQUUsZ0NBQVFDLFlBQVIsQ0FBcUJILE9BQXJCLEVBQThCLEtBQTlCO0FBQ0gsYUFIRDtBQUlILFNBUEQsRUFPRyxDQVBIO0FBUUgsS0F6Q1E7QUEwQ1RJLGVBMUNTLHVCQTBDR2pCLElBMUNILEVBMENTO0FBQ2Q7QUFDQWtCLGFBQUtDLG1CQUFMLElBQTRCRCxLQUFLQyxtQkFBTCxFQUE1QjtBQUNBRCxhQUFLRSxXQUFMO0FBQ0FDLHVCQUFFQyxHQUFGLEdBSmMsQ0FJTDtBQUNaLEtBL0NRO0FBZ0RUQyxnQkFoRFMsd0JBZ0RJQyxLQWhESixFQWdEVztBQUNoQixZQUFNQyxTQUFTLEtBQUtDLE9BQUwsQ0FBYSxRQUFiLEVBQXVCRixNQUFNRyxNQUFOLENBQWFDLE9BQXBDLENBQWY7QUFDQTtBQUNBO0FBQ0EsYUFBS0MsT0FBTCxDQUFhO0FBQ1QzQix5QkFBYXNCLE1BQU1HLE1BQU4sQ0FBYUMsT0FBYixHQUF1QjtBQUQzQixTQUFiO0FBR0gsS0F2RFE7QUF3RFRFLG1CQXhEUywyQkF3RE9OLEtBeERQLEVBd0RjO0FBQ25CLFlBQU1PLFNBQVNQLE1BQU1RLGFBQXJCO0FBQ0E7QUFDQSxhQUFLSCxPQUFMLENBQWEsdUJBQWIsRUFBc0NFLE9BQU9FLE9BQVAsQ0FBZUMsYUFBckQ7QUFDSCxLQTVEUTtBQTZEVEMsb0JBN0RTLDRCQTZEUVgsS0E3RFIsRUE2RGU7QUFDcEIsWUFBTU8sU0FBU1AsTUFBTVEsYUFBckI7QUFDQSxZQUFNSSxNQUFNTCxPQUFPRSxPQUFQLENBQWVHLEdBQTNCO0FBQ0E7QUFDQXZDLFlBQUl3QyxVQUFKLENBQWVDLFdBQWYsR0FBNkI7QUFDekJDLHdCQUFZSCxJQUFJRyxVQURTO0FBRXpCQyw2QkFBaUJKLElBQUlJLGVBRkk7QUFHekJDLHlCQUFhTCxJQUFJSyxXQUhRO0FBSXpCQywyQkFBZU4sSUFBSU0sYUFBSixJQUFxQjtBQUpYLFNBQTdCO0FBTUE7QUFDQXJCLHVCQUFFc0IsSUFBRixDQUFPLDBCQUFQO0FBQ0gsS0F6RVE7QUEwRVRDLGFBMUVTLHFCQTBFQ3BCLEtBMUVELEVBMEVRO0FBQ2IsWUFBTU8sU0FBU1AsTUFBTVEsYUFBckI7QUFDQSxZQUFNYSxTQUFTZCxPQUFPRSxPQUFQLENBQWVZLE1BQTlCO0FBQ0EsWUFBTUMsV0FBV2YsT0FBT0UsT0FBUCxDQUFlYSxRQUFoQztBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQUksQ0FBQ0QsTUFBTCxFQUFhO0FBQ1QzQixpQkFBSzZCLFNBQUwsQ0FBZTtBQUNYQyxzQkFBTSxNQURLO0FBRVhDLHVCQUFPO0FBRkksYUFBZjtBQUlBLG1CQUFPLEtBQVA7QUFDSDtBQUNELFlBQUlDLCtCQUE2QkwsTUFBakM7QUFDQSxZQUFJQyxZQUFZLENBQWhCLEVBQW1CO0FBQ2ZJLDJDQUE2QkwsTUFBN0I7QUFDSDtBQUNEeEIsdUJBQUVzQixJQUFGLENBQU9PLEdBQVA7QUFDSCxLQTdGUTtBQThGVEMsaUJBOUZTLDJCQThGTztBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBekhRLENBQWI7O0FBNkhBQyxLQUFLQyxPQUFPQyxNQUFQLENBQWMsRUFBZCxFQUFrQnZELElBQWxCLENBQUwsRSIsImZpbGUiOiJwYWdlcy9ob21lL2hvbWUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBpbXBvcnQgc2VhcmNoTGF5b3V0IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL3NlYXJjaExheW91dC9zZWFyY2hMYXlvdXRcIjtcbmltcG9ydCB1c2VyIGZyb20gXCIuLi8uLi9jb21tb24vdXNlci91c2VyXCI7XG5pbXBvcnQgYWN0aW9ucyBmcm9tIFwiLi9hY3Rpb25zL2luZGV4XCI7XG5pbXBvcnQgXyBmcm9tIFwiLi4vLi4vY29tbW9uL3V0aWxzL3V0aWxcIjtcblxuY29uc3QgYXBwID0gZ2V0QXBwKCk7XG5jb25zdCBwYWdlID0ge1xuICAgIGRhdGE6IHtcbiAgICAgICAgbG9hZDogJ25vbmUnLFxuICAgICAgICBiYW5uZXJJbmRleDogMSxcbiAgICAgICAgc2VsZWN0ZWRMaXZlU3VidHlwZUlkOiAwLFxuICAgICAgICAvLyBiYW5uZXI6IFtdLFxuICAgICAgICBjaGFubmVsc19hX290aGVyOiB7fSxcbiAgICAgICAgY2hhbm5lbHNfYV9yb29tTGlzdDogW10sXG4gICAgICAgIGNoYW5uZWxzX2Jfcm9vbUxpc3Q6IFtdLFxuICAgICAgICAvLyBjaGFubmVsczogW11cbiAgICB9LFxuICAgIG9uUHVsbERvd25SZWZyZXNoKCkge1xuICAgICAgICAvLyDkuIvmi4nliLfmlrBcbiAgICAgICAgdGhpcy5vbkxvYWQoKTtcbiAgICB9LFxuICAgIG9uU2hvdygpIHtcbiAgICAgICAgLy8gbGV0IF9jaGFubmVscyA9IHRoaXMuZ2V0RGF0YSgnY2hhbm5lbHMnKTtcbiAgICAgICAgLy8gaWYgKCFfY2hhbm5lbHMpIHtcbiAgICAgICAgLy8gICAgIHRoaXMub25Mb2FkKCk7XG4gICAgICAgIC8vIH1cbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29uU2hvdy4uLicpO1xuICAgIH0sXG4gICAgb25SZWFkeSgpIHtcbiAgICAgICAgLy8gc3dhbi5zaG93VG9hc3QoeyB0aXRsZTogJ29uUmVhZHkgISAnIH0pO1xuICAgICAgICAvLyBjb25zb2xlLmxvZygnb25SZWFkeS4uLicpO1xuICAgIH0sXG4gICAgb25Mb2FkKCkge1xuICAgICAgICAvLyBjb25zb2xlLmVycm9yKEpTT04uc3RyaW5naWZ5KHRoaXMuZGF0YSkpO1xuICAgICAgICAvLyB1c2VyLmluaXQoKTtcbiAgICAgICAgdGhpcy5sb2FkUGFnZSgpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZygnb25Mb2FkLi4uJyk7XG4gICAgfSxcbiAgICBsb2FkUGFnZSgpIHtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICBsZXQgaXNMb2dpbiA9IHVzZXIuaXNMb2dpbigpO1xuICAgICAgICAgICAgYWN0aW9ucy5nZXRJbmRleERhdGEoaXNMb2dpbiwgdGhpcyk7XG4gICAgICAgICAgICB0aGlzLmxvYWRQYWdlID0gKCkgPT4ge1xuICAgICAgICAgICAgICAgIGxldCBpc0xvZ2luID0gdXNlci5pc0xvZ2luKCk7XG4gICAgICAgICAgICAgICAgYWN0aW9ucy5nZXRJbmRleERhdGEoaXNMb2dpbiwgdGhpcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sIDApXG4gICAgfSxcbiAgICBfbG9hZGVkUGFnZShkYXRhKSB7XG4gICAgICAgIC8vIOa4suafk+WQjuWbnuiwg1xuICAgICAgICBzd2FuLnN0b3BQdWxsRG93blJlZnJlc2ggJiYgc3dhbi5zdG9wUHVsbERvd25SZWZyZXNoKCk7XG4gICAgICAgIHN3YW4uaGlkZUxvYWRpbmcoKTtcbiAgICAgICAgXy5zZW8oKTsgLy/pu5jorqQgU0VPXG4gICAgfSxcbiAgICBzd2lwZXJDaGFuZ2UoZXZlbnQpIHtcbiAgICAgICAgY29uc3QgYmFubmVyID0gdGhpcy5nZXREYXRhKCdiYW5uZXInKVtldmVudC5kZXRhaWwuY3VycmVudF07XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdiYW5uZXInLCBiYW5uZXIpO1xuICAgICAgICAvLyDngrnkuq4gc3dpcGVyLWRvdFxuICAgICAgICB0aGlzLnNldERhdGEoe1xuICAgICAgICAgICAgYmFubmVySW5kZXg6IGV2ZW50LmRldGFpbC5jdXJyZW50ICsgMVxuICAgICAgICB9KVxuICAgIH0sXG4gICAgc2VsZWN0ZWRCdG5Sb29tKGV2ZW50KSB7XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LmN1cnJlbnRUYXJnZXQ7XG4gICAgICAgIC8vIHN3YW4uc2hvd1RvYXN0KHsgdGl0bGU6IHRhcmdldC5kYXRhc2V0LmxpdmVTdWJ0eXBlTmFtZSB9KTtcbiAgICAgICAgdGhpcy5zZXREYXRhKCdzZWxlY3RlZExpdmVTdWJ0eXBlSWQnLCB0YXJnZXQuZGF0YXNldC5saXZlU3VidHlwZUlkKTtcbiAgICB9LFxuICAgIHJlZGlyZWN0Q2F0ZU1vcmUoZXZlbnQpIHtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gZXZlbnQuY3VycmVudFRhcmdldDtcbiAgICAgICAgY29uc3Qgb2JqID0gdGFyZ2V0LmRhdGFzZXQub2JqO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhvYmoubGl2ZUNoYW5uZWxOYW1lLCBvYmouY2hhbm5lbFR5cGUsIG9iai5saXZlVHlwZUlkKTtcbiAgICAgICAgYXBwLmdsb2JhbERhdGEudGFiQ2F0ZWdvcnkgPSB7XG4gICAgICAgICAgICBsaXZlVHlwZUlkOiBvYmoubGl2ZVR5cGVJZCxcbiAgICAgICAgICAgIGxpdmVDaGFubmVsTmFtZTogb2JqLmxpdmVDaGFubmVsTmFtZSxcbiAgICAgICAgICAgIGNoYW5uZWxUeXBlOiBvYmouY2hhbm5lbFR5cGUsXG4gICAgICAgICAgICBsaXZlU3ViVHlwZUlkOiBvYmoubGl2ZVN1YlR5cGVJZCB8fCAwXG4gICAgICAgIH07XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGFwcC5nbG9iYWxEYXRhLnRhYkNhdGVnb3J5KTtcbiAgICAgICAgXy5qdW1wKCcvcGFnZXMvY2F0ZWdvcnkvY2F0ZWdvcnknKTtcbiAgICB9LFxuICAgIHBsYXlWaWRlbyhldmVudCkge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgICAgICBjb25zdCByb29tSWQgPSB0YXJnZXQuZGF0YXNldC5yb29tSWQ7XG4gICAgICAgIGNvbnN0IGxpdmVUeXBlID0gdGFyZ2V0LmRhdGFzZXQubGl2ZVR5cGU7XG4gICAgICAgIC8vIGNvbnN0IG9iaiA9IHRhcmdldC5kYXRhc2V0Lm9iajtcbiAgICAgICAgLy8gY29uc29sZS5sb2cob2JqKTtcbiAgICAgICAgLy8gXy5yZWNvcmQoeyAuLi5vYmosIHJlY29yZFRpbWU6IG5ldyBEYXRlKCkuZ2V0VGltZSgpIH0pO1xuICAgICAgICBpZiAoIXJvb21JZCkge1xuICAgICAgICAgICAgc3dhbi5zaG93VG9hc3Qoe1xuICAgICAgICAgICAgICAgIGljb246ICdub25lJyxcbiAgICAgICAgICAgICAgICB0aXRsZTogJ+aVsOaNruW8guW4uCdcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IHVybCA9IGBwYWdlcy93L3Jvb20/cm9vbUlkPSR7cm9vbUlkfWA7XG4gICAgICAgIGlmIChsaXZlVHlwZSA9PSAyKSB7XG4gICAgICAgICAgICB1cmwgPSBgcGFnZXMvcy9yb29tP3Jvb21JZD0ke3Jvb21JZH1gO1xuICAgICAgICB9XG4gICAgICAgIF8uanVtcCh1cmwpO1xuICAgIH0sXG4gICAgdXBkYXRlVmVyc2lvbigpIHtcbiAgICAgICAgLy8gY29uc3QgdXBkYXRlTWFuYWdlciA9IHN3YW4uZ2V0VXBkYXRlTWFuYWdlcigpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyh1cGRhdGVNYW5hZ2VyKTtcbiAgICAgICAgLy8gdXBkYXRlTWFuYWdlci5vbkNoZWNrRm9yVXBkYXRlKGZ1bmN0aW9uKHJlcykge1xuICAgICAgICAvLyAgICAgLy8g6K+35rGC5a6M5paw54mI5pys5L+h5oGv55qE5Zue6LCDXG4gICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhyZXMpO1xuICAgICAgICAvLyAgICAgY29uc29sZS5sb2cocmVzLmhhc1VwZGF0ZSk7XG4gICAgICAgIC8vICAgICBzd2FuLnNob3dNb2RhbCh7IHRpdGxlOiAn5pu05paw5o+Q56S6JywgY29udGVudDogSlNPTi5zdHJpbmdpZnkocmVzKSB9KTtcbiAgICAgICAgLy8gfSk7XG4gICAgICAgIC8vIHVwZGF0ZU1hbmFnZXIub25VcGRhdGVSZWFkeShmdW5jdGlvbihyZXMpIHtcbiAgICAgICAgLy8gICAgIHN3YW4uc2hvd01vZGFsKHtcbiAgICAgICAgLy8gICAgICAgICB0aXRsZTogJ+abtOaWsOaPkOekuicsXG4gICAgICAgIC8vICAgICAgICAgY29udGVudDogJ+aWsOeJiOacrOW3sue7j+WHhuWkh+Wlve+8jOaYr+WQpumHjeWQr+W6lOeUqO+8nycsXG4gICAgICAgIC8vICAgICAgICAgc3VjY2VzcyhyZXMpIHtcbiAgICAgICAgLy8gICAgICAgICAgICAgY29uc29sZS5sb2cocmVzKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgaWYgKHJlcy5jb25maXJtKSB7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAvLyDmlrDnmoTniYjmnKzlt7Lnu4/kuIvovb3lpb3vvIzosIPnlKggYXBwbHlVcGRhdGUg5bqU55So5paw54mI5pys5bm26YeN5ZCvXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB1cGRhdGVNYW5hZ2VyLmFwcGx5VXBkYXRlKCk7XG4gICAgICAgIC8vICAgICAgICAgICAgIH1cbiAgICAgICAgLy8gICAgICAgICB9XG4gICAgICAgIC8vICAgICB9KTtcblxuICAgICAgICAvLyB9KTtcbiAgICAgICAgLy8gdXBkYXRlTWFuYWdlci5vblVwZGF0ZUZhaWxlZChmdW5jdGlvbihyZXMpIHtcbiAgICAgICAgLy8gICAgIC8vIOaWsOeahOeJiOacrOS4i+i9veWksei0pVxuICAgICAgICAvLyAgICAgY29uc29sZS5sb2cocmVzKTtcbiAgICAgICAgLy8gfSk7XG4gICAgfVxufVxuXG5cblBhZ2UoT2JqZWN0LmFzc2lnbih7fSwgcGFnZSkpXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC9Vc2Vycy9ob3ViaW5nYmluZy9jb2RlL2lxaXlpL3FsaXZlX21pbmlwcm9ncmFtL2JhaWR1L3BhZ2VzL2hvbWUvaG9tZS5qcyJdLCJzb3VyY2VSb290IjoiIn0=