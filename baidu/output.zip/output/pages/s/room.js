window.define('113', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _roomAction = __webpack_require__(114);

var room = _interopRequireWildcard(_roomAction);

var _reqService = __webpack_require__(40);

var req = _interopRequireWildcard(_reqService);

var _playerAction = __webpack_require__(75);

var _playerAction2 = _interopRequireDefault(_playerAction);

var _msgAction = __webpack_require__(74);

var _msgAction2 = _interopRequireDefault(_msgAction);

var _sendMsgAction = __webpack_require__(73);

var _sendMsgAction2 = _interopRequireDefault(_sendMsgAction);

var _praiseAction = __webpack_require__(116);

var _praiseAction2 = _interopRequireDefault(_praiseAction);

var _utils = __webpack_require__(54);

var utils = _interopRequireWildcard(_utils);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

var _Emitter = __webpack_require__(53);

var _Emitter2 = _interopRequireDefault(_Emitter);

var _jsSensor = __webpack_require__(59);

var _jsSensor2 = _interopRequireDefault(_jsSensor);

var _user = __webpack_require__(38);

var user = _interopRequireWildcard(_user);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

// import mutiAccount from '../../../components/mutiAccount/mutiAccount'

var app = getApp();
// import PlayerControl from './actions/playerAction';

var page = {
    /**
     * 页面的初始数据
     */
    data: {
        errorTip: true,
        activeTab: "chat",
        roomId: null,
        hostInfo: null,
        msgList: [{
            type: 0,
            content: "正在链接聊天室......"
        }],
        scrollHeight: 100,
        scrollHideLoadMore: true,
        scrollAnimation: false,
        inputFocus: false,
        inputText: "",
        inputAvailable: "",
        showKeyboard: "",
        videoBodyTop: 0,
        video: {
            needVIP: false,
            needLogin: false,
            show: false,
            offline: false
        },
        previewCover: '',
        roomStatus: 0,
        followed: false,
        recommendList: [],
        keyboardHeight: 0,
        open: false,
        errRoom: false, //房间 init error 
        canPraise: false // 是否可以点赞 
    },
    clickFollow: function clickFollow() {
        console.log('不能订阅!');
        return;
        room.clickFollow(this);
    },
    clickRecommend: function clickRecommend(e) {
        room.redirectTo(e.currentTarget.dataset);
    },
    destroyed: function destroyed() {
        // 销毁 定时器事件
        this.components.playerControl && this.components.playerControl.destroyed && this.components.playerControl.destroyed();
        this.components.msgBox && this.components.msgBox.destroyed && this.components.msgBox.destroyed();
    },

    clickMultiLive: function clickMultiLive(e) {
        this.destroyed();
        var dataset = e.currentTarget.dataset;
        if (dataset.roomid == this.data.roomId) {
            return;
        }
        _util2.default.jump('/pages/s/room?roomId=' + dataset.roomid);
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function onShareAppMessage() {
        var shareData = {
            title: this.roomInfo.shareInfo.programName,
            content: this.roomInfo.shareInfo.description,
            imageUrl: this.roomInfo.shareInfo.cover.replace("_480_270", "_480_360"),
            path: 'pages/s/room?roomId=' + this.roomInfo.roomId
        };
        return shareData;
    },

    onClickShare: function onClickShare() {
        var shareData = {
            title: this.roomInfo.shareInfo.programName,
            content: this.roomInfo.shareInfo.description,
            imageUrl: this.roomInfo.shareInfo.cover.replace("_480_270", "_480_360"),
            path: 'pages/s/room?roomId=' + this.roomInfo.roomId
        };
        swan.openShare(shareData);
    },
    /**
     * 生命周期函数--监听页面加载
     */
    store: {
        dispatch: function dispatch() {}
    },
    // isMultiAccount: mutiAccount.isMultiAccount,
    seo: function seo() {
        _util2.default.seo({
            desc: this.roomInfo.roomTitle + '_\u76F4\u64AD_\u7231\u5947\u827A\u76F4\u64AD-\u7231\u5947\u827A',
            keywords: this.roomInfo.roomTitle + ',' + this.roomInfo.roomTitle + '_\u76F4\u64AD,' + this.roomInfo.roomTitle + '\u76F4\u64AD\u95F4,' + this.roomInfo.roomTitle + '\u76F4\u64AD\u5730\u5740\uFF0C' + this.roomInfo.roomTitle + '\u76F4\u64AD\uFF0C' + this.roomInfo.roomTitle + '\u89C6\u9891',
            title: this.roomInfo.roomTitle + '_\u76F4\u64AD_\u7231\u5947\u827A\u76F4\u64AD-\u7231\u5947\u827A'
        });
    },
    sensorInit: function sensorInit() {
        var globalData = getApp().globalData;
        this.sensor = new _jsSensor2.default({
            pl: globalData.pl || '2_24_200_3',
            t: globalData.tl || 'bd_ios',
            version: globalData.version || '2.01.05', //baidu mini pro version 
            device_id: user.getDeviceId() || '',
            userId: '',
            url: '/v1/live/initial',
            roomId: this.data.roomId
        }, swan);
    },
    canPraiseHandler: function canPraiseHandler(bool) {
        this.setData({
            "canPraise": bool || false
        });
    },
    onLoad: function onLoad(opt) {
        // console.log('opt:\t', opt);
        // opt.roomId = '37542';
        opt = { roomId: opt && opt.roomId || this.roomInfo && this.roomInfo.qipuId || '' };
        this.trigger = new _Emitter2.default();
        getApp().emitter = this.trigger;
        this.roomInfo = {};
        this.components = {};
        this.setData({
            "roomId": opt.roomId
        });
        this.canPraiseHandler(); //默认不能点赞
        if (opt.env) {
            req.setENV("test");
        }
        this.sensor = {};
        this.sensorInit();
        this.reqInit(opt);
    },
    reqInit: function reqInit(opt) {
        var _this = this;

        var conStart = new Date().getTime();
        req.getRoomInfo(opt.roomId).then(function (res) {
            var conEnd = new Date().getTime();
            _this.sensor.push(_this.sensor.CODE.ROOM_INITIAL_SUCCESS, res.code, conEnd - conStart, 0, '', '' + res.msg);

            if (res.code === "A00000") {
                _this.roomInfo = res.data;
                _this.roomInfo.roomId = res.data.programInfo.qipuId;
                _this.roomInfo.qpId = res.data.programInfo.qipuId;
                _this.roomInfo.qipuId = res.data.programInfo.qipuId;
                _this.roomInfo.liveChannelId = res.data.programInfo.liveChannelId;
                _this.roomInfo.roomStatus = res.data.programInfo.playStatus;
                _this.roomInfo.playStatus = res.data.programInfo.playStatus;
                // this.roomInfo.roomId = res.data.programInfo.roomId;//pgc 独有
                // this.roomInfo.liveTypeId = res.data.programInfo.liveTypeId;//pgc 独有
                // this.roomInfo.liveSubTypeId = res.data.programInfo.liveSubTypeId;//pgc 独有
                _this.roomInfo.chatRoomId = res.data.chatInfo.chatRoomId;
                _this.roomInfo.startPlayTime = res.data.chatInfo.chatRoomId;

                // this.roomInfo.anchorNickname = res.data.anchorInfo.anchorNickName;//pgc 独有
                // this.roomInfo.subTitle = res.data.programInfo.liveTypeName;//pgc 独有

                _this.roomInfo.shareInfo = res.data.shareInfo;
                var recordObj = {
                    roomId: res.data.programInfo.roomId || res.data.programInfo.qipuId,
                    qipuId: res.data.programInfo.qipuId || res.data.programInfo.roomId,
                    coverImageUrl: res.data.programInfo.coverImageUrl || res.data.shareInfo.cover.replace("_480_270", "_480_360"),
                    liveType: 2,
                    playNumber: res.data.programInfo.playNumber,
                    title: res.data.programInfo.programName || res.data.programInfo.description,
                    // nickname: res.data.anchorInfo.anchorNickName,//不能添加这个字段 因为这个字段的对象不存在 会导致后续代码崩溃 停止执行
                    recordTime: new Date().getTime()
                };
                _util2.default.record(recordObj);
                var params = {
                    qipuId: res.data.programInfo.qipuId,
                    roomTitle: res.data.programInfo.programName || res.data.programInfo.description,
                    roomStatus: res.data.programInfo.playStatus, //0: 未知, 1：未开始，2：直播，3:回看中,4:回看结束 （新增）,5:轮播中, -1 禁播中  ### 对应合并 "roomStatus": 1, // 0.停播中 1.直播中 2禁播中 3轮播中,
                    // followed: res.data.anchorInfo.isFollowed,//pgc 独有
                    // followNum: utils.shortNum(res.data.anchorInfo.anchorFollowerNum),//pgc 独有
                    // liveTypeName: res.data.programInfo.liveTypeName,//pgc 独有
                    // liveSubTypeName: res.data.programInfo.liveSubTypeName,//pgc 独有
                    hostInfo: {
                        // "anchorIcon": res.data.anchorInfo.anchorIcon,//pgc 独有
                        // "nickname": res.data.anchorInfo.anchorNickName,//pgc 独有
                        // "wallet": utils.shortNum(res.data.wallet),// 身价
                        // "populaty": utils.shortNum(res.data.populaty), // 热度
                        "info": res.data.programInfo.description || res.data.programInfo.programName,
                        "hot": res.data.programInfo.playNumber
                    },
                    multiLiveInfo: res.data.multiLiveInfo, // 多机位数据
                    chatShouldDisplay: res.data.chatInfo.shouldDisplay,
                    switcher: res.data.switcher //很多开关  包括 点赞总开关
                    // startPlayTime: _.time.format(res.data.programInfo.startPlayTime, 'yyyy-MM-dd hh:mm')
                };

                var startPlayTime = new Date(res.data.programInfo && res.data.programInfo.startPlayTime || null);
                params['startPlayTime'] = _util2.default.time.format(startPlayTime, 'MM-dd hh:mm');

                _this.seo();
                _this.setData(params);

                // this.setData({ 'previewCover': res.data.programInfo.coverImageUrl || 'http://www.iqiyipic.com/common/fix/wx-iqiyi/player-tip-bg.jpg' })
                _this.setData({ 'previewCover': res.data.shareInfo.cover || 'http://www.iqiyipic.com/common/fix/wx-iqiyi/player-tip-bg.jpg' });
                swan.setNavigationBarTitle({
                    title: res.data.programInfo.programName
                });
                _this.components.praiseControl = new _praiseAction2.default(_this, res.data.praiseInfo);
                _this.components.playerControl = new _playerAction2.default(_this);
                // 拉取最后几条聊天记录
                // 聊天的是否需要展示 不展示 也需要 WS 链接
                req.getLatestMsg(_this.roomInfo.chatRoomId).then(function (data) {
                    _this.roomInfo.latestMsg = data;
                    _this.components.sendBox = new _sendMsgAction2.default(_this);
                    _this.components.msgBox = new _msgAction2.default(_this, res.data.chatInfo.chatRoomId);
                }).catch(function (err) {
                    console.error(err);
                    if (params.multiLiveInfo) {
                        _this.swchOpen(); // 打开多机位
                    }
                });
                _this.eventTester("canplaythrough", function (e) {
                    console.log('canplaythrough');
                });
            } else {
                if (res.code === "A00005") {
                    console.error('\u9700\u8981\u6295\u9012\u7684', res.msg); // TODO 投递
                    _this.sensor.push(_this.sensor.CODE.ROOM_INITIAL_ERR, res.code, conEnd - conStart, 0, '', '' + res.msg);
                }
                _this.components.playerControl = new _playerAction2.default(_this);
                _this.setData({
                    errRoom: true, //房间错误
                    video: {
                        show: false,
                        errorInfo: true,
                        errorMsg: res.msg || '视频不能播放'
                    },
                    previewCover: 'http://www.iqiyipic.com/common/fix/wx-iqiyi/player-tip-bg.jpg'
                });
            }
        }, function (res) {
            console.log(res);
        });
    },

    eventTester: function eventTester(e, eventHanler) {
        var Media = document.getElementById('videoId');
        Media.addEventListener(e, function () {
            eventHanler && eventHanler();
            out.debug(new Date().getTime(), e);
        }, false);
    },
    swchOpen: function swchOpen() {
        var _this2 = this;

        // 切换机位显示
        this.setData({ 'open': !this.data.open }, function () {
            if (_this2.data.multiLiveInfo) {
                if (!_this2.data.open) {
                    room.getRoomInfoHeight(_this2, false);
                } else {
                    room.getRoomInfoHeight(_this2, true);
                }
            } else {
                room.getRoomInfoHeight(_this2);
            }
        });
    },

    afterLoginTrigger: function afterLoginTrigger() {
        swan.showToast({
            title: '\u767B\u5F55\u6210\u529F',
            icon: 'none'
        });
        room.refreshInfo(this);
        this.trigger.emit("afterLoginSuccess");
    },

    afterLogoutTrigger: function afterLogoutTrigger() {
        room.resetFollowBtn(this);
        this.trigger.emit("afterLogoutSuccess");
    },

    loginSuccess: function loginSuccess() {
        this.trigger.emit("afterGetUserInfo");
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function onReady() {
        var page = this;
        // this.setData({
        //     scrollHeight: room.getScrollHeight(),
        //     roomInfoHeight: room.getRoomInfoHeight(),
        //     inputFitClass: room.getInputFitClass()
        // });
        room.getScrollHeight(page);
        room.getRoomInfoHeight(page);
        room.getInputFitClass(page);
        // getApp().emitter.on("afterLoginSuccess", this.afterLoginTrigger);
        // getApp().emitter.on("afterLogoutSuccess", this.afterLogoutTrigger);
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function onShow() {
        this.trigger.emit("showPage");
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function onHide() {
        getApp().emitter.emit("hidePage");
        this.trigger.emit("hidePage");
    },

    onError: function onError(aaa) {
        console.warn(aaa);
    },


    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function onUnload() {
        this.trigger.emit("pageUnload");
        this.trigger.off();
        this.setData({
            errorTip: true,
            activeTab: "chat",
            roomId: null,
            hostInfo: null,
            msgList: [{
                type: 0,
                content: "正在链接聊天室......"
            }],
            scrollHeight: 100,
            scrollHideLoadMore: true,
            scrollAnimation: false,
            inputFocus: false,
            inputText: "",
            inputAvailable: "",
            showKeyboard: "",
            videoBodyTop: 0,
            keyboardHeight: 0,
            video: {
                needVIP: false,
                needLogin: false,
                show: false,
                offline: false,
                url: ""
            }
        });
        // getApp().emitter.off("afterLoginSuccess",this.afterLoginTrigger);
        // getApp().emitter.off("afterLogoutSuccess", this.afterLogoutTrigger);
    }
};
Page(Object.assign({}, page));
});
window.__swanRoute='pages/s/room';window.usingComponents=[];require('113');

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvcy9yb29tLmpzIl0sIm5hbWVzIjpbInJvb20iLCJyZXEiLCJ1dGlscyIsInVzZXIiLCJhcHAiLCJnZXRBcHAiLCJwYWdlIiwiZGF0YSIsImVycm9yVGlwIiwiYWN0aXZlVGFiIiwicm9vbUlkIiwiaG9zdEluZm8iLCJtc2dMaXN0IiwidHlwZSIsImNvbnRlbnQiLCJzY3JvbGxIZWlnaHQiLCJzY3JvbGxIaWRlTG9hZE1vcmUiLCJzY3JvbGxBbmltYXRpb24iLCJpbnB1dEZvY3VzIiwiaW5wdXRUZXh0IiwiaW5wdXRBdmFpbGFibGUiLCJzaG93S2V5Ym9hcmQiLCJ2aWRlb0JvZHlUb3AiLCJ2aWRlbyIsIm5lZWRWSVAiLCJuZWVkTG9naW4iLCJzaG93Iiwib2ZmbGluZSIsInByZXZpZXdDb3ZlciIsInJvb21TdGF0dXMiLCJmb2xsb3dlZCIsInJlY29tbWVuZExpc3QiLCJrZXlib2FyZEhlaWdodCIsIm9wZW4iLCJlcnJSb29tIiwiY2FuUHJhaXNlIiwiY2xpY2tGb2xsb3ciLCJjb25zb2xlIiwibG9nIiwiY2xpY2tSZWNvbW1lbmQiLCJlIiwicmVkaXJlY3RUbyIsImN1cnJlbnRUYXJnZXQiLCJkYXRhc2V0IiwiZGVzdHJveWVkIiwiY29tcG9uZW50cyIsInBsYXllckNvbnRyb2wiLCJtc2dCb3giLCJjbGlja011bHRpTGl2ZSIsInJvb21pZCIsIl8iLCJqdW1wIiwib25TaGFyZUFwcE1lc3NhZ2UiLCJzaGFyZURhdGEiLCJ0aXRsZSIsInJvb21JbmZvIiwic2hhcmVJbmZvIiwicHJvZ3JhbU5hbWUiLCJkZXNjcmlwdGlvbiIsImltYWdlVXJsIiwiY292ZXIiLCJyZXBsYWNlIiwicGF0aCIsIm9uQ2xpY2tTaGFyZSIsInN3YW4iLCJvcGVuU2hhcmUiLCJzdG9yZSIsImRpc3BhdGNoIiwic2VvIiwiZGVzYyIsInJvb21UaXRsZSIsImtleXdvcmRzIiwic2Vuc29ySW5pdCIsImdsb2JhbERhdGEiLCJzZW5zb3IiLCJTZW5zb3IiLCJwbCIsInQiLCJ0bCIsInZlcnNpb24iLCJkZXZpY2VfaWQiLCJnZXREZXZpY2VJZCIsInVzZXJJZCIsInVybCIsImNhblByYWlzZUhhbmRsZXIiLCJib29sIiwic2V0RGF0YSIsIm9uTG9hZCIsIm9wdCIsInFpcHVJZCIsInRyaWdnZXIiLCJFbWl0dGVyIiwiZW1pdHRlciIsImVudiIsInNldEVOViIsInJlcUluaXQiLCJjb25TdGFydCIsIkRhdGUiLCJnZXRUaW1lIiwiZ2V0Um9vbUluZm8iLCJ0aGVuIiwiY29uRW5kIiwicHVzaCIsIkNPREUiLCJST09NX0lOSVRJQUxfU1VDQ0VTUyIsInJlcyIsImNvZGUiLCJtc2ciLCJwcm9ncmFtSW5mbyIsInFwSWQiLCJsaXZlQ2hhbm5lbElkIiwicGxheVN0YXR1cyIsImNoYXRSb29tSWQiLCJjaGF0SW5mbyIsInN0YXJ0UGxheVRpbWUiLCJyZWNvcmRPYmoiLCJjb3ZlckltYWdlVXJsIiwibGl2ZVR5cGUiLCJwbGF5TnVtYmVyIiwicmVjb3JkVGltZSIsInJlY29yZCIsInBhcmFtcyIsIm11bHRpTGl2ZUluZm8iLCJjaGF0U2hvdWxkRGlzcGxheSIsInNob3VsZERpc3BsYXkiLCJzd2l0Y2hlciIsInRpbWUiLCJmb3JtYXQiLCJzZXROYXZpZ2F0aW9uQmFyVGl0bGUiLCJwcmFpc2VDb250cm9sIiwicHJhaXNlSW5mbyIsIlBsYXllckNvbnRyb2wiLCJnZXRMYXRlc3RNc2ciLCJsYXRlc3RNc2ciLCJzZW5kQm94IiwiU2VuZEJveCIsIk1lc3NhZ2VCb3giLCJjYXRjaCIsImVyciIsImVycm9yIiwic3djaE9wZW4iLCJldmVudFRlc3RlciIsIlJPT01fSU5JVElBTF9FUlIiLCJlcnJvckluZm8iLCJlcnJvck1zZyIsImV2ZW50SGFubGVyIiwiTWVkaWEiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwiYWRkRXZlbnRMaXN0ZW5lciIsIm91dCIsImRlYnVnIiwiZ2V0Um9vbUluZm9IZWlnaHQiLCJhZnRlckxvZ2luVHJpZ2dlciIsInNob3dUb2FzdCIsImljb24iLCJyZWZyZXNoSW5mbyIsImVtaXQiLCJhZnRlckxvZ291dFRyaWdnZXIiLCJyZXNldEZvbGxvd0J0biIsImxvZ2luU3VjY2VzcyIsIm9uUmVhZHkiLCJnZXRTY3JvbGxIZWlnaHQiLCJnZXRJbnB1dEZpdENsYXNzIiwib25TaG93Iiwib25IaWRlIiwib25FcnJvciIsImFhYSIsIndhcm4iLCJvblVubG9hZCIsIm9mZiIsIlBhZ2UiLCJPYmplY3QiLCJhc3NpZ24iXSwibWFwcGluZ3MiOiI7OztBQUFBOztJQUFZQSxJOztBQUNaOztJQUFZQyxHOztBQUVaOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7O0lBQVlDLEs7O0FBQ1o7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7O0lBQVlDLEk7Ozs7OztBQUNaOztBQUVBLElBQU1DLE1BQU1DLFFBQVo7QUFaQTs7QUFhQSxJQUFNQyxPQUFPO0FBQ1Q7OztBQUdBQyxVQUFNO0FBQ0ZDLGtCQUFVLElBRFI7QUFFRkMsbUJBQVcsTUFGVDtBQUdGQyxnQkFBUSxJQUhOO0FBSUZDLGtCQUFVLElBSlI7QUFLRkMsaUJBQVMsQ0FBQztBQUNOQyxrQkFBTSxDQURBO0FBRU5DLHFCQUFTO0FBRkgsU0FBRCxDQUxQO0FBU0ZDLHNCQUFjLEdBVFo7QUFVRkMsNEJBQW9CLElBVmxCO0FBV0ZDLHlCQUFpQixLQVhmO0FBWUZDLG9CQUFZLEtBWlY7QUFhRkMsbUJBQVcsRUFiVDtBQWNGQyx3QkFBZ0IsRUFkZDtBQWVGQyxzQkFBYyxFQWZaO0FBZ0JGQyxzQkFBYyxDQWhCWjtBQWlCRkMsZUFBTztBQUNIQyxxQkFBUyxLQUROO0FBRUhDLHVCQUFXLEtBRlI7QUFHSEMsa0JBQU0sS0FISDtBQUlIQyxxQkFBUztBQUpOLFNBakJMO0FBdUJGQyxzQkFBYyxFQXZCWjtBQXdCRkMsb0JBQVksQ0F4QlY7QUF5QkZDLGtCQUFVLEtBekJSO0FBMEJGQyx1QkFBZSxFQTFCYjtBQTJCRkMsd0JBQWdCLENBM0JkO0FBNEJGQyxjQUFNLEtBNUJKO0FBNkJGQyxpQkFBUyxLQTdCUCxFQTZCYztBQUNoQkMsbUJBQVcsS0E5QlQsQ0E4QmU7QUE5QmYsS0FKRztBQW9DVEMsaUJBQWEsdUJBQVc7QUFDcEJDLGdCQUFRQyxHQUFSLENBQVksT0FBWjtBQUNBO0FBQ0F0QyxhQUFLb0MsV0FBTCxDQUFpQixJQUFqQjtBQUNILEtBeENRO0FBeUNURyxvQkFBZ0Isd0JBQVNDLENBQVQsRUFBWTtBQUN4QnhDLGFBQUt5QyxVQUFMLENBQWdCRCxFQUFFRSxhQUFGLENBQWdCQyxPQUFoQztBQUNILEtBM0NRO0FBNENUQyxhQTVDUyx1QkE0Q0c7QUFDUjtBQUNBLGFBQUtDLFVBQUwsQ0FBZ0JDLGFBQWhCLElBQWlDLEtBQUtELFVBQUwsQ0FBZ0JDLGFBQWhCLENBQThCRixTQUEvRCxJQUE0RSxLQUFLQyxVQUFMLENBQWdCQyxhQUFoQixDQUE4QkYsU0FBOUIsRUFBNUU7QUFDQSxhQUFLQyxVQUFMLENBQWdCRSxNQUFoQixJQUEwQixLQUFLRixVQUFMLENBQWdCRSxNQUFoQixDQUF1QkgsU0FBakQsSUFBOEQsS0FBS0MsVUFBTCxDQUFnQkUsTUFBaEIsQ0FBdUJILFNBQXZCLEVBQTlEO0FBQ0gsS0FoRFE7O0FBaURUSSxvQkFBZ0Isd0JBQVNSLENBQVQsRUFBWTtBQUN4QixhQUFLSSxTQUFMO0FBQ0EsWUFBSUQsVUFBVUgsRUFBRUUsYUFBRixDQUFnQkMsT0FBOUI7QUFDQSxZQUFJQSxRQUFRTSxNQUFSLElBQWtCLEtBQUsxQyxJQUFMLENBQVVHLE1BQWhDLEVBQXdDO0FBQ3BDO0FBQ0g7QUFDRHdDLHVCQUFFQyxJQUFGLDJCQUErQlIsUUFBUU0sTUFBdkM7QUFDSCxLQXhEUTs7QUEwRFQ7OztBQUdBRyx1QkFBbUIsNkJBQVc7QUFDMUIsWUFBSUMsWUFBWTtBQUNaQyxtQkFBTyxLQUFLQyxRQUFMLENBQWNDLFNBQWQsQ0FBd0JDLFdBRG5CO0FBRVozQyxxQkFBUyxLQUFLeUMsUUFBTCxDQUFjQyxTQUFkLENBQXdCRSxXQUZyQjtBQUdaQyxzQkFBVSxLQUFLSixRQUFMLENBQWNDLFNBQWQsQ0FBd0JJLEtBQXhCLENBQThCQyxPQUE5QixDQUFzQyxVQUF0QyxFQUFrRCxVQUFsRCxDQUhFO0FBSVpDLGtCQUFNLHlCQUF5QixLQUFLUCxRQUFMLENBQWM3QztBQUpqQyxTQUFoQjtBQU1BLGVBQU8yQyxTQUFQO0FBQ0gsS0FyRVE7O0FBdUVUVSxrQkFBYyx3QkFBVztBQUNyQixZQUFJVixZQUFZO0FBQ1pDLG1CQUFPLEtBQUtDLFFBQUwsQ0FBY0MsU0FBZCxDQUF3QkMsV0FEbkI7QUFFWjNDLHFCQUFTLEtBQUt5QyxRQUFMLENBQWNDLFNBQWQsQ0FBd0JFLFdBRnJCO0FBR1pDLHNCQUFVLEtBQUtKLFFBQUwsQ0FBY0MsU0FBZCxDQUF3QkksS0FBeEIsQ0FBOEJDLE9BQTlCLENBQXNDLFVBQXRDLEVBQWtELFVBQWxELENBSEU7QUFJWkMsa0JBQU0seUJBQXlCLEtBQUtQLFFBQUwsQ0FBYzdDO0FBSmpDLFNBQWhCO0FBTUFzRCxhQUFLQyxTQUFMLENBQWVaLFNBQWY7QUFDSCxLQS9FUTtBQWdGVDs7O0FBR0FhLFdBQU87QUFDSEMsa0JBQVUsb0JBQVcsQ0FBRTtBQURwQixLQW5GRTtBQXNGVDtBQUNBQyxPQXZGUyxpQkF1Rkg7QUFDRmxCLHVCQUFFa0IsR0FBRixDQUFNO0FBQ0ZDLGtCQUFTLEtBQUtkLFFBQUwsQ0FBY2UsU0FBdkIsb0VBREU7QUFFRkMsc0JBQWEsS0FBS2hCLFFBQUwsQ0FBY2UsU0FBM0IsU0FBeUMsS0FBS2YsUUFBTCxDQUFjZSxTQUF2RCxzQkFBd0UsS0FBS2YsUUFBTCxDQUFjZSxTQUF0RiwyQkFBdUcsS0FBS2YsUUFBTCxDQUFjZSxTQUFySCxzQ0FBdUksS0FBS2YsUUFBTCxDQUFjZSxTQUFySiwwQkFBcUssS0FBS2YsUUFBTCxDQUFjZSxTQUFuTCxpQkFGRTtBQUdGaEIsbUJBQVUsS0FBS0MsUUFBTCxDQUFjZSxTQUF4QjtBQUhFLFNBQU47QUFLSCxLQTdGUTtBQThGVEUsY0E5RlMsd0JBOEZJO0FBQ1QsWUFBSUMsYUFBYXBFLFNBQVNvRSxVQUExQjtBQUNBLGFBQUtDLE1BQUwsR0FBYyxJQUFJQyxrQkFBSixDQUFXO0FBQ3JCQyxnQkFBSUgsV0FBV0csRUFBWCxJQUFpQixZQURBO0FBRXJCQyxlQUFHSixXQUFXSyxFQUFYLElBQWlCLFFBRkM7QUFHckJDLHFCQUFTTixXQUFXTSxPQUFYLElBQXNCLFNBSFYsRUFHcUI7QUFDMUNDLHVCQUFXN0UsS0FBSzhFLFdBQUwsTUFBc0IsRUFKWjtBQUtyQkMsb0JBQVEsRUFMYTtBQU1yQkMsaUJBQUssa0JBTmdCO0FBT3JCekUsb0JBQVEsS0FBS0gsSUFBTCxDQUFVRztBQVBHLFNBQVgsRUFRWHNELElBUlcsQ0FBZDtBQVNILEtBekdRO0FBMEdUb0Isb0JBMUdTLDRCQTBHUUMsSUExR1IsRUEwR2M7QUFDbkIsYUFBS0MsT0FBTCxDQUFhO0FBQ1QseUJBQWFELFFBQVE7QUFEWixTQUFiO0FBR0gsS0E5R1E7QUErR1RFLFVBL0dTLGtCQStHRkMsR0EvR0UsRUErR0c7QUFDUjtBQUNBO0FBQ0FBLGNBQU0sRUFBRTlFLFFBQVE4RSxPQUFPQSxJQUFJOUUsTUFBWCxJQUFxQixLQUFLNkMsUUFBTCxJQUFpQixLQUFLQSxRQUFMLENBQWNrQyxNQUFwRCxJQUE4RCxFQUF4RSxFQUFOO0FBQ0EsYUFBS0MsT0FBTCxHQUFlLElBQUlDLGlCQUFKLEVBQWY7QUFDQXRGLGlCQUFTdUYsT0FBVCxHQUFtQixLQUFLRixPQUF4QjtBQUNBLGFBQUtuQyxRQUFMLEdBQWdCLEVBQWhCO0FBQ0EsYUFBS1YsVUFBTCxHQUFrQixFQUFsQjtBQUNBLGFBQUt5QyxPQUFMLENBQWE7QUFDVCxzQkFBVUUsSUFBSTlFO0FBREwsU0FBYjtBQUdBLGFBQUswRSxnQkFBTCxHQVhRLENBV2lCO0FBQ3pCLFlBQUlJLElBQUlLLEdBQVIsRUFBYTtBQUNUNUYsZ0JBQUk2RixNQUFKLENBQVcsTUFBWDtBQUNIO0FBQ0QsYUFBS3BCLE1BQUwsR0FBYyxFQUFkO0FBQ0EsYUFBS0YsVUFBTDtBQUNBLGFBQUt1QixPQUFMLENBQWFQLEdBQWI7QUFDSCxLQWpJUTtBQWtJVE8sV0FsSVMsbUJBa0lEUCxHQWxJQyxFQWtJSTtBQUFBOztBQUNULFlBQUlRLFdBQVcsSUFBSUMsSUFBSixHQUFXQyxPQUFYLEVBQWY7QUFDQWpHLFlBQUlrRyxXQUFKLENBQWdCWCxJQUFJOUUsTUFBcEIsRUFBNEIwRixJQUE1QixDQUFpQyxlQUFPO0FBQ3BDLGdCQUFJQyxTQUFTLElBQUlKLElBQUosR0FBV0MsT0FBWCxFQUFiO0FBQ0Esa0JBQUt4QixNQUFMLENBQVk0QixJQUFaLENBQWlCLE1BQUs1QixNQUFMLENBQVk2QixJQUFaLENBQWlCQyxvQkFBbEMsRUFBd0RDLElBQUlDLElBQTVELEVBQWtFTCxTQUFTTCxRQUEzRSxFQUFxRixDQUFyRixFQUF3RixFQUF4RixPQUErRlMsSUFBSUUsR0FBbkc7O0FBRUEsZ0JBQUlGLElBQUlDLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN2QixzQkFBS25ELFFBQUwsR0FBZ0JrRCxJQUFJbEcsSUFBcEI7QUFDQSxzQkFBS2dELFFBQUwsQ0FBYzdDLE1BQWQsR0FBdUIrRixJQUFJbEcsSUFBSixDQUFTcUcsV0FBVCxDQUFxQm5CLE1BQTVDO0FBQ0Esc0JBQUtsQyxRQUFMLENBQWNzRCxJQUFkLEdBQXFCSixJQUFJbEcsSUFBSixDQUFTcUcsV0FBVCxDQUFxQm5CLE1BQTFDO0FBQ0Esc0JBQUtsQyxRQUFMLENBQWNrQyxNQUFkLEdBQXVCZ0IsSUFBSWxHLElBQUosQ0FBU3FHLFdBQVQsQ0FBcUJuQixNQUE1QztBQUNBLHNCQUFLbEMsUUFBTCxDQUFjdUQsYUFBZCxHQUE4QkwsSUFBSWxHLElBQUosQ0FBU3FHLFdBQVQsQ0FBcUJFLGFBQW5EO0FBQ0Esc0JBQUt2RCxRQUFMLENBQWMxQixVQUFkLEdBQTJCNEUsSUFBSWxHLElBQUosQ0FBU3FHLFdBQVQsQ0FBcUJHLFVBQWhEO0FBQ0Esc0JBQUt4RCxRQUFMLENBQWN3RCxVQUFkLEdBQTJCTixJQUFJbEcsSUFBSixDQUFTcUcsV0FBVCxDQUFxQkcsVUFBaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBS3hELFFBQUwsQ0FBY3lELFVBQWQsR0FBMkJQLElBQUlsRyxJQUFKLENBQVMwRyxRQUFULENBQWtCRCxVQUE3QztBQUNBLHNCQUFLekQsUUFBTCxDQUFjMkQsYUFBZCxHQUE4QlQsSUFBSWxHLElBQUosQ0FBUzBHLFFBQVQsQ0FBa0JELFVBQWhEOztBQUVBO0FBQ0E7O0FBRUEsc0JBQUt6RCxRQUFMLENBQWNDLFNBQWQsR0FBMEJpRCxJQUFJbEcsSUFBSixDQUFTaUQsU0FBbkM7QUFDQSxvQkFBSTJELFlBQVk7QUFDWnpHLDRCQUFRK0YsSUFBSWxHLElBQUosQ0FBU3FHLFdBQVQsQ0FBcUJsRyxNQUFyQixJQUErQitGLElBQUlsRyxJQUFKLENBQVNxRyxXQUFULENBQXFCbkIsTUFEaEQ7QUFFWkEsNEJBQVFnQixJQUFJbEcsSUFBSixDQUFTcUcsV0FBVCxDQUFxQm5CLE1BQXJCLElBQStCZ0IsSUFBSWxHLElBQUosQ0FBU3FHLFdBQVQsQ0FBcUJsRyxNQUZoRDtBQUdaMEcsbUNBQWVYLElBQUlsRyxJQUFKLENBQVNxRyxXQUFULENBQXFCUSxhQUFyQixJQUFzQ1gsSUFBSWxHLElBQUosQ0FBU2lELFNBQVQsQ0FBbUJJLEtBQW5CLENBQXlCQyxPQUF6QixDQUFpQyxVQUFqQyxFQUE2QyxVQUE3QyxDQUh6QztBQUlad0QsOEJBQVUsQ0FKRTtBQUtaQyxnQ0FBWWIsSUFBSWxHLElBQUosQ0FBU3FHLFdBQVQsQ0FBcUJVLFVBTHJCO0FBTVpoRSwyQkFBT21ELElBQUlsRyxJQUFKLENBQVNxRyxXQUFULENBQXFCbkQsV0FBckIsSUFBb0NnRCxJQUFJbEcsSUFBSixDQUFTcUcsV0FBVCxDQUFxQmxELFdBTnBEO0FBT1o7QUFDQTZELGdDQUFZLElBQUl0QixJQUFKLEdBQVdDLE9BQVg7QUFSQSxpQkFBaEI7QUFVQWhELCtCQUFFc0UsTUFBRixDQUFTTCxTQUFUO0FBQ0Esb0JBQUlNLFNBQVM7QUFDVGhDLDRCQUFRZ0IsSUFBSWxHLElBQUosQ0FBU3FHLFdBQVQsQ0FBcUJuQixNQURwQjtBQUVUbkIsK0JBQVdtQyxJQUFJbEcsSUFBSixDQUFTcUcsV0FBVCxDQUFxQm5ELFdBQXJCLElBQW9DZ0QsSUFBSWxHLElBQUosQ0FBU3FHLFdBQVQsQ0FBcUJsRCxXQUYzRDtBQUdUN0IsZ0NBQVk0RSxJQUFJbEcsSUFBSixDQUFTcUcsV0FBVCxDQUFxQkcsVUFIeEIsRUFHb0M7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQXBHLDhCQUFVO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBUThGLElBQUlsRyxJQUFKLENBQVNxRyxXQUFULENBQXFCbEQsV0FBckIsSUFBb0MrQyxJQUFJbEcsSUFBSixDQUFTcUcsV0FBVCxDQUFxQm5ELFdBTDNEO0FBTU4sK0JBQU9nRCxJQUFJbEcsSUFBSixDQUFTcUcsV0FBVCxDQUFxQlU7QUFOdEIscUJBUkQ7QUFnQlRJLG1DQUFlakIsSUFBSWxHLElBQUosQ0FBU21ILGFBaEJmLEVBZ0I4QjtBQUN2Q0MsdUNBQW1CbEIsSUFBSWxHLElBQUosQ0FBUzBHLFFBQVQsQ0FBa0JXLGFBakI1QjtBQWtCVEMsOEJBQVVwQixJQUFJbEcsSUFBSixDQUFTc0gsUUFsQlYsQ0FrQm9CO0FBQzdCO0FBbkJTLGlCQUFiOztBQXNCQSxvQkFBSVgsZ0JBQWdCLElBQUlqQixJQUFKLENBQVNRLElBQUlsRyxJQUFKLENBQVNxRyxXQUFULElBQXdCSCxJQUFJbEcsSUFBSixDQUFTcUcsV0FBVCxDQUFxQk0sYUFBN0MsSUFBOEQsSUFBdkUsQ0FBcEI7QUFDQU8sdUJBQU8sZUFBUCxJQUEwQnZFLGVBQUU0RSxJQUFGLENBQU9DLE1BQVAsQ0FBY2IsYUFBZCxFQUE2QixhQUE3QixDQUExQjs7QUFFQSxzQkFBSzlDLEdBQUw7QUFDQSxzQkFBS2tCLE9BQUwsQ0FBYW1DLE1BQWI7O0FBRUE7QUFDQSxzQkFBS25DLE9BQUwsQ0FBYSxFQUFFLGdCQUFnQm1CLElBQUlsRyxJQUFKLENBQVNpRCxTQUFULENBQW1CSSxLQUFuQixJQUE0QiwrREFBOUMsRUFBYjtBQUNBSSxxQkFBS2dFLHFCQUFMLENBQTJCO0FBQ3ZCMUUsMkJBQU9tRCxJQUFJbEcsSUFBSixDQUFTcUcsV0FBVCxDQUFxQm5EO0FBREwsaUJBQTNCO0FBR0Esc0JBQUtaLFVBQUwsQ0FBZ0JvRixhQUFoQixHQUFnQyxJQUFJQSxzQkFBSixDQUFrQixLQUFsQixFQUF3QnhCLElBQUlsRyxJQUFKLENBQVMySCxVQUFqQyxDQUFoQztBQUNBLHNCQUFLckYsVUFBTCxDQUFnQkMsYUFBaEIsR0FBZ0MsSUFBSXFGLHNCQUFKLENBQWtCLEtBQWxCLENBQWhDO0FBQ0E7QUFDQTtBQUNBbEksb0JBQUltSSxZQUFKLENBQWlCLE1BQUs3RSxRQUFMLENBQWN5RCxVQUEvQixFQUNLWixJQURMLENBQ1UsVUFBQzdGLElBQUQsRUFBVTtBQUNaLDBCQUFLZ0QsUUFBTCxDQUFjOEUsU0FBZCxHQUEwQjlILElBQTFCO0FBQ0EsMEJBQUtzQyxVQUFMLENBQWdCeUYsT0FBaEIsR0FBMEIsSUFBSUMsdUJBQUosQ0FBWSxLQUFaLENBQTFCO0FBQ0EsMEJBQUsxRixVQUFMLENBQWdCRSxNQUFoQixHQUF5QixJQUFJeUYsbUJBQUosQ0FBZSxLQUFmLEVBQXFCL0IsSUFBSWxHLElBQUosQ0FBUzBHLFFBQVQsQ0FBa0JELFVBQXZDLENBQXpCO0FBQ0gsaUJBTEwsRUFLT3lCLEtBTFAsQ0FLYSxVQUFDQyxHQUFELEVBQVM7QUFDZHJHLDRCQUFRc0csS0FBUixDQUFjRCxHQUFkO0FBQ0Esd0JBQUlqQixPQUFPQyxhQUFYLEVBQTBCO0FBQ3RCLDhCQUFLa0IsUUFBTCxHQURzQixDQUNMO0FBQ3BCO0FBQ0osaUJBVkw7QUFXQSxzQkFBS0MsV0FBTCxDQUFpQixnQkFBakIsRUFBbUMsVUFBU3JHLENBQVQsRUFBWTtBQUMzQ0gsNEJBQVFDLEdBQVIsQ0FBWSxnQkFBWjtBQUNILGlCQUZEO0FBR0gsYUFoRkQsTUFnRk87QUFDSCxvQkFBSW1FLElBQUlDLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN2QnJFLDRCQUFRc0csS0FBUixtQ0FBdUJsQyxJQUFJRSxHQUEzQixFQUR1QixDQUNVO0FBQ2pDLDBCQUFLakMsTUFBTCxDQUFZNEIsSUFBWixDQUFpQixNQUFLNUIsTUFBTCxDQUFZNkIsSUFBWixDQUFpQnVDLGdCQUFsQyxFQUFvRHJDLElBQUlDLElBQXhELEVBQThETCxTQUFTTCxRQUF2RSxFQUFpRixDQUFqRixFQUFvRixFQUFwRixPQUEyRlMsSUFBSUUsR0FBL0Y7QUFDSDtBQUNELHNCQUFLOUQsVUFBTCxDQUFnQkMsYUFBaEIsR0FBZ0MsSUFBSXFGLHNCQUFKLENBQWtCLEtBQWxCLENBQWhDO0FBQ0Esc0JBQUs3QyxPQUFMLENBQWE7QUFDVHBELDZCQUFTLElBREEsRUFDTTtBQUNmWCwyQkFBTztBQUNIRyw4QkFBTSxLQURIO0FBRUhxSCxtQ0FBVyxJQUZSO0FBR0hDLGtDQUFVdkMsSUFBSUUsR0FBSixJQUFXO0FBSGxCLHFCQUZFO0FBT1QvRSxrQ0FBYztBQVBMLGlCQUFiO0FBU0g7QUFDSixTQXBHRCxFQW9HRyxlQUFPO0FBQ05TLG9CQUFRQyxHQUFSLENBQVltRSxHQUFaO0FBQ0gsU0F0R0Q7QUF1R0gsS0EzT1E7O0FBNE9Ub0MsaUJBQWEscUJBQVNyRyxDQUFULEVBQVl5RyxXQUFaLEVBQXlCO0FBQ2xDLFlBQUlDLFFBQVFDLFNBQVNDLGNBQVQsQ0FBd0IsU0FBeEIsQ0FBWjtBQUNBRixjQUFNRyxnQkFBTixDQUF1QjdHLENBQXZCLEVBQTBCLFlBQVc7QUFDakN5RywyQkFBZUEsYUFBZjtBQUNBSyxnQkFBSUMsS0FBSixDQUFXLElBQUl0RCxJQUFKLEVBQUQsQ0FBYUMsT0FBYixFQUFWLEVBQWtDMUQsQ0FBbEM7QUFDSCxTQUhELEVBR0csS0FISDtBQUlILEtBbFBRO0FBbVBUb0csWUFuUFMsc0JBbVBFO0FBQUE7O0FBQ1A7QUFDQSxhQUFLdEQsT0FBTCxDQUFhLEVBQUUsUUFBUSxDQUFDLEtBQUsvRSxJQUFMLENBQVUwQixJQUFyQixFQUFiLEVBQTBDLFlBQU07QUFDNUMsZ0JBQUksT0FBSzFCLElBQUwsQ0FBVW1ILGFBQWQsRUFBNkI7QUFDekIsb0JBQUksQ0FBQyxPQUFLbkgsSUFBTCxDQUFVMEIsSUFBZixFQUFxQjtBQUNqQmpDLHlCQUFLd0osaUJBQUwsQ0FBdUIsTUFBdkIsRUFBNkIsS0FBN0I7QUFDSCxpQkFGRCxNQUVPO0FBQ0h4Six5QkFBS3dKLGlCQUFMLENBQXVCLE1BQXZCLEVBQTZCLElBQTdCO0FBQ0g7QUFDSixhQU5ELE1BTU87QUFDSHhKLHFCQUFLd0osaUJBQUwsQ0FBdUIsTUFBdkI7QUFDSDtBQUVKLFNBWEQ7QUFZSCxLQWpRUTs7QUFrUVRDLHVCQUFtQiw2QkFBVztBQUMxQnpGLGFBQUswRixTQUFMLENBQWU7QUFDWHBHLDZDQURXO0FBRVhxRyxrQkFBTTtBQUZLLFNBQWY7QUFJQTNKLGFBQUs0SixXQUFMLENBQWlCLElBQWpCO0FBQ0EsYUFBS2xFLE9BQUwsQ0FBYW1FLElBQWIsQ0FBa0IsbUJBQWxCO0FBQ0gsS0F6UVE7O0FBMlFUQyx3QkFBb0IsOEJBQVc7QUFDM0I5SixhQUFLK0osY0FBTCxDQUFvQixJQUFwQjtBQUNBLGFBQUtyRSxPQUFMLENBQWFtRSxJQUFiLENBQWtCLG9CQUFsQjtBQUNILEtBOVFROztBQWdSVEcsa0JBQWMsd0JBQVc7QUFDckIsYUFBS3RFLE9BQUwsQ0FBYW1FLElBQWIsQ0FBa0Isa0JBQWxCO0FBQ0gsS0FsUlE7O0FBb1JUOzs7QUFHQUksYUFBUyxtQkFBVztBQUNoQixZQUFJM0osT0FBTyxJQUFYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBTixhQUFLa0ssZUFBTCxDQUFxQjVKLElBQXJCO0FBQ0FOLGFBQUt3SixpQkFBTCxDQUF1QmxKLElBQXZCO0FBQ0FOLGFBQUttSyxnQkFBTCxDQUFzQjdKLElBQXRCO0FBQ0E7QUFDQTtBQUNILEtBblNROztBQXFTVDs7O0FBR0E4SixZQUFRLGtCQUFXO0FBQ2YsYUFBSzFFLE9BQUwsQ0FBYW1FLElBQWIsQ0FBa0IsVUFBbEI7QUFDSCxLQTFTUTs7QUE0U1Q7OztBQUdBUSxZQUFRLGtCQUFXO0FBQ2ZoSyxpQkFBU3VGLE9BQVQsQ0FBaUJpRSxJQUFqQixDQUFzQixVQUF0QjtBQUNBLGFBQUtuRSxPQUFMLENBQWFtRSxJQUFiLENBQWtCLFVBQWxCO0FBQ0gsS0FsVFE7O0FBb1RUUyxXQXBUUyxtQkFvVERDLEdBcFRDLEVBb1RJO0FBQ1RsSSxnQkFBUW1JLElBQVIsQ0FBYUQsR0FBYjtBQUNILEtBdFRROzs7QUF3VFQ7OztBQUdBRSxjQUFVLG9CQUFXO0FBQ2pCLGFBQUsvRSxPQUFMLENBQWFtRSxJQUFiLENBQWtCLFlBQWxCO0FBQ0EsYUFBS25FLE9BQUwsQ0FBYWdGLEdBQWI7QUFDQSxhQUFLcEYsT0FBTCxDQUFhO0FBQ1Q5RSxzQkFBVSxJQUREO0FBRVRDLHVCQUFXLE1BRkY7QUFHVEMsb0JBQVEsSUFIQztBQUlUQyxzQkFBVSxJQUpEO0FBS1RDLHFCQUFTLENBQUM7QUFDTkMsc0JBQU0sQ0FEQTtBQUVOQyx5QkFBUztBQUZILGFBQUQsQ0FMQTtBQVNUQywwQkFBYyxHQVRMO0FBVVRDLGdDQUFvQixJQVZYO0FBV1RDLDZCQUFpQixLQVhSO0FBWVRDLHdCQUFZLEtBWkg7QUFhVEMsdUJBQVcsRUFiRjtBQWNUQyw0QkFBZ0IsRUFkUDtBQWVUQywwQkFBYyxFQWZMO0FBZ0JUQywwQkFBYyxDQWhCTDtBQWlCVFUsNEJBQWdCLENBakJQO0FBa0JUVCxtQkFBTztBQUNIQyx5QkFBUyxLQUROO0FBRUhDLDJCQUFXLEtBRlI7QUFHSEMsc0JBQU0sS0FISDtBQUlIQyx5QkFBUyxLQUpOO0FBS0h3RCxxQkFBSztBQUxGO0FBbEJFLFNBQWI7QUEwQkE7QUFDQTtBQUNIO0FBMVZRLENBQWI7QUE0VkF3RixLQUFLQyxPQUFPQyxNQUFQLENBQWMsRUFBZCxFQUFrQnZLLElBQWxCLENBQUwsRSIsImZpbGUiOiJwYWdlcy9zL3Jvb20uanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyByb29tIGZyb20gJy4vYWN0aW9ucy9yb29tQWN0aW9uLmpzJztcbmltcG9ydCAqIGFzIHJlcSBmcm9tICcuL3NlcnZpY2UvcmVxU2VydmljZSc7XG4vLyBpbXBvcnQgUGxheWVyQ29udHJvbCBmcm9tICcuL2FjdGlvbnMvcGxheWVyQWN0aW9uJztcbmltcG9ydCBQbGF5ZXJDb250cm9sIGZyb20gJy4vYWN0aW9ucy9wbGF5ZXJBY3Rpb24nO1xuaW1wb3J0IE1lc3NhZ2VCb3ggZnJvbSAnLi9hY3Rpb25zL21zZ0FjdGlvbic7XG5pbXBvcnQgU2VuZEJveCBmcm9tICcuL2FjdGlvbnMvc2VuZE1zZ0FjdGlvbic7XG5pbXBvcnQgcHJhaXNlQ29udHJvbCBmcm9tICcuL2FjdGlvbnMvcHJhaXNlQWN0aW9uJztcbmltcG9ydCAqIGFzIHV0aWxzIGZyb20gXCIuL2NvbW1vbi91dGlsc1wiO1xuaW1wb3J0IF8gZnJvbSBcIi4uLy4uL2NvbW1vbi91dGlscy91dGlsXCI7XG5pbXBvcnQgRW1pdHRlciBmcm9tICcuLi8uLi9jb21tb24vZW1pdHRlci9FbWl0dGVyJztcbmltcG9ydCBTZW5zb3IgZnJvbSAnLi4vLi4vY29tbW9uL3NlbnNvci9qc1NlbnNvcic7XG5pbXBvcnQgKiBhcyB1c2VyIGZyb20gJy4vY29tbW9uL3VzZXInO1xuLy8gaW1wb3J0IG11dGlBY2NvdW50IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvbXV0aUFjY291bnQvbXV0aUFjY291bnQnXG5cbmNvbnN0IGFwcCA9IGdldEFwcCgpO1xuY29uc3QgcGFnZSA9IHtcbiAgICAvKipcbiAgICAgKiDpobXpnaLnmoTliJ3lp4vmlbDmja5cbiAgICAgKi9cbiAgICBkYXRhOiB7XG4gICAgICAgIGVycm9yVGlwOiB0cnVlLFxuICAgICAgICBhY3RpdmVUYWI6IFwiY2hhdFwiLFxuICAgICAgICByb29tSWQ6IG51bGwsXG4gICAgICAgIGhvc3RJbmZvOiBudWxsLFxuICAgICAgICBtc2dMaXN0OiBbe1xuICAgICAgICAgICAgdHlwZTogMCxcbiAgICAgICAgICAgIGNvbnRlbnQ6IFwi5q2j5Zyo6ZO+5o6l6IGK5aSp5a6kLi4uLi4uXCJcbiAgICAgICAgfV0sXG4gICAgICAgIHNjcm9sbEhlaWdodDogMTAwLFxuICAgICAgICBzY3JvbGxIaWRlTG9hZE1vcmU6IHRydWUsXG4gICAgICAgIHNjcm9sbEFuaW1hdGlvbjogZmFsc2UsXG4gICAgICAgIGlucHV0Rm9jdXM6IGZhbHNlLFxuICAgICAgICBpbnB1dFRleHQ6IFwiXCIsXG4gICAgICAgIGlucHV0QXZhaWxhYmxlOiBcIlwiLFxuICAgICAgICBzaG93S2V5Ym9hcmQ6IFwiXCIsXG4gICAgICAgIHZpZGVvQm9keVRvcDogMCxcbiAgICAgICAgdmlkZW86IHtcbiAgICAgICAgICAgIG5lZWRWSVA6IGZhbHNlLFxuICAgICAgICAgICAgbmVlZExvZ2luOiBmYWxzZSxcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgb2ZmbGluZTogZmFsc2VcbiAgICAgICAgfSxcbiAgICAgICAgcHJldmlld0NvdmVyOiAnJyxcbiAgICAgICAgcm9vbVN0YXR1czogMCxcbiAgICAgICAgZm9sbG93ZWQ6IGZhbHNlLFxuICAgICAgICByZWNvbW1lbmRMaXN0OiBbXSxcbiAgICAgICAga2V5Ym9hcmRIZWlnaHQ6IDAsXG4gICAgICAgIG9wZW46IGZhbHNlLFxuICAgICAgICBlcnJSb29tOiBmYWxzZSwgLy/miL/pl7QgaW5pdCBlcnJvciBcbiAgICAgICAgY2FuUHJhaXNlOiBmYWxzZSAvLyDmmK/lkKblj6/ku6XngrnotZ4gXG4gICAgfSxcbiAgICBjbGlja0ZvbGxvdzogZnVuY3Rpb24oKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCfkuI3og73orqLpmIUhJyk7XG4gICAgICAgIHJldHVybjtcbiAgICAgICAgcm9vbS5jbGlja0ZvbGxvdyh0aGlzKTtcbiAgICB9LFxuICAgIGNsaWNrUmVjb21tZW5kOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIHJvb20ucmVkaXJlY3RUbyhlLmN1cnJlbnRUYXJnZXQuZGF0YXNldCk7XG4gICAgfSxcbiAgICBkZXN0cm95ZWQoKSB7XG4gICAgICAgIC8vIOmUgOavgSDlrprml7blmajkuovku7ZcbiAgICAgICAgdGhpcy5jb21wb25lbnRzLnBsYXllckNvbnRyb2wgJiYgdGhpcy5jb21wb25lbnRzLnBsYXllckNvbnRyb2wuZGVzdHJveWVkICYmIHRoaXMuY29tcG9uZW50cy5wbGF5ZXJDb250cm9sLmRlc3Ryb3llZCgpO1xuICAgICAgICB0aGlzLmNvbXBvbmVudHMubXNnQm94ICYmIHRoaXMuY29tcG9uZW50cy5tc2dCb3guZGVzdHJveWVkICYmIHRoaXMuY29tcG9uZW50cy5tc2dCb3guZGVzdHJveWVkKCk7XG4gICAgfSxcbiAgICBjbGlja011bHRpTGl2ZTogZnVuY3Rpb24oZSkge1xuICAgICAgICB0aGlzLmRlc3Ryb3llZCgpO1xuICAgICAgICBsZXQgZGF0YXNldCA9IGUuY3VycmVudFRhcmdldC5kYXRhc2V0O1xuICAgICAgICBpZiAoZGF0YXNldC5yb29taWQgPT0gdGhpcy5kYXRhLnJvb21JZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIF8uanVtcChgL3BhZ2VzL3Mvcm9vbT9yb29tSWQ9JHtkYXRhc2V0LnJvb21pZH1gKVxuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiDnlKjmiLfngrnlh7vlj7PkuIrop5LliIbkuqtcbiAgICAgKi9cbiAgICBvblNoYXJlQXBwTWVzc2FnZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIGxldCBzaGFyZURhdGEgPSB7XG4gICAgICAgICAgICB0aXRsZTogdGhpcy5yb29tSW5mby5zaGFyZUluZm8ucHJvZ3JhbU5hbWUsXG4gICAgICAgICAgICBjb250ZW50OiB0aGlzLnJvb21JbmZvLnNoYXJlSW5mby5kZXNjcmlwdGlvbixcbiAgICAgICAgICAgIGltYWdlVXJsOiB0aGlzLnJvb21JbmZvLnNoYXJlSW5mby5jb3Zlci5yZXBsYWNlKFwiXzQ4MF8yNzBcIiwgXCJfNDgwXzM2MFwiKSxcbiAgICAgICAgICAgIHBhdGg6ICdwYWdlcy9zL3Jvb20/cm9vbUlkPScgKyB0aGlzLnJvb21JbmZvLnJvb21JZFxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzaGFyZURhdGE7XG4gICAgfSxcblxuICAgIG9uQ2xpY2tTaGFyZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIGxldCBzaGFyZURhdGEgPSB7XG4gICAgICAgICAgICB0aXRsZTogdGhpcy5yb29tSW5mby5zaGFyZUluZm8ucHJvZ3JhbU5hbWUsXG4gICAgICAgICAgICBjb250ZW50OiB0aGlzLnJvb21JbmZvLnNoYXJlSW5mby5kZXNjcmlwdGlvbixcbiAgICAgICAgICAgIGltYWdlVXJsOiB0aGlzLnJvb21JbmZvLnNoYXJlSW5mby5jb3Zlci5yZXBsYWNlKFwiXzQ4MF8yNzBcIiwgXCJfNDgwXzM2MFwiKSxcbiAgICAgICAgICAgIHBhdGg6ICdwYWdlcy9zL3Jvb20/cm9vbUlkPScgKyB0aGlzLnJvb21JbmZvLnJvb21JZFxuICAgICAgICB9XG4gICAgICAgIHN3YW4ub3BlblNoYXJlKHNoYXJlRGF0YSk7XG4gICAgfSxcbiAgICAvKipcbiAgICAgKiDnlJ/lkb3lkajmnJ/lh73mlbAtLeebkeWQrOmhtemdouWKoOi9vVxuICAgICAqL1xuICAgIHN0b3JlOiB7XG4gICAgICAgIGRpc3BhdGNoOiBmdW5jdGlvbigpIHt9XG4gICAgfSxcbiAgICAvLyBpc011bHRpQWNjb3VudDogbXV0aUFjY291bnQuaXNNdWx0aUFjY291bnQsXG4gICAgc2VvKCkge1xuICAgICAgICBfLnNlbyh7XG4gICAgICAgICAgICBkZXNjOiBgJHt0aGlzLnJvb21JbmZvLnJvb21UaXRsZSB9X+ebtOaSrV/niLHlpYfoibrnm7Tmkq0t54ix5aWH6Im6YCxcbiAgICAgICAgICAgIGtleXdvcmRzOiBgJHt0aGlzLnJvb21JbmZvLnJvb21UaXRsZSB9LCR7dGhpcy5yb29tSW5mby5yb29tVGl0bGUgfV/nm7Tmkq0sJHt0aGlzLnJvb21JbmZvLnJvb21UaXRsZSB955u05pKt6Ze0LCR7dGhpcy5yb29tSW5mby5yb29tVGl0bGUgfeebtOaSreWcsOWdgO+8jCR7dGhpcy5yb29tSW5mby5yb29tVGl0bGUgfeebtOaSre+8jCR7dGhpcy5yb29tSW5mby5yb29tVGl0bGUgfeinhumikWAsXG4gICAgICAgICAgICB0aXRsZTogYCR7dGhpcy5yb29tSW5mby5yb29tVGl0bGUgfV/nm7Tmkq1f54ix5aWH6Im655u05pKtLeeIseWlh+iJumBcbiAgICAgICAgfSk7XG4gICAgfSxcbiAgICBzZW5zb3JJbml0KCkge1xuICAgICAgICBsZXQgZ2xvYmFsRGF0YSA9IGdldEFwcCgpLmdsb2JhbERhdGE7XG4gICAgICAgIHRoaXMuc2Vuc29yID0gbmV3IFNlbnNvcih7XG4gICAgICAgICAgICBwbDogZ2xvYmFsRGF0YS5wbCB8fCAnMl8yNF8yMDBfMycsXG4gICAgICAgICAgICB0OiBnbG9iYWxEYXRhLnRsIHx8ICdiZF9pb3MnLFxuICAgICAgICAgICAgdmVyc2lvbjogZ2xvYmFsRGF0YS52ZXJzaW9uIHx8ICcyLjAxLjA1JywgLy9iYWlkdSBtaW5pIHBybyB2ZXJzaW9uIFxuICAgICAgICAgICAgZGV2aWNlX2lkOiB1c2VyLmdldERldmljZUlkKCkgfHwgJycsXG4gICAgICAgICAgICB1c2VySWQ6ICcnLFxuICAgICAgICAgICAgdXJsOiAnL3YxL2xpdmUvaW5pdGlhbCcsXG4gICAgICAgICAgICByb29tSWQ6IHRoaXMuZGF0YS5yb29tSWQsXG4gICAgICAgIH0sIHN3YW4pO1xuICAgIH0sXG4gICAgY2FuUHJhaXNlSGFuZGxlcihib29sKSB7XG4gICAgICAgIHRoaXMuc2V0RGF0YSh7XG4gICAgICAgICAgICBcImNhblByYWlzZVwiOiBib29sIHx8IGZhbHNlXG4gICAgICAgIH0pO1xuICAgIH0sXG4gICAgb25Mb2FkKG9wdCkge1xuICAgICAgICAvLyBjb25zb2xlLmxvZygnb3B0OlxcdCcsIG9wdCk7XG4gICAgICAgIC8vIG9wdC5yb29tSWQgPSAnMzc1NDInO1xuICAgICAgICBvcHQgPSB7IHJvb21JZDogb3B0ICYmIG9wdC5yb29tSWQgfHwgdGhpcy5yb29tSW5mbyAmJiB0aGlzLnJvb21JbmZvLnFpcHVJZCB8fCAnJyB9O1xuICAgICAgICB0aGlzLnRyaWdnZXIgPSBuZXcgRW1pdHRlcigpO1xuICAgICAgICBnZXRBcHAoKS5lbWl0dGVyID0gdGhpcy50cmlnZ2VyO1xuICAgICAgICB0aGlzLnJvb21JbmZvID0ge307XG4gICAgICAgIHRoaXMuY29tcG9uZW50cyA9IHt9O1xuICAgICAgICB0aGlzLnNldERhdGEoe1xuICAgICAgICAgICAgXCJyb29tSWRcIjogb3B0LnJvb21JZCxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuY2FuUHJhaXNlSGFuZGxlcigpOyAvL+m7mOiupOS4jeiDveeCuei1nlxuICAgICAgICBpZiAob3B0LmVudikge1xuICAgICAgICAgICAgcmVxLnNldEVOVihcInRlc3RcIik7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zZW5zb3IgPSB7fTtcbiAgICAgICAgdGhpcy5zZW5zb3JJbml0KCk7XG4gICAgICAgIHRoaXMucmVxSW5pdChvcHQpO1xuICAgIH0sXG4gICAgcmVxSW5pdChvcHQpIHtcbiAgICAgICAgbGV0IGNvblN0YXJ0ID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICAgIHJlcS5nZXRSb29tSW5mbyhvcHQucm9vbUlkKS50aGVuKHJlcyA9PiB7XG4gICAgICAgICAgICBsZXQgY29uRW5kID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICAgICAgICB0aGlzLnNlbnNvci5wdXNoKHRoaXMuc2Vuc29yLkNPREUuUk9PTV9JTklUSUFMX1NVQ0NFU1MsIHJlcy5jb2RlLCBjb25FbmQgLSBjb25TdGFydCwgMCwgJycsIGAke3Jlcy5tc2d9YCk7XG5cbiAgICAgICAgICAgIGlmIChyZXMuY29kZSA9PT0gXCJBMDAwMDBcIikge1xuICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8gPSByZXMuZGF0YTtcbiAgICAgICAgICAgICAgICB0aGlzLnJvb21JbmZvLnJvb21JZCA9IHJlcy5kYXRhLnByb2dyYW1JbmZvLnFpcHVJZDtcbiAgICAgICAgICAgICAgICB0aGlzLnJvb21JbmZvLnFwSWQgPSByZXMuZGF0YS5wcm9ncmFtSW5mby5xaXB1SWQ7XG4gICAgICAgICAgICAgICAgdGhpcy5yb29tSW5mby5xaXB1SWQgPSByZXMuZGF0YS5wcm9ncmFtSW5mby5xaXB1SWQ7XG4gICAgICAgICAgICAgICAgdGhpcy5yb29tSW5mby5saXZlQ2hhbm5lbElkID0gcmVzLmRhdGEucHJvZ3JhbUluZm8ubGl2ZUNoYW5uZWxJZDtcbiAgICAgICAgICAgICAgICB0aGlzLnJvb21JbmZvLnJvb21TdGF0dXMgPSByZXMuZGF0YS5wcm9ncmFtSW5mby5wbGF5U3RhdHVzO1xuICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8ucGxheVN0YXR1cyA9IHJlcy5kYXRhLnByb2dyYW1JbmZvLnBsYXlTdGF0dXM7XG4gICAgICAgICAgICAgICAgLy8gdGhpcy5yb29tSW5mby5yb29tSWQgPSByZXMuZGF0YS5wcm9ncmFtSW5mby5yb29tSWQ7Ly9wZ2Mg54us5pyJXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5yb29tSW5mby5saXZlVHlwZUlkID0gcmVzLmRhdGEucHJvZ3JhbUluZm8ubGl2ZVR5cGVJZDsvL3BnYyDni6zmnIlcbiAgICAgICAgICAgICAgICAvLyB0aGlzLnJvb21JbmZvLmxpdmVTdWJUeXBlSWQgPSByZXMuZGF0YS5wcm9ncmFtSW5mby5saXZlU3ViVHlwZUlkOy8vcGdjIOeLrOaciVxuICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8uY2hhdFJvb21JZCA9IHJlcy5kYXRhLmNoYXRJbmZvLmNoYXRSb29tSWQ7XG4gICAgICAgICAgICAgICAgdGhpcy5yb29tSW5mby5zdGFydFBsYXlUaW1lID0gcmVzLmRhdGEuY2hhdEluZm8uY2hhdFJvb21JZDtcblxuICAgICAgICAgICAgICAgIC8vIHRoaXMucm9vbUluZm8uYW5jaG9yTmlja25hbWUgPSByZXMuZGF0YS5hbmNob3JJbmZvLmFuY2hvck5pY2tOYW1lOy8vcGdjIOeLrOaciVxuICAgICAgICAgICAgICAgIC8vIHRoaXMucm9vbUluZm8uc3ViVGl0bGUgPSByZXMuZGF0YS5wcm9ncmFtSW5mby5saXZlVHlwZU5hbWU7Ly9wZ2Mg54us5pyJXG5cbiAgICAgICAgICAgICAgICB0aGlzLnJvb21JbmZvLnNoYXJlSW5mbyA9IHJlcy5kYXRhLnNoYXJlSW5mbztcbiAgICAgICAgICAgICAgICBsZXQgcmVjb3JkT2JqID0ge1xuICAgICAgICAgICAgICAgICAgICByb29tSWQ6IHJlcy5kYXRhLnByb2dyYW1JbmZvLnJvb21JZCB8fCByZXMuZGF0YS5wcm9ncmFtSW5mby5xaXB1SWQsXG4gICAgICAgICAgICAgICAgICAgIHFpcHVJZDogcmVzLmRhdGEucHJvZ3JhbUluZm8ucWlwdUlkIHx8IHJlcy5kYXRhLnByb2dyYW1JbmZvLnJvb21JZCxcbiAgICAgICAgICAgICAgICAgICAgY292ZXJJbWFnZVVybDogcmVzLmRhdGEucHJvZ3JhbUluZm8uY292ZXJJbWFnZVVybCB8fCByZXMuZGF0YS5zaGFyZUluZm8uY292ZXIucmVwbGFjZShcIl80ODBfMjcwXCIsIFwiXzQ4MF8zNjBcIiksXG4gICAgICAgICAgICAgICAgICAgIGxpdmVUeXBlOiAyLFxuICAgICAgICAgICAgICAgICAgICBwbGF5TnVtYmVyOiByZXMuZGF0YS5wcm9ncmFtSW5mby5wbGF5TnVtYmVyLFxuICAgICAgICAgICAgICAgICAgICB0aXRsZTogcmVzLmRhdGEucHJvZ3JhbUluZm8ucHJvZ3JhbU5hbWUgfHwgcmVzLmRhdGEucHJvZ3JhbUluZm8uZGVzY3JpcHRpb24sXG4gICAgICAgICAgICAgICAgICAgIC8vIG5pY2tuYW1lOiByZXMuZGF0YS5hbmNob3JJbmZvLmFuY2hvck5pY2tOYW1lLC8v5LiN6IO95re75Yqg6L+Z5Liq5a2X5q61IOWboOS4uui/meS4quWtl+auteeahOWvueixoeS4jeWtmOWcqCDkvJrlr7zoh7TlkI7nu63ku6PnoIHltKnmuoMg5YGc5q2i5omn6KGMXG4gICAgICAgICAgICAgICAgICAgIHJlY29yZFRpbWU6IG5ldyBEYXRlKCkuZ2V0VGltZSgpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIF8ucmVjb3JkKHJlY29yZE9iaik7XG4gICAgICAgICAgICAgICAgbGV0IHBhcmFtcyA9IHtcbiAgICAgICAgICAgICAgICAgICAgcWlwdUlkOiByZXMuZGF0YS5wcm9ncmFtSW5mby5xaXB1SWQsXG4gICAgICAgICAgICAgICAgICAgIHJvb21UaXRsZTogcmVzLmRhdGEucHJvZ3JhbUluZm8ucHJvZ3JhbU5hbWUgfHwgcmVzLmRhdGEucHJvZ3JhbUluZm8uZGVzY3JpcHRpb24sXG4gICAgICAgICAgICAgICAgICAgIHJvb21TdGF0dXM6IHJlcy5kYXRhLnByb2dyYW1JbmZvLnBsYXlTdGF0dXMsIC8vMDog5pyq55+lLCAx77ya5pyq5byA5aeL77yMMu+8muebtOaSre+8jDM65Zue55yL5LitLDQ65Zue55yL57uT5p2fIO+8iOaWsOWinu+8iSw1Oui9ruaSreS4rSwgLTEg56aB5pKt5LitICAjIyMg5a+55bqU5ZCI5bm2IFwicm9vbVN0YXR1c1wiOiAxLCAvLyAwLuWBnOaSreS4rSAxLuebtOaSreS4rSAy56aB5pKt5LitIDPova7mkq3kuK0sXG4gICAgICAgICAgICAgICAgICAgIC8vIGZvbGxvd2VkOiByZXMuZGF0YS5hbmNob3JJbmZvLmlzRm9sbG93ZWQsLy9wZ2Mg54us5pyJXG4gICAgICAgICAgICAgICAgICAgIC8vIGZvbGxvd051bTogdXRpbHMuc2hvcnROdW0ocmVzLmRhdGEuYW5jaG9ySW5mby5hbmNob3JGb2xsb3dlck51bSksLy9wZ2Mg54us5pyJXG4gICAgICAgICAgICAgICAgICAgIC8vIGxpdmVUeXBlTmFtZTogcmVzLmRhdGEucHJvZ3JhbUluZm8ubGl2ZVR5cGVOYW1lLC8vcGdjIOeLrOaciVxuICAgICAgICAgICAgICAgICAgICAvLyBsaXZlU3ViVHlwZU5hbWU6IHJlcy5kYXRhLnByb2dyYW1JbmZvLmxpdmVTdWJUeXBlTmFtZSwvL3BnYyDni6zmnIlcbiAgICAgICAgICAgICAgICAgICAgaG9zdEluZm86IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFwiYW5jaG9ySWNvblwiOiByZXMuZGF0YS5hbmNob3JJbmZvLmFuY2hvckljb24sLy9wZ2Mg54us5pyJXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBcIm5pY2tuYW1lXCI6IHJlcy5kYXRhLmFuY2hvckluZm8uYW5jaG9yTmlja05hbWUsLy9wZ2Mg54us5pyJXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBcIndhbGxldFwiOiB1dGlscy5zaG9ydE51bShyZXMuZGF0YS53YWxsZXQpLC8vIOi6q+S7t1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gXCJwb3B1bGF0eVwiOiB1dGlscy5zaG9ydE51bShyZXMuZGF0YS5wb3B1bGF0eSksIC8vIOeDreW6plxuICAgICAgICAgICAgICAgICAgICAgICAgXCJpbmZvXCI6IHJlcy5kYXRhLnByb2dyYW1JbmZvLmRlc2NyaXB0aW9uIHx8IHJlcy5kYXRhLnByb2dyYW1JbmZvLnByb2dyYW1OYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJob3RcIjogcmVzLmRhdGEucHJvZ3JhbUluZm8ucGxheU51bWJlclxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBtdWx0aUxpdmVJbmZvOiByZXMuZGF0YS5tdWx0aUxpdmVJbmZvLCAvLyDlpJrmnLrkvY3mlbDmja5cbiAgICAgICAgICAgICAgICAgICAgY2hhdFNob3VsZERpc3BsYXk6IHJlcy5kYXRhLmNoYXRJbmZvLnNob3VsZERpc3BsYXksXG4gICAgICAgICAgICAgICAgICAgIHN3aXRjaGVyOiByZXMuZGF0YS5zd2l0Y2hlciwgLy/lvojlpJrlvIDlhbMgIOWMheaLrCDngrnotZ7mgLvlvIDlhbNcbiAgICAgICAgICAgICAgICAgICAgLy8gc3RhcnRQbGF5VGltZTogXy50aW1lLmZvcm1hdChyZXMuZGF0YS5wcm9ncmFtSW5mby5zdGFydFBsYXlUaW1lLCAneXl5eS1NTS1kZCBoaDptbScpXG4gICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgIGxldCBzdGFydFBsYXlUaW1lID0gbmV3IERhdGUocmVzLmRhdGEucHJvZ3JhbUluZm8gJiYgcmVzLmRhdGEucHJvZ3JhbUluZm8uc3RhcnRQbGF5VGltZSB8fCBudWxsKTtcbiAgICAgICAgICAgICAgICBwYXJhbXNbJ3N0YXJ0UGxheVRpbWUnXSA9IF8udGltZS5mb3JtYXQoc3RhcnRQbGF5VGltZSwgJ01NLWRkIGhoOm1tJyk7XG5cbiAgICAgICAgICAgICAgICB0aGlzLnNlbygpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YShwYXJhbXMpO1xuXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5zZXREYXRhKHsgJ3ByZXZpZXdDb3Zlcic6IHJlcy5kYXRhLnByb2dyYW1JbmZvLmNvdmVySW1hZ2VVcmwgfHwgJ2h0dHA6Ly93d3cuaXFpeWlwaWMuY29tL2NvbW1vbi9maXgvd3gtaXFpeWkvcGxheWVyLXRpcC1iZy5qcGcnIH0pXG4gICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKHsgJ3ByZXZpZXdDb3Zlcic6IHJlcy5kYXRhLnNoYXJlSW5mby5jb3ZlciB8fCAnaHR0cDovL3d3dy5pcWl5aXBpYy5jb20vY29tbW9uL2ZpeC93eC1pcWl5aS9wbGF5ZXItdGlwLWJnLmpwZycgfSlcbiAgICAgICAgICAgICAgICBzd2FuLnNldE5hdmlnYXRpb25CYXJUaXRsZSh7XG4gICAgICAgICAgICAgICAgICAgIHRpdGxlOiByZXMuZGF0YS5wcm9ncmFtSW5mby5wcm9ncmFtTmFtZVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHRoaXMuY29tcG9uZW50cy5wcmFpc2VDb250cm9sID0gbmV3IHByYWlzZUNvbnRyb2wodGhpcywgcmVzLmRhdGEucHJhaXNlSW5mbyk7XG4gICAgICAgICAgICAgICAgdGhpcy5jb21wb25lbnRzLnBsYXllckNvbnRyb2wgPSBuZXcgUGxheWVyQ29udHJvbCh0aGlzKTtcbiAgICAgICAgICAgICAgICAvLyDmi4nlj5bmnIDlkI7lh6DmnaHogYrlpKnorrDlvZVcbiAgICAgICAgICAgICAgICAvLyDogYrlpKnnmoTmmK/lkKbpnIDopoHlsZXnpLog5LiN5bGV56S6IOS5n+mcgOimgSBXUyDpk77mjqVcbiAgICAgICAgICAgICAgICByZXEuZ2V0TGF0ZXN0TXNnKHRoaXMucm9vbUluZm8uY2hhdFJvb21JZClcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4oKGRhdGEpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8ubGF0ZXN0TXNnID0gZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29tcG9uZW50cy5zZW5kQm94ID0gbmV3IFNlbmRCb3godGhpcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbXBvbmVudHMubXNnQm94ID0gbmV3IE1lc3NhZ2VCb3godGhpcywgcmVzLmRhdGEuY2hhdEluZm8uY2hhdFJvb21JZCk7XG4gICAgICAgICAgICAgICAgICAgIH0pLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwYXJhbXMubXVsdGlMaXZlSW5mbykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3djaE9wZW4oKTsgLy8g5omT5byA5aSa5py65L2NXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHRoaXMuZXZlbnRUZXN0ZXIoXCJjYW5wbGF5dGhyb3VnaFwiLCBmdW5jdGlvbihlKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdjYW5wbGF5dGhyb3VnaCcpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBpZiAocmVzLmNvZGUgPT09IFwiQTAwMDA1XCIpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihg6ZyA6KaB5oqV6YCS55qEYCwgcmVzLm1zZyk7IC8vIFRPRE8g5oqV6YCSXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2Vuc29yLnB1c2godGhpcy5zZW5zb3IuQ09ERS5ST09NX0lOSVRJQUxfRVJSLCByZXMuY29kZSwgY29uRW5kIC0gY29uU3RhcnQsIDAsICcnLCBgJHtyZXMubXNnfWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB0aGlzLmNvbXBvbmVudHMucGxheWVyQ29udHJvbCA9IG5ldyBQbGF5ZXJDb250cm9sKHRoaXMpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7XG4gICAgICAgICAgICAgICAgICAgIGVyclJvb206IHRydWUsIC8v5oi/6Ze06ZSZ6K+vXG4gICAgICAgICAgICAgICAgICAgIHZpZGVvOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93OiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9ySW5mbzogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yTXNnOiByZXMubXNnIHx8ICfop4bpopHkuI3og73mkq3mlL4nXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHByZXZpZXdDb3ZlcjogJ2h0dHA6Ly93d3cuaXFpeWlwaWMuY29tL2NvbW1vbi9maXgvd3gtaXFpeWkvcGxheWVyLXRpcC1iZy5qcGcnXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgcmVzID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlcyk7XG4gICAgICAgIH0pO1xuICAgIH0sXG4gICAgZXZlbnRUZXN0ZXI6IGZ1bmN0aW9uKGUsIGV2ZW50SGFubGVyKSB7XG4gICAgICAgIGxldCBNZWRpYSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd2aWRlb0lkJyk7XG4gICAgICAgIE1lZGlhLmFkZEV2ZW50TGlzdGVuZXIoZSwgZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICBldmVudEhhbmxlciAmJiBldmVudEhhbmxlcigpO1xuICAgICAgICAgICAgb3V0LmRlYnVnKChuZXcgRGF0ZSgpKS5nZXRUaW1lKCksIGUpXG4gICAgICAgIH0sIGZhbHNlKTtcbiAgICB9LFxuICAgIHN3Y2hPcGVuKCkge1xuICAgICAgICAvLyDliIfmjaLmnLrkvY3mmL7npLpcbiAgICAgICAgdGhpcy5zZXREYXRhKHsgJ29wZW4nOiAhdGhpcy5kYXRhLm9wZW4gfSwgKCkgPT4ge1xuICAgICAgICAgICAgaWYgKHRoaXMuZGF0YS5tdWx0aUxpdmVJbmZvKSB7XG4gICAgICAgICAgICAgICAgaWYgKCF0aGlzLmRhdGEub3Blbikge1xuICAgICAgICAgICAgICAgICAgICByb29tLmdldFJvb21JbmZvSGVpZ2h0KHRoaXMsIGZhbHNlKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByb29tLmdldFJvb21JbmZvSGVpZ2h0KHRoaXMsIHRydWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcm9vbS5nZXRSb29tSW5mb0hlaWdodCh0aGlzKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICB9KTtcbiAgICB9LFxuICAgIGFmdGVyTG9naW5UcmlnZ2VyOiBmdW5jdGlvbigpIHtcbiAgICAgICAgc3dhbi5zaG93VG9hc3Qoe1xuICAgICAgICAgICAgdGl0bGU6IGDnmbvlvZXmiJDlip9gLFxuICAgICAgICAgICAgaWNvbjogJ25vbmUnXG4gICAgICAgIH0pO1xuICAgICAgICByb29tLnJlZnJlc2hJbmZvKHRoaXMpO1xuICAgICAgICB0aGlzLnRyaWdnZXIuZW1pdChcImFmdGVyTG9naW5TdWNjZXNzXCIpO1xuICAgIH0sXG5cbiAgICBhZnRlckxvZ291dFRyaWdnZXI6IGZ1bmN0aW9uKCkge1xuICAgICAgICByb29tLnJlc2V0Rm9sbG93QnRuKHRoaXMpO1xuICAgICAgICB0aGlzLnRyaWdnZXIuZW1pdChcImFmdGVyTG9nb3V0U3VjY2Vzc1wiKTtcbiAgICB9LFxuXG4gICAgbG9naW5TdWNjZXNzOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy50cmlnZ2VyLmVtaXQoXCJhZnRlckdldFVzZXJJbmZvXCIpO1xuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiDnlJ/lkb3lkajmnJ/lh73mlbAtLeebkeWQrOmhtemdouWIneasoea4suafk+WujOaIkFxuICAgICAqL1xuICAgIG9uUmVhZHk6IGZ1bmN0aW9uKCkge1xuICAgICAgICBsZXQgcGFnZSA9IHRoaXM7XG4gICAgICAgIC8vIHRoaXMuc2V0RGF0YSh7XG4gICAgICAgIC8vICAgICBzY3JvbGxIZWlnaHQ6IHJvb20uZ2V0U2Nyb2xsSGVpZ2h0KCksXG4gICAgICAgIC8vICAgICByb29tSW5mb0hlaWdodDogcm9vbS5nZXRSb29tSW5mb0hlaWdodCgpLFxuICAgICAgICAvLyAgICAgaW5wdXRGaXRDbGFzczogcm9vbS5nZXRJbnB1dEZpdENsYXNzKClcbiAgICAgICAgLy8gfSk7XG4gICAgICAgIHJvb20uZ2V0U2Nyb2xsSGVpZ2h0KHBhZ2UpO1xuICAgICAgICByb29tLmdldFJvb21JbmZvSGVpZ2h0KHBhZ2UpO1xuICAgICAgICByb29tLmdldElucHV0Rml0Q2xhc3MocGFnZSk7XG4gICAgICAgIC8vIGdldEFwcCgpLmVtaXR0ZXIub24oXCJhZnRlckxvZ2luU3VjY2Vzc1wiLCB0aGlzLmFmdGVyTG9naW5UcmlnZ2VyKTtcbiAgICAgICAgLy8gZ2V0QXBwKCkuZW1pdHRlci5vbihcImFmdGVyTG9nb3V0U3VjY2Vzc1wiLCB0aGlzLmFmdGVyTG9nb3V0VHJpZ2dlcik7XG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIOeUn+WRveWRqOacn+WHveaVsC0t55uR5ZCs6aG16Z2i5pi+56S6XG4gICAgICovXG4gICAgb25TaG93OiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy50cmlnZ2VyLmVtaXQoXCJzaG93UGFnZVwiKTtcbiAgICB9LFxuXG4gICAgLyoqXG4gICAgICog55Sf5ZG95ZGo5pyf5Ye95pWwLS3nm5HlkKzpobXpnaLpmpDol49cbiAgICAgKi9cbiAgICBvbkhpZGU6IGZ1bmN0aW9uKCkge1xuICAgICAgICBnZXRBcHAoKS5lbWl0dGVyLmVtaXQoXCJoaWRlUGFnZVwiKTtcbiAgICAgICAgdGhpcy50cmlnZ2VyLmVtaXQoXCJoaWRlUGFnZVwiKTtcbiAgICB9LFxuXG4gICAgb25FcnJvcihhYWEpIHtcbiAgICAgICAgY29uc29sZS53YXJuKGFhYSk7XG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIOeUn+WRveWRqOacn+WHveaVsC0t55uR5ZCs6aG16Z2i5Y246L29XG4gICAgICovXG4gICAgb25VbmxvYWQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLnRyaWdnZXIuZW1pdChcInBhZ2VVbmxvYWRcIik7XG4gICAgICAgIHRoaXMudHJpZ2dlci5vZmYoKTtcbiAgICAgICAgdGhpcy5zZXREYXRhKHtcbiAgICAgICAgICAgIGVycm9yVGlwOiB0cnVlLFxuICAgICAgICAgICAgYWN0aXZlVGFiOiBcImNoYXRcIixcbiAgICAgICAgICAgIHJvb21JZDogbnVsbCxcbiAgICAgICAgICAgIGhvc3RJbmZvOiBudWxsLFxuICAgICAgICAgICAgbXNnTGlzdDogW3tcbiAgICAgICAgICAgICAgICB0eXBlOiAwLFxuICAgICAgICAgICAgICAgIGNvbnRlbnQ6IFwi5q2j5Zyo6ZO+5o6l6IGK5aSp5a6kLi4uLi4uXCJcbiAgICAgICAgICAgIH1dLFxuICAgICAgICAgICAgc2Nyb2xsSGVpZ2h0OiAxMDAsXG4gICAgICAgICAgICBzY3JvbGxIaWRlTG9hZE1vcmU6IHRydWUsXG4gICAgICAgICAgICBzY3JvbGxBbmltYXRpb246IGZhbHNlLFxuICAgICAgICAgICAgaW5wdXRGb2N1czogZmFsc2UsXG4gICAgICAgICAgICBpbnB1dFRleHQ6IFwiXCIsXG4gICAgICAgICAgICBpbnB1dEF2YWlsYWJsZTogXCJcIixcbiAgICAgICAgICAgIHNob3dLZXlib2FyZDogXCJcIixcbiAgICAgICAgICAgIHZpZGVvQm9keVRvcDogMCxcbiAgICAgICAgICAgIGtleWJvYXJkSGVpZ2h0OiAwLFxuICAgICAgICAgICAgdmlkZW86IHtcbiAgICAgICAgICAgICAgICBuZWVkVklQOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBuZWVkTG9naW46IGZhbHNlLFxuICAgICAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgICAgIG9mZmxpbmU6IGZhbHNlLFxuICAgICAgICAgICAgICAgIHVybDogXCJcIlxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgLy8gZ2V0QXBwKCkuZW1pdHRlci5vZmYoXCJhZnRlckxvZ2luU3VjY2Vzc1wiLHRoaXMuYWZ0ZXJMb2dpblRyaWdnZXIpO1xuICAgICAgICAvLyBnZXRBcHAoKS5lbWl0dGVyLm9mZihcImFmdGVyTG9nb3V0U3VjY2Vzc1wiLCB0aGlzLmFmdGVyTG9nb3V0VHJpZ2dlcik7XG4gICAgfVxufVxuUGFnZShPYmplY3QuYXNzaWduKHt9LCBwYWdlKSlcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvcy9yb29tLmpzIl0sInNvdXJjZVJvb3QiOiIifQ==