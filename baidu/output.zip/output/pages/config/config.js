window.define('124', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _session = __webpack_require__(32);

var _session2 = _interopRequireDefault(_session);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var app = getApp();
var globalData = app.globalData;
var originIcon = 'https://www.iqiyipic.com/common/fix/headicons/male-130.png';

var page = {
    data: {},
    onShow: function onShow() {},
    loginOut: function loginOut() {
        var _this = this;

        console.log(globalData);
        swan.showModal({
            title: '退出登录',
            cancelColor: '#999999',
            confirmColor: '#0099cc',
            success: function success(res) {
                if (res.confirm) {
                    console.log('用户点击了确定');
                    _this._updateUserInfo();
                } else if (res.cancel) {
                    console.log('用户点击了取消');
                }
            }
        });
    },
    _updateUserInfo: function _updateUserInfo() {
        this.setData('loginInfo.isLogin', false);
        this.setData('loginInfo.user.icon', originIcon);
        this.setData('loginInfo.user.nickname', '');
        this.setData('loginInfo.user.isVip', false);
        globalData.authCookie = '';
        _session2.default.Session.clear();
        _util2.default.jump({ 'type': 'back' });
    },
    jump: function jump(event) {
        var target = event.currentTarget;
        var url = target.dataset.url;
        // console.log(target);
        _util2.default.jump(url);
    },
    onReady: function onReady() {},
    onLoad: function onLoad() {
        // user.init();
    }
};

Page(Object.assign({}, page));
});
window.__swanRoute='pages/config/config';window.usingComponents=[];require('124');

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvY29uZmlnL2NvbmZpZy5qcyJdLCJuYW1lcyI6WyJhcHAiLCJnZXRBcHAiLCJnbG9iYWxEYXRhIiwib3JpZ2luSWNvbiIsInBhZ2UiLCJkYXRhIiwib25TaG93IiwibG9naW5PdXQiLCJjb25zb2xlIiwibG9nIiwic3dhbiIsInNob3dNb2RhbCIsInRpdGxlIiwiY2FuY2VsQ29sb3IiLCJjb25maXJtQ29sb3IiLCJzdWNjZXNzIiwicmVzIiwiY29uZmlybSIsIl91cGRhdGVVc2VySW5mbyIsImNhbmNlbCIsInNldERhdGEiLCJhdXRoQ29va2llIiwic2Vzc2lvbiIsIlNlc3Npb24iLCJjbGVhciIsIl8iLCJqdW1wIiwiZXZlbnQiLCJ0YXJnZXQiLCJjdXJyZW50VGFyZ2V0IiwidXJsIiwiZGF0YXNldCIsIm9uUmVhZHkiLCJvbkxvYWQiLCJQYWdlIiwiT2JqZWN0IiwiYXNzaWduIl0sIm1hcHBpbmdzIjoiOzs7QUFBQTs7OztBQUNBOzs7Ozs7QUFHQSxJQUFJQSxNQUFNQyxRQUFWO0FBQ0EsSUFBSUMsYUFBYUYsSUFBSUUsVUFBckI7QUFDQSxJQUFNQyxhQUFhLDREQUFuQjs7QUFFQSxJQUFNQyxPQUFPO0FBQ1RDLFVBQU0sRUFERztBQUVUQyxVQUZTLG9CQUVBLENBQ1IsQ0FIUTtBQUlUQyxZQUpTLHNCQUlFO0FBQUE7O0FBQ1BDLGdCQUFRQyxHQUFSLENBQVlQLFVBQVo7QUFDQVEsYUFBS0MsU0FBTCxDQUFlO0FBQ1hDLG1CQUFPLE1BREk7QUFFWEMseUJBQWEsU0FGRjtBQUdYQywwQkFBYyxTQUhIO0FBSVhDLHFCQUFTLGlCQUFDQyxHQUFELEVBQVM7QUFDZCxvQkFBR0EsSUFBSUMsT0FBUCxFQUFnQjtBQUNaVCw0QkFBUUMsR0FBUixDQUFZLFNBQVo7QUFDQSwwQkFBS1MsZUFBTDtBQUNILGlCQUhELE1BR08sSUFBR0YsSUFBSUcsTUFBUCxFQUFlO0FBQ2xCWCw0QkFBUUMsR0FBUixDQUFZLFNBQVo7QUFDSDtBQUNKO0FBWFUsU0FBZjtBQWFILEtBbkJRO0FBb0JUUyxtQkFwQlMsNkJBb0JTO0FBQ2QsYUFBS0UsT0FBTCxDQUFhLG1CQUFiLEVBQWtDLEtBQWxDO0FBQ0EsYUFBS0EsT0FBTCxDQUFhLHFCQUFiLEVBQW9DakIsVUFBcEM7QUFDQSxhQUFLaUIsT0FBTCxDQUFhLHlCQUFiLEVBQXdDLEVBQXhDO0FBQ0EsYUFBS0EsT0FBTCxDQUFhLHNCQUFiLEVBQXFDLEtBQXJDO0FBQ0FsQixtQkFBV21CLFVBQVgsR0FBd0IsRUFBeEI7QUFDQUMsMEJBQVFDLE9BQVIsQ0FBZ0JDLEtBQWhCO0FBQ0FDLHVCQUFFQyxJQUFGLENBQU8sRUFBQyxRQUFPLE1BQVIsRUFBUDtBQUNILEtBNUJRO0FBNkJUQSxRQTdCUyxnQkE2QkpDLEtBN0JJLEVBNkJHO0FBQ1IsWUFBTUMsU0FBU0QsTUFBTUUsYUFBckI7QUFDQSxZQUFNQyxNQUFNRixPQUFPRyxPQUFQLENBQWVELEdBQTNCO0FBQ0E7QUFDQUwsdUJBQUVDLElBQUYsQ0FBT0ksR0FBUDtBQUNILEtBbENRO0FBbUNURSxXQW5DUyxxQkFtQ0MsQ0FDVCxDQXBDUTtBQXFDVEMsVUFyQ1Msb0JBcUNBO0FBQ0w7QUFDSDtBQXZDUSxDQUFiOztBQTJDQUMsS0FBS0MsT0FBT0MsTUFBUCxDQUFjLEVBQWQsRUFBa0JoQyxJQUFsQixDQUFMLEUiLCJmaWxlIjoicGFnZXMvY29uZmlnL2NvbmZpZy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzZXNzaW9uIGZyb20gXCIuLi8uLi9jb21tb24vbG9naW4vc2Vzc2lvblwiO1xuaW1wb3J0IF8gZnJvbSBcIi4uLy4uL2NvbW1vbi91dGlscy91dGlsXCJcblxuXG5sZXQgYXBwID0gZ2V0QXBwKCk7XG5sZXQgZ2xvYmFsRGF0YSA9IGFwcC5nbG9iYWxEYXRhO1xuY29uc3Qgb3JpZ2luSWNvbiA9ICdodHRwczovL3d3dy5pcWl5aXBpYy5jb20vY29tbW9uL2ZpeC9oZWFkaWNvbnMvbWFsZS0xMzAucG5nJztcblxuY29uc3QgcGFnZSA9IHtcbiAgICBkYXRhOiB7fSxcbiAgICBvblNob3coKSB7XG4gICAgfSxcbiAgICBsb2dpbk91dCgpIHtcbiAgICAgICAgY29uc29sZS5sb2coZ2xvYmFsRGF0YSk7XG4gICAgICAgIHN3YW4uc2hvd01vZGFsKHtcbiAgICAgICAgICAgIHRpdGxlOiAn6YCA5Ye655m75b2VJyxcbiAgICAgICAgICAgIGNhbmNlbENvbG9yOiAnIzk5OTk5OScsXG4gICAgICAgICAgICBjb25maXJtQ29sb3I6ICcjMDA5OWNjJyxcbiAgICAgICAgICAgIHN1Y2Nlc3M6IChyZXMpID0+IHtcbiAgICAgICAgICAgICAgICBpZihyZXMuY29uZmlybSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygn55So5oi354K55Ye75LqG56Gu5a6aJyk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZVVzZXJJbmZvKCk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmKHJlcy5jYW5jZWwpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ+eUqOaIt+eCueWHu+S6huWPlua2iCcpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSxcbiAgICBfdXBkYXRlVXNlckluZm8oKSB7XG4gICAgICAgIHRoaXMuc2V0RGF0YSgnbG9naW5JbmZvLmlzTG9naW4nLCBmYWxzZSk7XG4gICAgICAgIHRoaXMuc2V0RGF0YSgnbG9naW5JbmZvLnVzZXIuaWNvbicsIG9yaWdpbkljb24pO1xuICAgICAgICB0aGlzLnNldERhdGEoJ2xvZ2luSW5mby51c2VyLm5pY2tuYW1lJywgJycpO1xuICAgICAgICB0aGlzLnNldERhdGEoJ2xvZ2luSW5mby51c2VyLmlzVmlwJywgZmFsc2UpO1xuICAgICAgICBnbG9iYWxEYXRhLmF1dGhDb29raWUgPSAnJztcbiAgICAgICAgc2Vzc2lvbi5TZXNzaW9uLmNsZWFyKCk7XG4gICAgICAgIF8uanVtcCh7J3R5cGUnOidiYWNrJ30pO1xuICAgIH0sXG4gICAganVtcChldmVudCkge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgICAgICBjb25zdCB1cmwgPSB0YXJnZXQuZGF0YXNldC51cmw7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHRhcmdldCk7XG4gICAgICAgIF8uanVtcCh1cmwpO1xuICAgIH0sXG4gICAgb25SZWFkeSgpIHtcbiAgICB9LFxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgLy8gdXNlci5pbml0KCk7XG4gICAgfVxufVxuXG5cblBhZ2UoT2JqZWN0LmFzc2lnbih7fSwgcGFnZSkpXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC9Vc2Vycy9ob3ViaW5nYmluZy9jb2RlL2lxaXlpL3FsaXZlX21pbmlwcm9ncmFtL2JhaWR1L3BhZ2VzL2NvbmZpZy9jb25maWcuanMiXSwic291cmNlUm9vdCI6IiJ9