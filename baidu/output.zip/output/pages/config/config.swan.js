

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave '.swan' file compiled runtime js
 * @author houyu(houyu01@baidu.com)
 */
(function (global, san) {
    global.errorMsg = [];

    // 自定义模板区域

    var templateComponents = Object.assign({}, {});

    var param = {};
    var filterArr = JSON.parse('[]');

    function processTemplateModule(filterTemplateArrs, filterModule) {
        eval(filterModule);
        var modules = {};
        var templateFiltersObj = {};
        filterTemplateArrs && filterTemplateArrs.forEach(function (element) {
            var filterName = element.filterName,
                func = element.func,
                module = element.module;

            modules[module] = eval(module);
            templateFiltersObj[filterName] = function () {
                var _modules$module;

                return (_modules$module = modules[module])[func].apply(_modules$module, arguments);
            };
        });
        return templateFiltersObj;
    }

    try {

        filterArr && filterArr.forEach(function (item) {
            param[item.module] = eval(item.module);
        });

        var pageContent = '<view class="page-config"><view class="list"><view class="logout"><button class="btn-warn" type="warn" on-bindtap="eventHappen(\'tap\', $event, \'loginOut\', \'\', \'bind\')">\u9000\u51FA\u767B\u5F55</button></view></view><view style="position: absolute;bottom:6.666666666666667vw;left: 0;right: 0;"><image src="/assets/logo/logo_live.png" class="c-icon-more" style="margin: auto;width: 27.866666666666667vw;height: 6.266666666666667vw;display: block;" /></view></view>';

        // 新的渲染逻辑
        var renderPage = function renderPage(filters, modules) {
            var componentFactory = global.componentFactory;
            // 获取所有内置组件 + 自定义组件的fragment
            var componentFragments = componentFactory.getAllComponents();

            // 所有的自定义组件
            ;

            // 路径与该组件映射
            var customAbsolutePathMap = {};

            // 当前页面使用的自定义组件
            var pageUsingComponentMap = JSON.parse('{}');

            // 生成该页面引用的自定义组件
            var customComponents = Object.keys(pageUsingComponentMap).reduce(function (customComponents, customName) {
                customComponents[customName] = customAbsolutePathMap[pageUsingComponentMap[customName]];
                return customComponents;
            }, {});

            // 启动页面渲染逻辑
            global.pageRender(pageContent, templateComponents, customComponents, filters, modules);
        };

        // 兼容旧的swan-core
        var oldPatch = function oldPatch(PageComponent) {
            Object.assign(PageComponent.components, {});
            // 渲染整个页面的顶层组件，template会在编译时被替换为用户的swan模板

            var Index = function (_PageComponent) {
                _inherits(Index, _PageComponent);

                function Index(options) {
                    _classCallCheck(this, Index);

                    var _this = _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));

                    _this.components = PageComponent.components;
                    return _this;
                }

                return Index;
            }(PageComponent);
            // 初始化页面对象


            Index.template = '<swan-wrapper tabindex="-1">' + pageContent + '</swan-wrapper>';
            var index = new Index();
            // 调用页面对象的加载完成通知
            index.slaveLoaded();
            // 监听等待initData，进行渲染
            index.communicator.onMessage('initData', function (params) {
                // 根据master传递的data，设定初始数据，并进行渲染
                index.setInitData(params);
                // 真正的页面渲染，发生在initData之后
                index.attach(document.body);
            }, { listenPreviousEvent: true });
        };

        if (global.pageRender) {
            renderPage(filterArr, param);
        } else {
            oldPatch(window.PageComponent);
        }
    } catch (e) {
        global.errorMsg['execError'] = e;
        throw e;
    }
})(window, window.san);

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvY29uZmlnL2NvbmZpZy5zd2FuIl0sIm5hbWVzIjpbImdsb2JhbCIsInNhbiIsImVycm9yTXNnIiwidGVtcGxhdGVDb21wb25lbnRzIiwiT2JqZWN0IiwiYXNzaWduIiwicGFyYW0iLCJmaWx0ZXJBcnIiLCJKU09OIiwicGFyc2UiLCJwcm9jZXNzVGVtcGxhdGVNb2R1bGUiLCJmaWx0ZXJUZW1wbGF0ZUFycnMiLCJmaWx0ZXJNb2R1bGUiLCJldmFsIiwibW9kdWxlcyIsInRlbXBsYXRlRmlsdGVyc09iaiIsImZvckVhY2giLCJmaWx0ZXJOYW1lIiwiZWxlbWVudCIsImZ1bmMiLCJtb2R1bGUiLCJpdGVtIiwicGFnZUNvbnRlbnQiLCJyZW5kZXJQYWdlIiwiZmlsdGVycyIsImNvbXBvbmVudEZhY3RvcnkiLCJjb21wb25lbnRGcmFnbWVudHMiLCJnZXRBbGxDb21wb25lbnRzIiwiY3VzdG9tQWJzb2x1dGVQYXRoTWFwIiwicGFnZVVzaW5nQ29tcG9uZW50TWFwIiwiY3VzdG9tQ29tcG9uZW50cyIsImtleXMiLCJyZWR1Y2UiLCJjdXN0b21OYW1lIiwicGFnZVJlbmRlciIsIm9sZFBhdGNoIiwiUGFnZUNvbXBvbmVudCIsImNvbXBvbmVudHMiLCJJbmRleCIsIm9wdGlvbnMiLCJ0ZW1wbGF0ZSIsImluZGV4Iiwic2xhdmVMb2FkZWQiLCJjb21tdW5pY2F0b3IiLCJvbk1lc3NhZ2UiLCJzZXRJbml0RGF0YSIsInBhcmFtcyIsImF0dGFjaCIsImRvY3VtZW50IiwiYm9keSIsImxpc3RlblByZXZpb3VzRXZlbnQiLCJ3aW5kb3ciLCJlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBOzs7O0FBSUEsQ0FBQyxVQUFDQSxNQUFELEVBQVNDLEdBQVQsRUFBZ0I7QUFDYkQsV0FBT0UsUUFBUCxHQUFrQixFQUFsQjs7QUFFQTs7QUFFQSxRQUFNQyxxQkFBcUJDLE9BQU9DLE1BQVAsQ0FBYyxFQUFkLEVBQWtCLEVBQWxCLENBQTNCOztBQUVBLFFBQUlDLFFBQVEsRUFBWjtBQUNBLFFBQU1DLFlBQVlDLEtBQUtDLEtBQUwsQ0FBVyxJQUFYLENBQWxCOztBQUdBLGFBQVNDLHFCQUFULENBQStCQyxrQkFBL0IsRUFBbURDLFlBQW5ELEVBQWlFO0FBQzdEQyxhQUFLRCxZQUFMO0FBQ0EsWUFBSUUsVUFBVSxFQUFkO0FBQ0EsWUFBSUMscUJBQXFCLEVBQXpCO0FBQ0FKLDhCQUFzQkEsbUJBQW1CSyxPQUFuQixDQUEyQixtQkFBVTtBQUFBLGdCQUNsREMsVUFEa0QsR0FDdEJDLE9BRHNCLENBQ2xERCxVQURrRDtBQUFBLGdCQUN0Q0UsSUFEc0MsR0FDdEJELE9BRHNCLENBQ3RDQyxJQURzQztBQUFBLGdCQUNoQ0MsTUFEZ0MsR0FDdEJGLE9BRHNCLENBQ2hDRSxNQURnQzs7QUFFdkROLG9CQUFRTSxNQUFSLElBQWtCUCxLQUFLTyxNQUFMLENBQWxCO0FBQ0FMLCtCQUFtQkUsVUFBbkIsSUFBaUM7QUFBQTs7QUFBQSx1QkFBWSwyQkFBUUcsTUFBUixHQUFnQkQsSUFBaEIsbUNBQVo7QUFBQSxhQUFqQztBQUNILFNBSnFCLENBQXRCO0FBS0EsZUFBT0osa0JBQVA7QUFDSDs7QUFFRCxRQUFJOztBQUVBUixxQkFBYUEsVUFBVVMsT0FBVixDQUFrQixnQkFBTztBQUNsQ1Ysa0JBQU1lLEtBQUtELE1BQVgsSUFBcUJQLEtBQUtRLEtBQUtELE1BQVYsQ0FBckI7QUFDSCxTQUZZLENBQWI7O0FBSUEsWUFBTUUscWVBQU47O0FBRUE7QUFDQSxZQUFNQyxhQUFhLFNBQWJBLFVBQWEsQ0FBQ0MsT0FBRCxFQUFVVixPQUFWLEVBQXFCO0FBQ3BDLGdCQUFNVyxtQkFBbUJ6QixPQUFPeUIsZ0JBQWhDO0FBQ0E7QUFDQSxnQkFBTUMscUJBQXFCRCxpQkFBaUJFLGdCQUFqQixFQUEzQjs7QUFFQTtBQUNBOztBQUVBO0FBQ0EsZ0JBQUlDLHdCQUF3QixFQUE1Qjs7QUFFQTtBQUNBLGdCQUFNQyx3QkFBd0JyQixLQUFLQyxLQUFMLE1BQTlCOztBQUVBO0FBQ0EsZ0JBQU1xQixtQkFBbUIxQixPQUFPMkIsSUFBUCxDQUFZRixxQkFBWixFQUFtQ0csTUFBbkMsQ0FBMEMsVUFBQ0YsZ0JBQUQsRUFBbUJHLFVBQW5CLEVBQWlDO0FBQ2hHSCxpQ0FBaUJHLFVBQWpCLElBQStCTCxzQkFBc0JDLHNCQUFzQkksVUFBdEIsQ0FBdEIsQ0FBL0I7QUFDQSx1QkFBT0gsZ0JBQVA7QUFDSCxhQUh3QixFQUd0QixFQUhzQixDQUF6Qjs7QUFLQTtBQUNBOUIsbUJBQU9rQyxVQUFQLENBQWtCWixXQUFsQixFQUErQm5CLGtCQUEvQixFQUFtRDJCLGdCQUFuRCxFQUFxRU4sT0FBckUsRUFBOEVWLE9BQTlFO0FBQ0gsU0F0QkQ7O0FBd0JBO0FBQ0EsWUFBTXFCLFdBQVcsU0FBWEEsUUFBVyxnQkFBZ0I7QUFDN0IvQixtQkFBT0MsTUFBUCxDQUFjK0IsY0FBY0MsVUFBNUIsRUFBd0MsRUFBeEM7QUFDQTs7QUFGNkIsZ0JBR3ZCQyxLQUh1QjtBQUFBOztBQUl6QiwrQkFBWUMsT0FBWixFQUFxQjtBQUFBOztBQUFBLDhIQUNYQSxPQURXOztBQUVqQiwwQkFBS0YsVUFBTCxHQUFrQkQsY0FBY0MsVUFBaEM7QUFGaUI7QUFHcEI7O0FBUHdCO0FBQUEsY0FHVEQsYUFIUztBQVU3Qjs7O0FBUE1FLGlCQUh1QixDQVFsQkUsUUFSa0Isb0NBUXdCbEIsV0FSeEI7QUFXN0IsZ0JBQU1tQixRQUFRLElBQUlILEtBQUosRUFBZDtBQUNBO0FBQ0FHLGtCQUFNQyxXQUFOO0FBQ0E7QUFDQUQsa0JBQU1FLFlBQU4sQ0FBbUJDLFNBQW5CLENBQTZCLFVBQTdCLEVBQXlDLGtCQUFTO0FBQzlDO0FBQ0FILHNCQUFNSSxXQUFOLENBQWtCQyxNQUFsQjtBQUNBO0FBQ0FMLHNCQUFNTSxNQUFOLENBQWFDLFNBQVNDLElBQXRCO0FBQ0gsYUFMRCxFQUtHLEVBQUNDLHFCQUFxQixJQUF0QixFQUxIO0FBTUgsU0FyQkQ7O0FBdUJBLFlBQUlsRCxPQUFPa0MsVUFBWCxFQUF1QjtBQUNuQlgsdUJBQVdoQixTQUFYLEVBQXNCRCxLQUF0QjtBQUNILFNBRkQsTUFHSztBQUNENkIscUJBQVNnQixPQUFPZixhQUFoQjtBQUNIO0FBQ0osS0EvREQsQ0FnRUEsT0FBT2dCLENBQVAsRUFBVTtBQUNOcEQsZUFBT0UsUUFBUCxDQUFnQixXQUFoQixJQUErQmtELENBQS9CO0FBQ0EsY0FBTUEsQ0FBTjtBQUNIO0FBQ0osQ0EzRkQsRUEyRkdELE1BM0ZILEVBMkZXQSxPQUFPbEQsR0EzRmxCLEUiLCJmaWxlIjoicGFnZXMvY29uZmlnL2NvbmZpZy5zd2FuLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAZmlsZSBzd2FuJ3Mgc2xhdmUgJy5zd2FuJyBmaWxlIGNvbXBpbGVkIHJ1bnRpbWUganNcbiAqIEBhdXRob3IgaG91eXUoaG91eXUwMUBiYWlkdS5jb20pXG4gKi9cbigoZ2xvYmFsLCBzYW4pID0+e1xuICAgIGdsb2JhbC5lcnJvck1zZyA9IFtdO1xuXG4gICAgLy8g6Ieq5a6a5LmJ5qih5p2/5Yy65Z+fXG4gICAgXG4gICAgY29uc3QgdGVtcGxhdGVDb21wb25lbnRzID0gT2JqZWN0LmFzc2lnbih7fSwge30pO1xuXG4gICAgbGV0IHBhcmFtID0ge307XG4gICAgY29uc3QgZmlsdGVyQXJyID0gSlNPTi5wYXJzZSgnW10nKTtcbiAgICBcblxuICAgIGZ1bmN0aW9uIHByb2Nlc3NUZW1wbGF0ZU1vZHVsZShmaWx0ZXJUZW1wbGF0ZUFycnMsIGZpbHRlck1vZHVsZSkge1xuICAgICAgICBldmFsKGZpbHRlck1vZHVsZSk7XG4gICAgICAgIGxldCBtb2R1bGVzID0ge307XG4gICAgICAgIGxldCB0ZW1wbGF0ZUZpbHRlcnNPYmogPSB7fTtcbiAgICAgICAgZmlsdGVyVGVtcGxhdGVBcnJzICYmIGZpbHRlclRlbXBsYXRlQXJycy5mb3JFYWNoKGVsZW1lbnQgPT57XG4gICAgICAgICAgICBsZXQge2ZpbHRlck5hbWUsIGZ1bmMsIG1vZHVsZX0gPSBlbGVtZW50O1xuICAgICAgICAgICAgbW9kdWxlc1ttb2R1bGVdID0gZXZhbChtb2R1bGUpO1xuICAgICAgICAgICAgdGVtcGxhdGVGaWx0ZXJzT2JqW2ZpbHRlck5hbWVdID0gKC4uLmFyZ3MpID0+bW9kdWxlc1ttb2R1bGVdW2Z1bmNdKC4uLmFyZ3MpO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHRlbXBsYXRlRmlsdGVyc09iajtcbiAgICB9XG5cbiAgICB0cnkge1xuXG4gICAgICAgIGZpbHRlckFyciAmJiBmaWx0ZXJBcnIuZm9yRWFjaChpdGVtID0+e1xuICAgICAgICAgICAgcGFyYW1baXRlbS5tb2R1bGVdID0gZXZhbChpdGVtLm1vZHVsZSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGNvbnN0IHBhZ2VDb250ZW50ID0gYDx2aWV3IGNsYXNzPVwicGFnZS1jb25maWdcIj48dmlldyBjbGFzcz1cImxpc3RcIj48dmlldyBjbGFzcz1cImxvZ291dFwiPjxidXR0b24gY2xhc3M9XCJidG4td2FyblwiIHR5cGU9XCJ3YXJuXCIgb24tYmluZHRhcD1cImV2ZW50SGFwcGVuKCd0YXAnLCAkZXZlbnQsICdsb2dpbk91dCcsICcnLCAnYmluZCcpXCI+6YCA5Ye655m75b2VPC9idXR0b24+PC92aWV3Pjwvdmlldz48dmlldyBzdHlsZT1cInBvc2l0aW9uOiBhYnNvbHV0ZTtib3R0b206Ni42NjY2NjY2NjY2NjY2Njd2dztsZWZ0OiAwO3JpZ2h0OiAwO1wiPjxpbWFnZSBzcmM9XCIvYXNzZXRzL2xvZ28vbG9nb19saXZlLnBuZ1wiIGNsYXNzPVwiYy1pY29uLW1vcmVcIiBzdHlsZT1cIm1hcmdpbjogYXV0bzt3aWR0aDogMjcuODY2NjY2NjY2NjY2NjY3dnc7aGVpZ2h0OiA2LjI2NjY2NjY2NjY2NjY2N3Z3O2Rpc3BsYXk6IGJsb2NrO1wiIC8+PC92aWV3Pjwvdmlldz5gO1xuXG4gICAgICAgIC8vIOaWsOeahOa4suafk+mAu+i+kVxuICAgICAgICBjb25zdCByZW5kZXJQYWdlID0gKGZpbHRlcnMsIG1vZHVsZXMpID0+e1xuICAgICAgICAgICAgY29uc3QgY29tcG9uZW50RmFjdG9yeSA9IGdsb2JhbC5jb21wb25lbnRGYWN0b3J5O1xuICAgICAgICAgICAgLy8g6I635Y+W5omA5pyJ5YaF572u57uE5Lu2ICsg6Ieq5a6a5LmJ57uE5Lu255qEZnJhZ21lbnRcbiAgICAgICAgICAgIGNvbnN0IGNvbXBvbmVudEZyYWdtZW50cyA9IGNvbXBvbmVudEZhY3RvcnkuZ2V0QWxsQ29tcG9uZW50cygpO1xuXG4gICAgICAgICAgICAvLyDmiYDmnInnmoToh6rlrprkuYnnu4Tku7ZcbiAgICAgICAgICAgIDtcblxuICAgICAgICAgICAgLy8g6Lev5b6E5LiO6K+l57uE5Lu25pig5bCEXG4gICAgICAgICAgICB2YXIgY3VzdG9tQWJzb2x1dGVQYXRoTWFwID0ge307XG5cbiAgICAgICAgICAgIC8vIOW9k+WJjemhtemdouS9v+eUqOeahOiHquWumuS5iee7hOS7tlxuICAgICAgICAgICAgY29uc3QgcGFnZVVzaW5nQ29tcG9uZW50TWFwID0gSlNPTi5wYXJzZShge31gKTtcblxuICAgICAgICAgICAgLy8g55Sf5oiQ6K+l6aG16Z2i5byV55So55qE6Ieq5a6a5LmJ57uE5Lu2XG4gICAgICAgICAgICBjb25zdCBjdXN0b21Db21wb25lbnRzID0gT2JqZWN0LmtleXMocGFnZVVzaW5nQ29tcG9uZW50TWFwKS5yZWR1Y2UoKGN1c3RvbUNvbXBvbmVudHMsIGN1c3RvbU5hbWUpID0+e1xuICAgICAgICAgICAgICAgIGN1c3RvbUNvbXBvbmVudHNbY3VzdG9tTmFtZV0gPSBjdXN0b21BYnNvbHV0ZVBhdGhNYXBbcGFnZVVzaW5nQ29tcG9uZW50TWFwW2N1c3RvbU5hbWVdXTtcbiAgICAgICAgICAgICAgICByZXR1cm4gY3VzdG9tQ29tcG9uZW50cztcbiAgICAgICAgICAgIH0sIHt9KTtcblxuICAgICAgICAgICAgLy8g5ZCv5Yqo6aG16Z2i5riy5p+T6YC76L6RXG4gICAgICAgICAgICBnbG9iYWwucGFnZVJlbmRlcihwYWdlQ29udGVudCwgdGVtcGxhdGVDb21wb25lbnRzLCBjdXN0b21Db21wb25lbnRzLCBmaWx0ZXJzLCBtb2R1bGVzKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvLyDlhbzlrrnml6fnmoRzd2FuLWNvcmVcbiAgICAgICAgY29uc3Qgb2xkUGF0Y2ggPSBQYWdlQ29tcG9uZW50ID0+e1xuICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihQYWdlQ29tcG9uZW50LmNvbXBvbmVudHMsIHt9KTtcbiAgICAgICAgICAgIC8vIOa4suafk+aVtOS4qumhtemdoueahOmhtuWxgue7hOS7tu+8jHRlbXBsYXRl5Lya5Zyo57yW6K+R5pe26KKr5pu/5o2i5Li655So5oi355qEc3dhbuaooeadv1xuICAgICAgICAgICAgY2xhc3MgSW5kZXggZXh0ZW5kcyBQYWdlQ29tcG9uZW50IHtcbiAgICAgICAgICAgICAgICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgICAgICAgICAgICAgICAgIHN1cGVyKG9wdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbXBvbmVudHMgPSBQYWdlQ29tcG9uZW50LmNvbXBvbmVudHM7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHN0YXRpYyB0ZW1wbGF0ZSA9IGA8c3dhbi13cmFwcGVyIHRhYmluZGV4PVwiLTFcIj4ke3BhZ2VDb250ZW50fTwvc3dhbi13cmFwcGVyPmA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyDliJ3lp4vljJbpobXpnaLlr7nosaFcbiAgICAgICAgICAgIGNvbnN0IGluZGV4ID0gbmV3IEluZGV4KCk7XG4gICAgICAgICAgICAvLyDosIPnlKjpobXpnaLlr7nosaHnmoTliqDovb3lrozmiJDpgJrnn6VcbiAgICAgICAgICAgIGluZGV4LnNsYXZlTG9hZGVkKCk7XG4gICAgICAgICAgICAvLyDnm5HlkKznrYnlvoVpbml0RGF0Ye+8jOi/m+ihjOa4suafk1xuICAgICAgICAgICAgaW5kZXguY29tbXVuaWNhdG9yLm9uTWVzc2FnZSgnaW5pdERhdGEnLCBwYXJhbXMgPT57XG4gICAgICAgICAgICAgICAgLy8g5qC55o2ubWFzdGVy5Lyg6YCS55qEZGF0Ye+8jOiuvuWumuWIneWni+aVsOaNru+8jOW5tui/m+ihjOa4suafk1xuICAgICAgICAgICAgICAgIGluZGV4LnNldEluaXREYXRhKHBhcmFtcyk7XG4gICAgICAgICAgICAgICAgLy8g55yf5q2j55qE6aG16Z2i5riy5p+T77yM5Y+R55Sf5ZyoaW5pdERhdGHkuYvlkI5cbiAgICAgICAgICAgICAgICBpbmRleC5hdHRhY2goZG9jdW1lbnQuYm9keSk7XG4gICAgICAgICAgICB9LCB7bGlzdGVuUHJldmlvdXNFdmVudDogdHJ1ZX0pO1xuICAgICAgICB9O1xuXG4gICAgICAgIGlmIChnbG9iYWwucGFnZVJlbmRlcikge1xuICAgICAgICAgICAgcmVuZGVyUGFnZShmaWx0ZXJBcnIsIHBhcmFtKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIG9sZFBhdGNoKHdpbmRvdy5QYWdlQ29tcG9uZW50KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjYXRjaCAoZSkge1xuICAgICAgICBnbG9iYWwuZXJyb3JNc2dbJ2V4ZWNFcnJvciddID0gZTtcbiAgICAgICAgdGhyb3cgZTtcbiAgICB9XG59KSh3aW5kb3csIHdpbmRvdy5zYW4pO1xuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC9Vc2Vycy9ob3ViaW5nYmluZy9jb2RlL2lxaXlpL3FsaXZlX21pbmlwcm9ncmFtL2JhaWR1L3BhZ2VzL2NvbmZpZy9jb25maWcuc3dhbiJdLCJzb3VyY2VSb290IjoiIn0=