

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave '.swan' file compiled runtime js
 * @author houyu(houyu01@baidu.com)
 */
(function (global, san) {
    global.errorMsg = [];

    // 自定义模板区域

    var templateComponents = Object.assign({}, {});

    var param = {};
    var filterArr = JSON.parse('[]');

    function processTemplateModule(filterTemplateArrs, filterModule) {
        eval(filterModule);
        var modules = {};
        var templateFiltersObj = {};
        filterTemplateArrs && filterTemplateArrs.forEach(function (element) {
            var filterName = element.filterName,
                func = element.func,
                module = element.module;

            modules[module] = eval(module);
            templateFiltersObj[filterName] = function () {
                var _modules$module;

                return (_modules$module = modules[module])[func].apply(_modules$module, arguments);
            };
        });
        return templateFiltersObj;
    }

    try {

        filterArr && filterArr.forEach(function (item) {
            param[item.module] = eval(item.module);
        });

        var pageContent = '<view class="container page-rank"><template ><view class="rank-top-content"><view class="rank-filtrate-list"><view s-for="item, index in rankTypeList" class="rank-tab-sub {{item.id == currOption.rankTypeId?\'active\':\'\'}}" data-rank-type-id="{{item.id}}" on-bindtouchstart="eventHappen(\'touchstart\', $event, \'switchRankHandle\', \'\', \'catch\')">{{item.name}}\n                </view></view></view></template><view class="rank-group"><view s-if="{{!dataList || dataList.length==0}}"><template ><view class="rank-list"><view s-for="item, index in [{},{},{},{},{},{},{},{}]" class="rank-item"><view class="rank-n"><view class="subtypeName text-ellips" style="width: 6.666666666666667vw;height:3.3333333333333335vw;background: #f3f3f3;margin-bottom: 0.6666666666666666vw;"></view></view><view class="rank-icon"><view class="author-face" style="width: 13.333333333333334vw;height: 13.333333333333334vw;background: #f3f3f3;border: 0;"></view></view><view class="rank-name"><view class="subtypeName text-ellips" style="width: 20vw;height:2vw;background: #f3f3f3;margin-bottom: 0.6666666666666666vw;"></view><view class="subtypeName text-ellips" style="width: 46.666666666666664vw;height:2vw;background: #f3f3f3;"></view></view><view class="rank-label"><view class="living" style="display: inline-block; width: 100%;height: 100%;background: #f3f3f3;"></view></view></view></view></template></view><view class="rank-title-tab"><view s-for="group in dataList" class="rank-title-tab-item {{group.title == currOption.title?\'active\':\'\'}}" data-title="{{group.title}}" on-bindtouchstart="eventHappen(\'touchstart\', $event, \'switchTitleHandle\', \'\', \'catch\')">{{group.title}}</view></view><template s-for="group in dataList"><view class="rank-list" s-if="currOption.title == group.title"><view s-for=" item, index in group.result" class="rank-item top-{{index+1}}" data-room-id="{{item.roomId}}" on-bindtap="eventHappen(\'tap\', $event, \'playVideo\', \'\', \'bind\')"><view class="rank-n"><text class="text">{{(index+1)}}</text></view><view class="rank-icon"><image class="author-face" src="{{item.icon}}" mode="aspectFill" /></view><view class="rank-name"><text class="nickname text-ellips">{{item.nickname}}</text><text class="subtypeName text-ellips">{{item.subtypeName}}</text></view><view class="rank-label"><image s-if="item.liveStatus == 1 " class="living" src="https://www.iqiyipic.com/qlive/fix/img/living16x16.gif" mode="aspectFill" /></view></view></view></template></view></view>';

        // 新的渲染逻辑
        var renderPage = function renderPage(filters, modules) {
            var componentFactory = global.componentFactory;
            // 获取所有内置组件 + 自定义组件的fragment
            var componentFragments = componentFactory.getAllComponents();

            // 所有的自定义组件
            ;

            // 路径与该组件映射
            var customAbsolutePathMap = {};

            // 当前页面使用的自定义组件
            var pageUsingComponentMap = JSON.parse('{}');

            // 生成该页面引用的自定义组件
            var customComponents = Object.keys(pageUsingComponentMap).reduce(function (customComponents, customName) {
                customComponents[customName] = customAbsolutePathMap[pageUsingComponentMap[customName]];
                return customComponents;
            }, {});

            // 启动页面渲染逻辑
            global.pageRender(pageContent, templateComponents, customComponents, filters, modules);
        };

        // 兼容旧的swan-core
        var oldPatch = function oldPatch(PageComponent) {
            Object.assign(PageComponent.components, {});
            // 渲染整个页面的顶层组件，template会在编译时被替换为用户的swan模板

            var Index = function (_PageComponent) {
                _inherits(Index, _PageComponent);

                function Index(options) {
                    _classCallCheck(this, Index);

                    var _this = _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));

                    _this.components = PageComponent.components;
                    return _this;
                }

                return Index;
            }(PageComponent);
            // 初始化页面对象


            Index.template = '<swan-wrapper tabindex="-1">' + pageContent + '</swan-wrapper>';
            var index = new Index();
            // 调用页面对象的加载完成通知
            index.slaveLoaded();
            // 监听等待initData，进行渲染
            index.communicator.onMessage('initData', function (params) {
                // 根据master传递的data，设定初始数据，并进行渲染
                index.setInitData(params);
                // 真正的页面渲染，发生在initData之后
                index.attach(document.body);
            }, { listenPreviousEvent: true });
        };

        if (global.pageRender) {
            renderPage(filterArr, param);
        } else {
            oldPatch(window.PageComponent);
        }
    } catch (e) {
        global.errorMsg['execError'] = e;
        throw e;
    }
})(window, window.san);

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvcmFuay9yYW5rLnN3YW4iXSwibmFtZXMiOlsiZ2xvYmFsIiwic2FuIiwiZXJyb3JNc2ciLCJ0ZW1wbGF0ZUNvbXBvbmVudHMiLCJPYmplY3QiLCJhc3NpZ24iLCJwYXJhbSIsImZpbHRlckFyciIsIkpTT04iLCJwYXJzZSIsInByb2Nlc3NUZW1wbGF0ZU1vZHVsZSIsImZpbHRlclRlbXBsYXRlQXJycyIsImZpbHRlck1vZHVsZSIsImV2YWwiLCJtb2R1bGVzIiwidGVtcGxhdGVGaWx0ZXJzT2JqIiwiZm9yRWFjaCIsImZpbHRlck5hbWUiLCJlbGVtZW50IiwiZnVuYyIsIm1vZHVsZSIsIml0ZW0iLCJwYWdlQ29udGVudCIsInJlbmRlclBhZ2UiLCJmaWx0ZXJzIiwiY29tcG9uZW50RmFjdG9yeSIsImNvbXBvbmVudEZyYWdtZW50cyIsImdldEFsbENvbXBvbmVudHMiLCJjdXN0b21BYnNvbHV0ZVBhdGhNYXAiLCJwYWdlVXNpbmdDb21wb25lbnRNYXAiLCJjdXN0b21Db21wb25lbnRzIiwia2V5cyIsInJlZHVjZSIsImN1c3RvbU5hbWUiLCJwYWdlUmVuZGVyIiwib2xkUGF0Y2giLCJQYWdlQ29tcG9uZW50IiwiY29tcG9uZW50cyIsIkluZGV4Iiwib3B0aW9ucyIsInRlbXBsYXRlIiwiaW5kZXgiLCJzbGF2ZUxvYWRlZCIsImNvbW11bmljYXRvciIsIm9uTWVzc2FnZSIsInNldEluaXREYXRhIiwicGFyYW1zIiwiYXR0YWNoIiwiZG9jdW1lbnQiLCJib2R5IiwibGlzdGVuUHJldmlvdXNFdmVudCIsIndpbmRvdyIsImUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUE7Ozs7QUFJQSxDQUFDLFVBQUNBLE1BQUQsRUFBU0MsR0FBVCxFQUFnQjtBQUNiRCxXQUFPRSxRQUFQLEdBQWtCLEVBQWxCOztBQUVBOztBQUVBLFFBQU1DLHFCQUFxQkMsT0FBT0MsTUFBUCxDQUFjLEVBQWQsRUFBa0IsRUFBbEIsQ0FBM0I7O0FBRUEsUUFBSUMsUUFBUSxFQUFaO0FBQ0EsUUFBTUMsWUFBWUMsS0FBS0MsS0FBTCxDQUFXLElBQVgsQ0FBbEI7O0FBR0EsYUFBU0MscUJBQVQsQ0FBK0JDLGtCQUEvQixFQUFtREMsWUFBbkQsRUFBaUU7QUFDN0RDLGFBQUtELFlBQUw7QUFDQSxZQUFJRSxVQUFVLEVBQWQ7QUFDQSxZQUFJQyxxQkFBcUIsRUFBekI7QUFDQUosOEJBQXNCQSxtQkFBbUJLLE9BQW5CLENBQTJCLG1CQUFVO0FBQUEsZ0JBQ2xEQyxVQURrRCxHQUN0QkMsT0FEc0IsQ0FDbERELFVBRGtEO0FBQUEsZ0JBQ3RDRSxJQURzQyxHQUN0QkQsT0FEc0IsQ0FDdENDLElBRHNDO0FBQUEsZ0JBQ2hDQyxNQURnQyxHQUN0QkYsT0FEc0IsQ0FDaENFLE1BRGdDOztBQUV2RE4sb0JBQVFNLE1BQVIsSUFBa0JQLEtBQUtPLE1BQUwsQ0FBbEI7QUFDQUwsK0JBQW1CRSxVQUFuQixJQUFpQztBQUFBOztBQUFBLHVCQUFZLDJCQUFRRyxNQUFSLEdBQWdCRCxJQUFoQixtQ0FBWjtBQUFBLGFBQWpDO0FBQ0gsU0FKcUIsQ0FBdEI7QUFLQSxlQUFPSixrQkFBUDtBQUNIOztBQUVELFFBQUk7O0FBRUFSLHFCQUFhQSxVQUFVUyxPQUFWLENBQWtCLGdCQUFPO0FBQ2xDVixrQkFBTWUsS0FBS0QsTUFBWCxJQUFxQlAsS0FBS1EsS0FBS0QsTUFBVixDQUFyQjtBQUNILFNBRlksQ0FBYjs7QUFJQSxZQUFNRSw4OEVBQU47O0FBR0E7QUFDQSxZQUFNQyxhQUFhLFNBQWJBLFVBQWEsQ0FBQ0MsT0FBRCxFQUFVVixPQUFWLEVBQXFCO0FBQ3BDLGdCQUFNVyxtQkFBbUJ6QixPQUFPeUIsZ0JBQWhDO0FBQ0E7QUFDQSxnQkFBTUMscUJBQXFCRCxpQkFBaUJFLGdCQUFqQixFQUEzQjs7QUFFQTtBQUNBOztBQUVBO0FBQ0EsZ0JBQUlDLHdCQUF3QixFQUE1Qjs7QUFFQTtBQUNBLGdCQUFNQyx3QkFBd0JyQixLQUFLQyxLQUFMLE1BQTlCOztBQUVBO0FBQ0EsZ0JBQU1xQixtQkFBbUIxQixPQUFPMkIsSUFBUCxDQUFZRixxQkFBWixFQUFtQ0csTUFBbkMsQ0FBMEMsVUFBQ0YsZ0JBQUQsRUFBbUJHLFVBQW5CLEVBQWlDO0FBQ2hHSCxpQ0FBaUJHLFVBQWpCLElBQStCTCxzQkFBc0JDLHNCQUFzQkksVUFBdEIsQ0FBdEIsQ0FBL0I7QUFDQSx1QkFBT0gsZ0JBQVA7QUFDSCxhQUh3QixFQUd0QixFQUhzQixDQUF6Qjs7QUFLQTtBQUNBOUIsbUJBQU9rQyxVQUFQLENBQWtCWixXQUFsQixFQUErQm5CLGtCQUEvQixFQUFtRDJCLGdCQUFuRCxFQUFxRU4sT0FBckUsRUFBOEVWLE9BQTlFO0FBQ0gsU0F0QkQ7O0FBd0JBO0FBQ0EsWUFBTXFCLFdBQVcsU0FBWEEsUUFBVyxnQkFBZ0I7QUFDN0IvQixtQkFBT0MsTUFBUCxDQUFjK0IsY0FBY0MsVUFBNUIsRUFBd0MsRUFBeEM7QUFDQTs7QUFGNkIsZ0JBR3ZCQyxLQUh1QjtBQUFBOztBQUl6QiwrQkFBWUMsT0FBWixFQUFxQjtBQUFBOztBQUFBLDhIQUNYQSxPQURXOztBQUVqQiwwQkFBS0YsVUFBTCxHQUFrQkQsY0FBY0MsVUFBaEM7QUFGaUI7QUFHcEI7O0FBUHdCO0FBQUEsY0FHVEQsYUFIUztBQVU3Qjs7O0FBUE1FLGlCQUh1QixDQVFsQkUsUUFSa0Isb0NBUXdCbEIsV0FSeEI7QUFXN0IsZ0JBQU1tQixRQUFRLElBQUlILEtBQUosRUFBZDtBQUNBO0FBQ0FHLGtCQUFNQyxXQUFOO0FBQ0E7QUFDQUQsa0JBQU1FLFlBQU4sQ0FBbUJDLFNBQW5CLENBQTZCLFVBQTdCLEVBQXlDLGtCQUFTO0FBQzlDO0FBQ0FILHNCQUFNSSxXQUFOLENBQWtCQyxNQUFsQjtBQUNBO0FBQ0FMLHNCQUFNTSxNQUFOLENBQWFDLFNBQVNDLElBQXRCO0FBQ0gsYUFMRCxFQUtHLEVBQUNDLHFCQUFxQixJQUF0QixFQUxIO0FBTUgsU0FyQkQ7O0FBdUJBLFlBQUlsRCxPQUFPa0MsVUFBWCxFQUF1QjtBQUNuQlgsdUJBQVdoQixTQUFYLEVBQXNCRCxLQUF0QjtBQUNILFNBRkQsTUFHSztBQUNENkIscUJBQVNnQixPQUFPZixhQUFoQjtBQUNIO0FBQ0osS0FoRUQsQ0FpRUEsT0FBT2dCLENBQVAsRUFBVTtBQUNOcEQsZUFBT0UsUUFBUCxDQUFnQixXQUFoQixJQUErQmtELENBQS9CO0FBQ0EsY0FBTUEsQ0FBTjtBQUNIO0FBQ0osQ0E1RkQsRUE0RkdELE1BNUZILEVBNEZXQSxPQUFPbEQsR0E1RmxCLEUiLCJmaWxlIjoicGFnZXMvcmFuay9yYW5rLnN3YW4uanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBmaWxlIHN3YW4ncyBzbGF2ZSAnLnN3YW4nIGZpbGUgY29tcGlsZWQgcnVudGltZSBqc1xuICogQGF1dGhvciBob3V5dShob3V5dTAxQGJhaWR1LmNvbSlcbiAqL1xuKChnbG9iYWwsIHNhbikgPT57XG4gICAgZ2xvYmFsLmVycm9yTXNnID0gW107XG5cbiAgICAvLyDoh6rlrprkuYnmqKHmnb/ljLrln59cbiAgICBcbiAgICBjb25zdCB0ZW1wbGF0ZUNvbXBvbmVudHMgPSBPYmplY3QuYXNzaWduKHt9LCB7fSk7XG5cbiAgICBsZXQgcGFyYW0gPSB7fTtcbiAgICBjb25zdCBmaWx0ZXJBcnIgPSBKU09OLnBhcnNlKCdbXScpO1xuICAgIFxuXG4gICAgZnVuY3Rpb24gcHJvY2Vzc1RlbXBsYXRlTW9kdWxlKGZpbHRlclRlbXBsYXRlQXJycywgZmlsdGVyTW9kdWxlKSB7XG4gICAgICAgIGV2YWwoZmlsdGVyTW9kdWxlKTtcbiAgICAgICAgbGV0IG1vZHVsZXMgPSB7fTtcbiAgICAgICAgbGV0IHRlbXBsYXRlRmlsdGVyc09iaiA9IHt9O1xuICAgICAgICBmaWx0ZXJUZW1wbGF0ZUFycnMgJiYgZmlsdGVyVGVtcGxhdGVBcnJzLmZvckVhY2goZWxlbWVudCA9PntcbiAgICAgICAgICAgIGxldCB7ZmlsdGVyTmFtZSwgZnVuYywgbW9kdWxlfSA9IGVsZW1lbnQ7XG4gICAgICAgICAgICBtb2R1bGVzW21vZHVsZV0gPSBldmFsKG1vZHVsZSk7XG4gICAgICAgICAgICB0ZW1wbGF0ZUZpbHRlcnNPYmpbZmlsdGVyTmFtZV0gPSAoLi4uYXJncykgPT5tb2R1bGVzW21vZHVsZV1bZnVuY10oLi4uYXJncyk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdGVtcGxhdGVGaWx0ZXJzT2JqO1xuICAgIH1cblxuICAgIHRyeSB7XG5cbiAgICAgICAgZmlsdGVyQXJyICYmIGZpbHRlckFyci5mb3JFYWNoKGl0ZW0gPT57XG4gICAgICAgICAgICBwYXJhbVtpdGVtLm1vZHVsZV0gPSBldmFsKGl0ZW0ubW9kdWxlKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3QgcGFnZUNvbnRlbnQgPSBgPHZpZXcgY2xhc3M9XCJjb250YWluZXIgcGFnZS1yYW5rXCI+PHRlbXBsYXRlID48dmlldyBjbGFzcz1cInJhbmstdG9wLWNvbnRlbnRcIj48dmlldyBjbGFzcz1cInJhbmstZmlsdHJhdGUtbGlzdFwiPjx2aWV3IHMtZm9yPVwiaXRlbSwgaW5kZXggaW4gcmFua1R5cGVMaXN0XCIgY2xhc3M9XCJyYW5rLXRhYi1zdWIge3tpdGVtLmlkID09IGN1cnJPcHRpb24ucmFua1R5cGVJZD8nYWN0aXZlJzonJ319XCIgZGF0YS1yYW5rLXR5cGUtaWQ9XCJ7e2l0ZW0uaWR9fVwiIG9uLWJpbmR0b3VjaHN0YXJ0PVwiZXZlbnRIYXBwZW4oJ3RvdWNoc3RhcnQnLCAkZXZlbnQsICdzd2l0Y2hSYW5rSGFuZGxlJywgJycsICdjYXRjaCcpXCI+e3tpdGVtLm5hbWV9fVxuICAgICAgICAgICAgICAgIDwvdmlldz48L3ZpZXc+PC92aWV3PjwvdGVtcGxhdGU+PHZpZXcgY2xhc3M9XCJyYW5rLWdyb3VwXCI+PHZpZXcgcy1pZj1cInt7IWRhdGFMaXN0IHx8IGRhdGFMaXN0Lmxlbmd0aD09MH19XCI+PHRlbXBsYXRlID48dmlldyBjbGFzcz1cInJhbmstbGlzdFwiPjx2aWV3IHMtZm9yPVwiaXRlbSwgaW5kZXggaW4gW3t9LHt9LHt9LHt9LHt9LHt9LHt9LHt9XVwiIGNsYXNzPVwicmFuay1pdGVtXCI+PHZpZXcgY2xhc3M9XCJyYW5rLW5cIj48dmlldyBjbGFzcz1cInN1YnR5cGVOYW1lIHRleHQtZWxsaXBzXCIgc3R5bGU9XCJ3aWR0aDogNi42NjY2NjY2NjY2NjY2Njd2dztoZWlnaHQ6My4zMzMzMzMzMzMzMzMzMzM1dnc7YmFja2dyb3VuZDogI2YzZjNmMzttYXJnaW4tYm90dG9tOiAwLjY2NjY2NjY2NjY2NjY2NjZ2dztcIj48L3ZpZXc+PC92aWV3Pjx2aWV3IGNsYXNzPVwicmFuay1pY29uXCI+PHZpZXcgY2xhc3M9XCJhdXRob3ItZmFjZVwiIHN0eWxlPVwid2lkdGg6IDEzLjMzMzMzMzMzMzMzMzMzNHZ3O2hlaWdodDogMTMuMzMzMzMzMzMzMzMzMzM0dnc7YmFja2dyb3VuZDogI2YzZjNmMztib3JkZXI6IDA7XCI+PC92aWV3Pjwvdmlldz48dmlldyBjbGFzcz1cInJhbmstbmFtZVwiPjx2aWV3IGNsYXNzPVwic3VidHlwZU5hbWUgdGV4dC1lbGxpcHNcIiBzdHlsZT1cIndpZHRoOiAyMHZ3O2hlaWdodDoydnc7YmFja2dyb3VuZDogI2YzZjNmMzttYXJnaW4tYm90dG9tOiAwLjY2NjY2NjY2NjY2NjY2NjZ2dztcIj48L3ZpZXc+PHZpZXcgY2xhc3M9XCJzdWJ0eXBlTmFtZSB0ZXh0LWVsbGlwc1wiIHN0eWxlPVwid2lkdGg6IDQ2LjY2NjY2NjY2NjY2NjY2NHZ3O2hlaWdodDoydnc7YmFja2dyb3VuZDogI2YzZjNmMztcIj48L3ZpZXc+PC92aWV3Pjx2aWV3IGNsYXNzPVwicmFuay1sYWJlbFwiPjx2aWV3IGNsYXNzPVwibGl2aW5nXCIgc3R5bGU9XCJkaXNwbGF5OiBpbmxpbmUtYmxvY2s7IHdpZHRoOiAxMDAlO2hlaWdodDogMTAwJTtiYWNrZ3JvdW5kOiAjZjNmM2YzO1wiPjwvdmlldz48L3ZpZXc+PC92aWV3Pjwvdmlldz48L3RlbXBsYXRlPjwvdmlldz48dmlldyBjbGFzcz1cInJhbmstdGl0bGUtdGFiXCI+PHZpZXcgcy1mb3I9XCJncm91cCBpbiBkYXRhTGlzdFwiIGNsYXNzPVwicmFuay10aXRsZS10YWItaXRlbSB7e2dyb3VwLnRpdGxlID09IGN1cnJPcHRpb24udGl0bGU/J2FjdGl2ZSc6Jyd9fVwiIGRhdGEtdGl0bGU9XCJ7e2dyb3VwLnRpdGxlfX1cIiBvbi1iaW5kdG91Y2hzdGFydD1cImV2ZW50SGFwcGVuKCd0b3VjaHN0YXJ0JywgJGV2ZW50LCAnc3dpdGNoVGl0bGVIYW5kbGUnLCAnJywgJ2NhdGNoJylcIj57e2dyb3VwLnRpdGxlfX08L3ZpZXc+PC92aWV3Pjx0ZW1wbGF0ZSBzLWZvcj1cImdyb3VwIGluIGRhdGFMaXN0XCI+PHZpZXcgY2xhc3M9XCJyYW5rLWxpc3RcIiBzLWlmPVwiY3Vyck9wdGlvbi50aXRsZSA9PSBncm91cC50aXRsZVwiPjx2aWV3IHMtZm9yPVwiIGl0ZW0sIGluZGV4IGluIGdyb3VwLnJlc3VsdFwiIGNsYXNzPVwicmFuay1pdGVtIHRvcC17e2luZGV4KzF9fVwiIGRhdGEtcm9vbS1pZD1cInt7aXRlbS5yb29tSWR9fVwiIG9uLWJpbmR0YXA9XCJldmVudEhhcHBlbigndGFwJywgJGV2ZW50LCAncGxheVZpZGVvJywgJycsICdiaW5kJylcIj48dmlldyBjbGFzcz1cInJhbmstblwiPjx0ZXh0IGNsYXNzPVwidGV4dFwiPnt7KGluZGV4KzEpfX08L3RleHQ+PC92aWV3Pjx2aWV3IGNsYXNzPVwicmFuay1pY29uXCI+PGltYWdlIGNsYXNzPVwiYXV0aG9yLWZhY2VcIiBzcmM9XCJ7e2l0ZW0uaWNvbn19XCIgbW9kZT1cImFzcGVjdEZpbGxcIiAvPjwvdmlldz48dmlldyBjbGFzcz1cInJhbmstbmFtZVwiPjx0ZXh0IGNsYXNzPVwibmlja25hbWUgdGV4dC1lbGxpcHNcIj57e2l0ZW0ubmlja25hbWV9fTwvdGV4dD48dGV4dCBjbGFzcz1cInN1YnR5cGVOYW1lIHRleHQtZWxsaXBzXCI+e3tpdGVtLnN1YnR5cGVOYW1lfX08L3RleHQ+PC92aWV3Pjx2aWV3IGNsYXNzPVwicmFuay1sYWJlbFwiPjxpbWFnZSBzLWlmPVwiaXRlbS5saXZlU3RhdHVzID09IDEgXCIgY2xhc3M9XCJsaXZpbmdcIiBzcmM9XCJodHRwczovL3d3dy5pcWl5aXBpYy5jb20vcWxpdmUvZml4L2ltZy9saXZpbmcxNngxNi5naWZcIiBtb2RlPVwiYXNwZWN0RmlsbFwiIC8+PC92aWV3Pjwvdmlldz48L3ZpZXc+PC90ZW1wbGF0ZT48L3ZpZXc+PC92aWV3PmA7XG5cbiAgICAgICAgLy8g5paw55qE5riy5p+T6YC76L6RXG4gICAgICAgIGNvbnN0IHJlbmRlclBhZ2UgPSAoZmlsdGVycywgbW9kdWxlcykgPT57XG4gICAgICAgICAgICBjb25zdCBjb21wb25lbnRGYWN0b3J5ID0gZ2xvYmFsLmNvbXBvbmVudEZhY3Rvcnk7XG4gICAgICAgICAgICAvLyDojrflj5bmiYDmnInlhoXnva7nu4Tku7YgKyDoh6rlrprkuYnnu4Tku7bnmoRmcmFnbWVudFxuICAgICAgICAgICAgY29uc3QgY29tcG9uZW50RnJhZ21lbnRzID0gY29tcG9uZW50RmFjdG9yeS5nZXRBbGxDb21wb25lbnRzKCk7XG5cbiAgICAgICAgICAgIC8vIOaJgOacieeahOiHquWumuS5iee7hOS7tlxuICAgICAgICAgICAgO1xuXG4gICAgICAgICAgICAvLyDot6/lvoTkuI7or6Xnu4Tku7bmmKDlsIRcbiAgICAgICAgICAgIHZhciBjdXN0b21BYnNvbHV0ZVBhdGhNYXAgPSB7fTtcblxuICAgICAgICAgICAgLy8g5b2T5YmN6aG16Z2i5L2/55So55qE6Ieq5a6a5LmJ57uE5Lu2XG4gICAgICAgICAgICBjb25zdCBwYWdlVXNpbmdDb21wb25lbnRNYXAgPSBKU09OLnBhcnNlKGB7fWApO1xuXG4gICAgICAgICAgICAvLyDnlJ/miJDor6XpobXpnaLlvJXnlKjnmoToh6rlrprkuYnnu4Tku7ZcbiAgICAgICAgICAgIGNvbnN0IGN1c3RvbUNvbXBvbmVudHMgPSBPYmplY3Qua2V5cyhwYWdlVXNpbmdDb21wb25lbnRNYXApLnJlZHVjZSgoY3VzdG9tQ29tcG9uZW50cywgY3VzdG9tTmFtZSkgPT57XG4gICAgICAgICAgICAgICAgY3VzdG9tQ29tcG9uZW50c1tjdXN0b21OYW1lXSA9IGN1c3RvbUFic29sdXRlUGF0aE1hcFtwYWdlVXNpbmdDb21wb25lbnRNYXBbY3VzdG9tTmFtZV1dO1xuICAgICAgICAgICAgICAgIHJldHVybiBjdXN0b21Db21wb25lbnRzO1xuICAgICAgICAgICAgfSwge30pO1xuXG4gICAgICAgICAgICAvLyDlkK/liqjpobXpnaLmuLLmn5PpgLvovpFcbiAgICAgICAgICAgIGdsb2JhbC5wYWdlUmVuZGVyKHBhZ2VDb250ZW50LCB0ZW1wbGF0ZUNvbXBvbmVudHMsIGN1c3RvbUNvbXBvbmVudHMsIGZpbHRlcnMsIG1vZHVsZXMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8vIOWFvOWuueaXp+eahHN3YW4tY29yZVxuICAgICAgICBjb25zdCBvbGRQYXRjaCA9IFBhZ2VDb21wb25lbnQgPT57XG4gICAgICAgICAgICBPYmplY3QuYXNzaWduKFBhZ2VDb21wb25lbnQuY29tcG9uZW50cywge30pO1xuICAgICAgICAgICAgLy8g5riy5p+T5pW05Liq6aG16Z2i55qE6aG25bGC57uE5Lu277yMdGVtcGxhdGXkvJrlnKjnvJbor5Hml7booqvmm7/mjaLkuLrnlKjmiLfnmoRzd2Fu5qih5p2/XG4gICAgICAgICAgICBjbGFzcyBJbmRleCBleHRlbmRzIFBhZ2VDb21wb25lbnQge1xuICAgICAgICAgICAgICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICAgICAgICAgICAgICAgICAgc3VwZXIob3B0aW9ucyk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY29tcG9uZW50cyA9IFBhZ2VDb21wb25lbnQuY29tcG9uZW50cztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgc3RhdGljIHRlbXBsYXRlID0gYDxzd2FuLXdyYXBwZXIgdGFiaW5kZXg9XCItMVwiPiR7cGFnZUNvbnRlbnR9PC9zd2FuLXdyYXBwZXI+YDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIOWIneWni+WMlumhtemdouWvueixoVxuICAgICAgICAgICAgY29uc3QgaW5kZXggPSBuZXcgSW5kZXgoKTtcbiAgICAgICAgICAgIC8vIOiwg+eUqOmhtemdouWvueixoeeahOWKoOi9veWujOaIkOmAmuefpVxuICAgICAgICAgICAgaW5kZXguc2xhdmVMb2FkZWQoKTtcbiAgICAgICAgICAgIC8vIOebkeWQrOetieW+hWluaXREYXRh77yM6L+b6KGM5riy5p+TXG4gICAgICAgICAgICBpbmRleC5jb21tdW5pY2F0b3Iub25NZXNzYWdlKCdpbml0RGF0YScsIHBhcmFtcyA9PntcbiAgICAgICAgICAgICAgICAvLyDmoLnmja5tYXN0ZXLkvKDpgJLnmoRkYXRh77yM6K6+5a6a5Yid5aeL5pWw5o2u77yM5bm26L+b6KGM5riy5p+TXG4gICAgICAgICAgICAgICAgaW5kZXguc2V0SW5pdERhdGEocGFyYW1zKTtcbiAgICAgICAgICAgICAgICAvLyDnnJ/mraPnmoTpobXpnaLmuLLmn5PvvIzlj5HnlJ/lnKhpbml0RGF0YeS5i+WQjlxuICAgICAgICAgICAgICAgIGluZGV4LmF0dGFjaChkb2N1bWVudC5ib2R5KTtcbiAgICAgICAgICAgIH0sIHtsaXN0ZW5QcmV2aW91c0V2ZW50OiB0cnVlfSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgaWYgKGdsb2JhbC5wYWdlUmVuZGVyKSB7XG4gICAgICAgICAgICByZW5kZXJQYWdlKGZpbHRlckFyciwgcGFyYW0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgb2xkUGF0Y2god2luZG93LlBhZ2VDb21wb25lbnQpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIGdsb2JhbC5lcnJvck1zZ1snZXhlY0Vycm9yJ10gPSBlO1xuICAgICAgICB0aHJvdyBlO1xuICAgIH1cbn0pKHdpbmRvdywgd2luZG93LnNhbik7XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvcmFuay9yYW5rLnN3YW4iXSwic291cmNlUm9vdCI6IiJ9