window.define('98', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _index = __webpack_require__(99);

var _index2 = _interopRequireDefault(_index);

var _user = __webpack_require__(29);

var _user2 = _interopRequireDefault(_user);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var app = getApp(); // global object
var page = {
    data: {
        dataList: [],
        rankTypeList: [],
        currOption: {
            rankTypeId: 0,
            title: ''
        }
    },
    onShow: function onShow() {
        var rankTypeList = this.data.rankTypeList;
        var rankTypeId = this.data.currOption.rankTypeId;
        if (rankTypeList && rankTypeId != 0) {
            this.setData('currOption.rankTypeId', 0);
            this.loadPage();
        }
    },

    onTabItemTap: function onTabItemTap(item) {
        console.log(item);
    },
    onLoad: function onLoad() {
        this.loadType();
        this.loadPage();
    },
    loadType: function loadType() {
        var isLogin = _user2.default.isLogin();
        _index2.default.getRankTypeData(this, isLogin);
    },
    loadPage: function loadPage() {
        var _this = this;

        setTimeout(function () {
            swan.showLoading({ title: "\u52A0\u8F7D\u4E2D.." });
            var isLogin = _user2.default.isLogin();
            _index2.default.getIndexData(_this, isLogin);
            _util2.default.seo(); //第一次加载 使用一次就够了
            _this.loadPage = function () {
                swan.showLoading({ title: "\u52A0\u8F7D\u4E2D.." });
                var isLogin = _user2.default.isLogin();
                _index2.default.getIndexData(_this, isLogin);
            };
        }, 0);
    },
    _loadedPage: function _loadedPage(data) {
        this.setData({
            'dataList': data.dataList,
            'currOption.title': data.dataList[0].title
        });
        swan.hideLoading();
    },
    _loadedRankType: function _loadedRankType(data) {
        this.setData('rankTypeList', data);
    },
    switchRankHandle: function switchRankHandle(event) {
        var target = event.currentTarget;
        this.setData('currOption.rankTypeId', target.dataset.rankTypeId);
        this.loadPage();
    },
    switchTitleHandle: function switchTitleHandle(event) {
        var target = event.currentTarget;
        this.setData('currOption.title', target.dataset.title);
    },
    playVideo: function playVideo(event) {
        var target = event.currentTarget;
        var roomId = target.dataset.roomId;
        if (!roomId) {
            return false;
        }
        var url = "pages/w/room?roomId=" + roomId;
        _util2.default.jump(url);
    }
};

Page(Object.assign({}, page));
});
window.__swanRoute='pages/rank/rank';window.usingComponents=[];require('98');

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvcmFuay9yYW5rLmpzIl0sIm5hbWVzIjpbImFwcCIsImdldEFwcCIsInBhZ2UiLCJkYXRhIiwiZGF0YUxpc3QiLCJyYW5rVHlwZUxpc3QiLCJjdXJyT3B0aW9uIiwicmFua1R5cGVJZCIsInRpdGxlIiwib25TaG93Iiwic2V0RGF0YSIsImxvYWRQYWdlIiwib25UYWJJdGVtVGFwIiwiaXRlbSIsImNvbnNvbGUiLCJsb2ciLCJvbkxvYWQiLCJsb2FkVHlwZSIsImlzTG9naW4iLCJ1c2VyIiwiYWN0aW9ucyIsImdldFJhbmtUeXBlRGF0YSIsInNldFRpbWVvdXQiLCJzd2FuIiwic2hvd0xvYWRpbmciLCJnZXRJbmRleERhdGEiLCJfIiwic2VvIiwiX2xvYWRlZFBhZ2UiLCJoaWRlTG9hZGluZyIsIl9sb2FkZWRSYW5rVHlwZSIsInN3aXRjaFJhbmtIYW5kbGUiLCJldmVudCIsInRhcmdldCIsImN1cnJlbnRUYXJnZXQiLCJkYXRhc2V0Iiwic3dpdGNoVGl0bGVIYW5kbGUiLCJwbGF5VmlkZW8iLCJyb29tSWQiLCJ1cmwiLCJqdW1wIiwiUGFnZSIsIk9iamVjdCIsImFzc2lnbiJdLCJtYXBwaW5ncyI6Ijs7O0FBQUE7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7QUFFQSxJQUFNQSxNQUFNQyxRQUFaLEMsQ0FBc0I7QUFDdEIsSUFBTUMsT0FBTztBQUNUQyxVQUFNO0FBQ0ZDLGtCQUFVLEVBRFI7QUFFRkMsc0JBQWMsRUFGWjtBQUdGQyxvQkFBWTtBQUNSQyx3QkFBWSxDQURKO0FBRVJDLG1CQUFPO0FBRkM7QUFIVixLQURHO0FBU1RDLFVBVFMsb0JBU0E7QUFDTCxZQUFJSixlQUFlLEtBQUtGLElBQUwsQ0FBVUUsWUFBN0I7QUFDQSxZQUFNRSxhQUFhLEtBQUtKLElBQUwsQ0FBVUcsVUFBVixDQUFxQkMsVUFBeEM7QUFDQSxZQUFJRixnQkFBZ0JFLGNBQWMsQ0FBbEMsRUFBcUM7QUFDakMsaUJBQUtHLE9BQUwsQ0FBYSx1QkFBYixFQUFzQyxDQUF0QztBQUNBLGlCQUFLQyxRQUFMO0FBQ0g7QUFDSixLQWhCUTs7QUFpQlRDLGtCQUFjLHNCQUFTQyxJQUFULEVBQWU7QUFDekJDLGdCQUFRQyxHQUFSLENBQVlGLElBQVo7QUFDSCxLQW5CUTtBQW9CVEcsVUFwQlMsb0JBb0JBO0FBQ0wsYUFBS0MsUUFBTDtBQUNBLGFBQUtOLFFBQUw7QUFDSCxLQXZCUTtBQXdCVE0sWUF4QlMsc0JBd0JFO0FBQ1AsWUFBSUMsVUFBVUMsZUFBS0QsT0FBTCxFQUFkO0FBQ0FFLHdCQUFRQyxlQUFSLENBQXdCLElBQXhCLEVBQThCSCxPQUE5QjtBQUVILEtBNUJRO0FBNkJUUCxZQTdCUyxzQkE2QkU7QUFBQTs7QUFDUFcsbUJBQVcsWUFBTTtBQUNiQyxpQkFBS0MsV0FBTCxDQUFpQixFQUFFaEIsNkJBQUYsRUFBakI7QUFDQSxnQkFBSVUsVUFBVUMsZUFBS0QsT0FBTCxFQUFkO0FBQ0FFLDRCQUFRSyxZQUFSLENBQXFCLEtBQXJCLEVBQTJCUCxPQUEzQjtBQUNBUSwyQkFBRUMsR0FBRixHQUphLENBSUw7QUFDUixrQkFBS2hCLFFBQUwsR0FBZ0IsWUFBTTtBQUNsQlkscUJBQUtDLFdBQUwsQ0FBaUIsRUFBRWhCLDZCQUFGLEVBQWpCO0FBQ0Esb0JBQUlVLFVBQVVDLGVBQUtELE9BQUwsRUFBZDtBQUNBRSxnQ0FBUUssWUFBUixDQUFxQixLQUFyQixFQUEyQlAsT0FBM0I7QUFDSCxhQUpEO0FBS0gsU0FWRCxFQVVHLENBVkg7QUFZSCxLQTFDUTtBQTJDVFUsZUEzQ1MsdUJBMkNHekIsSUEzQ0gsRUEyQ1M7QUFDZCxhQUFLTyxPQUFMLENBQWE7QUFDVCx3QkFBWVAsS0FBS0MsUUFEUjtBQUVULGdDQUFvQkQsS0FBS0MsUUFBTCxDQUFjLENBQWQsRUFBaUJJO0FBRjVCLFNBQWI7QUFJQWUsYUFBS00sV0FBTDtBQUNILEtBakRRO0FBa0RUQyxtQkFsRFMsMkJBa0RPM0IsSUFsRFAsRUFrRGE7QUFDbEIsYUFBS08sT0FBTCxDQUFhLGNBQWIsRUFBNkJQLElBQTdCO0FBQ0gsS0FwRFE7QUFxRFQ0QixvQkFyRFMsNEJBcURRQyxLQXJEUixFQXFEZTtBQUNwQixZQUFNQyxTQUFTRCxNQUFNRSxhQUFyQjtBQUNBLGFBQUt4QixPQUFMLENBQWEsdUJBQWIsRUFBc0N1QixPQUFPRSxPQUFQLENBQWU1QixVQUFyRDtBQUNBLGFBQUtJLFFBQUw7QUFDSCxLQXpEUTtBQTBEVHlCLHFCQTFEUyw2QkEwRFNKLEtBMURULEVBMERnQjtBQUNyQixZQUFNQyxTQUFTRCxNQUFNRSxhQUFyQjtBQUNBLGFBQUt4QixPQUFMLENBQWEsa0JBQWIsRUFBaUN1QixPQUFPRSxPQUFQLENBQWUzQixLQUFoRDtBQUNILEtBN0RRO0FBOERUNkIsYUE5RFMscUJBOERDTCxLQTlERCxFQThEUTtBQUNiLFlBQU1DLFNBQVNELE1BQU1FLGFBQXJCO0FBQ0EsWUFBTUksU0FBU0wsT0FBT0UsT0FBUCxDQUFlRyxNQUE5QjtBQUNBLFlBQUksQ0FBQ0EsTUFBTCxFQUFhO0FBQ1QsbUJBQU8sS0FBUDtBQUNIO0FBQ0QsWUFBSUMsK0JBQTZCRCxNQUFqQztBQUNBWix1QkFBRWMsSUFBRixDQUFPRCxHQUFQO0FBQ0g7QUF0RVEsQ0FBYjs7QUF5RUFFLEtBQUtDLE9BQU9DLE1BQVAsQ0FBYyxFQUFkLEVBQWtCekMsSUFBbEIsQ0FBTCxFIiwiZmlsZSI6InBhZ2VzL3JhbmsvcmFuay5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBhY3Rpb25zIGZyb20gXCIuL2FjdGlvbnMvaW5kZXhcIjtcbmltcG9ydCB1c2VyIGZyb20gXCIuLi8uLi9jb21tb24vdXNlci91c2VyXCI7XG5pbXBvcnQgXyBmcm9tIFwiLi4vLi4vY29tbW9uL3V0aWxzL3V0aWxcIjtcblxuY29uc3QgYXBwID0gZ2V0QXBwKCk7IC8vIGdsb2JhbCBvYmplY3RcbmNvbnN0IHBhZ2UgPSB7XG4gICAgZGF0YToge1xuICAgICAgICBkYXRhTGlzdDogW10sXG4gICAgICAgIHJhbmtUeXBlTGlzdDogW10sXG4gICAgICAgIGN1cnJPcHRpb246IHtcbiAgICAgICAgICAgIHJhbmtUeXBlSWQ6IDAsXG4gICAgICAgICAgICB0aXRsZTogJydcbiAgICAgICAgfVxuICAgIH0sXG4gICAgb25TaG93KCkge1xuICAgICAgICBsZXQgcmFua1R5cGVMaXN0ID0gdGhpcy5kYXRhLnJhbmtUeXBlTGlzdDtcbiAgICAgICAgY29uc3QgcmFua1R5cGVJZCA9IHRoaXMuZGF0YS5jdXJyT3B0aW9uLnJhbmtUeXBlSWQ7XG4gICAgICAgIGlmIChyYW5rVHlwZUxpc3QgJiYgcmFua1R5cGVJZCAhPSAwKSB7XG4gICAgICAgICAgICB0aGlzLnNldERhdGEoJ2N1cnJPcHRpb24ucmFua1R5cGVJZCcsIDApO1xuICAgICAgICAgICAgdGhpcy5sb2FkUGFnZSgpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICBvblRhYkl0ZW1UYXA6IGZ1bmN0aW9uKGl0ZW0pIHtcbiAgICAgICAgY29uc29sZS5sb2coaXRlbSk7XG4gICAgfSxcbiAgICBvbkxvYWQoKSB7XG4gICAgICAgIHRoaXMubG9hZFR5cGUoKTtcbiAgICAgICAgdGhpcy5sb2FkUGFnZSgpO1xuICAgIH0sXG4gICAgbG9hZFR5cGUoKSB7XG4gICAgICAgIGxldCBpc0xvZ2luID0gdXNlci5pc0xvZ2luKCk7XG4gICAgICAgIGFjdGlvbnMuZ2V0UmFua1R5cGVEYXRhKHRoaXMsIGlzTG9naW4pO1xuXG4gICAgfSxcbiAgICBsb2FkUGFnZSgpIHtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICBzd2FuLnNob3dMb2FkaW5nKHsgdGl0bGU6IGDliqDovb3kuK0uLmAgfSk7XG4gICAgICAgICAgICBsZXQgaXNMb2dpbiA9IHVzZXIuaXNMb2dpbigpO1xuICAgICAgICAgICAgYWN0aW9ucy5nZXRJbmRleERhdGEodGhpcywgaXNMb2dpbik7XG4gICAgICAgICAgICBfLnNlbygpOy8v56ys5LiA5qyh5Yqg6L29IOS9v+eUqOS4gOasoeWwseWkn+S6hlxuICAgICAgICAgICAgdGhpcy5sb2FkUGFnZSA9ICgpID0+IHtcbiAgICAgICAgICAgICAgICBzd2FuLnNob3dMb2FkaW5nKHsgdGl0bGU6IGDliqDovb3kuK0uLmAgfSk7XG4gICAgICAgICAgICAgICAgbGV0IGlzTG9naW4gPSB1c2VyLmlzTG9naW4oKTtcbiAgICAgICAgICAgICAgICBhY3Rpb25zLmdldEluZGV4RGF0YSh0aGlzLCBpc0xvZ2luKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgMCk7XG5cbiAgICB9LFxuICAgIF9sb2FkZWRQYWdlKGRhdGEpIHtcbiAgICAgICAgdGhpcy5zZXREYXRhKHtcbiAgICAgICAgICAgICdkYXRhTGlzdCc6IGRhdGEuZGF0YUxpc3QsXG4gICAgICAgICAgICAnY3Vyck9wdGlvbi50aXRsZSc6IGRhdGEuZGF0YUxpc3RbMF0udGl0bGVcbiAgICAgICAgfSk7XG4gICAgICAgIHN3YW4uaGlkZUxvYWRpbmcoKTtcbiAgICB9LFxuICAgIF9sb2FkZWRSYW5rVHlwZShkYXRhKSB7XG4gICAgICAgIHRoaXMuc2V0RGF0YSgncmFua1R5cGVMaXN0JywgZGF0YSk7XG4gICAgfSxcbiAgICBzd2l0Y2hSYW5rSGFuZGxlKGV2ZW50KSB7XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LmN1cnJlbnRUYXJnZXQ7XG4gICAgICAgIHRoaXMuc2V0RGF0YSgnY3Vyck9wdGlvbi5yYW5rVHlwZUlkJywgdGFyZ2V0LmRhdGFzZXQucmFua1R5cGVJZCk7XG4gICAgICAgIHRoaXMubG9hZFBhZ2UoKTtcbiAgICB9LFxuICAgIHN3aXRjaFRpdGxlSGFuZGxlKGV2ZW50KSB7XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LmN1cnJlbnRUYXJnZXQ7XG4gICAgICAgIHRoaXMuc2V0RGF0YSgnY3Vyck9wdGlvbi50aXRsZScsIHRhcmdldC5kYXRhc2V0LnRpdGxlKTtcbiAgICB9LFxuICAgIHBsYXlWaWRlbyhldmVudCkge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgICAgICBjb25zdCByb29tSWQgPSB0YXJnZXQuZGF0YXNldC5yb29tSWQ7XG4gICAgICAgIGlmICghcm9vbUlkKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IHVybCA9IGBwYWdlcy93L3Jvb20/cm9vbUlkPSR7cm9vbUlkfWA7XG4gICAgICAgIF8uanVtcCh1cmwpO1xuICAgIH1cbn1cblxuUGFnZShPYmplY3QuYXNzaWduKHt9LCBwYWdlKSlcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvcmFuay9yYW5rLmpzIl0sInNvdXJjZVJvb3QiOiIifQ==