

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave '.swan' file compiled runtime js
 * @author houyu(houyu01@baidu.com)
 */
(function (global, san) {
    global.errorMsg = [];

    // 自定义模板区域

    var templateComponents = Object.assign({}, {});

    var param = {};
    var filterArr = JSON.parse('[]');

    function processTemplateModule(filterTemplateArrs, filterModule) {
        eval(filterModule);
        var modules = {};
        var templateFiltersObj = {};
        filterTemplateArrs && filterTemplateArrs.forEach(function (element) {
            var filterName = element.filterName,
                func = element.func,
                module = element.module;

            modules[module] = eval(module);
            templateFiltersObj[filterName] = function () {
                var _modules$module;

                return (_modules$module = modules[module])[func].apply(_modules$module, arguments);
            };
        });
        return templateFiltersObj;
    }

    try {

        filterArr && filterArr.forEach(function (item) {
            param[item.module] = eval(item.module);
        });

        var pageContent = '<view class="container page-my"><view class="av-block"><view class="av-box"><image class="img" src="{{loginInfo.user.icon}}"></image></view><view class="btn-group" s-if="{{!loginInfo.isLogin}}"><view class="btn-login" data-url="pages/login/login" on-bindtap="eventHappen(\'tap\', $event, \'jump\', \'\', \'catch\')">\u767B\u5F55</view></view><view class="m-user-name" s-if="{{loginInfo.isLogin}}"><text class="user-name">{{loginInfo.user.nickname}}</text><image s-if="{{loginInfo.user.isVip}}" class="c-vip-icon" src="/assets/my/c-vip-icon.png"></image></view></view><view class="multi-block"><view class="flex-block" data-url="subPackage/pages/my/playLog" on-bindtap="eventHappen(\'tap\', $event, \'jump\', \'\', \'catch\')"><text >\u89C2\u770B\u5386\u53F2</text><view class="title_more"><image src="/assets/common/c-icon-arrow.png" class="c-icon-more" /></view></view><template ><view class="record" s-if="records && records.length>0"><scroll-view class="multiLive" scroll-x=""><view class="ric-item" s-for="roomObj in records" data-room-id="{{roomObj.roomId}}" data-live-type="{{roomObj.liveType}}" on-bindtap="eventHappen(\'tap\', $event, \'playVideo\', \'\', \'catch\')"><view class="picbox"><image src="{{roomObj.coverImageUrl}}" /></view><view class="t text-ellips">{{roomObj.title}}</view></view></scroll-view></view></template></view><view class="flex-block" data-url="pages/config/config" s-if="{{loginInfo.isLogin}}" on-bindtap="eventHappen(\'tap\', $event, \'jump\', \'\', \'catch\')"><text >\u8BBE\u7F6E</text><view class="title_more"><image src="/assets/common/c-icon-arrow.png" class="c-icon-more" /></view></view><view class="flex-block" data-url="subPackage/pages/my/about" on-bindtap="eventHappen(\'tap\', $event, \'jump\', \'\', \'catch\')"><text >\u5173\u4E8E</text><view class="title_more"><image src="/assets/common/c-icon-arrow.png" class="c-icon-more" /></view></view><view style="position: absolute;bottom:6.666666666666667vw;left: 0;right: 0;"><image src="/assets/logo/logo_live.png" class="c-icon-more" style="margin: auto;width: 27.866666666666667vw;height: 6.266666666666667vw;display: block;" /></view></view>';

        // 新的渲染逻辑
        var renderPage = function renderPage(filters, modules) {
            var componentFactory = global.componentFactory;
            // 获取所有内置组件 + 自定义组件的fragment
            var componentFragments = componentFactory.getAllComponents();

            // 所有的自定义组件
            ;

            // 路径与该组件映射
            var customAbsolutePathMap = {};

            // 当前页面使用的自定义组件
            var pageUsingComponentMap = JSON.parse('{}');

            // 生成该页面引用的自定义组件
            var customComponents = Object.keys(pageUsingComponentMap).reduce(function (customComponents, customName) {
                customComponents[customName] = customAbsolutePathMap[pageUsingComponentMap[customName]];
                return customComponents;
            }, {});

            // 启动页面渲染逻辑
            global.pageRender(pageContent, templateComponents, customComponents, filters, modules);
        };

        // 兼容旧的swan-core
        var oldPatch = function oldPatch(PageComponent) {
            Object.assign(PageComponent.components, {});
            // 渲染整个页面的顶层组件，template会在编译时被替换为用户的swan模板

            var Index = function (_PageComponent) {
                _inherits(Index, _PageComponent);

                function Index(options) {
                    _classCallCheck(this, Index);

                    var _this = _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));

                    _this.components = PageComponent.components;
                    return _this;
                }

                return Index;
            }(PageComponent);
            // 初始化页面对象


            Index.template = '<swan-wrapper tabindex="-1">' + pageContent + '</swan-wrapper>';
            var index = new Index();
            // 调用页面对象的加载完成通知
            index.slaveLoaded();
            // 监听等待initData，进行渲染
            index.communicator.onMessage('initData', function (params) {
                // 根据master传递的data，设定初始数据，并进行渲染
                index.setInitData(params);
                // 真正的页面渲染，发生在initData之后
                index.attach(document.body);
            }, { listenPreviousEvent: true });
        };

        if (global.pageRender) {
            renderPage(filterArr, param);
        } else {
            oldPatch(window.PageComponent);
        }
    } catch (e) {
        global.errorMsg['execError'] = e;
        throw e;
    }
})(window, window.san);

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvbXkvbXkuc3dhbiJdLCJuYW1lcyI6WyJnbG9iYWwiLCJzYW4iLCJlcnJvck1zZyIsInRlbXBsYXRlQ29tcG9uZW50cyIsIk9iamVjdCIsImFzc2lnbiIsInBhcmFtIiwiZmlsdGVyQXJyIiwiSlNPTiIsInBhcnNlIiwicHJvY2Vzc1RlbXBsYXRlTW9kdWxlIiwiZmlsdGVyVGVtcGxhdGVBcnJzIiwiZmlsdGVyTW9kdWxlIiwiZXZhbCIsIm1vZHVsZXMiLCJ0ZW1wbGF0ZUZpbHRlcnNPYmoiLCJmb3JFYWNoIiwiZmlsdGVyTmFtZSIsImVsZW1lbnQiLCJmdW5jIiwibW9kdWxlIiwiaXRlbSIsInBhZ2VDb250ZW50IiwicmVuZGVyUGFnZSIsImZpbHRlcnMiLCJjb21wb25lbnRGYWN0b3J5IiwiY29tcG9uZW50RnJhZ21lbnRzIiwiZ2V0QWxsQ29tcG9uZW50cyIsImN1c3RvbUFic29sdXRlUGF0aE1hcCIsInBhZ2VVc2luZ0NvbXBvbmVudE1hcCIsImN1c3RvbUNvbXBvbmVudHMiLCJrZXlzIiwicmVkdWNlIiwiY3VzdG9tTmFtZSIsInBhZ2VSZW5kZXIiLCJvbGRQYXRjaCIsIlBhZ2VDb21wb25lbnQiLCJjb21wb25lbnRzIiwiSW5kZXgiLCJvcHRpb25zIiwidGVtcGxhdGUiLCJpbmRleCIsInNsYXZlTG9hZGVkIiwiY29tbXVuaWNhdG9yIiwib25NZXNzYWdlIiwic2V0SW5pdERhdGEiLCJwYXJhbXMiLCJhdHRhY2giLCJkb2N1bWVudCIsImJvZHkiLCJsaXN0ZW5QcmV2aW91c0V2ZW50Iiwid2luZG93IiwiZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQTs7OztBQUlBLENBQUMsVUFBQ0EsTUFBRCxFQUFTQyxHQUFULEVBQWdCO0FBQ2JELFdBQU9FLFFBQVAsR0FBa0IsRUFBbEI7O0FBRUE7O0FBRUEsUUFBTUMscUJBQXFCQyxPQUFPQyxNQUFQLENBQWMsRUFBZCxFQUFrQixFQUFsQixDQUEzQjs7QUFFQSxRQUFJQyxRQUFRLEVBQVo7QUFDQSxRQUFNQyxZQUFZQyxLQUFLQyxLQUFMLENBQVcsSUFBWCxDQUFsQjs7QUFHQSxhQUFTQyxxQkFBVCxDQUErQkMsa0JBQS9CLEVBQW1EQyxZQUFuRCxFQUFpRTtBQUM3REMsYUFBS0QsWUFBTDtBQUNBLFlBQUlFLFVBQVUsRUFBZDtBQUNBLFlBQUlDLHFCQUFxQixFQUF6QjtBQUNBSiw4QkFBc0JBLG1CQUFtQkssT0FBbkIsQ0FBMkIsbUJBQVU7QUFBQSxnQkFDbERDLFVBRGtELEdBQ3RCQyxPQURzQixDQUNsREQsVUFEa0Q7QUFBQSxnQkFDdENFLElBRHNDLEdBQ3RCRCxPQURzQixDQUN0Q0MsSUFEc0M7QUFBQSxnQkFDaENDLE1BRGdDLEdBQ3RCRixPQURzQixDQUNoQ0UsTUFEZ0M7O0FBRXZETixvQkFBUU0sTUFBUixJQUFrQlAsS0FBS08sTUFBTCxDQUFsQjtBQUNBTCwrQkFBbUJFLFVBQW5CLElBQWlDO0FBQUE7O0FBQUEsdUJBQVksMkJBQVFHLE1BQVIsR0FBZ0JELElBQWhCLG1DQUFaO0FBQUEsYUFBakM7QUFDSCxTQUpxQixDQUF0QjtBQUtBLGVBQU9KLGtCQUFQO0FBQ0g7O0FBRUQsUUFBSTs7QUFFQVIscUJBQWFBLFVBQVVTLE9BQVYsQ0FBa0IsZ0JBQU87QUFDbENWLGtCQUFNZSxLQUFLRCxNQUFYLElBQXFCUCxLQUFLUSxLQUFLRCxNQUFWLENBQXJCO0FBQ0gsU0FGWSxDQUFiOztBQUlBLFlBQU1FLDJtRUFBTjs7QUFFQTtBQUNBLFlBQU1DLGFBQWEsU0FBYkEsVUFBYSxDQUFDQyxPQUFELEVBQVVWLE9BQVYsRUFBcUI7QUFDcEMsZ0JBQU1XLG1CQUFtQnpCLE9BQU95QixnQkFBaEM7QUFDQTtBQUNBLGdCQUFNQyxxQkFBcUJELGlCQUFpQkUsZ0JBQWpCLEVBQTNCOztBQUVBO0FBQ0E7O0FBRUE7QUFDQSxnQkFBSUMsd0JBQXdCLEVBQTVCOztBQUVBO0FBQ0EsZ0JBQU1DLHdCQUF3QnJCLEtBQUtDLEtBQUwsTUFBOUI7O0FBRUE7QUFDQSxnQkFBTXFCLG1CQUFtQjFCLE9BQU8yQixJQUFQLENBQVlGLHFCQUFaLEVBQW1DRyxNQUFuQyxDQUEwQyxVQUFDRixnQkFBRCxFQUFtQkcsVUFBbkIsRUFBaUM7QUFDaEdILGlDQUFpQkcsVUFBakIsSUFBK0JMLHNCQUFzQkMsc0JBQXNCSSxVQUF0QixDQUF0QixDQUEvQjtBQUNBLHVCQUFPSCxnQkFBUDtBQUNILGFBSHdCLEVBR3RCLEVBSHNCLENBQXpCOztBQUtBO0FBQ0E5QixtQkFBT2tDLFVBQVAsQ0FBa0JaLFdBQWxCLEVBQStCbkIsa0JBQS9CLEVBQW1EMkIsZ0JBQW5ELEVBQXFFTixPQUFyRSxFQUE4RVYsT0FBOUU7QUFDSCxTQXRCRDs7QUF3QkE7QUFDQSxZQUFNcUIsV0FBVyxTQUFYQSxRQUFXLGdCQUFnQjtBQUM3Qi9CLG1CQUFPQyxNQUFQLENBQWMrQixjQUFjQyxVQUE1QixFQUF3QyxFQUF4QztBQUNBOztBQUY2QixnQkFHdkJDLEtBSHVCO0FBQUE7O0FBSXpCLCtCQUFZQyxPQUFaLEVBQXFCO0FBQUE7O0FBQUEsOEhBQ1hBLE9BRFc7O0FBRWpCLDBCQUFLRixVQUFMLEdBQWtCRCxjQUFjQyxVQUFoQztBQUZpQjtBQUdwQjs7QUFQd0I7QUFBQSxjQUdURCxhQUhTO0FBVTdCOzs7QUFQTUUsaUJBSHVCLENBUWxCRSxRQVJrQixvQ0FRd0JsQixXQVJ4QjtBQVc3QixnQkFBTW1CLFFBQVEsSUFBSUgsS0FBSixFQUFkO0FBQ0E7QUFDQUcsa0JBQU1DLFdBQU47QUFDQTtBQUNBRCxrQkFBTUUsWUFBTixDQUFtQkMsU0FBbkIsQ0FBNkIsVUFBN0IsRUFBeUMsa0JBQVM7QUFDOUM7QUFDQUgsc0JBQU1JLFdBQU4sQ0FBa0JDLE1BQWxCO0FBQ0E7QUFDQUwsc0JBQU1NLE1BQU4sQ0FBYUMsU0FBU0MsSUFBdEI7QUFDSCxhQUxELEVBS0csRUFBQ0MscUJBQXFCLElBQXRCLEVBTEg7QUFNSCxTQXJCRDs7QUF1QkEsWUFBSWxELE9BQU9rQyxVQUFYLEVBQXVCO0FBQ25CWCx1QkFBV2hCLFNBQVgsRUFBc0JELEtBQXRCO0FBQ0gsU0FGRCxNQUdLO0FBQ0Q2QixxQkFBU2dCLE9BQU9mLGFBQWhCO0FBQ0g7QUFDSixLQS9ERCxDQWdFQSxPQUFPZ0IsQ0FBUCxFQUFVO0FBQ05wRCxlQUFPRSxRQUFQLENBQWdCLFdBQWhCLElBQStCa0QsQ0FBL0I7QUFDQSxjQUFNQSxDQUFOO0FBQ0g7QUFDSixDQTNGRCxFQTJGR0QsTUEzRkgsRUEyRldBLE9BQU9sRCxHQTNGbEIsRSIsImZpbGUiOiJwYWdlcy9teS9teS5zd2FuLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAZmlsZSBzd2FuJ3Mgc2xhdmUgJy5zd2FuJyBmaWxlIGNvbXBpbGVkIHJ1bnRpbWUganNcbiAqIEBhdXRob3IgaG91eXUoaG91eXUwMUBiYWlkdS5jb20pXG4gKi9cbigoZ2xvYmFsLCBzYW4pID0+e1xuICAgIGdsb2JhbC5lcnJvck1zZyA9IFtdO1xuXG4gICAgLy8g6Ieq5a6a5LmJ5qih5p2/5Yy65Z+fXG4gICAgXG4gICAgY29uc3QgdGVtcGxhdGVDb21wb25lbnRzID0gT2JqZWN0LmFzc2lnbih7fSwge30pO1xuXG4gICAgbGV0IHBhcmFtID0ge307XG4gICAgY29uc3QgZmlsdGVyQXJyID0gSlNPTi5wYXJzZSgnW10nKTtcbiAgICBcblxuICAgIGZ1bmN0aW9uIHByb2Nlc3NUZW1wbGF0ZU1vZHVsZShmaWx0ZXJUZW1wbGF0ZUFycnMsIGZpbHRlck1vZHVsZSkge1xuICAgICAgICBldmFsKGZpbHRlck1vZHVsZSk7XG4gICAgICAgIGxldCBtb2R1bGVzID0ge307XG4gICAgICAgIGxldCB0ZW1wbGF0ZUZpbHRlcnNPYmogPSB7fTtcbiAgICAgICAgZmlsdGVyVGVtcGxhdGVBcnJzICYmIGZpbHRlclRlbXBsYXRlQXJycy5mb3JFYWNoKGVsZW1lbnQgPT57XG4gICAgICAgICAgICBsZXQge2ZpbHRlck5hbWUsIGZ1bmMsIG1vZHVsZX0gPSBlbGVtZW50O1xuICAgICAgICAgICAgbW9kdWxlc1ttb2R1bGVdID0gZXZhbChtb2R1bGUpO1xuICAgICAgICAgICAgdGVtcGxhdGVGaWx0ZXJzT2JqW2ZpbHRlck5hbWVdID0gKC4uLmFyZ3MpID0+bW9kdWxlc1ttb2R1bGVdW2Z1bmNdKC4uLmFyZ3MpO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHRlbXBsYXRlRmlsdGVyc09iajtcbiAgICB9XG5cbiAgICB0cnkge1xuXG4gICAgICAgIGZpbHRlckFyciAmJiBmaWx0ZXJBcnIuZm9yRWFjaChpdGVtID0+e1xuICAgICAgICAgICAgcGFyYW1baXRlbS5tb2R1bGVdID0gZXZhbChpdGVtLm1vZHVsZSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGNvbnN0IHBhZ2VDb250ZW50ID0gYDx2aWV3IGNsYXNzPVwiY29udGFpbmVyIHBhZ2UtbXlcIj48dmlldyBjbGFzcz1cImF2LWJsb2NrXCI+PHZpZXcgY2xhc3M9XCJhdi1ib3hcIj48aW1hZ2UgY2xhc3M9XCJpbWdcIiBzcmM9XCJ7e2xvZ2luSW5mby51c2VyLmljb259fVwiPjwvaW1hZ2U+PC92aWV3Pjx2aWV3IGNsYXNzPVwiYnRuLWdyb3VwXCIgcy1pZj1cInt7IWxvZ2luSW5mby5pc0xvZ2lufX1cIj48dmlldyBjbGFzcz1cImJ0bi1sb2dpblwiIGRhdGEtdXJsPVwicGFnZXMvbG9naW4vbG9naW5cIiBvbi1iaW5kdGFwPVwiZXZlbnRIYXBwZW4oJ3RhcCcsICRldmVudCwgJ2p1bXAnLCAnJywgJ2NhdGNoJylcIj7nmbvlvZU8L3ZpZXc+PC92aWV3Pjx2aWV3IGNsYXNzPVwibS11c2VyLW5hbWVcIiBzLWlmPVwie3tsb2dpbkluZm8uaXNMb2dpbn19XCI+PHRleHQgY2xhc3M9XCJ1c2VyLW5hbWVcIj57e2xvZ2luSW5mby51c2VyLm5pY2tuYW1lfX08L3RleHQ+PGltYWdlIHMtaWY9XCJ7e2xvZ2luSW5mby51c2VyLmlzVmlwfX1cIiBjbGFzcz1cImMtdmlwLWljb25cIiBzcmM9XCIvYXNzZXRzL215L2MtdmlwLWljb24ucG5nXCI+PC9pbWFnZT48L3ZpZXc+PC92aWV3Pjx2aWV3IGNsYXNzPVwibXVsdGktYmxvY2tcIj48dmlldyBjbGFzcz1cImZsZXgtYmxvY2tcIiBkYXRhLXVybD1cInN1YlBhY2thZ2UvcGFnZXMvbXkvcGxheUxvZ1wiIG9uLWJpbmR0YXA9XCJldmVudEhhcHBlbigndGFwJywgJGV2ZW50LCAnanVtcCcsICcnLCAnY2F0Y2gnKVwiPjx0ZXh0ID7op4LnnIvljoblj7I8L3RleHQ+PHZpZXcgY2xhc3M9XCJ0aXRsZV9tb3JlXCI+PGltYWdlIHNyYz1cIi9hc3NldHMvY29tbW9uL2MtaWNvbi1hcnJvdy5wbmdcIiBjbGFzcz1cImMtaWNvbi1tb3JlXCIgLz48L3ZpZXc+PC92aWV3Pjx0ZW1wbGF0ZSA+PHZpZXcgY2xhc3M9XCJyZWNvcmRcIiBzLWlmPVwicmVjb3JkcyAmJiByZWNvcmRzLmxlbmd0aD4wXCI+PHNjcm9sbC12aWV3IGNsYXNzPVwibXVsdGlMaXZlXCIgc2Nyb2xsLXg9XCJcIj48dmlldyBjbGFzcz1cInJpYy1pdGVtXCIgcy1mb3I9XCJyb29tT2JqIGluIHJlY29yZHNcIiBkYXRhLXJvb20taWQ9XCJ7e3Jvb21PYmoucm9vbUlkfX1cIiBkYXRhLWxpdmUtdHlwZT1cInt7cm9vbU9iai5saXZlVHlwZX19XCIgb24tYmluZHRhcD1cImV2ZW50SGFwcGVuKCd0YXAnLCAkZXZlbnQsICdwbGF5VmlkZW8nLCAnJywgJ2NhdGNoJylcIj48dmlldyBjbGFzcz1cInBpY2JveFwiPjxpbWFnZSBzcmM9XCJ7e3Jvb21PYmouY292ZXJJbWFnZVVybH19XCIgLz48L3ZpZXc+PHZpZXcgY2xhc3M9XCJ0IHRleHQtZWxsaXBzXCI+e3tyb29tT2JqLnRpdGxlfX08L3ZpZXc+PC92aWV3Pjwvc2Nyb2xsLXZpZXc+PC92aWV3PjwvdGVtcGxhdGU+PC92aWV3Pjx2aWV3IGNsYXNzPVwiZmxleC1ibG9ja1wiIGRhdGEtdXJsPVwicGFnZXMvY29uZmlnL2NvbmZpZ1wiIHMtaWY9XCJ7e2xvZ2luSW5mby5pc0xvZ2lufX1cIiBvbi1iaW5kdGFwPVwiZXZlbnRIYXBwZW4oJ3RhcCcsICRldmVudCwgJ2p1bXAnLCAnJywgJ2NhdGNoJylcIj48dGV4dCA+6K6+572uPC90ZXh0Pjx2aWV3IGNsYXNzPVwidGl0bGVfbW9yZVwiPjxpbWFnZSBzcmM9XCIvYXNzZXRzL2NvbW1vbi9jLWljb24tYXJyb3cucG5nXCIgY2xhc3M9XCJjLWljb24tbW9yZVwiIC8+PC92aWV3Pjwvdmlldz48dmlldyBjbGFzcz1cImZsZXgtYmxvY2tcIiBkYXRhLXVybD1cInN1YlBhY2thZ2UvcGFnZXMvbXkvYWJvdXRcIiBvbi1iaW5kdGFwPVwiZXZlbnRIYXBwZW4oJ3RhcCcsICRldmVudCwgJ2p1bXAnLCAnJywgJ2NhdGNoJylcIj48dGV4dCA+5YWz5LqOPC90ZXh0Pjx2aWV3IGNsYXNzPVwidGl0bGVfbW9yZVwiPjxpbWFnZSBzcmM9XCIvYXNzZXRzL2NvbW1vbi9jLWljb24tYXJyb3cucG5nXCIgY2xhc3M9XCJjLWljb24tbW9yZVwiIC8+PC92aWV3Pjwvdmlldz48dmlldyBzdHlsZT1cInBvc2l0aW9uOiBhYnNvbHV0ZTtib3R0b206Ni42NjY2NjY2NjY2NjY2Njd2dztsZWZ0OiAwO3JpZ2h0OiAwO1wiPjxpbWFnZSBzcmM9XCIvYXNzZXRzL2xvZ28vbG9nb19saXZlLnBuZ1wiIGNsYXNzPVwiYy1pY29uLW1vcmVcIiBzdHlsZT1cIm1hcmdpbjogYXV0bzt3aWR0aDogMjcuODY2NjY2NjY2NjY2NjY3dnc7aGVpZ2h0OiA2LjI2NjY2NjY2NjY2NjY2N3Z3O2Rpc3BsYXk6IGJsb2NrO1wiIC8+PC92aWV3Pjwvdmlldz5gO1xuXG4gICAgICAgIC8vIOaWsOeahOa4suafk+mAu+i+kVxuICAgICAgICBjb25zdCByZW5kZXJQYWdlID0gKGZpbHRlcnMsIG1vZHVsZXMpID0+e1xuICAgICAgICAgICAgY29uc3QgY29tcG9uZW50RmFjdG9yeSA9IGdsb2JhbC5jb21wb25lbnRGYWN0b3J5O1xuICAgICAgICAgICAgLy8g6I635Y+W5omA5pyJ5YaF572u57uE5Lu2ICsg6Ieq5a6a5LmJ57uE5Lu255qEZnJhZ21lbnRcbiAgICAgICAgICAgIGNvbnN0IGNvbXBvbmVudEZyYWdtZW50cyA9IGNvbXBvbmVudEZhY3RvcnkuZ2V0QWxsQ29tcG9uZW50cygpO1xuXG4gICAgICAgICAgICAvLyDmiYDmnInnmoToh6rlrprkuYnnu4Tku7ZcbiAgICAgICAgICAgIDtcblxuICAgICAgICAgICAgLy8g6Lev5b6E5LiO6K+l57uE5Lu25pig5bCEXG4gICAgICAgICAgICB2YXIgY3VzdG9tQWJzb2x1dGVQYXRoTWFwID0ge307XG5cbiAgICAgICAgICAgIC8vIOW9k+WJjemhtemdouS9v+eUqOeahOiHquWumuS5iee7hOS7tlxuICAgICAgICAgICAgY29uc3QgcGFnZVVzaW5nQ29tcG9uZW50TWFwID0gSlNPTi5wYXJzZShge31gKTtcblxuICAgICAgICAgICAgLy8g55Sf5oiQ6K+l6aG16Z2i5byV55So55qE6Ieq5a6a5LmJ57uE5Lu2XG4gICAgICAgICAgICBjb25zdCBjdXN0b21Db21wb25lbnRzID0gT2JqZWN0LmtleXMocGFnZVVzaW5nQ29tcG9uZW50TWFwKS5yZWR1Y2UoKGN1c3RvbUNvbXBvbmVudHMsIGN1c3RvbU5hbWUpID0+e1xuICAgICAgICAgICAgICAgIGN1c3RvbUNvbXBvbmVudHNbY3VzdG9tTmFtZV0gPSBjdXN0b21BYnNvbHV0ZVBhdGhNYXBbcGFnZVVzaW5nQ29tcG9uZW50TWFwW2N1c3RvbU5hbWVdXTtcbiAgICAgICAgICAgICAgICByZXR1cm4gY3VzdG9tQ29tcG9uZW50cztcbiAgICAgICAgICAgIH0sIHt9KTtcblxuICAgICAgICAgICAgLy8g5ZCv5Yqo6aG16Z2i5riy5p+T6YC76L6RXG4gICAgICAgICAgICBnbG9iYWwucGFnZVJlbmRlcihwYWdlQ29udGVudCwgdGVtcGxhdGVDb21wb25lbnRzLCBjdXN0b21Db21wb25lbnRzLCBmaWx0ZXJzLCBtb2R1bGVzKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvLyDlhbzlrrnml6fnmoRzd2FuLWNvcmVcbiAgICAgICAgY29uc3Qgb2xkUGF0Y2ggPSBQYWdlQ29tcG9uZW50ID0+e1xuICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihQYWdlQ29tcG9uZW50LmNvbXBvbmVudHMsIHt9KTtcbiAgICAgICAgICAgIC8vIOa4suafk+aVtOS4qumhtemdoueahOmhtuWxgue7hOS7tu+8jHRlbXBsYXRl5Lya5Zyo57yW6K+R5pe26KKr5pu/5o2i5Li655So5oi355qEc3dhbuaooeadv1xuICAgICAgICAgICAgY2xhc3MgSW5kZXggZXh0ZW5kcyBQYWdlQ29tcG9uZW50IHtcbiAgICAgICAgICAgICAgICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgICAgICAgICAgICAgICAgIHN1cGVyKG9wdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbXBvbmVudHMgPSBQYWdlQ29tcG9uZW50LmNvbXBvbmVudHM7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHN0YXRpYyB0ZW1wbGF0ZSA9IGA8c3dhbi13cmFwcGVyIHRhYmluZGV4PVwiLTFcIj4ke3BhZ2VDb250ZW50fTwvc3dhbi13cmFwcGVyPmA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyDliJ3lp4vljJbpobXpnaLlr7nosaFcbiAgICAgICAgICAgIGNvbnN0IGluZGV4ID0gbmV3IEluZGV4KCk7XG4gICAgICAgICAgICAvLyDosIPnlKjpobXpnaLlr7nosaHnmoTliqDovb3lrozmiJDpgJrnn6VcbiAgICAgICAgICAgIGluZGV4LnNsYXZlTG9hZGVkKCk7XG4gICAgICAgICAgICAvLyDnm5HlkKznrYnlvoVpbml0RGF0Ye+8jOi/m+ihjOa4suafk1xuICAgICAgICAgICAgaW5kZXguY29tbXVuaWNhdG9yLm9uTWVzc2FnZSgnaW5pdERhdGEnLCBwYXJhbXMgPT57XG4gICAgICAgICAgICAgICAgLy8g5qC55o2ubWFzdGVy5Lyg6YCS55qEZGF0Ye+8jOiuvuWumuWIneWni+aVsOaNru+8jOW5tui/m+ihjOa4suafk1xuICAgICAgICAgICAgICAgIGluZGV4LnNldEluaXREYXRhKHBhcmFtcyk7XG4gICAgICAgICAgICAgICAgLy8g55yf5q2j55qE6aG16Z2i5riy5p+T77yM5Y+R55Sf5ZyoaW5pdERhdGHkuYvlkI5cbiAgICAgICAgICAgICAgICBpbmRleC5hdHRhY2goZG9jdW1lbnQuYm9keSk7XG4gICAgICAgICAgICB9LCB7bGlzdGVuUHJldmlvdXNFdmVudDogdHJ1ZX0pO1xuICAgICAgICB9O1xuXG4gICAgICAgIGlmIChnbG9iYWwucGFnZVJlbmRlcikge1xuICAgICAgICAgICAgcmVuZGVyUGFnZShmaWx0ZXJBcnIsIHBhcmFtKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIG9sZFBhdGNoKHdpbmRvdy5QYWdlQ29tcG9uZW50KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjYXRjaCAoZSkge1xuICAgICAgICBnbG9iYWwuZXJyb3JNc2dbJ2V4ZWNFcnJvciddID0gZTtcbiAgICAgICAgdGhyb3cgZTtcbiAgICB9XG59KSh3aW5kb3csIHdpbmRvdy5zYW4pO1xuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC9Vc2Vycy9ob3ViaW5nYmluZy9jb2RlL2lxaXlpL3FsaXZlX21pbmlwcm9ncmFtL2JhaWR1L3BhZ2VzL215L215LnN3YW4iXSwic291cmNlUm9vdCI6IiJ9