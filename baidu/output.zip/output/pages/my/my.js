window.define('100', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _userInfo = __webpack_require__(36);

var user = _interopRequireWildcard(_userInfo);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

var _reqService = __webpack_require__(101);

var _reqService2 = _interopRequireDefault(_reqService);

var _session = __webpack_require__(32);

var _session2 = _interopRequireDefault(_session);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var app = getApp();
var globalData = app.globalData;
var originIcon = '../../assets/my/avatar-144.png';
var page = {
    data: {
        load: 'none',
        records: [],
        options: {
            needLogin: false, //页面打开后是否需要登录吗?
            authCookie: ''
        },
        loginInfo: {
            isLogin: false,
            user: {
                icon: originIcon,
                nickname: '',
                isVip: false
            }
        }
    },
    onShow: function onShow() {
        this.loadPage();
        // this._getUserInfo('91lLqbrla3ve9WkFf5kuAXekJxZQZa7jnlMkfVoqZjveWPMnMtfnlwPdpYm2zgjDCdN5c');//TODO test DELETE
        if (globalData.needLogin) {
            // swan.showToast({ title: `${app.globalData.needLogin}~~${app.globalData.authCookie}` });
            this.data.options.needLogin = app.globalData.needLogin; //TODO 由于 swan.switchTab  跳转传参会导致页面报错假死 就写入全局变量中执行
            this.data.options.authCookie = app.globalData.authCookie;

            this.setData('loginInfo.isLogin', false);
            this._needLogin();
        } else if (globalData.authCookie.length === 0) {
            this._updateUserInfo();
        }
    },
    onLoad: function onLoad() {
        // TODO
        // globalData.needLogin = 1;
        // globalData.authCookie = 'BAtVCBS3Xd7loPuNJ70bR5m3DIqzpZPdSASleIam3Wm31oOTEl7W3ebTZEFcG5cYrEF9JZvUB0SDNwBm1QwzxtA4AMx5gtCMu40hQMfRXiZSVdqrVHCNzqm1FUg';
    },
    initUpdateData: function initUpdateData() {
        this.data.options.needLogin = globalData.authCookie;
    },
    _needLogin: function _needLogin() {
        var authCookie = this.data.options.authCookie; //获取 options

        if (authCookie && authCookie !== '') {
            this._getUserInfo(authCookie);
            this.data.options.needLogin = false;
            app.globalData.needLogin = false;
        } else {
            this._updateUserInfo();
            swan.showToast({ title: '请点击登录' });
            console.log("\u672A\u767B\u5F55");
        }
    },
    _getUserInfo: function _getUserInfo(authCookie) {
        var _this = this;

        var getUserInfo = user.getUserInfo();
        // console.log(getUserInfo);
        if (getUserInfo && Object.keys(getUserInfo).length > 0) {
            console.log(getUserInfo);
        }

        _reqService2.default.getUserInfo({ authcookie: authCookie }).then(function (data) {
            console.warn("\u767B\u5F55 \u6210\u529F!");
            _this._updateUserInfo(data, authCookie);
        }, function (err) {
            _this.loginOut();
            console.error(err);
        });
    },
    loginOut: function loginOut() {
        return false;
    },
    _updateUserInfo: function _updateUserInfo(data, authCookie) {
        if (!data) {
            //登出
            this.setData('loginInfo.isLogin', false);
            this.setData('loginInfo.user.icon', originIcon);
            this.setData('loginInfo.user.nickname', '');
            this.setData('loginInfo.user.isVip', false);
            _session2.default.Session.clear();
        } else {
            // 登录 success
            var _data$userinfo = data.userinfo,
                nickname = _data$userinfo.nickname,
                icon = _data$userinfo.icon;

            var isVip = (data.qiyi_vip_info || {}).level > 1;
            // [isVip] = qiyi_vip_info.level > 1
            console.log(nickname, icon);
            this.setData('loginInfo.isLogin', true);
            this.setData('loginInfo.user.icon', icon);
            this.setData('loginInfo.user.nickname', nickname);
            this.setData('loginInfo.user.isVip', isVip || false);

            _session2.default.Session.set(_session2.default.SESSION_AUTH_KEY, authCookie);
            _session2.default.Session.set(_session2.default.SESSION_INFO_KEY, data);
            swan.showToast({ title: "\u767B\u5F55\u6210\u529F" });
        }
    },
    loadPage: function loadPage() {
        var _this2 = this;

        // _.jump('subPackage/pages/my/about');
        // _.jump('subPackage/pages/my/playLog');
        _util2.default.record().then(function (data) {
            _this2.setData({ 'records': data && data.reverse().splice(0, 4) });
        });
    },
    _loadedPage: function _loadedPage(data) {
        // 渲染后回调
        _util2.default.seo(); //默认 SEO 
    },
    jump: function jump(event) {
        var target = event.currentTarget;
        var url = target.dataset.url;
        // console.log(target);
        _util2.default.jump(url);
    },
    playVideo: function playVideo(event) {
        var target = event.currentTarget;
        var roomId = target.dataset.roomId;
        var liveType = target.dataset.liveType;
        if (!roomId) {
            swan.showToast({
                icon: 'none',
                title: '数据异常'
            });
            return false;
        }
        var url = "pages/w/room?roomId=" + roomId;
        if (liveType == 2) {
            url = "pages/s/room?roomId=" + roomId;
        }
        _util2.default.jump(url);
    },
    clearRecord: function clearRecord(event) {
        var _this3 = this;

        swan.showModal({
            title: '提示',
            content: '删除观看历史',
            cancelColor: '#999999',
            confirmColor: '#0099cc',
            success: function success(res) {
                if (res.confirm) {
                    console.log('删除观看记录 storyage');
                    swan.showToast({ title: '删除成功' });
                    _util2.default.record([]).then(function (res) {
                        _this3.loadPage();
                    });
                } else if (res.cancel) {
                    console.log('用户点击了取消');
                }
            }
        });
    }
};

Page(Object.assign({}, page));
});
window.__swanRoute='pages/my/my';window.usingComponents=[];require('100');

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvbXkvbXkuanMiXSwibmFtZXMiOlsidXNlciIsImFwcCIsImdldEFwcCIsImdsb2JhbERhdGEiLCJvcmlnaW5JY29uIiwicGFnZSIsImRhdGEiLCJsb2FkIiwicmVjb3JkcyIsIm9wdGlvbnMiLCJuZWVkTG9naW4iLCJhdXRoQ29va2llIiwibG9naW5JbmZvIiwiaXNMb2dpbiIsImljb24iLCJuaWNrbmFtZSIsImlzVmlwIiwib25TaG93IiwibG9hZFBhZ2UiLCJzZXREYXRhIiwiX25lZWRMb2dpbiIsImxlbmd0aCIsIl91cGRhdGVVc2VySW5mbyIsIm9uTG9hZCIsImluaXRVcGRhdGVEYXRhIiwiX2dldFVzZXJJbmZvIiwic3dhbiIsInNob3dUb2FzdCIsInRpdGxlIiwiY29uc29sZSIsImxvZyIsImdldFVzZXJJbmZvIiwiT2JqZWN0Iiwia2V5cyIsInJlcSIsImF1dGhjb29raWUiLCJ0aGVuIiwid2FybiIsImVyciIsImxvZ2luT3V0IiwiZXJyb3IiLCJzZXNzaW9uIiwiU2Vzc2lvbiIsImNsZWFyIiwidXNlcmluZm8iLCJxaXlpX3ZpcF9pbmZvIiwibGV2ZWwiLCJzZXQiLCJTRVNTSU9OX0FVVEhfS0VZIiwiU0VTU0lPTl9JTkZPX0tFWSIsIl8iLCJyZWNvcmQiLCJyZXZlcnNlIiwic3BsaWNlIiwiX2xvYWRlZFBhZ2UiLCJzZW8iLCJqdW1wIiwiZXZlbnQiLCJ0YXJnZXQiLCJjdXJyZW50VGFyZ2V0IiwidXJsIiwiZGF0YXNldCIsInBsYXlWaWRlbyIsInJvb21JZCIsImxpdmVUeXBlIiwiY2xlYXJSZWNvcmQiLCJzaG93TW9kYWwiLCJjb250ZW50IiwiY2FuY2VsQ29sb3IiLCJjb25maXJtQ29sb3IiLCJzdWNjZXNzIiwicmVzIiwiY29uZmlybSIsImNhbmNlbCIsIlBhZ2UiLCJhc3NpZ24iXSwibWFwcGluZ3MiOiI7OztBQUFBOztJQUFZQSxJOztBQUNaOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7QUFHQSxJQUFJQyxNQUFNQyxRQUFWO0FBQ0EsSUFBSUMsYUFBYUYsSUFBSUUsVUFBckI7QUFDQSxJQUFNQyxhQUFhLGdDQUFuQjtBQUNBLElBQU1DLE9BQU87QUFDVEMsVUFBTTtBQUNGQyxjQUFNLE1BREo7QUFFRkMsaUJBQVMsRUFGUDtBQUdGQyxpQkFBUztBQUNMQyx1QkFBVyxLQUROLEVBQ1k7QUFDakJDLHdCQUFZO0FBRlAsU0FIUDtBQU9GQyxtQkFBVztBQUNQQyxxQkFBUyxLQURGO0FBRVBiLGtCQUFNO0FBQ0ZjLHNCQUFNVixVQURKO0FBRUZXLDBCQUFVLEVBRlI7QUFHRkMsdUJBQU87QUFITDtBQUZDO0FBUFQsS0FERztBQWlCVEMsVUFqQlMsb0JBaUJBO0FBQ0wsYUFBS0MsUUFBTDtBQUNBO0FBQ0EsWUFBR2YsV0FBV08sU0FBZCxFQUF5QjtBQUNyQjtBQUNBLGlCQUFLSixJQUFMLENBQVVHLE9BQVYsQ0FBa0JDLFNBQWxCLEdBQThCVCxJQUFJRSxVQUFKLENBQWVPLFNBQTdDLENBRnFCLENBRWtDO0FBQ3ZELGlCQUFLSixJQUFMLENBQVVHLE9BQVYsQ0FBa0JFLFVBQWxCLEdBQStCVixJQUFJRSxVQUFKLENBQWVRLFVBQTlDOztBQUVBLGlCQUFLUSxPQUFMLENBQWEsbUJBQWIsRUFBa0MsS0FBbEM7QUFDQSxpQkFBS0MsVUFBTDtBQUNILFNBUEQsTUFPTyxJQUFHakIsV0FBV1EsVUFBWCxDQUFzQlUsTUFBdEIsS0FBaUMsQ0FBcEMsRUFBdUM7QUFDMUMsaUJBQUtDLGVBQUw7QUFDSDtBQUNKLEtBOUJRO0FBK0JUQyxVQS9CUyxvQkErQkE7QUFDTDtBQUNBO0FBQ0E7QUFDSCxLQW5DUTtBQW9DVEMsa0JBcENTLDRCQW9DUTtBQUNiLGFBQUtsQixJQUFMLENBQVVHLE9BQVYsQ0FBa0JDLFNBQWxCLEdBQThCUCxXQUFXUSxVQUF6QztBQUNILEtBdENRO0FBdUNUUyxjQXZDUyx3QkF1Q0k7QUFDVCxZQUFJVCxhQUFhLEtBQUtMLElBQUwsQ0FBVUcsT0FBVixDQUFrQkUsVUFBbkMsQ0FEUyxDQUNxQzs7QUFFOUMsWUFBR0EsY0FBY0EsZUFBZSxFQUFoQyxFQUFvQztBQUNoQyxpQkFBS2MsWUFBTCxDQUFrQmQsVUFBbEI7QUFDQSxpQkFBS0wsSUFBTCxDQUFVRyxPQUFWLENBQWtCQyxTQUFsQixHQUE4QixLQUE5QjtBQUNBVCxnQkFBSUUsVUFBSixDQUFlTyxTQUFmLEdBQTJCLEtBQTNCO0FBQ0gsU0FKRCxNQUlPO0FBQ0gsaUJBQUtZLGVBQUw7QUFDQUksaUJBQUtDLFNBQUwsQ0FBZSxFQUFFQyxPQUFPLE9BQVQsRUFBZjtBQUNBQyxvQkFBUUMsR0FBUjtBQUNIO0FBQ0osS0FuRFE7QUFvRFRMLGdCQXBEUyx3QkFvRElkLFVBcERKLEVBb0RnQjtBQUFBOztBQUNyQixZQUFJb0IsY0FBYy9CLEtBQUsrQixXQUFMLEVBQWxCO0FBQ0E7QUFDQSxZQUFHQSxlQUFlQyxPQUFPQyxJQUFQLENBQVlGLFdBQVosRUFBeUJWLE1BQXpCLEdBQWtDLENBQXBELEVBQXVEO0FBQ25EUSxvQkFBUUMsR0FBUixDQUFZQyxXQUFaO0FBQ0g7O0FBRURHLDZCQUFJSCxXQUFKLENBQWdCLEVBQUVJLFlBQVl4QixVQUFkLEVBQWhCLEVBQTRDeUIsSUFBNUMsQ0FBaUQsVUFBQzlCLElBQUQsRUFBVTtBQUN2RHVCLG9CQUFRUSxJQUFSO0FBQ0Esa0JBQUtmLGVBQUwsQ0FBcUJoQixJQUFyQixFQUEyQkssVUFBM0I7QUFDSCxTQUhELEVBR0csVUFBQzJCLEdBQUQsRUFBUztBQUNSLGtCQUFLQyxRQUFMO0FBQ0FWLG9CQUFRVyxLQUFSLENBQWNGLEdBQWQ7QUFDSCxTQU5EO0FBT0gsS0FsRVE7QUFtRVRDLFlBbkVTLHNCQW1FRTtBQUNQLGVBQU8sS0FBUDtBQUNILEtBckVRO0FBc0VUakIsbUJBdEVTLDJCQXNFT2hCLElBdEVQLEVBc0VhSyxVQXRFYixFQXNFeUI7QUFDOUIsWUFBRyxDQUFDTCxJQUFKLEVBQVU7QUFBQztBQUNQLGlCQUFLYSxPQUFMLENBQWEsbUJBQWIsRUFBa0MsS0FBbEM7QUFDQSxpQkFBS0EsT0FBTCxDQUFhLHFCQUFiLEVBQW9DZixVQUFwQztBQUNBLGlCQUFLZSxPQUFMLENBQWEseUJBQWIsRUFBd0MsRUFBeEM7QUFDQSxpQkFBS0EsT0FBTCxDQUFhLHNCQUFiLEVBQXFDLEtBQXJDO0FBQ0FzQiw4QkFBUUMsT0FBUixDQUFnQkMsS0FBaEI7QUFFSCxTQVBELE1BT087QUFBQztBQUFELGlDQUNzQnJDLEtBQUtzQyxRQUQzQjtBQUFBLGdCQUNHN0IsUUFESCxrQkFDR0EsUUFESDtBQUFBLGdCQUNhRCxJQURiLGtCQUNhQSxJQURiOztBQUVILGdCQUFJRSxRQUFRLENBQUNWLEtBQUt1QyxhQUFMLElBQXNCLEVBQXZCLEVBQTJCQyxLQUEzQixHQUFtQyxDQUEvQztBQUNBO0FBQ0FqQixvQkFBUUMsR0FBUixDQUFZZixRQUFaLEVBQXNCRCxJQUF0QjtBQUNBLGlCQUFLSyxPQUFMLENBQWEsbUJBQWIsRUFBa0MsSUFBbEM7QUFDQSxpQkFBS0EsT0FBTCxDQUFhLHFCQUFiLEVBQW9DTCxJQUFwQztBQUNBLGlCQUFLSyxPQUFMLENBQWEseUJBQWIsRUFBd0NKLFFBQXhDO0FBQ0EsaUJBQUtJLE9BQUwsQ0FBYSxzQkFBYixFQUFxQ0gsU0FBUyxLQUE5Qzs7QUFFQXlCLDhCQUFRQyxPQUFSLENBQWdCSyxHQUFoQixDQUFvQk4sa0JBQVFPLGdCQUE1QixFQUE4Q3JDLFVBQTlDO0FBQ0E4Qiw4QkFBUUMsT0FBUixDQUFnQkssR0FBaEIsQ0FBb0JOLGtCQUFRUSxnQkFBNUIsRUFBOEMzQyxJQUE5QztBQUNBb0IsaUJBQUtDLFNBQUwsQ0FBZSxFQUFFQyxpQ0FBRixFQUFmO0FBQ0g7QUFDSixLQTVGUTtBQTZGVFYsWUE3RlMsc0JBNkZFO0FBQUE7O0FBQ1A7QUFDQTtBQUNBZ0MsdUJBQUVDLE1BQUYsR0FBV2YsSUFBWCxDQUFnQixVQUFDOUIsSUFBRCxFQUFVO0FBQ3RCLG1CQUFLYSxPQUFMLENBQWEsRUFBRSxXQUFXYixRQUFRQSxLQUFLOEMsT0FBTCxHQUFlQyxNQUFmLENBQXNCLENBQXRCLEVBQXlCLENBQXpCLENBQXJCLEVBQWI7QUFDSCxTQUZEO0FBSUgsS0FwR1E7QUFxR1RDLGVBckdTLHVCQXFHR2hELElBckdILEVBcUdTO0FBQ2Q7QUFDQTRDLHVCQUFFSyxHQUFGLEdBRmMsQ0FFTDtBQUNaLEtBeEdRO0FBeUdUQyxRQXpHUyxnQkF5R0pDLEtBekdJLEVBeUdHO0FBQ1IsWUFBTUMsU0FBU0QsTUFBTUUsYUFBckI7QUFDQSxZQUFNQyxNQUFNRixPQUFPRyxPQUFQLENBQWVELEdBQTNCO0FBQ0E7QUFDQVYsdUJBQUVNLElBQUYsQ0FBT0ksR0FBUDtBQUNILEtBOUdRO0FBK0dURSxhQS9HUyxxQkErR0NMLEtBL0dELEVBK0dRO0FBQ2IsWUFBTUMsU0FBU0QsTUFBTUUsYUFBckI7QUFDQSxZQUFNSSxTQUFTTCxPQUFPRyxPQUFQLENBQWVFLE1BQTlCO0FBQ0EsWUFBTUMsV0FBV04sT0FBT0csT0FBUCxDQUFlRyxRQUFoQztBQUNBLFlBQUcsQ0FBQ0QsTUFBSixFQUFZO0FBQ1JyQyxpQkFBS0MsU0FBTCxDQUFlO0FBQ1hiLHNCQUFNLE1BREs7QUFFWGMsdUJBQU87QUFGSSxhQUFmO0FBSUEsbUJBQU8sS0FBUDtBQUNIO0FBQ0QsWUFBSWdDLCtCQUE2QkcsTUFBakM7QUFDQSxZQUFHQyxZQUFZLENBQWYsRUFBa0I7QUFDZEosMkNBQTZCRyxNQUE3QjtBQUNIO0FBQ0RiLHVCQUFFTSxJQUFGLENBQU9JLEdBQVA7QUFDSCxLQS9IUTtBQWdJVEssZUFoSVMsdUJBZ0lHUixLQWhJSCxFQWdJVTtBQUFBOztBQUNmL0IsYUFBS3dDLFNBQUwsQ0FBZTtBQUNYdEMsbUJBQU8sSUFESTtBQUVYdUMscUJBQVMsUUFGRTtBQUdYQyx5QkFBYSxTQUhGO0FBSVhDLDBCQUFjLFNBSkg7QUFLWEMscUJBQVMsaUJBQUNDLEdBQUQsRUFBUztBQUNkLG9CQUFHQSxJQUFJQyxPQUFQLEVBQWdCO0FBQ1ozQyw0QkFBUUMsR0FBUixDQUFZLGlCQUFaO0FBQ0FKLHlCQUFLQyxTQUFMLENBQWUsRUFBRUMsT0FBTyxNQUFULEVBQWY7QUFDQXNCLG1DQUFFQyxNQUFGLENBQVMsRUFBVCxFQUFhZixJQUFiLENBQWtCLFVBQUNtQyxHQUFELEVBQVM7QUFDdkIsK0JBQUtyRCxRQUFMO0FBQ0gscUJBRkQ7QUFHSCxpQkFORCxNQU1PLElBQUdxRCxJQUFJRSxNQUFQLEVBQWU7QUFDbEI1Qyw0QkFBUUMsR0FBUixDQUFZLFNBQVo7QUFDSDtBQUNKO0FBZlUsU0FBZjtBQWlCSDtBQWxKUSxDQUFiOztBQXNKQTRDLEtBQUsxQyxPQUFPMkMsTUFBUCxDQUFjLEVBQWQsRUFBa0J0RSxJQUFsQixDQUFMLEUiLCJmaWxlIjoicGFnZXMvbXkvbXkuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyB1c2VyIGZyb20gJy4uLy4uL2NvbW1vbi91c2VyL3VzZXJJbmZvJztcbmltcG9ydCBfIGZyb20gXCIuLi8uLi9jb21tb24vdXRpbHMvdXRpbFwiXG5pbXBvcnQgcmVxIGZyb20gXCIuL3NlcnZpY2UvcmVxU2VydmljZVwiO1xuaW1wb3J0IHNlc3Npb24gZnJvbSBcIi4uLy4uL2NvbW1vbi9sb2dpbi9zZXNzaW9uXCI7XG5cblxubGV0IGFwcCA9IGdldEFwcCgpO1xubGV0IGdsb2JhbERhdGEgPSBhcHAuZ2xvYmFsRGF0YTtcbmNvbnN0IG9yaWdpbkljb24gPSAnLi4vLi4vYXNzZXRzL215L2F2YXRhci0xNDQucG5nJztcbmNvbnN0IHBhZ2UgPSB7XG4gICAgZGF0YToge1xuICAgICAgICBsb2FkOiAnbm9uZScsXG4gICAgICAgIHJlY29yZHM6IFtdLFxuICAgICAgICBvcHRpb25zOiB7XG4gICAgICAgICAgICBuZWVkTG9naW46IGZhbHNlLC8v6aG16Z2i5omT5byA5ZCO5piv5ZCm6ZyA6KaB55m75b2V5ZCXP1xuICAgICAgICAgICAgYXV0aENvb2tpZTogJydcbiAgICAgICAgfSxcbiAgICAgICAgbG9naW5JbmZvOiB7XG4gICAgICAgICAgICBpc0xvZ2luOiBmYWxzZSxcbiAgICAgICAgICAgIHVzZXI6IHtcbiAgICAgICAgICAgICAgICBpY29uOiBvcmlnaW5JY29uLFxuICAgICAgICAgICAgICAgIG5pY2tuYW1lOiAnJyxcbiAgICAgICAgICAgICAgICBpc1ZpcDogZmFsc2VcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sXG4gICAgb25TaG93KCkge1xuICAgICAgICB0aGlzLmxvYWRQYWdlKCk7XG4gICAgICAgIC8vIHRoaXMuX2dldFVzZXJJbmZvKCc5MWxMcWJybGEzdmU5V2tGZjVrdUFYZWtKeFpRWmE3am5sTWtmVm9xWmp2ZVdQTW5NdGZubHdQZHBZbTJ6Z2pEQ2RONWMnKTsvL1RPRE8gdGVzdCBERUxFVEVcbiAgICAgICAgaWYoZ2xvYmFsRGF0YS5uZWVkTG9naW4pIHtcbiAgICAgICAgICAgIC8vIHN3YW4uc2hvd1RvYXN0KHsgdGl0bGU6IGAke2FwcC5nbG9iYWxEYXRhLm5lZWRMb2dpbn1+fiR7YXBwLmdsb2JhbERhdGEuYXV0aENvb2tpZX1gIH0pO1xuICAgICAgICAgICAgdGhpcy5kYXRhLm9wdGlvbnMubmVlZExvZ2luID0gYXBwLmdsb2JhbERhdGEubmVlZExvZ2luOy8vVE9ETyDnlLHkuo4gc3dhbi5zd2l0Y2hUYWIgIOi3s+i9rOS8oOWPguS8muWvvOiHtOmhtemdouaKpemUmeWBh+atuyDlsLHlhpnlhaXlhajlsYDlj5jph4/kuK3miafooYxcbiAgICAgICAgICAgIHRoaXMuZGF0YS5vcHRpb25zLmF1dGhDb29raWUgPSBhcHAuZ2xvYmFsRGF0YS5hdXRoQ29va2llO1xuXG4gICAgICAgICAgICB0aGlzLnNldERhdGEoJ2xvZ2luSW5mby5pc0xvZ2luJywgZmFsc2UpO1xuICAgICAgICAgICAgdGhpcy5fbmVlZExvZ2luKCk7XG4gICAgICAgIH0gZWxzZSBpZihnbG9iYWxEYXRhLmF1dGhDb29raWUubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICB0aGlzLl91cGRhdGVVc2VySW5mbygpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICBvbkxvYWQoKSB7XG4gICAgICAgIC8vIFRPRE9cbiAgICAgICAgLy8gZ2xvYmFsRGF0YS5uZWVkTG9naW4gPSAxO1xuICAgICAgICAvLyBnbG9iYWxEYXRhLmF1dGhDb29raWUgPSAnQkF0VkNCUzNYZDdsb1B1Tko3MGJSNW0zRElxenBaUGRTQVNsZUlhbTNXbTMxb09URWw3VzNlYlRaRUZjRzVjWXJFRjlKWnZVQjBTRE53Qm0xUXd6eHRBNEFNeDVndENNdTQwaFFNZlJYaVpTVmRxclZIQ056cW0xRlVnJztcbiAgICB9LFxuICAgIGluaXRVcGRhdGVEYXRhKCkge1xuICAgICAgICB0aGlzLmRhdGEub3B0aW9ucy5uZWVkTG9naW4gPSBnbG9iYWxEYXRhLmF1dGhDb29raWU7XG4gICAgfSxcbiAgICBfbmVlZExvZ2luKCkge1xuICAgICAgICBsZXQgYXV0aENvb2tpZSA9IHRoaXMuZGF0YS5vcHRpb25zLmF1dGhDb29raWU7Ly/ojrflj5Ygb3B0aW9uc1xuXG4gICAgICAgIGlmKGF1dGhDb29raWUgJiYgYXV0aENvb2tpZSAhPT0gJycpIHtcbiAgICAgICAgICAgIHRoaXMuX2dldFVzZXJJbmZvKGF1dGhDb29raWUpXG4gICAgICAgICAgICB0aGlzLmRhdGEub3B0aW9ucy5uZWVkTG9naW4gPSBmYWxzZTtcbiAgICAgICAgICAgIGFwcC5nbG9iYWxEYXRhLm5lZWRMb2dpbiA9IGZhbHNlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5fdXBkYXRlVXNlckluZm8oKTtcbiAgICAgICAgICAgIHN3YW4uc2hvd1RvYXN0KHsgdGl0bGU6ICfor7fngrnlh7vnmbvlvZUnIH0pO1xuICAgICAgICAgICAgY29uc29sZS5sb2coYOacqueZu+W9lWApO1xuICAgICAgICB9XG4gICAgfSxcbiAgICBfZ2V0VXNlckluZm8oYXV0aENvb2tpZSkge1xuICAgICAgICBsZXQgZ2V0VXNlckluZm8gPSB1c2VyLmdldFVzZXJJbmZvKCk7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGdldFVzZXJJbmZvKTtcbiAgICAgICAgaWYoZ2V0VXNlckluZm8gJiYgT2JqZWN0LmtleXMoZ2V0VXNlckluZm8pLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGdldFVzZXJJbmZvKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJlcS5nZXRVc2VySW5mbyh7IGF1dGhjb29raWU6IGF1dGhDb29raWUgfSkudGhlbigoZGF0YSkgPT4ge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKGDnmbvlvZUg5oiQ5YqfIWApO1xuICAgICAgICAgICAgdGhpcy5fdXBkYXRlVXNlckluZm8oZGF0YSwgYXV0aENvb2tpZSk7XG4gICAgICAgIH0sIChlcnIpID0+IHtcbiAgICAgICAgICAgIHRoaXMubG9naW5PdXQoKTtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICAgICAgfSlcbiAgICB9LFxuICAgIGxvZ2luT3V0KCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfSxcbiAgICBfdXBkYXRlVXNlckluZm8oZGF0YSwgYXV0aENvb2tpZSkge1xuICAgICAgICBpZighZGF0YSkgey8v55m75Ye6XG4gICAgICAgICAgICB0aGlzLnNldERhdGEoJ2xvZ2luSW5mby5pc0xvZ2luJywgZmFsc2UpO1xuICAgICAgICAgICAgdGhpcy5zZXREYXRhKCdsb2dpbkluZm8udXNlci5pY29uJywgb3JpZ2luSWNvbik7XG4gICAgICAgICAgICB0aGlzLnNldERhdGEoJ2xvZ2luSW5mby51c2VyLm5pY2tuYW1lJywgJycpO1xuICAgICAgICAgICAgdGhpcy5zZXREYXRhKCdsb2dpbkluZm8udXNlci5pc1ZpcCcsIGZhbHNlKTtcbiAgICAgICAgICAgIHNlc3Npb24uU2Vzc2lvbi5jbGVhcigpO1xuXG4gICAgICAgIH0gZWxzZSB7Ly8g55m75b2VIHN1Y2Nlc3NcbiAgICAgICAgICAgIGxldCB7IG5pY2tuYW1lLCBpY29uIH0gPSBkYXRhLnVzZXJpbmZvO1xuICAgICAgICAgICAgbGV0IGlzVmlwID0gKGRhdGEucWl5aV92aXBfaW5mbyB8fCB7fSkubGV2ZWwgPiAxO1xuICAgICAgICAgICAgLy8gW2lzVmlwXSA9IHFpeWlfdmlwX2luZm8ubGV2ZWwgPiAxXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhuaWNrbmFtZSwgaWNvbik7XG4gICAgICAgICAgICB0aGlzLnNldERhdGEoJ2xvZ2luSW5mby5pc0xvZ2luJywgdHJ1ZSk7XG4gICAgICAgICAgICB0aGlzLnNldERhdGEoJ2xvZ2luSW5mby51c2VyLmljb24nLCBpY29uKTtcbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YSgnbG9naW5JbmZvLnVzZXIubmlja25hbWUnLCBuaWNrbmFtZSk7XG4gICAgICAgICAgICB0aGlzLnNldERhdGEoJ2xvZ2luSW5mby51c2VyLmlzVmlwJywgaXNWaXAgfHwgZmFsc2UpO1xuXG4gICAgICAgICAgICBzZXNzaW9uLlNlc3Npb24uc2V0KHNlc3Npb24uU0VTU0lPTl9BVVRIX0tFWSwgYXV0aENvb2tpZSk7XG4gICAgICAgICAgICBzZXNzaW9uLlNlc3Npb24uc2V0KHNlc3Npb24uU0VTU0lPTl9JTkZPX0tFWSwgZGF0YSk7XG4gICAgICAgICAgICBzd2FuLnNob3dUb2FzdCh7IHRpdGxlOiBg55m75b2V5oiQ5YqfYCB9KTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgbG9hZFBhZ2UoKSB7XG4gICAgICAgIC8vIF8uanVtcCgnc3ViUGFja2FnZS9wYWdlcy9teS9hYm91dCcpO1xuICAgICAgICAvLyBfLmp1bXAoJ3N1YlBhY2thZ2UvcGFnZXMvbXkvcGxheUxvZycpO1xuICAgICAgICBfLnJlY29yZCgpLnRoZW4oKGRhdGEpID0+IHtcbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7ICdyZWNvcmRzJzogZGF0YSAmJiBkYXRhLnJldmVyc2UoKS5zcGxpY2UoMCwgNCkgfSk7XG4gICAgICAgIH0pXG5cbiAgICB9LFxuICAgIF9sb2FkZWRQYWdlKGRhdGEpIHtcbiAgICAgICAgLy8g5riy5p+T5ZCO5Zue6LCDXG4gICAgICAgIF8uc2VvKCk7IC8v6buY6K6kIFNFTyBcbiAgICB9LFxuICAgIGp1bXAoZXZlbnQpIHtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gZXZlbnQuY3VycmVudFRhcmdldDtcbiAgICAgICAgY29uc3QgdXJsID0gdGFyZ2V0LmRhdGFzZXQudXJsO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyh0YXJnZXQpO1xuICAgICAgICBfLmp1bXAodXJsKTtcbiAgICB9LFxuICAgIHBsYXlWaWRlbyhldmVudCkge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgICAgICBjb25zdCByb29tSWQgPSB0YXJnZXQuZGF0YXNldC5yb29tSWQ7XG4gICAgICAgIGNvbnN0IGxpdmVUeXBlID0gdGFyZ2V0LmRhdGFzZXQubGl2ZVR5cGU7XG4gICAgICAgIGlmKCFyb29tSWQpIHtcbiAgICAgICAgICAgIHN3YW4uc2hvd1RvYXN0KHtcbiAgICAgICAgICAgICAgICBpY29uOiAnbm9uZScsXG4gICAgICAgICAgICAgICAgdGl0bGU6ICfmlbDmja7lvILluLgnXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGxldCB1cmwgPSBgcGFnZXMvdy9yb29tP3Jvb21JZD0ke3Jvb21JZH1gO1xuICAgICAgICBpZihsaXZlVHlwZSA9PSAyKSB7XG4gICAgICAgICAgICB1cmwgPSBgcGFnZXMvcy9yb29tP3Jvb21JZD0ke3Jvb21JZH1gO1xuICAgICAgICB9XG4gICAgICAgIF8uanVtcCh1cmwpO1xuICAgIH0sXG4gICAgY2xlYXJSZWNvcmQoZXZlbnQpIHtcbiAgICAgICAgc3dhbi5zaG93TW9kYWwoe1xuICAgICAgICAgICAgdGl0bGU6ICfmj5DnpLonLFxuICAgICAgICAgICAgY29udGVudDogJ+WIoOmZpOingueci+WOhuWPsicsXG4gICAgICAgICAgICBjYW5jZWxDb2xvcjogJyM5OTk5OTknLFxuICAgICAgICAgICAgY29uZmlybUNvbG9yOiAnIzAwOTljYycsXG4gICAgICAgICAgICBzdWNjZXNzOiAocmVzKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYocmVzLmNvbmZpcm0pIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ+WIoOmZpOingueci+iusOW9lSBzdG9yeWFnZScpO1xuICAgICAgICAgICAgICAgICAgICBzd2FuLnNob3dUb2FzdCh7IHRpdGxlOiAn5Yig6Zmk5oiQ5YqfJyB9KTtcbiAgICAgICAgICAgICAgICAgICAgXy5yZWNvcmQoW10pLnRoZW4oKHJlcykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkUGFnZSgpO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYocmVzLmNhbmNlbCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygn55So5oi354K55Ye75LqG5Y+W5raIJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG59XG5cblxuUGFnZShPYmplY3QuYXNzaWduKHt9LCBwYWdlKSlcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvbXkvbXkuanMiXSwic291cmNlUm9vdCI6IiJ9