window.define('102', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _roomAction = __webpack_require__(103);

var room = _interopRequireWildcard(_roomAction);

var _reqService = __webpack_require__(44);

var req = _interopRequireWildcard(_reqService);

var _playerAction = __webpack_require__(70);

var _playerAction2 = _interopRequireDefault(_playerAction);

var _msgAction = __webpack_require__(67);

var _msgAction2 = _interopRequireDefault(_msgAction);

var _sendMsgAction = __webpack_require__(66);

var _sendMsgAction2 = _interopRequireDefault(_sendMsgAction);

var _utils = __webpack_require__(51);

var utils = _interopRequireWildcard(_utils);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

var _Emitter = __webpack_require__(53);

var _Emitter2 = _interopRequireDefault(_Emitter);

var _jsSensor = __webpack_require__(59);

var _jsSensor2 = _interopRequireDefault(_jsSensor);

var _user = __webpack_require__(37);

var user = _interopRequireWildcard(_user);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

// import mutiAccount from '../../../components/mutiAccount/mutiAccount'

var app = getApp();

var page = {
    /**
     * 页面的初始数据
     */
    data: {
        errorTip: true,
        activeTab: "chat",
        roomId: null,
        hostInfo: null,
        msgList: [{
            type: 0,
            content: "正在准备弹幕"
        }],
        scrollHeight: 100,
        scrollHideLoadMore: true,
        scrollAnimation: false,
        inputFocus: false,
        inputText: "",
        inputAvailable: "",
        showKeyboard: "",
        videoBodyTop: 0,
        video: {
            needVIP: false,
            needLogin: false,
            show: false,
            offline: false
        },
        previewCover: 'http://www.iqiyipic.com/common/fix/wx-iqiyi/player-tip-bg.jpg',
        roomStatus: 0,
        followed: false,
        recommendList: [],
        tab: {
            host: false,
            chat: false
        },
        keyboardHeight: 0
    },

    clickShowHost: function clickShowHost() {
        this.setData({
            activeTab: "host"
        });
        room.getRecommendList(this);
    },

    clickShowChat: function clickShowChat() {
        this.setData({
            activeTab: "chat"
        });
    },

    clickFollow: function clickFollow() {
        console.log('暂时不能订阅!');
        swan.showToast({ title: '订阅成功' });
        this.clickFollow = function () {
            swan.showToast({ title: '已订阅' });
        };
        // room.clickFollow(this);
    },


    clickRecommend: function clickRecommend(e) {
        room.redirectTo(e.currentTarget.dataset);
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function onShareAppMessage() {
        var shareData = {
            title: this.roomInfo.shareInfo.programName,
            imageUrl: this.roomInfo.shareInfo.cover.replace("_480_270", "_480_360"),
            path: 'pages/w/room?roomId=' + this.roomInfo.roomId
        };
        return shareData;
    },

    onClickShare: function onClickShare() {
        var shareData = {
            title: this.roomInfo.shareInfo.programName,
            content: this.roomInfo.shareInfo.description,
            imageUrl: this.roomInfo.shareInfo.cover.replace("_480_270", "_480_360"),
            path: 'pages/w/room?roomId=' + this.roomInfo.roomId
        };
        swan.openShare(shareData);
    },

    /**
     * 生命周期函数--监听页面加载
     */
    store: {
        dispatch: function dispatch() {}
    },
    // isMultiAccount: mutiAccount.isMultiAccount,
    seo: function seo() {
        _util2.default.seo({
            desc: this.roomInfo.anchorNickname + '_' + this.roomInfo.roomTitle + '_' + this.roomInfo.subTitle + '\u76F4\u64AD_\u7231\u5947\u827A\u76F4\u64AD-\u7231\u5947\u827A',
            keywords: this.roomInfo.anchorNickname + ',' + this.roomInfo.anchorNickname + '\u76F4\u64AD,' + this.roomInfo.anchorNickname + '\u76F4\u64AD\u95F4,' + this.roomInfo.anchorNickname + '\u76F4\u64AD\u5730\u5740\uFF0C' + this.roomInfo.anchorNickname + ' ' + this.roomInfo.subTitle + '\uFF0C' + this.roomInfo.anchorNickname + ' ' + this.roomInfo.subTitle + '\u76F4\u64AD\uFF0C' + this.roomInfo.anchorNickname + ' ' + this.roomInfo.subTitle + '\u89C6\u9891',
            title: this.roomInfo.anchorNickname + '_' + this.roomInfo.roomTitle + '_' + this.roomInfo.subTitle + '\u76F4\u64AD_\u7231\u5947\u827A\u76F4\u64AD-\u7231\u5947\u827A',
            video: {
                url: 'pages/w/room?roomId=' + this.roomInfo.roomId,
                duration: 3600,
                image: this.roomInfo.shareInfo.cover.replace("_480_270", "_480_360")
            }
        });
    },
    onLoad: function onLoad(opt) {
        this.trigger = new _Emitter2.default();
        this.roomInfo = {};
        this.components = {};
        this.setData({
            "roomId": opt.roomId,
            "reqSuccess": false
        });
        this.sensor = {};
        this.sensorInit();
        this.reqInit();
    },
    sensorInit: function sensorInit() {
        var globalData = getApp().globalData;
        this.sensor = new _jsSensor2.default({
            pl: globalData.pl || '2_24_200_3',
            t: globalData.tl || 'bd_ios',
            version: globalData.version || '2.01.05', //baidu mini pro version 
            device_id: user.getDeviceId() || '',
            userId: '',
            url: '/v1/live/initial',
            roomId: this.data.roomId
        }, swan);
    },
    reqInit: function reqInit() {
        var _this = this;

        var conStart = new Date().getTime();
        req.getRoomInfo(this.data.roomId).then(function (res) {
            _this.setData({
                "reqSuccess": true
            });
            var conEnd = new Date().getTime();
            _this.sensor.push(_this.sensor.CODE.ROOM_INITIAL_SUCCESS, res.code, conEnd - conStart, 0, '', '' + res.msg);

            if (res.code === "A00000") {
                _this.roomInfo = res.data;
                _this.roomInfo.qpId = res.data.programInfo.qipuId;
                _this.roomInfo.roomStatus = res.data.programInfo.playStatus;
                _this.roomInfo.roomId = res.data.programInfo.roomId;
                _this.roomInfo.liveTypeId = res.data.programInfo.liveTypeId;
                _this.roomInfo.liveSubTypeId = res.data.programInfo.liveSubTypeId;
                _this.roomInfo.chatRoomId = res.data.chatInfo.chatRoomId;

                _this.roomInfo.anchorNickname = res.data.anchorInfo.anchorNickName;
                _this.roomInfo.roomTitle = res.data.programInfo.programName;
                _this.roomInfo.subTitle = res.data.programInfo.liveTypeName;

                _this.roomInfo.shareInfo = res.data.shareInfo;

                _this._tabDisplay(res.data.tabControl);
                //添加到本地缓存历史记录
                _util2.default.record({
                    roomId: res.data.programInfo.roomId,
                    qipuId: res.data.programInfo.qipuId,
                    coverImageUrl: res.data.programInfo.coverImageUrl || res.data.shareInfo.cover.replace("_480_270", "_480_360"),
                    liveType: 1,
                    playNumber: res.data.programInfo.playNumber,
                    title: res.data.programInfo.programName || res.data.programInfo.description,
                    nickname: res.data.anchorInfo.anchorNickName,
                    recordTime: new Date().getTime()
                });

                var params = {
                    roomTitle: res.data.programInfo.programName,
                    roomStatus: res.data.programInfo.playStatus, //0: 未知, 1：未开始，2：直播，3:回看中,4:回看结束 （新增）,5:轮播中, -1 禁播中  ### 对应合并 "roomStatus": 1, // 0.停播中 1.直播中 2禁播中 3轮播中,
                    followed: res.data.anchorInfo.isFollowed,
                    followNum: utils.shortNum(res.data.anchorInfo.anchorFollowerNum),
                    liveTypeName: res.data.programInfo.liveTypeName,
                    liveSubTypeName: res.data.programInfo.liveSubTypeName,
                    hostInfo: {
                        "anchorIcon": res.data.anchorInfo.anchorIcon,
                        "nickname": res.data.anchorInfo.anchorNickName,
                        // "wallet": utils.shortNum(res.data.wallet),// 身价
                        // "populaty": utils.shortNum(res.data.populaty), // 热度
                        "info": res.data.programInfo.description
                    }
                };
                _this.seo();
                _this.setData(params);
                _this.setData({ 'previewCover': res.data.programInfo.coverImageUrl || 'http://www.iqiyipic.com/common/fix/wx-iqiyi/player-tip-bg.jpg' });
                swan.setNavigationBarTitle({
                    title: res.data.programInfo.programName
                });
                _this.components.playerControl = new _playerAction2.default(_this);
                // 拉取最后几条聊天记录
                req.getLatestMsg(_this.roomInfo.chatRoomId).then(function (data) {
                    _this.roomInfo.latestMsg = data;
                    _this.components.sendBox = new _sendMsgAction2.default(_this);
                    _this.components.msgBox = new _msgAction2.default(_this, res.data.chatInfo.chatRoomId);
                }).catch(function (err) {
                    console.error(err);
                });
                _this.eventTester("canplaythrough", function (e) {
                    console.log('canplaythrough');
                });
            } else {
                if (res.code === "A00005") {
                    console.error('\u9700\u8981\u6295\u9012\u7684', res.msg); // TODO 投递
                    _this.sensor.push(_this.sensor.CODE.ROOM_INITIAL_ERR, res.code, conEnd - conStart, 0, '', '' + res.msg);
                }
                _this.components.playerControl = new _playerAction2.default(_this);
                _this.setData({
                    errRoom: true, //房间错误
                    video: {
                        show: false,
                        errorInfo: true,
                        errorMsg: res.msg || '视频不能播放'
                    },
                    previewCover: 'http://www.iqiyipic.com/common/fix/wx-iqiyi/player-tip-bg.jpg'
                });
            }
        }, function (res) {
            console.log(res);
        });
    },
    otherSmartProgram: function otherSmartProgram() {
        swan.navigateToSmartProgram({
            appKey: 'FSTodu0UiA5MGU5CUp31WyvmZtxt905Y', // 要打开的小程序 App Key
            path: 'pages/w/room?roomId=' + this.roomInfo.roomId,
            // path: '', // 打开的页面路径，如果为空则打开首页
            extraData: {
                // roomId: 52581
            },
            success: function success(res) {
                console.log(res);
                // 打开成功
            },
            complete: function complete() {
                swan.showModal({ title: '123321' });
                // 打开成功
            }
        });
    },
    _tabDisplay: function _tabDisplay(tabList) {
        var _this2 = this;

        tabList.forEach(function (item) {
            if (item.displayName === '主播' && item.enable) {
                _this2.data.tab.host = true;
            } else if (item.displayName === '聊天' && item.enable) {
                _this2.data.tab.chat = true;
            }
            _this2.setData({ tab: _this2.data.tab });
        });
        if (!this.data.tab.chat && this.data.tab.host) {
            this.data.activeTab = 'host';
            this.setData({ activeTab: 'host' });
            room.getRecommendList(this);
        }
    },

    eventTester: function eventTester(e, eventHanler) {
        var Media = document.getElementById('videoId');
        Media.addEventListener(e, function () {
            eventHanler && eventHanler();
            out.debug(new Date().getTime(), e);
        }, false);
    },

    afterLoginTrigger: function afterLoginTrigger() {
        swan.showToast({
            title: '\u767B\u5F55\u6210\u529F',
            icon: 'none'
        });
        room.refreshInfo(this);
        this.trigger.emit("afterLoginSuccess");
    },

    afterLogoutTrigger: function afterLogoutTrigger() {
        room.resetFollowBtn(this);
        this.trigger.emit("afterLogoutSuccess");
    },

    loginSuccess: function loginSuccess() {
        this.trigger.emit("afterGetUserInfo");
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function onReady() {
        // console.log('onReady');
        var page = this;
        // this.setData({
        //     scrollHeight: room.getScrollHeight(),
        //     roomInfoHeight: room.getRoomInfoHeight(),
        //     inputFitClass: room.getInputFitClass()
        // });
        room.getScrollHeight(page);
        room.getRoomInfoHeight(page);
        room.getInputFitClass(page);
        // getApp().emitter.on("afterLoginSuccess", this.afterLoginTrigger);
        // getApp().emitter.on("afterLogoutSuccess", this.afterLogoutTrigger);
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function onShow() {
        this.trigger.emit("showPage");
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function onHide() {
        // getApp().emitter.emit("hidePage");
        this.trigger.emit("hidePage");
    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function onUnload() {
        this.trigger.emit("pageUnload");
        // console.log(this.trigger);
        this.trigger.off();
        this.setData({
            errorTip: true,
            activeTab: "chat",
            // roomId: null,
            hostInfo: null,
            // msgList: [{
            //     type: 0,
            //     content: "正在准备弹幕"
            // }],
            scrollHeight: 100,
            scrollHideLoadMore: true,
            scrollAnimation: false,
            inputFocus: false,
            inputText: "",
            inputAvailable: "",
            showKeyboard: "",
            videoBodyTop: 0,
            keyboardHeight: 0,
            video: {
                needVIP: false,
                needLogin: false,
                show: false,
                offline: false,
                url: ""
            }
        });
        // getApp().emitter.off("afterLoginSuccess", this.afterLoginTrigger);
        // getApp().emitter.off("afterLogoutSuccess", this.afterLogoutTrigger);
    }
};
Page(Object.assign({}, page));
});
window.__swanRoute='pages/w/room';window.usingComponents=[];require('102');

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvdy9yb29tLmpzIl0sIm5hbWVzIjpbInJvb20iLCJyZXEiLCJ1dGlscyIsInVzZXIiLCJhcHAiLCJnZXRBcHAiLCJwYWdlIiwiZGF0YSIsImVycm9yVGlwIiwiYWN0aXZlVGFiIiwicm9vbUlkIiwiaG9zdEluZm8iLCJtc2dMaXN0IiwidHlwZSIsImNvbnRlbnQiLCJzY3JvbGxIZWlnaHQiLCJzY3JvbGxIaWRlTG9hZE1vcmUiLCJzY3JvbGxBbmltYXRpb24iLCJpbnB1dEZvY3VzIiwiaW5wdXRUZXh0IiwiaW5wdXRBdmFpbGFibGUiLCJzaG93S2V5Ym9hcmQiLCJ2aWRlb0JvZHlUb3AiLCJ2aWRlbyIsIm5lZWRWSVAiLCJuZWVkTG9naW4iLCJzaG93Iiwib2ZmbGluZSIsInByZXZpZXdDb3ZlciIsInJvb21TdGF0dXMiLCJmb2xsb3dlZCIsInJlY29tbWVuZExpc3QiLCJ0YWIiLCJob3N0IiwiY2hhdCIsImtleWJvYXJkSGVpZ2h0IiwiY2xpY2tTaG93SG9zdCIsInNldERhdGEiLCJnZXRSZWNvbW1lbmRMaXN0IiwiY2xpY2tTaG93Q2hhdCIsImNsaWNrRm9sbG93IiwiY29uc29sZSIsImxvZyIsInN3YW4iLCJzaG93VG9hc3QiLCJ0aXRsZSIsImNsaWNrUmVjb21tZW5kIiwiZSIsInJlZGlyZWN0VG8iLCJjdXJyZW50VGFyZ2V0IiwiZGF0YXNldCIsIm9uU2hhcmVBcHBNZXNzYWdlIiwic2hhcmVEYXRhIiwicm9vbUluZm8iLCJzaGFyZUluZm8iLCJwcm9ncmFtTmFtZSIsImltYWdlVXJsIiwiY292ZXIiLCJyZXBsYWNlIiwicGF0aCIsIm9uQ2xpY2tTaGFyZSIsImRlc2NyaXB0aW9uIiwib3BlblNoYXJlIiwic3RvcmUiLCJkaXNwYXRjaCIsInNlbyIsIl8iLCJkZXNjIiwiYW5jaG9yTmlja25hbWUiLCJyb29tVGl0bGUiLCJzdWJUaXRsZSIsImtleXdvcmRzIiwidXJsIiwiZHVyYXRpb24iLCJpbWFnZSIsIm9uTG9hZCIsIm9wdCIsInRyaWdnZXIiLCJFbWl0dGVyIiwiY29tcG9uZW50cyIsInNlbnNvciIsInNlbnNvckluaXQiLCJyZXFJbml0IiwiZ2xvYmFsRGF0YSIsIlNlbnNvciIsInBsIiwidCIsInRsIiwidmVyc2lvbiIsImRldmljZV9pZCIsImdldERldmljZUlkIiwidXNlcklkIiwiY29uU3RhcnQiLCJEYXRlIiwiZ2V0VGltZSIsImdldFJvb21JbmZvIiwidGhlbiIsImNvbkVuZCIsInB1c2giLCJDT0RFIiwiUk9PTV9JTklUSUFMX1NVQ0NFU1MiLCJyZXMiLCJjb2RlIiwibXNnIiwicXBJZCIsInByb2dyYW1JbmZvIiwicWlwdUlkIiwicGxheVN0YXR1cyIsImxpdmVUeXBlSWQiLCJsaXZlU3ViVHlwZUlkIiwiY2hhdFJvb21JZCIsImNoYXRJbmZvIiwiYW5jaG9ySW5mbyIsImFuY2hvck5pY2tOYW1lIiwibGl2ZVR5cGVOYW1lIiwiX3RhYkRpc3BsYXkiLCJ0YWJDb250cm9sIiwicmVjb3JkIiwiY292ZXJJbWFnZVVybCIsImxpdmVUeXBlIiwicGxheU51bWJlciIsIm5pY2tuYW1lIiwicmVjb3JkVGltZSIsInBhcmFtcyIsImlzRm9sbG93ZWQiLCJmb2xsb3dOdW0iLCJzaG9ydE51bSIsImFuY2hvckZvbGxvd2VyTnVtIiwibGl2ZVN1YlR5cGVOYW1lIiwiYW5jaG9ySWNvbiIsInNldE5hdmlnYXRpb25CYXJUaXRsZSIsInBsYXllckNvbnRyb2wiLCJQbGF5ZXJDb250cm9sIiwiZ2V0TGF0ZXN0TXNnIiwibGF0ZXN0TXNnIiwic2VuZEJveCIsIlNlbmRCb3giLCJtc2dCb3giLCJNZXNzYWdlQm94IiwiY2F0Y2giLCJlcnIiLCJlcnJvciIsImV2ZW50VGVzdGVyIiwiUk9PTV9JTklUSUFMX0VSUiIsImVyclJvb20iLCJlcnJvckluZm8iLCJlcnJvck1zZyIsIm90aGVyU21hcnRQcm9ncmFtIiwibmF2aWdhdGVUb1NtYXJ0UHJvZ3JhbSIsImFwcEtleSIsImV4dHJhRGF0YSIsInN1Y2Nlc3MiLCJjb21wbGV0ZSIsInNob3dNb2RhbCIsInRhYkxpc3QiLCJmb3JFYWNoIiwiaXRlbSIsImRpc3BsYXlOYW1lIiwiZW5hYmxlIiwiZXZlbnRIYW5sZXIiLCJNZWRpYSIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJhZGRFdmVudExpc3RlbmVyIiwib3V0IiwiZGVidWciLCJhZnRlckxvZ2luVHJpZ2dlciIsImljb24iLCJyZWZyZXNoSW5mbyIsImVtaXQiLCJhZnRlckxvZ291dFRyaWdnZXIiLCJyZXNldEZvbGxvd0J0biIsImxvZ2luU3VjY2VzcyIsIm9uUmVhZHkiLCJnZXRTY3JvbGxIZWlnaHQiLCJnZXRSb29tSW5mb0hlaWdodCIsImdldElucHV0Rml0Q2xhc3MiLCJvblNob3ciLCJvbkhpZGUiLCJvblVubG9hZCIsIm9mZiIsIlBhZ2UiLCJPYmplY3QiLCJhc3NpZ24iXSwibWFwcGluZ3MiOiI7OztBQUFBOztJQUFZQSxJOztBQUNaOztJQUFZQyxHOztBQUNaOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOztJQUFZQyxLOztBQUNaOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOztJQUFZQyxJOzs7Ozs7QUFDWjs7QUFFQSxJQUFNQyxNQUFNQyxRQUFaOztBQUVBLElBQU1DLE9BQU87QUFDVDs7O0FBR0FDLFVBQU07QUFDRkMsa0JBQVUsSUFEUjtBQUVGQyxtQkFBVyxNQUZUO0FBR0ZDLGdCQUFRLElBSE47QUFJRkMsa0JBQVUsSUFKUjtBQUtGQyxpQkFBUyxDQUFDO0FBQ05DLGtCQUFNLENBREE7QUFFTkMscUJBQVM7QUFGSCxTQUFELENBTFA7QUFTRkMsc0JBQWMsR0FUWjtBQVVGQyw0QkFBb0IsSUFWbEI7QUFXRkMseUJBQWlCLEtBWGY7QUFZRkMsb0JBQVksS0FaVjtBQWFGQyxtQkFBVyxFQWJUO0FBY0ZDLHdCQUFnQixFQWRkO0FBZUZDLHNCQUFjLEVBZlo7QUFnQkZDLHNCQUFjLENBaEJaO0FBaUJGQyxlQUFPO0FBQ0hDLHFCQUFTLEtBRE47QUFFSEMsdUJBQVcsS0FGUjtBQUdIQyxrQkFBTSxLQUhIO0FBSUhDLHFCQUFTO0FBSk4sU0FqQkw7QUF1QkZDLHNCQUFjLCtEQXZCWjtBQXdCRkMsb0JBQVksQ0F4QlY7QUF5QkZDLGtCQUFVLEtBekJSO0FBMEJGQyx1QkFBZSxFQTFCYjtBQTJCRkMsYUFBSztBQUNEQyxrQkFBTSxLQURMO0FBRURDLGtCQUFNO0FBRkwsU0EzQkg7QUErQkZDLHdCQUFnQjtBQS9CZCxLQUpHOztBQXNDVEMsbUJBQWUseUJBQVc7QUFDdEIsYUFBS0MsT0FBTCxDQUFhO0FBQ1Q1Qix1QkFBVztBQURGLFNBQWI7QUFHQVQsYUFBS3NDLGdCQUFMLENBQXNCLElBQXRCO0FBQ0gsS0EzQ1E7O0FBNkNUQyxtQkFBZSx5QkFBVztBQUN0QixhQUFLRixPQUFMLENBQWE7QUFDVDVCLHVCQUFXO0FBREYsU0FBYjtBQUdILEtBakRROztBQW1EVCtCLGVBbkRTLHlCQW1ESztBQUNWQyxnQkFBUUMsR0FBUixDQUFZLFNBQVo7QUFDQUMsYUFBS0MsU0FBTCxDQUFlLEVBQUVDLE9BQU8sTUFBVCxFQUFmO0FBQ0EsYUFBS0wsV0FBTCxHQUFtQixZQUFNO0FBQ3JCRyxpQkFBS0MsU0FBTCxDQUFlLEVBQUVDLE9BQU8sS0FBVCxFQUFmO0FBQ0gsU0FGRDtBQUdBO0FBQ0gsS0ExRFE7OztBQTREVEMsb0JBQWdCLHdCQUFTQyxDQUFULEVBQVk7QUFDeEIvQyxhQUFLZ0QsVUFBTCxDQUFnQkQsRUFBRUUsYUFBRixDQUFnQkMsT0FBaEM7QUFDSCxLQTlEUTs7QUFnRVQ7OztBQUdBQyx1QkFBbUIsNkJBQVc7QUFDMUIsWUFBSUMsWUFBWTtBQUNaUCxtQkFBTyxLQUFLUSxRQUFMLENBQWNDLFNBQWQsQ0FBd0JDLFdBRG5CO0FBRVpDLHNCQUFVLEtBQUtILFFBQUwsQ0FBY0MsU0FBZCxDQUF3QkcsS0FBeEIsQ0FBOEJDLE9BQTlCLENBQXNDLFVBQXRDLEVBQWtELFVBQWxELENBRkU7QUFHWkMsa0JBQU0seUJBQXlCLEtBQUtOLFFBQUwsQ0FBYzNDO0FBSGpDLFNBQWhCO0FBS0EsZUFBTzBDLFNBQVA7QUFDSCxLQTFFUTs7QUE0RVRRLGtCQUFjLHdCQUFXO0FBQ3JCLFlBQUlSLFlBQVk7QUFDWlAsbUJBQU8sS0FBS1EsUUFBTCxDQUFjQyxTQUFkLENBQXdCQyxXQURuQjtBQUVaekMscUJBQVMsS0FBS3VDLFFBQUwsQ0FBY0MsU0FBZCxDQUF3Qk8sV0FGckI7QUFHWkwsc0JBQVUsS0FBS0gsUUFBTCxDQUFjQyxTQUFkLENBQXdCRyxLQUF4QixDQUE4QkMsT0FBOUIsQ0FBc0MsVUFBdEMsRUFBa0QsVUFBbEQsQ0FIRTtBQUlaQyxrQkFBTSx5QkFBeUIsS0FBS04sUUFBTCxDQUFjM0M7QUFKakMsU0FBaEI7QUFNQWlDLGFBQUttQixTQUFMLENBQWVWLFNBQWY7QUFDSCxLQXBGUTs7QUFzRlQ7OztBQUdBVyxXQUFPO0FBQ0hDLGtCQUFVLG9CQUFXLENBQUU7QUFEcEIsS0F6RkU7QUE0RlQ7QUFDQUMsT0E3RlMsaUJBNkZIO0FBQ0ZDLHVCQUFFRCxHQUFGLENBQU07QUFDRkUsa0JBQVMsS0FBS2QsUUFBTCxDQUFjZSxjQUF2QixTQUF5QyxLQUFLZixRQUFMLENBQWNnQixTQUF2RCxTQUFxRSxLQUFLaEIsUUFBTCxDQUFjaUIsUUFBbkYsbUVBREU7QUFFRkMsc0JBQWEsS0FBS2xCLFFBQUwsQ0FBY2UsY0FBM0IsU0FBNkMsS0FBS2YsUUFBTCxDQUFjZSxjQUEzRCxxQkFBK0UsS0FBS2YsUUFBTCxDQUFjZSxjQUE3RiwyQkFBa0gsS0FBS2YsUUFBTCxDQUFjZSxjQUFoSSxzQ0FBc0osS0FBS2YsUUFBTCxDQUFjZSxjQUFwSyxTQUFzTCxLQUFLZixRQUFMLENBQWNpQixRQUFwTSxjQUFnTixLQUFLakIsUUFBTCxDQUFjZSxjQUE5TixTQUFnUCxLQUFLZixRQUFMLENBQWNpQixRQUE5UCwwQkFBNFEsS0FBS2pCLFFBQUwsQ0FBY2UsY0FBMVIsU0FBNFMsS0FBS2YsUUFBTCxDQUFjaUIsUUFBMVQsaUJBRkU7QUFHRnpCLG1CQUFVLEtBQUtRLFFBQUwsQ0FBY2UsY0FBeEIsU0FBMkMsS0FBS2YsUUFBTCxDQUFjZ0IsU0FBekQsU0FBdUUsS0FBS2hCLFFBQUwsQ0FBY2lCLFFBQXJGLG1FQUhFO0FBSUYvQyxtQkFBTTtBQUNGaUQscUJBQUkseUJBQXlCLEtBQUtuQixRQUFMLENBQWMzQyxNQUR6QztBQUVGK0QsMEJBQVMsSUFGUDtBQUdGQyx1QkFBTSxLQUFLckIsUUFBTCxDQUFjQyxTQUFkLENBQXdCRyxLQUF4QixDQUE4QkMsT0FBOUIsQ0FBc0MsVUFBdEMsRUFBa0QsVUFBbEQ7QUFISjtBQUpKLFNBQU47QUFVSCxLQXhHUTtBQXlHVGlCLFVBekdTLGtCQXlHRkMsR0F6R0UsRUF5R0c7QUFDUixhQUFLQyxPQUFMLEdBQWUsSUFBSUMsaUJBQUosRUFBZjtBQUNBLGFBQUt6QixRQUFMLEdBQWdCLEVBQWhCO0FBQ0EsYUFBSzBCLFVBQUwsR0FBa0IsRUFBbEI7QUFDQSxhQUFLMUMsT0FBTCxDQUFhO0FBQ1Qsc0JBQVV1QyxJQUFJbEUsTUFETDtBQUVULDBCQUFjO0FBRkwsU0FBYjtBQUlBLGFBQUtzRSxNQUFMLEdBQWMsRUFBZDtBQUNBLGFBQUtDLFVBQUw7QUFDQSxhQUFLQyxPQUFMO0FBQ0gsS0FwSFE7QUFxSFRELGNBckhTLHdCQXFISTtBQUNULFlBQUlFLGFBQWE5RSxTQUFTOEUsVUFBMUI7QUFDQSxhQUFLSCxNQUFMLEdBQWMsSUFBSUksa0JBQUosQ0FBVztBQUNyQkMsZ0JBQUlGLFdBQVdFLEVBQVgsSUFBaUIsWUFEQTtBQUVyQkMsZUFBR0gsV0FBV0ksRUFBWCxJQUFpQixRQUZDO0FBR3JCQyxxQkFBU0wsV0FBV0ssT0FBWCxJQUFzQixTQUhWLEVBR3FCO0FBQzFDQyx1QkFBV3RGLEtBQUt1RixXQUFMLE1BQXNCLEVBSlo7QUFLckJDLG9CQUFRLEVBTGE7QUFNckJuQixpQkFBSyxrQkFOZ0I7QUFPckI5RCxvQkFBUSxLQUFLSCxJQUFMLENBQVVHO0FBUEcsU0FBWCxFQVFYaUMsSUFSVyxDQUFkO0FBU0gsS0FoSVE7QUFpSVR1QyxXQWpJUyxxQkFpSUM7QUFBQTs7QUFDTixZQUFJVSxXQUFXLElBQUlDLElBQUosR0FBV0MsT0FBWCxFQUFmO0FBQ0E3RixZQUFJOEYsV0FBSixDQUFnQixLQUFLeEYsSUFBTCxDQUFVRyxNQUExQixFQUFrQ3NGLElBQWxDLENBQXVDLGVBQU87QUFDMUMsa0JBQUszRCxPQUFMLENBQWE7QUFDVCw4QkFBYztBQURMLGFBQWI7QUFHQSxnQkFBSTRELFNBQVMsSUFBSUosSUFBSixHQUFXQyxPQUFYLEVBQWI7QUFDQSxrQkFBS2QsTUFBTCxDQUFZa0IsSUFBWixDQUFpQixNQUFLbEIsTUFBTCxDQUFZbUIsSUFBWixDQUFpQkMsb0JBQWxDLEVBQXdEQyxJQUFJQyxJQUE1RCxFQUFrRUwsU0FBU0wsUUFBM0UsRUFBcUYsQ0FBckYsRUFBd0YsRUFBeEYsT0FBK0ZTLElBQUlFLEdBQW5HOztBQUVBLGdCQUFJRixJQUFJQyxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDdkIsc0JBQUtqRCxRQUFMLEdBQWdCZ0QsSUFBSTlGLElBQXBCO0FBQ0Esc0JBQUs4QyxRQUFMLENBQWNtRCxJQUFkLEdBQXFCSCxJQUFJOUYsSUFBSixDQUFTa0csV0FBVCxDQUFxQkMsTUFBMUM7QUFDQSxzQkFBS3JELFFBQUwsQ0FBY3hCLFVBQWQsR0FBMkJ3RSxJQUFJOUYsSUFBSixDQUFTa0csV0FBVCxDQUFxQkUsVUFBaEQ7QUFDQSxzQkFBS3RELFFBQUwsQ0FBYzNDLE1BQWQsR0FBdUIyRixJQUFJOUYsSUFBSixDQUFTa0csV0FBVCxDQUFxQi9GLE1BQTVDO0FBQ0Esc0JBQUsyQyxRQUFMLENBQWN1RCxVQUFkLEdBQTJCUCxJQUFJOUYsSUFBSixDQUFTa0csV0FBVCxDQUFxQkcsVUFBaEQ7QUFDQSxzQkFBS3ZELFFBQUwsQ0FBY3dELGFBQWQsR0FBOEJSLElBQUk5RixJQUFKLENBQVNrRyxXQUFULENBQXFCSSxhQUFuRDtBQUNBLHNCQUFLeEQsUUFBTCxDQUFjeUQsVUFBZCxHQUEyQlQsSUFBSTlGLElBQUosQ0FBU3dHLFFBQVQsQ0FBa0JELFVBQTdDOztBQUVBLHNCQUFLekQsUUFBTCxDQUFjZSxjQUFkLEdBQStCaUMsSUFBSTlGLElBQUosQ0FBU3lHLFVBQVQsQ0FBb0JDLGNBQW5EO0FBQ0Esc0JBQUs1RCxRQUFMLENBQWNnQixTQUFkLEdBQTBCZ0MsSUFBSTlGLElBQUosQ0FBU2tHLFdBQVQsQ0FBcUJsRCxXQUEvQztBQUNBLHNCQUFLRixRQUFMLENBQWNpQixRQUFkLEdBQXlCK0IsSUFBSTlGLElBQUosQ0FBU2tHLFdBQVQsQ0FBcUJTLFlBQTlDOztBQUVBLHNCQUFLN0QsUUFBTCxDQUFjQyxTQUFkLEdBQTBCK0MsSUFBSTlGLElBQUosQ0FBUytDLFNBQW5DOztBQUVBLHNCQUFLNkQsV0FBTCxDQUFpQmQsSUFBSTlGLElBQUosQ0FBUzZHLFVBQTFCO0FBQ0E7QUFDQWxELCtCQUFFbUQsTUFBRixDQUFTO0FBQ0wzRyw0QkFBUTJGLElBQUk5RixJQUFKLENBQVNrRyxXQUFULENBQXFCL0YsTUFEeEI7QUFFTGdHLDRCQUFRTCxJQUFJOUYsSUFBSixDQUFTa0csV0FBVCxDQUFxQkMsTUFGeEI7QUFHTFksbUNBQWVqQixJQUFJOUYsSUFBSixDQUFTa0csV0FBVCxDQUFxQmEsYUFBckIsSUFBc0NqQixJQUFJOUYsSUFBSixDQUFTK0MsU0FBVCxDQUFtQkcsS0FBbkIsQ0FBeUJDLE9BQXpCLENBQWlDLFVBQWpDLEVBQTZDLFVBQTdDLENBSGhEO0FBSUw2RCw4QkFBVSxDQUpMO0FBS0xDLGdDQUFZbkIsSUFBSTlGLElBQUosQ0FBU2tHLFdBQVQsQ0FBcUJlLFVBTDVCO0FBTUwzRSwyQkFBT3dELElBQUk5RixJQUFKLENBQVNrRyxXQUFULENBQXFCbEQsV0FBckIsSUFBb0M4QyxJQUFJOUYsSUFBSixDQUFTa0csV0FBVCxDQUFxQjVDLFdBTjNEO0FBT0w0RCw4QkFBVXBCLElBQUk5RixJQUFKLENBQVN5RyxVQUFULENBQW9CQyxjQVB6QjtBQVFMUyxnQ0FBWSxJQUFJN0IsSUFBSixHQUFXQyxPQUFYO0FBUlAsaUJBQVQ7O0FBV0Esb0JBQUk2QixTQUFTO0FBQ1R0RCwrQkFBV2dDLElBQUk5RixJQUFKLENBQVNrRyxXQUFULENBQXFCbEQsV0FEdkI7QUFFVDFCLGdDQUFZd0UsSUFBSTlGLElBQUosQ0FBU2tHLFdBQVQsQ0FBcUJFLFVBRnhCLEVBRW9DO0FBQzdDN0UsOEJBQVV1RSxJQUFJOUYsSUFBSixDQUFTeUcsVUFBVCxDQUFvQlksVUFIckI7QUFJVEMsK0JBQVczSCxNQUFNNEgsUUFBTixDQUFlekIsSUFBSTlGLElBQUosQ0FBU3lHLFVBQVQsQ0FBb0JlLGlCQUFuQyxDQUpGO0FBS1RiLGtDQUFjYixJQUFJOUYsSUFBSixDQUFTa0csV0FBVCxDQUFxQlMsWUFMMUI7QUFNVGMscUNBQWlCM0IsSUFBSTlGLElBQUosQ0FBU2tHLFdBQVQsQ0FBcUJ1QixlQU43QjtBQU9UckgsOEJBQVU7QUFDTixzQ0FBYzBGLElBQUk5RixJQUFKLENBQVN5RyxVQUFULENBQW9CaUIsVUFENUI7QUFFTixvQ0FBWTVCLElBQUk5RixJQUFKLENBQVN5RyxVQUFULENBQW9CQyxjQUYxQjtBQUdOO0FBQ0E7QUFDQSxnQ0FBUVosSUFBSTlGLElBQUosQ0FBU2tHLFdBQVQsQ0FBcUI1QztBQUx2QjtBQVBELGlCQUFiO0FBZUEsc0JBQUtJLEdBQUw7QUFDQSxzQkFBSzVCLE9BQUwsQ0FBYXNGLE1BQWI7QUFDQSxzQkFBS3RGLE9BQUwsQ0FBYSxFQUFFLGdCQUFnQmdFLElBQUk5RixJQUFKLENBQVNrRyxXQUFULENBQXFCYSxhQUFyQixJQUFzQywrREFBeEQsRUFBYjtBQUNBM0UscUJBQUt1RixxQkFBTCxDQUEyQjtBQUN2QnJGLDJCQUFPd0QsSUFBSTlGLElBQUosQ0FBU2tHLFdBQVQsQ0FBcUJsRDtBQURMLGlCQUEzQjtBQUdBLHNCQUFLd0IsVUFBTCxDQUFnQm9ELGFBQWhCLEdBQWdDLElBQUlDLHNCQUFKLENBQWtCLEtBQWxCLENBQWhDO0FBQ0E7QUFDQW5JLG9CQUFJb0ksWUFBSixDQUFpQixNQUFLaEYsUUFBTCxDQUFjeUQsVUFBL0IsRUFDS2QsSUFETCxDQUNVLFVBQUN6RixJQUFELEVBQVU7QUFDWiwwQkFBSzhDLFFBQUwsQ0FBY2lGLFNBQWQsR0FBMEIvSCxJQUExQjtBQUNBLDBCQUFLd0UsVUFBTCxDQUFnQndELE9BQWhCLEdBQTBCLElBQUlDLHVCQUFKLENBQVksS0FBWixDQUExQjtBQUNBLDBCQUFLekQsVUFBTCxDQUFnQjBELE1BQWhCLEdBQXlCLElBQUlDLG1CQUFKLENBQWUsS0FBZixFQUFxQnJDLElBQUk5RixJQUFKLENBQVN3RyxRQUFULENBQWtCRCxVQUF2QyxDQUF6QjtBQUNILGlCQUxMLEVBS082QixLQUxQLENBS2EsVUFBQ0MsR0FBRCxFQUFTO0FBQ2RuRyw0QkFBUW9HLEtBQVIsQ0FBY0QsR0FBZDtBQUNILGlCQVBMO0FBUUEsc0JBQUtFLFdBQUwsQ0FBaUIsZ0JBQWpCLEVBQW1DLFVBQVMvRixDQUFULEVBQVk7QUFDM0NOLDRCQUFRQyxHQUFSLENBQVksZ0JBQVo7QUFDSCxpQkFGRDtBQUdILGFBOURELE1BOERPO0FBQ0gsb0JBQUkyRCxJQUFJQyxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDdkI3RCw0QkFBUW9HLEtBQVIsbUNBQXVCeEMsSUFBSUUsR0FBM0IsRUFEdUIsQ0FDVTtBQUNqQywwQkFBS3ZCLE1BQUwsQ0FBWWtCLElBQVosQ0FBaUIsTUFBS2xCLE1BQUwsQ0FBWW1CLElBQVosQ0FBaUI0QyxnQkFBbEMsRUFBb0QxQyxJQUFJQyxJQUF4RCxFQUE4REwsU0FBU0wsUUFBdkUsRUFBaUYsQ0FBakYsRUFBb0YsRUFBcEYsT0FBMkZTLElBQUlFLEdBQS9GO0FBQ0g7QUFDRCxzQkFBS3hCLFVBQUwsQ0FBZ0JvRCxhQUFoQixHQUFnQyxJQUFJQyxzQkFBSixDQUFrQixLQUFsQixDQUFoQztBQUNBLHNCQUFLL0YsT0FBTCxDQUFhO0FBQ1QyRyw2QkFBUyxJQURBLEVBQ007QUFDZnpILDJCQUFPO0FBQ0hHLDhCQUFNLEtBREg7QUFFSHVILG1DQUFXLElBRlI7QUFHSEMsa0NBQVU3QyxJQUFJRSxHQUFKLElBQVc7QUFIbEIscUJBRkU7QUFPVDNFLGtDQUFjO0FBUEwsaUJBQWI7QUFTSDtBQUNKLFNBckZELEVBcUZHLGVBQU87QUFDTmEsb0JBQVFDLEdBQVIsQ0FBWTJELEdBQVo7QUFDSCxTQXZGRDtBQXdGSCxLQTNOUTtBQTZOVDhDLHFCQTdOUywrQkE2Tlc7QUFDaEJ4RyxhQUFLeUcsc0JBQUwsQ0FBNEI7QUFDeEJDLG9CQUFRLGtDQURnQixFQUNvQjtBQUM1QzFGLGtCQUFNLHlCQUF5QixLQUFLTixRQUFMLENBQWMzQyxNQUZyQjtBQUd4QjtBQUNBNEksdUJBQVc7QUFDUDtBQURPLGFBSmE7QUFPeEJDLHFCQUFTLGlCQUFTbEQsR0FBVCxFQUFjO0FBQ25CNUQsd0JBQVFDLEdBQVIsQ0FBWTJELEdBQVo7QUFDQTtBQUNILGFBVnVCO0FBV3hCbUQsc0JBQVUsb0JBQVc7QUFDakI3RyxxQkFBSzhHLFNBQUwsQ0FBZSxFQUFFNUcsT0FBTyxRQUFULEVBQWY7QUFDQTtBQUNIO0FBZHVCLFNBQTVCO0FBZ0JILEtBOU9RO0FBK09Uc0UsZUEvT1MsdUJBK09HdUMsT0EvT0gsRUErT1k7QUFBQTs7QUFDakJBLGdCQUFRQyxPQUFSLENBQWdCLFVBQUNDLElBQUQsRUFBVTtBQUN0QixnQkFBSUEsS0FBS0MsV0FBTCxLQUFxQixJQUFyQixJQUE2QkQsS0FBS0UsTUFBdEMsRUFBOEM7QUFDMUMsdUJBQUt2SixJQUFMLENBQVV5QixHQUFWLENBQWNDLElBQWQsR0FBcUIsSUFBckI7QUFDSCxhQUZELE1BRU8sSUFBSTJILEtBQUtDLFdBQUwsS0FBcUIsSUFBckIsSUFBNkJELEtBQUtFLE1BQXRDLEVBQThDO0FBQ2pELHVCQUFLdkosSUFBTCxDQUFVeUIsR0FBVixDQUFjRSxJQUFkLEdBQXFCLElBQXJCO0FBQ0g7QUFDRCxtQkFBS0csT0FBTCxDQUFhLEVBQUVMLEtBQUssT0FBS3pCLElBQUwsQ0FBVXlCLEdBQWpCLEVBQWI7QUFDSCxTQVBEO0FBUUEsWUFBSSxDQUFDLEtBQUt6QixJQUFMLENBQVV5QixHQUFWLENBQWNFLElBQWYsSUFBdUIsS0FBSzNCLElBQUwsQ0FBVXlCLEdBQVYsQ0FBY0MsSUFBekMsRUFBK0M7QUFDM0MsaUJBQUsxQixJQUFMLENBQVVFLFNBQVYsR0FBc0IsTUFBdEI7QUFDQSxpQkFBSzRCLE9BQUwsQ0FBYSxFQUFFNUIsV0FBVyxNQUFiLEVBQWI7QUFDQVQsaUJBQUtzQyxnQkFBTCxDQUFzQixJQUF0QjtBQUNIO0FBQ0osS0E3UFE7O0FBOFBUd0csaUJBQWEscUJBQVMvRixDQUFULEVBQVlnSCxXQUFaLEVBQXlCO0FBQ2xDLFlBQUlDLFFBQVFDLFNBQVNDLGNBQVQsQ0FBd0IsU0FBeEIsQ0FBWjtBQUNBRixjQUFNRyxnQkFBTixDQUF1QnBILENBQXZCLEVBQTBCLFlBQVc7QUFDakNnSCwyQkFBZUEsYUFBZjtBQUNBSyxnQkFBSUMsS0FBSixDQUFXLElBQUl4RSxJQUFKLEVBQUQsQ0FBYUMsT0FBYixFQUFWLEVBQWtDL0MsQ0FBbEM7QUFDSCxTQUhELEVBR0csS0FISDtBQUlILEtBcFFROztBQXNRVHVILHVCQUFtQiw2QkFBVztBQUMxQjNILGFBQUtDLFNBQUwsQ0FBZTtBQUNYQyw2Q0FEVztBQUVYMEgsa0JBQU07QUFGSyxTQUFmO0FBSUF2SyxhQUFLd0ssV0FBTCxDQUFpQixJQUFqQjtBQUNBLGFBQUszRixPQUFMLENBQWE0RixJQUFiLENBQWtCLG1CQUFsQjtBQUNILEtBN1FROztBQStRVEMsd0JBQW9CLDhCQUFXO0FBQzNCMUssYUFBSzJLLGNBQUwsQ0FBb0IsSUFBcEI7QUFDQSxhQUFLOUYsT0FBTCxDQUFhNEYsSUFBYixDQUFrQixvQkFBbEI7QUFDSCxLQWxSUTs7QUFvUlRHLGtCQUFjLHdCQUFXO0FBQ3JCLGFBQUsvRixPQUFMLENBQWE0RixJQUFiLENBQWtCLGtCQUFsQjtBQUNILEtBdFJROztBQXdSVDs7O0FBR0FJLGFBQVMsbUJBQVc7QUFDaEI7QUFDQSxZQUFJdkssT0FBTyxJQUFYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBTixhQUFLOEssZUFBTCxDQUFxQnhLLElBQXJCO0FBQ0FOLGFBQUsrSyxpQkFBTCxDQUF1QnpLLElBQXZCO0FBQ0FOLGFBQUtnTCxnQkFBTCxDQUFzQjFLLElBQXRCO0FBQ0E7QUFDQTtBQUNILEtBeFNROztBQTBTVDs7O0FBR0EySyxZQUFRLGtCQUFXO0FBQ2YsYUFBS3BHLE9BQUwsQ0FBYTRGLElBQWIsQ0FBa0IsVUFBbEI7QUFDSCxLQS9TUTs7QUFpVFQ7OztBQUdBUyxZQUFRLGtCQUFXO0FBQ2Y7QUFDQSxhQUFLckcsT0FBTCxDQUFhNEYsSUFBYixDQUFrQixVQUFsQjtBQUNILEtBdlRROztBQXlUVDs7O0FBR0FVLGNBQVUsb0JBQVc7QUFDakIsYUFBS3RHLE9BQUwsQ0FBYTRGLElBQWIsQ0FBa0IsWUFBbEI7QUFDQTtBQUNBLGFBQUs1RixPQUFMLENBQWF1RyxHQUFiO0FBQ0EsYUFBSy9JLE9BQUwsQ0FBYTtBQUNUN0Isc0JBQVUsSUFERDtBQUVUQyx1QkFBVyxNQUZGO0FBR1Q7QUFDQUUsc0JBQVUsSUFKRDtBQUtUO0FBQ0E7QUFDQTtBQUNBO0FBQ0FJLDBCQUFjLEdBVEw7QUFVVEMsZ0NBQW9CLElBVlg7QUFXVEMsNkJBQWlCLEtBWFI7QUFZVEMsd0JBQVksS0FaSDtBQWFUQyx1QkFBVyxFQWJGO0FBY1RDLDRCQUFnQixFQWRQO0FBZVRDLDBCQUFjLEVBZkw7QUFnQlRDLDBCQUFjLENBaEJMO0FBaUJUYSw0QkFBZ0IsQ0FqQlA7QUFrQlRaLG1CQUFPO0FBQ0hDLHlCQUFTLEtBRE47QUFFSEMsMkJBQVcsS0FGUjtBQUdIQyxzQkFBTSxLQUhIO0FBSUhDLHlCQUFTLEtBSk47QUFLSDZDLHFCQUFLO0FBTEY7QUFsQkUsU0FBYjtBQTBCQTtBQUNBO0FBQ0g7QUE1VlEsQ0FBYjtBQThWQTZHLEtBQUtDLE9BQU9DLE1BQVAsQ0FBYyxFQUFkLEVBQWtCakwsSUFBbEIsQ0FBTCxFIiwiZmlsZSI6InBhZ2VzL3cvcm9vbS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIHJvb20gZnJvbSAnLi9hY3Rpb25zL3Jvb21BY3Rpb24uanMnO1xuaW1wb3J0ICogYXMgcmVxIGZyb20gJy4vc2VydmljZS9yZXFTZXJ2aWNlJztcbmltcG9ydCBQbGF5ZXJDb250cm9sIGZyb20gJy4vYWN0aW9ucy9wbGF5ZXJBY3Rpb24nO1xuaW1wb3J0IE1lc3NhZ2VCb3ggZnJvbSAnLi9hY3Rpb25zL21zZ0FjdGlvbic7XG5pbXBvcnQgU2VuZEJveCBmcm9tICcuL2FjdGlvbnMvc2VuZE1zZ0FjdGlvbic7XG5pbXBvcnQgKiBhcyB1dGlscyBmcm9tIFwiLi9jb21tb24vdXRpbHNcIjtcbmltcG9ydCBfIGZyb20gXCIuLi8uLi9jb21tb24vdXRpbHMvdXRpbFwiO1xuaW1wb3J0IEVtaXR0ZXIgZnJvbSAnLi4vLi4vY29tbW9uL2VtaXR0ZXIvRW1pdHRlcic7XG5pbXBvcnQgU2Vuc29yIGZyb20gJy4uLy4uL2NvbW1vbi9zZW5zb3IvanNTZW5zb3InO1xuaW1wb3J0ICogYXMgdXNlciBmcm9tICcuL2NvbW1vbi91c2VyJztcbi8vIGltcG9ydCBtdXRpQWNjb3VudCBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL211dGlBY2NvdW50L211dGlBY2NvdW50J1xuXG5jb25zdCBhcHAgPSBnZXRBcHAoKTtcblxuY29uc3QgcGFnZSA9IHtcbiAgICAvKipcbiAgICAgKiDpobXpnaLnmoTliJ3lp4vmlbDmja5cbiAgICAgKi9cbiAgICBkYXRhOiB7XG4gICAgICAgIGVycm9yVGlwOiB0cnVlLFxuICAgICAgICBhY3RpdmVUYWI6IFwiY2hhdFwiLFxuICAgICAgICByb29tSWQ6IG51bGwsXG4gICAgICAgIGhvc3RJbmZvOiBudWxsLFxuICAgICAgICBtc2dMaXN0OiBbe1xuICAgICAgICAgICAgdHlwZTogMCxcbiAgICAgICAgICAgIGNvbnRlbnQ6IFwi5q2j5Zyo5YeG5aSH5by55bmVXCJcbiAgICAgICAgfV0sXG4gICAgICAgIHNjcm9sbEhlaWdodDogMTAwLFxuICAgICAgICBzY3JvbGxIaWRlTG9hZE1vcmU6IHRydWUsXG4gICAgICAgIHNjcm9sbEFuaW1hdGlvbjogZmFsc2UsXG4gICAgICAgIGlucHV0Rm9jdXM6IGZhbHNlLFxuICAgICAgICBpbnB1dFRleHQ6IFwiXCIsXG4gICAgICAgIGlucHV0QXZhaWxhYmxlOiBcIlwiLFxuICAgICAgICBzaG93S2V5Ym9hcmQ6IFwiXCIsXG4gICAgICAgIHZpZGVvQm9keVRvcDogMCxcbiAgICAgICAgdmlkZW86IHtcbiAgICAgICAgICAgIG5lZWRWSVA6IGZhbHNlLFxuICAgICAgICAgICAgbmVlZExvZ2luOiBmYWxzZSxcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgb2ZmbGluZTogZmFsc2VcbiAgICAgICAgfSxcbiAgICAgICAgcHJldmlld0NvdmVyOiAnaHR0cDovL3d3dy5pcWl5aXBpYy5jb20vY29tbW9uL2ZpeC93eC1pcWl5aS9wbGF5ZXItdGlwLWJnLmpwZycsXG4gICAgICAgIHJvb21TdGF0dXM6IDAsXG4gICAgICAgIGZvbGxvd2VkOiBmYWxzZSxcbiAgICAgICAgcmVjb21tZW5kTGlzdDogW10sXG4gICAgICAgIHRhYjoge1xuICAgICAgICAgICAgaG9zdDogZmFsc2UsXG4gICAgICAgICAgICBjaGF0OiBmYWxzZVxuICAgICAgICB9LFxuICAgICAgICBrZXlib2FyZEhlaWdodDogMFxuICAgIH0sXG5cbiAgICBjbGlja1Nob3dIb3N0OiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy5zZXREYXRhKHtcbiAgICAgICAgICAgIGFjdGl2ZVRhYjogXCJob3N0XCJcbiAgICAgICAgfSk7XG4gICAgICAgIHJvb20uZ2V0UmVjb21tZW5kTGlzdCh0aGlzKTtcbiAgICB9LFxuXG4gICAgY2xpY2tTaG93Q2hhdDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMuc2V0RGF0YSh7XG4gICAgICAgICAgICBhY3RpdmVUYWI6IFwiY2hhdFwiXG4gICAgICAgIH0pO1xuICAgIH0sXG5cbiAgICBjbGlja0ZvbGxvdygpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ+aaguaXtuS4jeiDveiuoumYhSEnKTtcbiAgICAgICAgc3dhbi5zaG93VG9hc3QoeyB0aXRsZTogJ+iuoumYheaIkOWKnycgfSk7XG4gICAgICAgIHRoaXMuY2xpY2tGb2xsb3cgPSAoKSA9PiB7XG4gICAgICAgICAgICBzd2FuLnNob3dUb2FzdCh7IHRpdGxlOiAn5bey6K6i6ZiFJyB9KTtcbiAgICAgICAgfVxuICAgICAgICAvLyByb29tLmNsaWNrRm9sbG93KHRoaXMpO1xuICAgIH0sXG5cbiAgICBjbGlja1JlY29tbWVuZDogZnVuY3Rpb24oZSkge1xuICAgICAgICByb29tLnJlZGlyZWN0VG8oZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQpO1xuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiDnlKjmiLfngrnlh7vlj7PkuIrop5LliIbkuqtcbiAgICAgKi9cbiAgICBvblNoYXJlQXBwTWVzc2FnZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIGxldCBzaGFyZURhdGEgPSB7XG4gICAgICAgICAgICB0aXRsZTogdGhpcy5yb29tSW5mby5zaGFyZUluZm8ucHJvZ3JhbU5hbWUsXG4gICAgICAgICAgICBpbWFnZVVybDogdGhpcy5yb29tSW5mby5zaGFyZUluZm8uY292ZXIucmVwbGFjZShcIl80ODBfMjcwXCIsIFwiXzQ4MF8zNjBcIiksXG4gICAgICAgICAgICBwYXRoOiAncGFnZXMvdy9yb29tP3Jvb21JZD0nICsgdGhpcy5yb29tSW5mby5yb29tSWRcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc2hhcmVEYXRhO1xuICAgIH0sXG5cbiAgICBvbkNsaWNrU2hhcmU6IGZ1bmN0aW9uKCkge1xuICAgICAgICBsZXQgc2hhcmVEYXRhID0ge1xuICAgICAgICAgICAgdGl0bGU6IHRoaXMucm9vbUluZm8uc2hhcmVJbmZvLnByb2dyYW1OYW1lLFxuICAgICAgICAgICAgY29udGVudDogdGhpcy5yb29tSW5mby5zaGFyZUluZm8uZGVzY3JpcHRpb24sXG4gICAgICAgICAgICBpbWFnZVVybDogdGhpcy5yb29tSW5mby5zaGFyZUluZm8uY292ZXIucmVwbGFjZShcIl80ODBfMjcwXCIsIFwiXzQ4MF8zNjBcIiksXG4gICAgICAgICAgICBwYXRoOiAncGFnZXMvdy9yb29tP3Jvb21JZD0nICsgdGhpcy5yb29tSW5mby5yb29tSWRcbiAgICAgICAgfVxuICAgICAgICBzd2FuLm9wZW5TaGFyZShzaGFyZURhdGEpO1xuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiDnlJ/lkb3lkajmnJ/lh73mlbAtLeebkeWQrOmhtemdouWKoOi9vVxuICAgICAqL1xuICAgIHN0b3JlOiB7XG4gICAgICAgIGRpc3BhdGNoOiBmdW5jdGlvbigpIHt9XG4gICAgfSxcbiAgICAvLyBpc011bHRpQWNjb3VudDogbXV0aUFjY291bnQuaXNNdWx0aUFjY291bnQsXG4gICAgc2VvKCkge1xuICAgICAgICBfLnNlbyh7XG4gICAgICAgICAgICBkZXNjOiBgJHt0aGlzLnJvb21JbmZvLmFuY2hvck5pY2tuYW1lfV8ke3RoaXMucm9vbUluZm8ucm9vbVRpdGxlIH1fJHt0aGlzLnJvb21JbmZvLnN1YlRpdGxlfeebtOaSrV/niLHlpYfoibrnm7Tmkq0t54ix5aWH6Im6YCxcbiAgICAgICAgICAgIGtleXdvcmRzOiBgJHt0aGlzLnJvb21JbmZvLmFuY2hvck5pY2tuYW1lfSwke3RoaXMucm9vbUluZm8uYW5jaG9yTmlja25hbWV955u05pKtLCR7dGhpcy5yb29tSW5mby5hbmNob3JOaWNrbmFtZX3nm7Tmkq3pl7QsJHt0aGlzLnJvb21JbmZvLmFuY2hvck5pY2tuYW1lfeebtOaSreWcsOWdgO+8jCR7dGhpcy5yb29tSW5mby5hbmNob3JOaWNrbmFtZX0gJHt0aGlzLnJvb21JbmZvLnN1YlRpdGxlfe+8jCR7dGhpcy5yb29tSW5mby5hbmNob3JOaWNrbmFtZX0gJHt0aGlzLnJvb21JbmZvLnN1YlRpdGxlfeebtOaSre+8jCR7dGhpcy5yb29tSW5mby5hbmNob3JOaWNrbmFtZX0gJHt0aGlzLnJvb21JbmZvLnN1YlRpdGxlfeinhumikWAsXG4gICAgICAgICAgICB0aXRsZTogYCR7dGhpcy5yb29tSW5mby5hbmNob3JOaWNrbmFtZSB9XyR7dGhpcy5yb29tSW5mby5yb29tVGl0bGUgfV8ke3RoaXMucm9vbUluZm8uc3ViVGl0bGUgfeebtOaSrV/niLHlpYfoibrnm7Tmkq0t54ix5aWH6Im6YCxcbiAgICAgICAgICAgIHZpZGVvOntcbiAgICAgICAgICAgICAgICB1cmw6J3BhZ2VzL3cvcm9vbT9yb29tSWQ9JyArIHRoaXMucm9vbUluZm8ucm9vbUlkLFxuICAgICAgICAgICAgICAgIGR1cmF0aW9uOjM2MDAsXG4gICAgICAgICAgICAgICAgaW1hZ2U6dGhpcy5yb29tSW5mby5zaGFyZUluZm8uY292ZXIucmVwbGFjZShcIl80ODBfMjcwXCIsIFwiXzQ4MF8zNjBcIiksXG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0sXG4gICAgb25Mb2FkKG9wdCkge1xuICAgICAgICB0aGlzLnRyaWdnZXIgPSBuZXcgRW1pdHRlcigpO1xuICAgICAgICB0aGlzLnJvb21JbmZvID0ge307XG4gICAgICAgIHRoaXMuY29tcG9uZW50cyA9IHt9O1xuICAgICAgICB0aGlzLnNldERhdGEoe1xuICAgICAgICAgICAgXCJyb29tSWRcIjogb3B0LnJvb21JZCxcbiAgICAgICAgICAgIFwicmVxU3VjY2Vzc1wiOiBmYWxzZVxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5zZW5zb3IgPSB7fTtcbiAgICAgICAgdGhpcy5zZW5zb3JJbml0KCk7XG4gICAgICAgIHRoaXMucmVxSW5pdCgpO1xuICAgIH0sXG4gICAgc2Vuc29ySW5pdCgpIHtcbiAgICAgICAgbGV0IGdsb2JhbERhdGEgPSBnZXRBcHAoKS5nbG9iYWxEYXRhO1xuICAgICAgICB0aGlzLnNlbnNvciA9IG5ldyBTZW5zb3Ioe1xuICAgICAgICAgICAgcGw6IGdsb2JhbERhdGEucGwgfHwgJzJfMjRfMjAwXzMnLFxuICAgICAgICAgICAgdDogZ2xvYmFsRGF0YS50bCB8fCAnYmRfaW9zJyxcbiAgICAgICAgICAgIHZlcnNpb246IGdsb2JhbERhdGEudmVyc2lvbiB8fCAnMi4wMS4wNScsIC8vYmFpZHUgbWluaSBwcm8gdmVyc2lvbiBcbiAgICAgICAgICAgIGRldmljZV9pZDogdXNlci5nZXREZXZpY2VJZCgpIHx8ICcnLFxuICAgICAgICAgICAgdXNlcklkOiAnJyxcbiAgICAgICAgICAgIHVybDogJy92MS9saXZlL2luaXRpYWwnLFxuICAgICAgICAgICAgcm9vbUlkOiB0aGlzLmRhdGEucm9vbUlkLFxuICAgICAgICB9LCBzd2FuKTtcbiAgICB9LFxuICAgIHJlcUluaXQoKSB7XG4gICAgICAgIGxldCBjb25TdGFydCA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xuICAgICAgICByZXEuZ2V0Um9vbUluZm8odGhpcy5kYXRhLnJvb21JZCkudGhlbihyZXMgPT4ge1xuICAgICAgICAgICAgdGhpcy5zZXREYXRhKHtcbiAgICAgICAgICAgICAgICBcInJlcVN1Y2Nlc3NcIjogdHJ1ZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBsZXQgY29uRW5kID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICAgICAgICB0aGlzLnNlbnNvci5wdXNoKHRoaXMuc2Vuc29yLkNPREUuUk9PTV9JTklUSUFMX1NVQ0NFU1MsIHJlcy5jb2RlLCBjb25FbmQgLSBjb25TdGFydCwgMCwgJycsIGAke3Jlcy5tc2d9YCk7XG5cbiAgICAgICAgICAgIGlmIChyZXMuY29kZSA9PT0gXCJBMDAwMDBcIikge1xuICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8gPSByZXMuZGF0YTtcbiAgICAgICAgICAgICAgICB0aGlzLnJvb21JbmZvLnFwSWQgPSByZXMuZGF0YS5wcm9ncmFtSW5mby5xaXB1SWQ7XG4gICAgICAgICAgICAgICAgdGhpcy5yb29tSW5mby5yb29tU3RhdHVzID0gcmVzLmRhdGEucHJvZ3JhbUluZm8ucGxheVN0YXR1cztcbiAgICAgICAgICAgICAgICB0aGlzLnJvb21JbmZvLnJvb21JZCA9IHJlcy5kYXRhLnByb2dyYW1JbmZvLnJvb21JZDtcbiAgICAgICAgICAgICAgICB0aGlzLnJvb21JbmZvLmxpdmVUeXBlSWQgPSByZXMuZGF0YS5wcm9ncmFtSW5mby5saXZlVHlwZUlkO1xuICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8ubGl2ZVN1YlR5cGVJZCA9IHJlcy5kYXRhLnByb2dyYW1JbmZvLmxpdmVTdWJUeXBlSWQ7XG4gICAgICAgICAgICAgICAgdGhpcy5yb29tSW5mby5jaGF0Um9vbUlkID0gcmVzLmRhdGEuY2hhdEluZm8uY2hhdFJvb21JZDtcblxuICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8uYW5jaG9yTmlja25hbWUgPSByZXMuZGF0YS5hbmNob3JJbmZvLmFuY2hvck5pY2tOYW1lO1xuICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8ucm9vbVRpdGxlID0gcmVzLmRhdGEucHJvZ3JhbUluZm8ucHJvZ3JhbU5hbWU7XG4gICAgICAgICAgICAgICAgdGhpcy5yb29tSW5mby5zdWJUaXRsZSA9IHJlcy5kYXRhLnByb2dyYW1JbmZvLmxpdmVUeXBlTmFtZTtcblxuICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8uc2hhcmVJbmZvID0gcmVzLmRhdGEuc2hhcmVJbmZvO1xuXG4gICAgICAgICAgICAgICAgdGhpcy5fdGFiRGlzcGxheShyZXMuZGF0YS50YWJDb250cm9sKTtcbiAgICAgICAgICAgICAgICAvL+a3u+WKoOWIsOacrOWcsOe8k+WtmOWOhuWPsuiusOW9lVxuICAgICAgICAgICAgICAgIF8ucmVjb3JkKHtcbiAgICAgICAgICAgICAgICAgICAgcm9vbUlkOiByZXMuZGF0YS5wcm9ncmFtSW5mby5yb29tSWQsXG4gICAgICAgICAgICAgICAgICAgIHFpcHVJZDogcmVzLmRhdGEucHJvZ3JhbUluZm8ucWlwdUlkLFxuICAgICAgICAgICAgICAgICAgICBjb3ZlckltYWdlVXJsOiByZXMuZGF0YS5wcm9ncmFtSW5mby5jb3ZlckltYWdlVXJsIHx8IHJlcy5kYXRhLnNoYXJlSW5mby5jb3Zlci5yZXBsYWNlKFwiXzQ4MF8yNzBcIiwgXCJfNDgwXzM2MFwiKSxcbiAgICAgICAgICAgICAgICAgICAgbGl2ZVR5cGU6IDEsXG4gICAgICAgICAgICAgICAgICAgIHBsYXlOdW1iZXI6IHJlcy5kYXRhLnByb2dyYW1JbmZvLnBsYXlOdW1iZXIsXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlOiByZXMuZGF0YS5wcm9ncmFtSW5mby5wcm9ncmFtTmFtZSB8fCByZXMuZGF0YS5wcm9ncmFtSW5mby5kZXNjcmlwdGlvbixcbiAgICAgICAgICAgICAgICAgICAgbmlja25hbWU6IHJlcy5kYXRhLmFuY2hvckluZm8uYW5jaG9yTmlja05hbWUsXG4gICAgICAgICAgICAgICAgICAgIHJlY29yZFRpbWU6IG5ldyBEYXRlKCkuZ2V0VGltZSgpXG4gICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xuICAgICAgICAgICAgICAgICAgICByb29tVGl0bGU6IHJlcy5kYXRhLnByb2dyYW1JbmZvLnByb2dyYW1OYW1lLFxuICAgICAgICAgICAgICAgICAgICByb29tU3RhdHVzOiByZXMuZGF0YS5wcm9ncmFtSW5mby5wbGF5U3RhdHVzLCAvLzA6IOacquefpSwgMe+8muacquW8gOWni++8jDLvvJrnm7Tmkq3vvIwzOuWbnueci+S4rSw0OuWbnueci+e7k+adnyDvvIjmlrDlop7vvIksNTrova7mkq3kuK0sIC0xIOemgeaSreS4rSAgIyMjIOWvueW6lOWQiOW5tiBcInJvb21TdGF0dXNcIjogMSwgLy8gMC7lgZzmkq3kuK0gMS7nm7Tmkq3kuK0gMuemgeaSreS4rSAz6L2u5pKt5LitLFxuICAgICAgICAgICAgICAgICAgICBmb2xsb3dlZDogcmVzLmRhdGEuYW5jaG9ySW5mby5pc0ZvbGxvd2VkLFxuICAgICAgICAgICAgICAgICAgICBmb2xsb3dOdW06IHV0aWxzLnNob3J0TnVtKHJlcy5kYXRhLmFuY2hvckluZm8uYW5jaG9yRm9sbG93ZXJOdW0pLFxuICAgICAgICAgICAgICAgICAgICBsaXZlVHlwZU5hbWU6IHJlcy5kYXRhLnByb2dyYW1JbmZvLmxpdmVUeXBlTmFtZSxcbiAgICAgICAgICAgICAgICAgICAgbGl2ZVN1YlR5cGVOYW1lOiByZXMuZGF0YS5wcm9ncmFtSW5mby5saXZlU3ViVHlwZU5hbWUsXG4gICAgICAgICAgICAgICAgICAgIGhvc3RJbmZvOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBcImFuY2hvckljb25cIjogcmVzLmRhdGEuYW5jaG9ySW5mby5hbmNob3JJY29uLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJuaWNrbmFtZVwiOiByZXMuZGF0YS5hbmNob3JJbmZvLmFuY2hvck5pY2tOYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gXCJ3YWxsZXRcIjogdXRpbHMuc2hvcnROdW0ocmVzLmRhdGEud2FsbGV0KSwvLyDouqvku7dcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFwicG9wdWxhdHlcIjogdXRpbHMuc2hvcnROdW0ocmVzLmRhdGEucG9wdWxhdHkpLCAvLyDng63luqZcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiaW5mb1wiOiByZXMuZGF0YS5wcm9ncmFtSW5mby5kZXNjcmlwdGlvblxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB0aGlzLnNlbygpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YShwYXJhbXMpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7ICdwcmV2aWV3Q292ZXInOiByZXMuZGF0YS5wcm9ncmFtSW5mby5jb3ZlckltYWdlVXJsIHx8ICdodHRwOi8vd3d3LmlxaXlpcGljLmNvbS9jb21tb24vZml4L3d4LWlxaXlpL3BsYXllci10aXAtYmcuanBnJyB9KVxuICAgICAgICAgICAgICAgIHN3YW4uc2V0TmF2aWdhdGlvbkJhclRpdGxlKHtcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU6IHJlcy5kYXRhLnByb2dyYW1JbmZvLnByb2dyYW1OYW1lXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgdGhpcy5jb21wb25lbnRzLnBsYXllckNvbnRyb2wgPSBuZXcgUGxheWVyQ29udHJvbCh0aGlzKTtcbiAgICAgICAgICAgICAgICAvLyDmi4nlj5bmnIDlkI7lh6DmnaHogYrlpKnorrDlvZVcbiAgICAgICAgICAgICAgICByZXEuZ2V0TGF0ZXN0TXNnKHRoaXMucm9vbUluZm8uY2hhdFJvb21JZClcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4oKGRhdGEpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8ubGF0ZXN0TXNnID0gZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29tcG9uZW50cy5zZW5kQm94ID0gbmV3IFNlbmRCb3godGhpcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbXBvbmVudHMubXNnQm94ID0gbmV3IE1lc3NhZ2VCb3godGhpcywgcmVzLmRhdGEuY2hhdEluZm8uY2hhdFJvb21JZCk7XG4gICAgICAgICAgICAgICAgICAgIH0pLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgdGhpcy5ldmVudFRlc3RlcihcImNhbnBsYXl0aHJvdWdoXCIsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2NhbnBsYXl0aHJvdWdoJyk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGlmIChyZXMuY29kZSA9PT0gXCJBMDAwMDVcIikge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGDpnIDopoHmipXpgJLnmoRgLCByZXMubXNnKTsgLy8gVE9ETyDmipXpgJJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZW5zb3IucHVzaCh0aGlzLnNlbnNvci5DT0RFLlJPT01fSU5JVElBTF9FUlIsIHJlcy5jb2RlLCBjb25FbmQgLSBjb25TdGFydCwgMCwgJycsIGAke3Jlcy5tc2d9YCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRoaXMuY29tcG9uZW50cy5wbGF5ZXJDb250cm9sID0gbmV3IFBsYXllckNvbnRyb2wodGhpcyk7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgZXJyUm9vbTogdHJ1ZSwgLy/miL/pl7TplJnor69cbiAgICAgICAgICAgICAgICAgICAgdmlkZW86IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JJbmZvOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JNc2c6IHJlcy5tc2cgfHwgJ+inhumikeS4jeiDveaSreaUvidcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgcHJldmlld0NvdmVyOiAnaHR0cDovL3d3dy5pcWl5aXBpYy5jb20vY29tbW9uL2ZpeC93eC1pcWl5aS9wbGF5ZXItdGlwLWJnLmpwZydcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfVxuICAgICAgICB9LCByZXMgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2cocmVzKTtcbiAgICAgICAgfSk7XG4gICAgfSxcblxuICAgIG90aGVyU21hcnRQcm9ncmFtKCkge1xuICAgICAgICBzd2FuLm5hdmlnYXRlVG9TbWFydFByb2dyYW0oe1xuICAgICAgICAgICAgYXBwS2V5OiAnRlNUb2R1MFVpQTVNR1U1Q1VwMzFXeXZtWnR4dDkwNVknLCAvLyDopoHmiZPlvIDnmoTlsI/nqIvluo8gQXBwIEtleVxuICAgICAgICAgICAgcGF0aDogJ3BhZ2VzL3cvcm9vbT9yb29tSWQ9JyArIHRoaXMucm9vbUluZm8ucm9vbUlkLFxuICAgICAgICAgICAgLy8gcGF0aDogJycsIC8vIOaJk+W8gOeahOmhtemdoui3r+W+hO+8jOWmguaenOS4uuepuuWImeaJk+W8gOmmlumhtVxuICAgICAgICAgICAgZXh0cmFEYXRhOiB7XG4gICAgICAgICAgICAgICAgLy8gcm9vbUlkOiA1MjU4MVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHN1Y2Nlc3M6IGZ1bmN0aW9uKHJlcykge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlcyk7XG4gICAgICAgICAgICAgICAgLy8g5omT5byA5oiQ5YqfXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgY29tcGxldGU6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIHN3YW4uc2hvd01vZGFsKHsgdGl0bGU6ICcxMjMzMjEnIH0pO1xuICAgICAgICAgICAgICAgIC8vIOaJk+W8gOaIkOWKn1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9LFxuICAgIF90YWJEaXNwbGF5KHRhYkxpc3QpIHtcbiAgICAgICAgdGFiTGlzdC5mb3JFYWNoKChpdGVtKSA9PiB7XG4gICAgICAgICAgICBpZiAoaXRlbS5kaXNwbGF5TmFtZSA9PT0gJ+S4u+aSrScgJiYgaXRlbS5lbmFibGUpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmRhdGEudGFiLmhvc3QgPSB0cnVlO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChpdGVtLmRpc3BsYXlOYW1lID09PSAn6IGK5aSpJyAmJiBpdGVtLmVuYWJsZSkge1xuICAgICAgICAgICAgICAgIHRoaXMuZGF0YS50YWIuY2hhdCA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnNldERhdGEoeyB0YWI6IHRoaXMuZGF0YS50YWIgfSk7XG4gICAgICAgIH0pO1xuICAgICAgICBpZiAoIXRoaXMuZGF0YS50YWIuY2hhdCAmJiB0aGlzLmRhdGEudGFiLmhvc3QpIHtcbiAgICAgICAgICAgIHRoaXMuZGF0YS5hY3RpdmVUYWIgPSAnaG9zdCc7XG4gICAgICAgICAgICB0aGlzLnNldERhdGEoeyBhY3RpdmVUYWI6ICdob3N0JyB9KTtcbiAgICAgICAgICAgIHJvb20uZ2V0UmVjb21tZW5kTGlzdCh0aGlzKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgZXZlbnRUZXN0ZXI6IGZ1bmN0aW9uKGUsIGV2ZW50SGFubGVyKSB7XG4gICAgICAgIGxldCBNZWRpYSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd2aWRlb0lkJyk7XG4gICAgICAgIE1lZGlhLmFkZEV2ZW50TGlzdGVuZXIoZSwgZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICBldmVudEhhbmxlciAmJiBldmVudEhhbmxlcigpO1xuICAgICAgICAgICAgb3V0LmRlYnVnKChuZXcgRGF0ZSgpKS5nZXRUaW1lKCksIGUpXG4gICAgICAgIH0sIGZhbHNlKTtcbiAgICB9LFxuXG4gICAgYWZ0ZXJMb2dpblRyaWdnZXI6IGZ1bmN0aW9uKCkge1xuICAgICAgICBzd2FuLnNob3dUb2FzdCh7XG4gICAgICAgICAgICB0aXRsZTogYOeZu+W9leaIkOWKn2AsXG4gICAgICAgICAgICBpY29uOiAnbm9uZSdcbiAgICAgICAgfSk7XG4gICAgICAgIHJvb20ucmVmcmVzaEluZm8odGhpcyk7XG4gICAgICAgIHRoaXMudHJpZ2dlci5lbWl0KFwiYWZ0ZXJMb2dpblN1Y2Nlc3NcIik7XG4gICAgfSxcblxuICAgIGFmdGVyTG9nb3V0VHJpZ2dlcjogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJvb20ucmVzZXRGb2xsb3dCdG4odGhpcyk7XG4gICAgICAgIHRoaXMudHJpZ2dlci5lbWl0KFwiYWZ0ZXJMb2dvdXRTdWNjZXNzXCIpO1xuICAgIH0sXG5cbiAgICBsb2dpblN1Y2Nlc3M6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLnRyaWdnZXIuZW1pdChcImFmdGVyR2V0VXNlckluZm9cIik7XG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIOeUn+WRveWRqOacn+WHveaVsC0t55uR5ZCs6aG16Z2i5Yid5qyh5riy5p+T5a6M5oiQXG4gICAgICovXG4gICAgb25SZWFkeTogZnVuY3Rpb24oKSB7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdvblJlYWR5Jyk7XG4gICAgICAgIGxldCBwYWdlID0gdGhpcztcbiAgICAgICAgLy8gdGhpcy5zZXREYXRhKHtcbiAgICAgICAgLy8gICAgIHNjcm9sbEhlaWdodDogcm9vbS5nZXRTY3JvbGxIZWlnaHQoKSxcbiAgICAgICAgLy8gICAgIHJvb21JbmZvSGVpZ2h0OiByb29tLmdldFJvb21JbmZvSGVpZ2h0KCksXG4gICAgICAgIC8vICAgICBpbnB1dEZpdENsYXNzOiByb29tLmdldElucHV0Rml0Q2xhc3MoKVxuICAgICAgICAvLyB9KTtcbiAgICAgICAgcm9vbS5nZXRTY3JvbGxIZWlnaHQocGFnZSk7XG4gICAgICAgIHJvb20uZ2V0Um9vbUluZm9IZWlnaHQocGFnZSk7XG4gICAgICAgIHJvb20uZ2V0SW5wdXRGaXRDbGFzcyhwYWdlKTtcbiAgICAgICAgLy8gZ2V0QXBwKCkuZW1pdHRlci5vbihcImFmdGVyTG9naW5TdWNjZXNzXCIsIHRoaXMuYWZ0ZXJMb2dpblRyaWdnZXIpO1xuICAgICAgICAvLyBnZXRBcHAoKS5lbWl0dGVyLm9uKFwiYWZ0ZXJMb2dvdXRTdWNjZXNzXCIsIHRoaXMuYWZ0ZXJMb2dvdXRUcmlnZ2VyKTtcbiAgICB9LFxuXG4gICAgLyoqXG4gICAgICog55Sf5ZG95ZGo5pyf5Ye95pWwLS3nm5HlkKzpobXpnaLmmL7npLpcbiAgICAgKi9cbiAgICBvblNob3c6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLnRyaWdnZXIuZW1pdChcInNob3dQYWdlXCIpO1xuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiDnlJ/lkb3lkajmnJ/lh73mlbAtLeebkeWQrOmhtemdoumakOiXj1xuICAgICAqL1xuICAgIG9uSGlkZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIC8vIGdldEFwcCgpLmVtaXR0ZXIuZW1pdChcImhpZGVQYWdlXCIpO1xuICAgICAgICB0aGlzLnRyaWdnZXIuZW1pdChcImhpZGVQYWdlXCIpO1xuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiDnlJ/lkb3lkajmnJ/lh73mlbAtLeebkeWQrOmhtemdouWNuOi9vVxuICAgICAqL1xuICAgIG9uVW5sb2FkOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy50cmlnZ2VyLmVtaXQoXCJwYWdlVW5sb2FkXCIpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyh0aGlzLnRyaWdnZXIpO1xuICAgICAgICB0aGlzLnRyaWdnZXIub2ZmKCk7XG4gICAgICAgIHRoaXMuc2V0RGF0YSh7XG4gICAgICAgICAgICBlcnJvclRpcDogdHJ1ZSxcbiAgICAgICAgICAgIGFjdGl2ZVRhYjogXCJjaGF0XCIsXG4gICAgICAgICAgICAvLyByb29tSWQ6IG51bGwsXG4gICAgICAgICAgICBob3N0SW5mbzogbnVsbCxcbiAgICAgICAgICAgIC8vIG1zZ0xpc3Q6IFt7XG4gICAgICAgICAgICAvLyAgICAgdHlwZTogMCxcbiAgICAgICAgICAgIC8vICAgICBjb250ZW50OiBcIuato+WcqOWHhuWkh+W8ueW5lVwiXG4gICAgICAgICAgICAvLyB9XSxcbiAgICAgICAgICAgIHNjcm9sbEhlaWdodDogMTAwLFxuICAgICAgICAgICAgc2Nyb2xsSGlkZUxvYWRNb3JlOiB0cnVlLFxuICAgICAgICAgICAgc2Nyb2xsQW5pbWF0aW9uOiBmYWxzZSxcbiAgICAgICAgICAgIGlucHV0Rm9jdXM6IGZhbHNlLFxuICAgICAgICAgICAgaW5wdXRUZXh0OiBcIlwiLFxuICAgICAgICAgICAgaW5wdXRBdmFpbGFibGU6IFwiXCIsXG4gICAgICAgICAgICBzaG93S2V5Ym9hcmQ6IFwiXCIsXG4gICAgICAgICAgICB2aWRlb0JvZHlUb3A6IDAsXG4gICAgICAgICAgICBrZXlib2FyZEhlaWdodDogMCxcbiAgICAgICAgICAgIHZpZGVvOiB7XG4gICAgICAgICAgICAgICAgbmVlZFZJUDogZmFsc2UsXG4gICAgICAgICAgICAgICAgbmVlZExvZ2luOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBzaG93OiBmYWxzZSxcbiAgICAgICAgICAgICAgICBvZmZsaW5lOiBmYWxzZSxcbiAgICAgICAgICAgICAgICB1cmw6IFwiXCJcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIC8vIGdldEFwcCgpLmVtaXR0ZXIub2ZmKFwiYWZ0ZXJMb2dpblN1Y2Nlc3NcIiwgdGhpcy5hZnRlckxvZ2luVHJpZ2dlcik7XG4gICAgICAgIC8vIGdldEFwcCgpLmVtaXR0ZXIub2ZmKFwiYWZ0ZXJMb2dvdXRTdWNjZXNzXCIsIHRoaXMuYWZ0ZXJMb2dvdXRUcmlnZ2VyKTtcbiAgICB9XG59XG5QYWdlKE9iamVjdC5hc3NpZ24oe30sIHBhZ2UpKVxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAvVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9wYWdlcy93L3Jvb20uanMiXSwic291cmNlUm9vdCI6IiJ9