window.define('125', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

var _runMacine = __webpack_require__(35);

var _runMacine2 = _interopRequireDefault(_runMacine);

var _jump = __webpack_require__(61);

var _jump2 = _interopRequireDefault(_jump);

var _userInfo = __webpack_require__(36);

var user = _interopRequireWildcard(_userInfo);

var _rsaUtil = __webpack_require__(42);

var _rsaUtil2 = _interopRequireDefault(_rsaUtil);

var _serviceApi = __webpack_require__(31);

var serviceApi = _interopRequireWildcard(_serviceApi);

var _session = __webpack_require__(32);

var _session2 = _interopRequireDefault(_session);

var _object = __webpack_require__(39);

var object = _interopRequireWildcard(_object);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var app = getApp();
var CELLPHONE_LOGIN_URL = _util2.default.OUTERHOST.PASSPORT + '/apis/reglogin/cellphone_authcode_login.action';
var page = {
    data: {
        options: {},
        info: {
            area_code: 86,
            phone: '13899997777',
            showPhone: '138****7777',
            phonecode: '',
            resend: false
        },
        isFocus: true
    },
    onShow: function onShow(event) {
        var _this = this;

        // this.loadPage();
        setTimeout(function () {
            _this.set_Focus();
        }, 200);
    },
    onReady: function onReady() {},
    onLoad: function onLoad(options) {
        this.data.options = options;
        console.log(options);
        this.init();
    },
    loadPage: function loadPage() {
        console.log(12333);
    },
    _loadedPage: function _loadedPage(data) {},
    init: function init() {
        var _data$options = this.data.options,
            tokens = _data$options.tokens,
            area_code = _data$options.area_code,
            phone = _data$options.phone,
            requestType = _data$options.requestType,
            pagefrom = _data$options.pagefrom,
            delta = _data$options.delta,
            phoneType = _data$options.phoneType;

        var showPhone = phone;
        if (area_code + '' === '86') {
            showPhone = phone.substring(0, 3) + '****' + phone.substring(7);
        }
        this.data.showphone = phone;
        this.setData('info.area_code', area_code);
        this.setData('info.phone', phone);
        this.setData('info.showPhone', showPhone);
        this.setData('info.requestType', requestType);
        this.setData('info.tokens', tokens);
        this.setData('info.resend', false);
        this.countDown();
    },
    countDown: function countDown() {
        var _this2 = this;

        var time = 5;
        if (this.runObj) {
            this.setData('info.resend', true);
            _runMacine2.default.clear(this.runObj);
        }
        this.data.counts = time;
        this.runObj = _runMacine2.default.run(function () {
            if (_this2.data.counts <= 1) {
                _this2.data.counts = 0;
                _this2.setData('info.resend', true);
            }
            _this2.data.counts--;
            _this2.setData({ counts: _this2.data.counts });
        }, 1000, time);
    },
    resend: function resend() {
        _util2.default.jump({ type: 'back' });
    },
    set_Focus: function set_Focus() {
        //聚焦input
        this.setData({ isFocus: true });
        console.log('聚焦');
    },
    set_notFocus: function set_notFocus() {
        //失去焦点
        this.setData({ isFocus: false });
        console.error('失去焦点!');
    },
    set_phonecode: function set_phonecode(event) {
        var value = event.detail.value;
        if (this.verify.requesting) {
            return;
        }
        this.data.info.phonecode = value + '';
        this.setData('info.phonecode', value);
        if (value && value.length === 6) {
            this.set_notFocus();
            this.verify(value);
        }
    },
    verify: function verify(value) {
        var _this3 = this;

        var state = this.data;
        var area_code = state.info.area_code || '';
        var authCode = state.info.origincode;
        var phone = state.info.phone;
        var requestType = state.info.requestType || '';
        var tokens = state.info.tokens || '';

        var params = {
            // qd_sc:''
            agenttype: app.globalData.agenttype,
            ptid: app.globalData.ptid,
            cellphoneNumber: phone,
            area_code: area_code,
            serviceId: 1,
            device_id: user.getDeviceId(),
            dfp: user.getDeviceId(),
            authCode: value, //验证码
            requestType: requestType,
            QC005: user.getDeviceId()
        };

        params.qd_sc = _rsaUtil2.default.getQiyiQtsc(params);

        if (this.verify.requesting) {
            return;
        }
        this.verify.requesting = true;

        if (swan.showLoading) {
            swan.showLoading({
                title: '加载中',
                mask: true
            });
        }

        // let res = {
        //     authcookie: "9dPYP4iRHKTlm3syE4i9cWfOeFyrK8eExOLjpEnom1xfm2qPtV6A8MDiw67nXYSm2kzm3C314",
        //     isNewUser: false
        // }
        // this.verifySuccessHandle(res);
        // return;


        if (requestType == 22) {
            serviceApi.commonPostRequest({
                url: CELLPHONE_LOGIN_URL,
                reqParams: params
            }, true).then(function (data) {
                if (data.code === 'A00000') {
                    console.log('login success');
                    _this3.setData('info.phonecode', '');
                    _this3.setData('info.origincode', '');

                    // session.Session.set(session.SESSION_PHONE_NUMBER, phone);//写入手机号码

                    var res = data.data || {};

                    // let tempAuthCookie = '9dPYP4iRHKTlm3syE4i9cWfOeFyrK8eExOLjpEnom1xfm2qPtV6A8MDiw67nXYSm2kzm3C314';//TODO TEST authCookie
                    // let authCookie = res && res.authcookie ? res.authcookie : tempAuthCookie;
                    // http://wiki.qiyi.domain/pages/viewpage.action?pageId=176152245#id-%E5%A4%A7%E7%9B%B4%E6%92%ADEdge%E6%8E%A5%E5%8F%A3(V1)-20%E4%B8%AA%E4%BA%BA%E4%B8%AD%E5%BF%83

                    if (!res.isNewuser) {
                        console.log('\u8001\u7528\u6237');
                    } else {
                        console.log('\u6211\u662F\u65B0\u7528\u6237');
                    }
                    var _app = getApp();
                    _app.globalData.needLogin = 1;
                    _app.globalData.authCookie = res && res.authcookie || '';
                    _app.globalData.phone = phone;
                    console.log(_app.globalData);
                    // swan.switchTab({ url: '/pages/my/my' });//跳转到个人页面 ?needLogin=1&authCookie=${res && res.authcookie}&isNewuser=${res && res.isNewuser}
                    _util2.default.jump('pages/my/my');
                } else {
                    swan.showToast({ title: '' + data.msg, icon: 'none' });
                    console.log(data.msg);
                }
                setTimeout(function () {
                    swan.hideLoading && swan.hideLoading();
                    _this3.verify.requesting = false;
                }, 0);
            }, function (err) {
                if (swan.hideLoading) {
                    swan.hideLoading();
                }
                console.log(err);
                if (err.code === 'FEC000') {
                    swan.showToast({ title: '\u7F51\u7EDC\u5F02\u5E38', icon: 'none' });
                } else {
                    swan.showToast({ title: err.msg || '\u670D\u52A1\u5F02\u5E38', icon: 'none' });
                }
                _this3.verify.requesting = false;
            });
        } else if (requestType == 26) {
            phoneService.verifyPhoneCodeInfo(params).then(function (data) {
                if (swan.hideLoading) {
                    swan.hideLoading();
                }
                _this3.setData('info.phonecode', '');
                _this3.setData('info.origincode', '');
                if (data.code === 'A00000') {
                    _this3.verifySuccessHandle(data, value);
                } else {
                    swan.showToast({
                        title: '' + data.msg,
                        icon: 'none'
                    });
                }
                setTimeout(function () {
                    _this3.verify.requesting = false;
                }, 0);
            }, function (error) {
                if (swan.hideLoading) {
                    swan.hideLoading();
                }
                swan.showToast({
                    title: '\u670D\u52A1\u5F02\u5E38',
                    icon: 'none'
                });
                _this3.verify.requesting = false;
            });
        } else if (requestType == 30) {
            var deviceId = user.getAnonymousUid();
            params = Object.assign({}, params, {
                device_id: deviceId,
                authcookie: this.app.globalData.mutiAuthcookie,
                cellphoneNumber: _rsaUtil2.default.RSAEncryption(phone)
            });
            if (swan.showLoading) {
                swan.showLoading({
                    title: '加载中'
                });
            }
            this.verifyLogin(params).then(function () {
                var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

                var authcookie = _util2.default.isObject(data) ? data.authcookie : '';
                var nickname = _util2.default.isObject(data) ? data.nickname ? data.nickname : '' : '';
                if (swan.hideLoading) {
                    swan.hideLoading();
                }
                //更新authcookie
                _session2.default.Session.set(_session2.default.SESSION_AUTH_KEY, authcookie);
                _this3.mutiVerifyFlag = true;

                getApp().emitter.emit('hideMutiDialog');
                //toast提示
                _this3.showMutiAccountToast();
                _this3.setData({
                    'mutiUserName': nickname
                });
                _this3.verify.requesting = false;
                //返回原页面
                setTimeout(function () {

                    swan.navigateBack({
                        delta: 2
                    });
                }, 3000);
            }).catch(function (err) {
                _this3.verify.requesting = false;
                _this3.setData('info.phonecode', '');
                _this3.setData('info.origincode', '');
                if (swan.hideLoading) {
                    swan.hideLoading();
                }
                /*提示文案*/
                var toastMsg = '切换失败，请重试';
                if (_util2.default.isObject(err) && typeof err.code == 'string' && err.code.indexOf('FEC') == -1) {
                    toastMsg = err.msg ? err.msg : toastMsg;
                }
                swan.hideToast();
                swan.showToast({
                    title: toastMsg,
                    icon: 'none'
                });
            });
        }
    },
    jump: function jump(event) {
        var target = event.currentTarget;
        var url = target.dataset.url;
        _util2.default.jump(url);
    }
};

Page(Object.assign({}, page));
});
window.__swanRoute='pages/messageCodeInput/messageCodeInput';window.usingComponents=[];require('125');

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvbWVzc2FnZUNvZGVJbnB1dC9tZXNzYWdlQ29kZUlucHV0LmpzIl0sIm5hbWVzIjpbInVzZXIiLCJzZXJ2aWNlQXBpIiwib2JqZWN0IiwiYXBwIiwiZ2V0QXBwIiwiQ0VMTFBIT05FX0xPR0lOX1VSTCIsIl8iLCJPVVRFUkhPU1QiLCJQQVNTUE9SVCIsInBhZ2UiLCJkYXRhIiwib3B0aW9ucyIsImluZm8iLCJhcmVhX2NvZGUiLCJwaG9uZSIsInNob3dQaG9uZSIsInBob25lY29kZSIsInJlc2VuZCIsImlzRm9jdXMiLCJvblNob3ciLCJldmVudCIsInNldFRpbWVvdXQiLCJzZXRfRm9jdXMiLCJvblJlYWR5Iiwib25Mb2FkIiwiY29uc29sZSIsImxvZyIsImluaXQiLCJsb2FkUGFnZSIsIl9sb2FkZWRQYWdlIiwidG9rZW5zIiwicmVxdWVzdFR5cGUiLCJwYWdlZnJvbSIsImRlbHRhIiwicGhvbmVUeXBlIiwic3Vic3RyaW5nIiwic2hvd3Bob25lIiwic2V0RGF0YSIsImNvdW50RG93biIsInRpbWUiLCJydW5PYmoiLCJydW5NYWNpbmUiLCJjbGVhciIsImNvdW50cyIsInJ1biIsImp1bXAiLCJ0eXBlIiwic2V0X25vdEZvY3VzIiwiZXJyb3IiLCJzZXRfcGhvbmVjb2RlIiwidmFsdWUiLCJkZXRhaWwiLCJ2ZXJpZnkiLCJyZXF1ZXN0aW5nIiwibGVuZ3RoIiwic3RhdGUiLCJhdXRoQ29kZSIsIm9yaWdpbmNvZGUiLCJwYXJhbXMiLCJhZ2VudHR5cGUiLCJnbG9iYWxEYXRhIiwicHRpZCIsImNlbGxwaG9uZU51bWJlciIsInNlcnZpY2VJZCIsImRldmljZV9pZCIsImdldERldmljZUlkIiwiZGZwIiwiUUMwMDUiLCJxZF9zYyIsInJzYVV0aWwiLCJnZXRRaXlpUXRzYyIsInN3YW4iLCJzaG93TG9hZGluZyIsInRpdGxlIiwibWFzayIsImNvbW1vblBvc3RSZXF1ZXN0IiwidXJsIiwicmVxUGFyYW1zIiwidGhlbiIsImNvZGUiLCJyZXMiLCJpc05ld3VzZXIiLCJuZWVkTG9naW4iLCJhdXRoQ29va2llIiwiYXV0aGNvb2tpZSIsInNob3dUb2FzdCIsIm1zZyIsImljb24iLCJoaWRlTG9hZGluZyIsImVyciIsInBob25lU2VydmljZSIsInZlcmlmeVBob25lQ29kZUluZm8iLCJ2ZXJpZnlTdWNjZXNzSGFuZGxlIiwiZGV2aWNlSWQiLCJnZXRBbm9ueW1vdXNVaWQiLCJPYmplY3QiLCJhc3NpZ24iLCJtdXRpQXV0aGNvb2tpZSIsIlJTQUVuY3J5cHRpb24iLCJ2ZXJpZnlMb2dpbiIsImlzT2JqZWN0Iiwibmlja25hbWUiLCJzZXNzaW9uIiwiU2Vzc2lvbiIsInNldCIsIlNFU1NJT05fQVVUSF9LRVkiLCJtdXRpVmVyaWZ5RmxhZyIsImVtaXR0ZXIiLCJlbWl0Iiwic2hvd011dGlBY2NvdW50VG9hc3QiLCJuYXZpZ2F0ZUJhY2siLCJjYXRjaCIsInRvYXN0TXNnIiwiaW5kZXhPZiIsImhpZGVUb2FzdCIsInRhcmdldCIsImN1cnJlbnRUYXJnZXQiLCJkYXRhc2V0IiwiUGFnZSJdLCJtYXBwaW5ncyI6Ijs7O0FBQUE7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7O0lBQVlBLEk7O0FBQ1o7Ozs7QUFDQTs7SUFBWUMsVTs7QUFDWjs7OztBQUNBOztJQUFZQyxNOzs7Ozs7QUFFWixJQUFNQyxNQUFNQyxRQUFaO0FBQ0EsSUFBTUMsc0JBQXlCQyxlQUFFQyxTQUFGLENBQVlDLFFBQXJDLG1EQUFOO0FBQ0EsSUFBTUMsT0FBTztBQUNUQyxVQUFNO0FBQ0ZDLGlCQUFTLEVBRFA7QUFFRkMsY0FBTTtBQUNGQyx1QkFBVyxFQURUO0FBRUZDLG1CQUFPLGFBRkw7QUFHRkMsdUJBQVcsYUFIVDtBQUlGQyx1QkFBVyxFQUpUO0FBS0ZDLG9CQUFRO0FBTE4sU0FGSjtBQVNGQyxpQkFBUztBQVRQLEtBREc7QUFZVEMsVUFaUyxrQkFZRkMsS0FaRSxFQVlLO0FBQUE7O0FBQ1Y7QUFDQUMsbUJBQVcsWUFBTTtBQUNiLGtCQUFLQyxTQUFMO0FBQ0gsU0FGRCxFQUVHLEdBRkg7QUFHSCxLQWpCUTtBQWtCVEMsV0FsQlMscUJBa0JDLENBQ1QsQ0FuQlE7QUFvQlRDLFVBcEJTLGtCQW9CRmIsT0FwQkUsRUFvQk87QUFDWixhQUFLRCxJQUFMLENBQVVDLE9BQVYsR0FBb0JBLE9BQXBCO0FBQ0FjLGdCQUFRQyxHQUFSLENBQVlmLE9BQVo7QUFDQSxhQUFLZ0IsSUFBTDtBQUNILEtBeEJRO0FBeUJUQyxZQXpCUyxzQkF5QkU7QUFDUEgsZ0JBQVFDLEdBQVIsQ0FBWSxLQUFaO0FBQ0gsS0EzQlE7QUE0QlRHLGVBNUJTLHVCQTRCR25CLElBNUJILEVBNEJTLENBRWpCLENBOUJRO0FBK0JUaUIsUUEvQlMsa0JBK0JGO0FBQUEsNEJBQ3lFLEtBQUtqQixJQUFMLENBQVVDLE9BRG5GO0FBQUEsWUFDR21CLE1BREgsaUJBQ0dBLE1BREg7QUFBQSxZQUNXakIsU0FEWCxpQkFDV0EsU0FEWDtBQUFBLFlBQ3NCQyxLQUR0QixpQkFDc0JBLEtBRHRCO0FBQUEsWUFDNkJpQixXQUQ3QixpQkFDNkJBLFdBRDdCO0FBQUEsWUFDMENDLFFBRDFDLGlCQUMwQ0EsUUFEMUM7QUFBQSxZQUNvREMsS0FEcEQsaUJBQ29EQSxLQURwRDtBQUFBLFlBQzJEQyxTQUQzRCxpQkFDMkRBLFNBRDNEOztBQUVILFlBQUluQixZQUFZRCxLQUFoQjtBQUNBLFlBQUlELFlBQVksRUFBYixLQUFxQixJQUF4QixFQUE4QjtBQUMxQkUsd0JBQVlELE1BQU1xQixTQUFOLENBQWdCLENBQWhCLEVBQW1CLENBQW5CLElBQXdCLE1BQXhCLEdBQWlDckIsTUFBTXFCLFNBQU4sQ0FBZ0IsQ0FBaEIsQ0FBN0M7QUFDSDtBQUNELGFBQUt6QixJQUFMLENBQVUwQixTQUFWLEdBQXNCdEIsS0FBdEI7QUFDQSxhQUFLdUIsT0FBTCxDQUFhLGdCQUFiLEVBQStCeEIsU0FBL0I7QUFDQSxhQUFLd0IsT0FBTCxDQUFhLFlBQWIsRUFBMkJ2QixLQUEzQjtBQUNBLGFBQUt1QixPQUFMLENBQWEsZ0JBQWIsRUFBK0J0QixTQUEvQjtBQUNBLGFBQUtzQixPQUFMLENBQWEsa0JBQWIsRUFBaUNOLFdBQWpDO0FBQ0EsYUFBS00sT0FBTCxDQUFhLGFBQWIsRUFBNEJQLE1BQTVCO0FBQ0EsYUFBS08sT0FBTCxDQUFhLGFBQWIsRUFBNEIsS0FBNUI7QUFDQSxhQUFLQyxTQUFMO0FBQ0gsS0E3Q1E7QUE4Q1RBLGFBOUNTLHVCQThDRztBQUFBOztBQUNSLFlBQU1DLE9BQU8sQ0FBYjtBQUNBLFlBQUcsS0FBS0MsTUFBUixFQUFnQjtBQUNaLGlCQUFLSCxPQUFMLENBQWEsYUFBYixFQUE0QixJQUE1QjtBQUNBSSxnQ0FBVUMsS0FBVixDQUFnQixLQUFLRixNQUFyQjtBQUNIO0FBQ0QsYUFBSzlCLElBQUwsQ0FBVWlDLE1BQVYsR0FBbUJKLElBQW5CO0FBQ0EsYUFBS0MsTUFBTCxHQUFjQyxvQkFBVUcsR0FBVixDQUFjLFlBQU07QUFDOUIsZ0JBQUcsT0FBS2xDLElBQUwsQ0FBVWlDLE1BQVYsSUFBb0IsQ0FBdkIsRUFBMEI7QUFDdEIsdUJBQUtqQyxJQUFMLENBQVVpQyxNQUFWLEdBQW1CLENBQW5CO0FBQ0EsdUJBQUtOLE9BQUwsQ0FBYSxhQUFiLEVBQTRCLElBQTVCO0FBQ0g7QUFDRCxtQkFBSzNCLElBQUwsQ0FBVWlDLE1BQVY7QUFDQSxtQkFBS04sT0FBTCxDQUFhLEVBQUVNLFFBQVEsT0FBS2pDLElBQUwsQ0FBVWlDLE1BQXBCLEVBQWI7QUFDSCxTQVBhLEVBT1gsSUFQVyxFQU9MSixJQVBLLENBQWQ7QUFRSCxLQTdEUTtBQThEVHRCLFVBOURTLG9CQThEQTtBQUNMWCx1QkFBRXVDLElBQUYsQ0FBTyxFQUFFQyxNQUFNLE1BQVIsRUFBUDtBQUNILEtBaEVRO0FBaUVUeEIsYUFqRVMsdUJBaUVHO0FBQUU7QUFDVixhQUFLZSxPQUFMLENBQWEsRUFBRW5CLFNBQVMsSUFBWCxFQUFiO0FBQ0FPLGdCQUFRQyxHQUFSLENBQVksSUFBWjtBQUNILEtBcEVRO0FBcUVUcUIsZ0JBckVTLDBCQXFFTTtBQUFFO0FBQ2IsYUFBS1YsT0FBTCxDQUFhLEVBQUVuQixTQUFTLEtBQVgsRUFBYjtBQUNBTyxnQkFBUXVCLEtBQVIsQ0FBYyxPQUFkO0FBQ0gsS0F4RVE7QUF5RVRDLGlCQXpFUyx5QkF5RUs3QixLQXpFTCxFQXlFWTtBQUNqQixZQUFJOEIsUUFBUTlCLE1BQU0rQixNQUFOLENBQWFELEtBQXpCO0FBQ0EsWUFBRyxLQUFLRSxNQUFMLENBQVlDLFVBQWYsRUFBMkI7QUFDdkI7QUFDSDtBQUNELGFBQUszQyxJQUFMLENBQVVFLElBQVYsQ0FBZUksU0FBZixHQUEyQmtDLFFBQVEsRUFBbkM7QUFDQSxhQUFLYixPQUFMLENBQWEsZ0JBQWIsRUFBK0JhLEtBQS9CO0FBQ0EsWUFBR0EsU0FBU0EsTUFBTUksTUFBTixLQUFpQixDQUE3QixFQUFnQztBQUM1QixpQkFBS1AsWUFBTDtBQUNBLGlCQUFLSyxNQUFMLENBQVlGLEtBQVo7QUFDSDtBQUNKLEtBcEZRO0FBcUZURSxVQXJGUyxrQkFxRkZGLEtBckZFLEVBcUZLO0FBQUE7O0FBQ1YsWUFBSUssUUFBUSxLQUFLN0MsSUFBakI7QUFDQSxZQUFJRyxZQUFZMEMsTUFBTTNDLElBQU4sQ0FBV0MsU0FBWCxJQUF3QixFQUF4QztBQUNBLFlBQUkyQyxXQUFXRCxNQUFNM0MsSUFBTixDQUFXNkMsVUFBMUI7QUFDQSxZQUFJM0MsUUFBUXlDLE1BQU0zQyxJQUFOLENBQVdFLEtBQXZCO0FBQ0EsWUFBSWlCLGNBQWN3QixNQUFNM0MsSUFBTixDQUFXbUIsV0FBWCxJQUEwQixFQUE1QztBQUNBLFlBQUlELFNBQVN5QixNQUFNM0MsSUFBTixDQUFXa0IsTUFBWCxJQUFxQixFQUFsQzs7QUFFQSxZQUFJNEIsU0FBUztBQUNUO0FBQ0FDLHVCQUFXeEQsSUFBSXlELFVBQUosQ0FBZUQsU0FGakI7QUFHVEUsa0JBQU0xRCxJQUFJeUQsVUFBSixDQUFlQyxJQUhaO0FBSVRDLDZCQUFpQmhELEtBSlI7QUFLVEQsdUJBQVdBLFNBTEY7QUFNVGtELHVCQUFXLENBTkY7QUFPVEMsdUJBQVdoRSxLQUFLaUUsV0FBTCxFQVBGO0FBUVRDLGlCQUFLbEUsS0FBS2lFLFdBQUwsRUFSSTtBQVNUVCxzQkFBVU4sS0FURCxFQVNPO0FBQ2hCbkIseUJBQWFBLFdBVko7QUFXVG9DLG1CQUFPbkUsS0FBS2lFLFdBQUw7QUFYRSxTQUFiOztBQWNBUCxlQUFPVSxLQUFQLEdBQWVDLGtCQUFRQyxXQUFSLENBQW9CWixNQUFwQixDQUFmOztBQUVBLFlBQUcsS0FBS04sTUFBTCxDQUFZQyxVQUFmLEVBQTJCO0FBQ3ZCO0FBQ0g7QUFDRCxhQUFLRCxNQUFMLENBQVlDLFVBQVosR0FBeUIsSUFBekI7O0FBRUEsWUFBR2tCLEtBQUtDLFdBQVIsRUFBcUI7QUFDakJELGlCQUFLQyxXQUFMLENBQWlCO0FBQ2JDLHVCQUFPLEtBRE07QUFFYkMsc0JBQU07QUFGTyxhQUFqQjtBQUlIOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0EsWUFBRzNDLGVBQWUsRUFBbEIsRUFBc0I7QUFDbEI5Qix1QkFBVzBFLGlCQUFYLENBQTZCO0FBQ3pCQyxxQkFBS3ZFLG1CQURvQjtBQUV6QndFLDJCQUFXbkI7QUFGYyxhQUE3QixFQUdHLElBSEgsRUFHU29CLElBSFQsQ0FHYyxVQUFDcEUsSUFBRCxFQUFVO0FBQ3BCLG9CQUFHQSxLQUFLcUUsSUFBTCxLQUFjLFFBQWpCLEVBQTJCO0FBQ3ZCdEQsNEJBQVFDLEdBQVIsQ0FBWSxlQUFaO0FBQ0EsMkJBQUtXLE9BQUwsQ0FBYSxnQkFBYixFQUErQixFQUEvQjtBQUNBLDJCQUFLQSxPQUFMLENBQWEsaUJBQWIsRUFBZ0MsRUFBaEM7O0FBRUE7O0FBRUEsd0JBQUkyQyxNQUFNdEUsS0FBS0EsSUFBTCxJQUFhLEVBQXZCOztBQUVBO0FBQ0E7QUFDQTs7QUFFQSx3QkFBRyxDQUFDc0UsSUFBSUMsU0FBUixFQUFtQjtBQUNmeEQsZ0NBQVFDLEdBQVI7QUFDSCxxQkFGRCxNQUVPO0FBQ0hELGdDQUFRQyxHQUFSO0FBQ0g7QUFDRCx3QkFBSXZCLE9BQU1DLFFBQVY7QUFDQUQseUJBQUl5RCxVQUFKLENBQWVzQixTQUFmLEdBQTJCLENBQTNCO0FBQ0EvRSx5QkFBSXlELFVBQUosQ0FBZXVCLFVBQWYsR0FBNEJILE9BQU9BLElBQUlJLFVBQVgsSUFBeUIsRUFBckQ7QUFDQWpGLHlCQUFJeUQsVUFBSixDQUFlOUMsS0FBZixHQUF1QkEsS0FBdkI7QUFDQVcsNEJBQVFDLEdBQVIsQ0FBWXZCLEtBQUl5RCxVQUFoQjtBQUNBO0FBQ0F0RCxtQ0FBRXVDLElBQUY7QUFFSCxpQkExQkQsTUEwQk87QUFDSDBCLHlCQUFLYyxTQUFMLENBQWUsRUFBRVosWUFBVS9ELEtBQUs0RSxHQUFqQixFQUF3QkMsTUFBTSxNQUE5QixFQUFmO0FBQ0E5RCw0QkFBUUMsR0FBUixDQUFZaEIsS0FBSzRFLEdBQWpCO0FBQ0g7QUFDRGpFLDJCQUFXLFlBQU07QUFDYmtELHlCQUFLaUIsV0FBTCxJQUFvQmpCLEtBQUtpQixXQUFMLEVBQXBCO0FBQ0EsMkJBQUtwQyxNQUFMLENBQVlDLFVBQVosR0FBeUIsS0FBekI7QUFDSCxpQkFIRCxFQUdHLENBSEg7QUFJSCxhQXRDRCxFQXNDRyxVQUFDb0MsR0FBRCxFQUFTO0FBQ1Isb0JBQUdsQixLQUFLaUIsV0FBUixFQUFxQjtBQUNqQmpCLHlCQUFLaUIsV0FBTDtBQUNIO0FBQ0QvRCx3QkFBUUMsR0FBUixDQUFZK0QsR0FBWjtBQUNBLG9CQUFHQSxJQUFJVixJQUFKLEtBQWEsUUFBaEIsRUFBMEI7QUFDdEJSLHlCQUFLYyxTQUFMLENBQWUsRUFBRVosaUNBQUYsRUFBaUJjLE1BQU0sTUFBdkIsRUFBZjtBQUNILGlCQUZELE1BRU87QUFDSGhCLHlCQUFLYyxTQUFMLENBQWUsRUFBRVosT0FBT2dCLElBQUlILEdBQUosOEJBQVQsRUFBNEJDLE1BQU0sTUFBbEMsRUFBZjtBQUNIO0FBQ0QsdUJBQUtuQyxNQUFMLENBQVlDLFVBQVosR0FBeUIsS0FBekI7QUFDSCxhQWpERDtBQWtESCxTQW5ERCxNQW1ETyxJQUFHdEIsZUFBZSxFQUFsQixFQUFzQjtBQUN6QjJELHlCQUFhQyxtQkFBYixDQUFpQ2pDLE1BQWpDLEVBQXlDb0IsSUFBekMsQ0FBOEMsVUFBQ3BFLElBQUQsRUFBVTtBQUNwRCxvQkFBRzZELEtBQUtpQixXQUFSLEVBQXFCO0FBQ2pCakIseUJBQUtpQixXQUFMO0FBQ0g7QUFDRCx1QkFBS25ELE9BQUwsQ0FBYSxnQkFBYixFQUErQixFQUEvQjtBQUNBLHVCQUFLQSxPQUFMLENBQWEsaUJBQWIsRUFBZ0MsRUFBaEM7QUFDQSxvQkFBRzNCLEtBQUtxRSxJQUFMLEtBQWMsUUFBakIsRUFBMkI7QUFDdkIsMkJBQUthLG1CQUFMLENBQXlCbEYsSUFBekIsRUFBK0J3QyxLQUEvQjtBQUNILGlCQUZELE1BRU87QUFDSHFCLHlCQUFLYyxTQUFMLENBQWU7QUFDWFosb0NBQVUvRCxLQUFLNEUsR0FESjtBQUVYQyw4QkFBTTtBQUZLLHFCQUFmO0FBSUg7QUFDRGxFLDJCQUFXLFlBQU07QUFDYiwyQkFBSytCLE1BQUwsQ0FBWUMsVUFBWixHQUF5QixLQUF6QjtBQUNILGlCQUZELEVBRUcsQ0FGSDtBQUdILGFBakJELEVBaUJHLFVBQUNMLEtBQUQsRUFBVztBQUNWLG9CQUFHdUIsS0FBS2lCLFdBQVIsRUFBcUI7QUFDakJqQix5QkFBS2lCLFdBQUw7QUFDSDtBQUNEakIscUJBQUtjLFNBQUwsQ0FBZTtBQUNYWixxREFEVztBQUVYYywwQkFBTTtBQUZLLGlCQUFmO0FBSUEsdUJBQUtuQyxNQUFMLENBQVlDLFVBQVosR0FBeUIsS0FBekI7QUFDSCxhQTFCRDtBQTJCSCxTQTVCTSxNQTRCQSxJQUFHdEIsZUFBZSxFQUFsQixFQUFzQjtBQUN6QixnQkFBSThELFdBQVc3RixLQUFLOEYsZUFBTCxFQUFmO0FBQ0FwQyxxQkFBU3FDLE9BQU9DLE1BQVAsQ0FBYyxFQUFkLEVBQWtCdEMsTUFBbEIsRUFBMEI7QUFDL0JNLDJCQUFXNkIsUUFEb0I7QUFFL0JULDRCQUFZLEtBQUtqRixHQUFMLENBQVN5RCxVQUFULENBQW9CcUMsY0FGRDtBQUcvQm5DLGlDQUFpQk8sa0JBQVE2QixhQUFSLENBQXNCcEYsS0FBdEI7QUFIYyxhQUExQixDQUFUO0FBS0EsZ0JBQUd5RCxLQUFLQyxXQUFSLEVBQXFCO0FBQ2pCRCxxQkFBS0MsV0FBTCxDQUFpQjtBQUNiQywyQkFBTztBQURNLGlCQUFqQjtBQUdIO0FBQ0QsaUJBQUswQixXQUFMLENBQWlCekMsTUFBakIsRUFBeUJvQixJQUF6QixDQUE4QixZQUFlO0FBQUEsb0JBQWRwRSxJQUFjLHVFQUFQLEVBQU87O0FBQ3pDLG9CQUFJMEUsYUFBYTlFLGVBQUU4RixRQUFGLENBQVcxRixJQUFYLElBQW1CQSxLQUFLMEUsVUFBeEIsR0FBcUMsRUFBdEQ7QUFDQSxvQkFBSWlCLFdBQVcvRixlQUFFOEYsUUFBRixDQUFXMUYsSUFBWCxJQUFvQkEsS0FBSzJGLFFBQUwsR0FBZ0IzRixLQUFLMkYsUUFBckIsR0FBZ0MsRUFBcEQsR0FBMEQsRUFBekU7QUFDQSxvQkFBRzlCLEtBQUtpQixXQUFSLEVBQXFCO0FBQ2pCakIseUJBQUtpQixXQUFMO0FBQ0g7QUFDRDtBQUNBYyxrQ0FBUUMsT0FBUixDQUFnQkMsR0FBaEIsQ0FBb0JGLGtCQUFRRyxnQkFBNUIsRUFBOENyQixVQUE5QztBQUNBLHVCQUFLc0IsY0FBTCxHQUFzQixJQUF0Qjs7QUFFQXRHLHlCQUFTdUcsT0FBVCxDQUFpQkMsSUFBakIsQ0FBc0IsZ0JBQXRCO0FBQ0E7QUFDQSx1QkFBS0Msb0JBQUw7QUFDQSx1QkFBS3hFLE9BQUwsQ0FBYTtBQUNULG9DQUFnQmdFO0FBRFAsaUJBQWI7QUFHQSx1QkFBS2pELE1BQUwsQ0FBWUMsVUFBWixHQUF5QixLQUF6QjtBQUNBO0FBQ0FoQywyQkFBVyxZQUFNOztBQUVia0QseUJBQUt1QyxZQUFMLENBQWtCO0FBQ2Q3RSwrQkFBTztBQURPLHFCQUFsQjtBQUlILGlCQU5ELEVBTUcsSUFOSDtBQVFILGFBMUJELEVBMEJHOEUsS0ExQkgsQ0EwQlMsVUFBQ3RCLEdBQUQsRUFBUztBQUNkLHVCQUFLckMsTUFBTCxDQUFZQyxVQUFaLEdBQXlCLEtBQXpCO0FBQ0EsdUJBQUtoQixPQUFMLENBQWEsZ0JBQWIsRUFBK0IsRUFBL0I7QUFDQSx1QkFBS0EsT0FBTCxDQUFhLGlCQUFiLEVBQWdDLEVBQWhDO0FBQ0Esb0JBQUdrQyxLQUFLaUIsV0FBUixFQUFxQjtBQUNqQmpCLHlCQUFLaUIsV0FBTDtBQUNIO0FBQ0Q7QUFDQSxvQkFBSXdCLFdBQVcsVUFBZjtBQUNBLG9CQUFHMUcsZUFBRThGLFFBQUYsQ0FBV1gsR0FBWCxLQUFvQixPQUFPQSxJQUFJVixJQUFYLElBQW1CLFFBQXZDLElBQXFEVSxJQUFJVixJQUFKLENBQVNrQyxPQUFULENBQWlCLEtBQWpCLEtBQTJCLENBQUMsQ0FBcEYsRUFBd0Y7QUFDcEZELCtCQUFXdkIsSUFBSUgsR0FBSixHQUFVRyxJQUFJSCxHQUFkLEdBQW9CMEIsUUFBL0I7QUFDSDtBQUNEekMscUJBQUsyQyxTQUFMO0FBQ0EzQyxxQkFBS2MsU0FBTCxDQUFlO0FBQ1haLDJCQUFPdUMsUUFESTtBQUVYekIsMEJBQU07QUFGSyxpQkFBZjtBQUlILGFBM0NEO0FBNENIO0FBQ0osS0F6UVE7QUEwUVQxQyxRQTFRUyxnQkEwUUp6QixLQTFRSSxFQTBRRztBQUNSLFlBQU0rRixTQUFTL0YsTUFBTWdHLGFBQXJCO0FBQ0EsWUFBTXhDLE1BQU11QyxPQUFPRSxPQUFQLENBQWV6QyxHQUEzQjtBQUNBdEUsdUJBQUV1QyxJQUFGLENBQU8rQixHQUFQO0FBQ0g7QUE5UVEsQ0FBYjs7QUFrUkEwQyxLQUFLdkIsT0FBT0MsTUFBUCxDQUFjLEVBQWQsRUFBa0J2RixJQUFsQixDQUFMLEUiLCJmaWxlIjoicGFnZXMvbWVzc2FnZUNvZGVJbnB1dC9tZXNzYWdlQ29kZUlucHV0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IF8gZnJvbSAnLi4vLi4vY29tbW9uL3V0aWxzL3V0aWwnXG5pbXBvcnQgcnVuTWFjaW5lIGZyb20gJy4uLy4uL2NvbW1vbi91dGlscy9ydW5NYWNpbmUnO1xuaW1wb3J0IGp1bXAgZnJvbSBcIi4uLy4uL2NvbW1vbi91dGlscy9qdW1wXCI7XG5pbXBvcnQgKiBhcyB1c2VyIGZyb20gXCIuLi8uLi9jb21tb24vdXNlci91c2VySW5mb1wiO1xuaW1wb3J0IHJzYVV0aWwgZnJvbSBcIi4uLy4uL2NvbW1vbi91dGlscy9SU0EvcnNhVXRpbFwiO1xuaW1wb3J0ICogYXMgc2VydmljZUFwaSBmcm9tICcuLi8uLi9jb21tb24vc2VydmljZUFwaS9zZXJ2aWNlQXBpJ1xuaW1wb3J0IHNlc3Npb24gZnJvbSBcIi4uLy4uL2NvbW1vbi9sb2dpbi9zZXNzaW9uXCI7XG5pbXBvcnQgKiBhcyBvYmplY3QgZnJvbSBcIi4uLy4uL2NvbW1vbi91dGlscy9vYmplY3RcIjtcblxuY29uc3QgYXBwID0gZ2V0QXBwKCk7XG5jb25zdCBDRUxMUEhPTkVfTE9HSU5fVVJMID0gYCR7Xy5PVVRFUkhPU1QuUEFTU1BPUlR9L2FwaXMvcmVnbG9naW4vY2VsbHBob25lX2F1dGhjb2RlX2xvZ2luLmFjdGlvbmA7XG5jb25zdCBwYWdlID0ge1xuICAgIGRhdGE6IHtcbiAgICAgICAgb3B0aW9uczoge30sXG4gICAgICAgIGluZm86IHtcbiAgICAgICAgICAgIGFyZWFfY29kZTogODYsXG4gICAgICAgICAgICBwaG9uZTogJzEzODk5OTk3Nzc3JyxcbiAgICAgICAgICAgIHNob3dQaG9uZTogJzEzOCoqKio3Nzc3JyxcbiAgICAgICAgICAgIHBob25lY29kZTogJycsXG4gICAgICAgICAgICByZXNlbmQ6IGZhbHNlXG4gICAgICAgIH0sXG4gICAgICAgIGlzRm9jdXM6IHRydWVcbiAgICB9LFxuICAgIG9uU2hvdyhldmVudCkge1xuICAgICAgICAvLyB0aGlzLmxvYWRQYWdlKCk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5zZXRfRm9jdXMoKTtcbiAgICAgICAgfSwgMjAwKVxuICAgIH0sXG4gICAgb25SZWFkeSgpIHtcbiAgICB9LFxuICAgIG9uTG9hZChvcHRpb25zKSB7XG4gICAgICAgIHRoaXMuZGF0YS5vcHRpb25zID0gb3B0aW9ucztcbiAgICAgICAgY29uc29sZS5sb2cob3B0aW9ucyk7XG4gICAgICAgIHRoaXMuaW5pdCgpO1xuICAgIH0sXG4gICAgbG9hZFBhZ2UoKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKDEyMzMzKTtcbiAgICB9LFxuICAgIF9sb2FkZWRQYWdlKGRhdGEpIHtcblxuICAgIH0sXG4gICAgaW5pdCgpIHtcbiAgICAgICAgbGV0IHsgdG9rZW5zLCBhcmVhX2NvZGUsIHBob25lLCByZXF1ZXN0VHlwZSwgcGFnZWZyb20sIGRlbHRhLCBwaG9uZVR5cGUgfSA9IHRoaXMuZGF0YS5vcHRpb25zO1xuICAgICAgICBsZXQgc2hvd1Bob25lID0gcGhvbmU7XG4gICAgICAgIGlmKChhcmVhX2NvZGUgKyAnJykgPT09ICc4NicpIHtcbiAgICAgICAgICAgIHNob3dQaG9uZSA9IHBob25lLnN1YnN0cmluZygwLCAzKSArICcqKioqJyArIHBob25lLnN1YnN0cmluZyg3KTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmRhdGEuc2hvd3Bob25lID0gcGhvbmU7XG4gICAgICAgIHRoaXMuc2V0RGF0YSgnaW5mby5hcmVhX2NvZGUnLCBhcmVhX2NvZGUpO1xuICAgICAgICB0aGlzLnNldERhdGEoJ2luZm8ucGhvbmUnLCBwaG9uZSk7XG4gICAgICAgIHRoaXMuc2V0RGF0YSgnaW5mby5zaG93UGhvbmUnLCBzaG93UGhvbmUpO1xuICAgICAgICB0aGlzLnNldERhdGEoJ2luZm8ucmVxdWVzdFR5cGUnLCByZXF1ZXN0VHlwZSk7XG4gICAgICAgIHRoaXMuc2V0RGF0YSgnaW5mby50b2tlbnMnLCB0b2tlbnMpO1xuICAgICAgICB0aGlzLnNldERhdGEoJ2luZm8ucmVzZW5kJywgZmFsc2UpO1xuICAgICAgICB0aGlzLmNvdW50RG93bigpO1xuICAgIH0sXG4gICAgY291bnREb3duKCkge1xuICAgICAgICBjb25zdCB0aW1lID0gNTtcbiAgICAgICAgaWYodGhpcy5ydW5PYmopIHtcbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YSgnaW5mby5yZXNlbmQnLCB0cnVlKTtcbiAgICAgICAgICAgIHJ1bk1hY2luZS5jbGVhcih0aGlzLnJ1bk9iaik7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5kYXRhLmNvdW50cyA9IHRpbWU7XG4gICAgICAgIHRoaXMucnVuT2JqID0gcnVuTWFjaW5lLnJ1bigoKSA9PiB7XG4gICAgICAgICAgICBpZih0aGlzLmRhdGEuY291bnRzIDw9IDEpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmRhdGEuY291bnRzID0gMDtcbiAgICAgICAgICAgICAgICB0aGlzLnNldERhdGEoJ2luZm8ucmVzZW5kJywgdHJ1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLmRhdGEuY291bnRzLS07XG4gICAgICAgICAgICB0aGlzLnNldERhdGEoeyBjb3VudHM6IHRoaXMuZGF0YS5jb3VudHMgfSk7XG4gICAgICAgIH0sIDEwMDAsIHRpbWUpO1xuICAgIH0sXG4gICAgcmVzZW5kKCkge1xuICAgICAgICBfLmp1bXAoeyB0eXBlOiAnYmFjaycgfSk7XG4gICAgfSxcbiAgICBzZXRfRm9jdXMoKSB7IC8v6IGa54SmaW5wdXRcbiAgICAgICAgdGhpcy5zZXREYXRhKHsgaXNGb2N1czogdHJ1ZSB9KVxuICAgICAgICBjb25zb2xlLmxvZygn6IGa54SmJyk7XG4gICAgfSxcbiAgICBzZXRfbm90Rm9jdXMoKSB7IC8v5aSx5Y6754Sm54K5XG4gICAgICAgIHRoaXMuc2V0RGF0YSh7IGlzRm9jdXM6IGZhbHNlIH0pXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ+WkseWOu+eEpueCuSEnKTtcbiAgICB9LFxuICAgIHNldF9waG9uZWNvZGUoZXZlbnQpIHtcbiAgICAgICAgbGV0IHZhbHVlID0gZXZlbnQuZGV0YWlsLnZhbHVlO1xuICAgICAgICBpZih0aGlzLnZlcmlmeS5yZXF1ZXN0aW5nKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5kYXRhLmluZm8ucGhvbmVjb2RlID0gdmFsdWUgKyAnJztcbiAgICAgICAgdGhpcy5zZXREYXRhKCdpbmZvLnBob25lY29kZScsIHZhbHVlKVxuICAgICAgICBpZih2YWx1ZSAmJiB2YWx1ZS5sZW5ndGggPT09IDYpIHtcbiAgICAgICAgICAgIHRoaXMuc2V0X25vdEZvY3VzKCk7XG4gICAgICAgICAgICB0aGlzLnZlcmlmeSh2YWx1ZSk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIHZlcmlmeSh2YWx1ZSkge1xuICAgICAgICBsZXQgc3RhdGUgPSB0aGlzLmRhdGE7XG4gICAgICAgIGxldCBhcmVhX2NvZGUgPSBzdGF0ZS5pbmZvLmFyZWFfY29kZSB8fCAnJztcbiAgICAgICAgbGV0IGF1dGhDb2RlID0gc3RhdGUuaW5mby5vcmlnaW5jb2RlO1xuICAgICAgICBsZXQgcGhvbmUgPSBzdGF0ZS5pbmZvLnBob25lO1xuICAgICAgICBsZXQgcmVxdWVzdFR5cGUgPSBzdGF0ZS5pbmZvLnJlcXVlc3RUeXBlIHx8ICcnO1xuICAgICAgICBsZXQgdG9rZW5zID0gc3RhdGUuaW5mby50b2tlbnMgfHwgJyc7XG5cbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcbiAgICAgICAgICAgIC8vIHFkX3NjOicnXG4gICAgICAgICAgICBhZ2VudHR5cGU6IGFwcC5nbG9iYWxEYXRhLmFnZW50dHlwZSxcbiAgICAgICAgICAgIHB0aWQ6IGFwcC5nbG9iYWxEYXRhLnB0aWQsXG4gICAgICAgICAgICBjZWxscGhvbmVOdW1iZXI6IHBob25lLFxuICAgICAgICAgICAgYXJlYV9jb2RlOiBhcmVhX2NvZGUsXG4gICAgICAgICAgICBzZXJ2aWNlSWQ6IDEsXG4gICAgICAgICAgICBkZXZpY2VfaWQ6IHVzZXIuZ2V0RGV2aWNlSWQoKSxcbiAgICAgICAgICAgIGRmcDogdXNlci5nZXREZXZpY2VJZCgpLFxuICAgICAgICAgICAgYXV0aENvZGU6IHZhbHVlLC8v6aqM6K+B56CBXG4gICAgICAgICAgICByZXF1ZXN0VHlwZTogcmVxdWVzdFR5cGUsXG4gICAgICAgICAgICBRQzAwNTogdXNlci5nZXREZXZpY2VJZCgpXG4gICAgICAgIH07XG5cbiAgICAgICAgcGFyYW1zLnFkX3NjID0gcnNhVXRpbC5nZXRRaXlpUXRzYyhwYXJhbXMpO1xuXG4gICAgICAgIGlmKHRoaXMudmVyaWZ5LnJlcXVlc3RpbmcpIHtcbiAgICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG4gICAgICAgIHRoaXMudmVyaWZ5LnJlcXVlc3RpbmcgPSB0cnVlO1xuXG4gICAgICAgIGlmKHN3YW4uc2hvd0xvYWRpbmcpIHtcbiAgICAgICAgICAgIHN3YW4uc2hvd0xvYWRpbmcoe1xuICAgICAgICAgICAgICAgIHRpdGxlOiAn5Yqg6L295LitJyxcbiAgICAgICAgICAgICAgICBtYXNrOiB0cnVlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGxldCByZXMgPSB7XG4gICAgICAgIC8vICAgICBhdXRoY29va2llOiBcIjlkUFlQNGlSSEtUbG0zc3lFNGk5Y1dmT2VGeXJLOGVFeE9ManBFbm9tMXhmbTJxUHRWNkE4TURpdzY3blhZU20ya3ptM0MzMTRcIixcbiAgICAgICAgLy8gICAgIGlzTmV3VXNlcjogZmFsc2VcbiAgICAgICAgLy8gfVxuICAgICAgICAvLyB0aGlzLnZlcmlmeVN1Y2Nlc3NIYW5kbGUocmVzKTtcbiAgICAgICAgLy8gcmV0dXJuO1xuXG5cbiAgICAgICAgaWYocmVxdWVzdFR5cGUgPT0gMjIpIHtcbiAgICAgICAgICAgIHNlcnZpY2VBcGkuY29tbW9uUG9zdFJlcXVlc3Qoe1xuICAgICAgICAgICAgICAgIHVybDogQ0VMTFBIT05FX0xPR0lOX1VSTCxcbiAgICAgICAgICAgICAgICByZXFQYXJhbXM6IHBhcmFtc1xuICAgICAgICAgICAgfSwgdHJ1ZSkudGhlbigoZGF0YSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmKGRhdGEuY29kZSA9PT0gJ0EwMDAwMCcpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2xvZ2luIHN1Y2Nlc3MnKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKCdpbmZvLnBob25lY29kZScsICcnKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKCdpbmZvLm9yaWdpbmNvZGUnLCAnJyk7XG5cbiAgICAgICAgICAgICAgICAgICAgLy8gc2Vzc2lvbi5TZXNzaW9uLnNldChzZXNzaW9uLlNFU1NJT05fUEhPTkVfTlVNQkVSLCBwaG9uZSk7Ly/lhpnlhaXmiYvmnLrlj7fnoIFcblxuICAgICAgICAgICAgICAgICAgICBsZXQgcmVzID0gZGF0YS5kYXRhIHx8IHt9O1xuXG4gICAgICAgICAgICAgICAgICAgIC8vIGxldCB0ZW1wQXV0aENvb2tpZSA9ICc5ZFBZUDRpUkhLVGxtM3N5RTRpOWNXZk9lRnlySzhlRXhPTGpwRW5vbTF4Zm0ycVB0VjZBOE1EaXc2N25YWVNtMmt6bTNDMzE0JzsvL1RPRE8gVEVTVCBhdXRoQ29va2llXG4gICAgICAgICAgICAgICAgICAgIC8vIGxldCBhdXRoQ29va2llID0gcmVzICYmIHJlcy5hdXRoY29va2llID8gcmVzLmF1dGhjb29raWUgOiB0ZW1wQXV0aENvb2tpZTtcbiAgICAgICAgICAgICAgICAgICAgLy8gaHR0cDovL3dpa2kucWl5aS5kb21haW4vcGFnZXMvdmlld3BhZ2UuYWN0aW9uP3BhZ2VJZD0xNzYxNTIyNDUjaWQtJUU1JUE0JUE3JUU3JTlCJUI0JUU2JTkyJUFERWRnZSVFNiU4RSVBNSVFNSU4RiVBMyhWMSktMjAlRTQlQjglQUElRTQlQkElQkElRTQlQjglQUQlRTUlQkYlODNcblxuICAgICAgICAgICAgICAgICAgICBpZighcmVzLmlzTmV3dXNlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coYOiAgeeUqOaIt2ApO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coYOaIkeaYr+aWsOeUqOaIt2ApO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGxldCBhcHAgPSBnZXRBcHAoKTtcbiAgICAgICAgICAgICAgICAgICAgYXBwLmdsb2JhbERhdGEubmVlZExvZ2luID0gMTtcbiAgICAgICAgICAgICAgICAgICAgYXBwLmdsb2JhbERhdGEuYXV0aENvb2tpZSA9IHJlcyAmJiByZXMuYXV0aGNvb2tpZSB8fCAnJztcbiAgICAgICAgICAgICAgICAgICAgYXBwLmdsb2JhbERhdGEucGhvbmUgPSBwaG9uZTtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coYXBwLmdsb2JhbERhdGEpO1xuICAgICAgICAgICAgICAgICAgICAvLyBzd2FuLnN3aXRjaFRhYih7IHVybDogJy9wYWdlcy9teS9teScgfSk7Ly/ot7PovazliLDkuKrkurrpobXpnaIgP25lZWRMb2dpbj0xJmF1dGhDb29raWU9JHtyZXMgJiYgcmVzLmF1dGhjb29raWV9JmlzTmV3dXNlcj0ke3JlcyAmJiByZXMuaXNOZXd1c2VyfVxuICAgICAgICAgICAgICAgICAgICBfLmp1bXAoYHBhZ2VzL215L215YCk7XG5cbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBzd2FuLnNob3dUb2FzdCh7IHRpdGxlOiBgJHtkYXRhLm1zZ31gLCBpY29uOiAnbm9uZScgfSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGRhdGEubXNnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHN3YW4uaGlkZUxvYWRpbmcgJiYgc3dhbi5oaWRlTG9hZGluZygpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnZlcmlmeS5yZXF1ZXN0aW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfSwgMClcbiAgICAgICAgICAgIH0sIChlcnIpID0+IHtcbiAgICAgICAgICAgICAgICBpZihzd2FuLmhpZGVMb2FkaW5nKSB7XG4gICAgICAgICAgICAgICAgICAgIHN3YW4uaGlkZUxvYWRpbmcoKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICAgICAgICAgIGlmKGVyci5jb2RlID09PSAnRkVDMDAwJykge1xuICAgICAgICAgICAgICAgICAgICBzd2FuLnNob3dUb2FzdCh7IHRpdGxlOiBg572R57uc5byC5bi4YCwgaWNvbjogJ25vbmUnIH0pO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHN3YW4uc2hvd1RvYXN0KHsgdGl0bGU6IGVyci5tc2cgfHwgYOacjeWKoeW8guW4uGAsIGljb246ICdub25lJyB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGhpcy52ZXJpZnkucmVxdWVzdGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgfSBlbHNlIGlmKHJlcXVlc3RUeXBlID09IDI2KSB7XG4gICAgICAgICAgICBwaG9uZVNlcnZpY2UudmVyaWZ5UGhvbmVDb2RlSW5mbyhwYXJhbXMpLnRoZW4oKGRhdGEpID0+IHtcbiAgICAgICAgICAgICAgICBpZihzd2FuLmhpZGVMb2FkaW5nKSB7XG4gICAgICAgICAgICAgICAgICAgIHN3YW4uaGlkZUxvYWRpbmcoKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB0aGlzLnNldERhdGEoJ2luZm8ucGhvbmVjb2RlJywgJycpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YSgnaW5mby5vcmlnaW5jb2RlJywgJycpO1xuICAgICAgICAgICAgICAgIGlmKGRhdGEuY29kZSA9PT0gJ0EwMDAwMCcpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy52ZXJpZnlTdWNjZXNzSGFuZGxlKGRhdGEsIHZhbHVlKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBzd2FuLnNob3dUb2FzdCh7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogYCR7ZGF0YS5tc2d9YCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGljb246ICdub25lJ1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMudmVyaWZ5LnJlcXVlc3RpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB9LCAwKVxuICAgICAgICAgICAgfSwgKGVycm9yKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYoc3dhbi5oaWRlTG9hZGluZykge1xuICAgICAgICAgICAgICAgICAgICBzd2FuLmhpZGVMb2FkaW5nKClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgc3dhbi5zaG93VG9hc3Qoe1xuICAgICAgICAgICAgICAgICAgICB0aXRsZTogYOacjeWKoeW8guW4uGAsXG4gICAgICAgICAgICAgICAgICAgIGljb246ICdub25lJ1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHRoaXMudmVyaWZ5LnJlcXVlc3RpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0gZWxzZSBpZihyZXF1ZXN0VHlwZSA9PSAzMCkge1xuICAgICAgICAgICAgbGV0IGRldmljZUlkID0gdXNlci5nZXRBbm9ueW1vdXNVaWQoKTtcbiAgICAgICAgICAgIHBhcmFtcyA9IE9iamVjdC5hc3NpZ24oe30sIHBhcmFtcywge1xuICAgICAgICAgICAgICAgIGRldmljZV9pZDogZGV2aWNlSWQsXG4gICAgICAgICAgICAgICAgYXV0aGNvb2tpZTogdGhpcy5hcHAuZ2xvYmFsRGF0YS5tdXRpQXV0aGNvb2tpZSxcbiAgICAgICAgICAgICAgICBjZWxscGhvbmVOdW1iZXI6IHJzYVV0aWwuUlNBRW5jcnlwdGlvbihwaG9uZSlcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICBpZihzd2FuLnNob3dMb2FkaW5nKSB7XG4gICAgICAgICAgICAgICAgc3dhbi5zaG93TG9hZGluZyh7XG4gICAgICAgICAgICAgICAgICAgIHRpdGxlOiAn5Yqg6L295LitJ1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy52ZXJpZnlMb2dpbihwYXJhbXMpLnRoZW4oKGRhdGEgPSB7fSkgPT4ge1xuICAgICAgICAgICAgICAgIGxldCBhdXRoY29va2llID0gXy5pc09iamVjdChkYXRhKSA/IGRhdGEuYXV0aGNvb2tpZSA6ICcnO1xuICAgICAgICAgICAgICAgIGxldCBuaWNrbmFtZSA9IF8uaXNPYmplY3QoZGF0YSkgPyAoZGF0YS5uaWNrbmFtZSA/IGRhdGEubmlja25hbWUgOiAnJykgOiAnJztcbiAgICAgICAgICAgICAgICBpZihzd2FuLmhpZGVMb2FkaW5nKSB7XG4gICAgICAgICAgICAgICAgICAgIHN3YW4uaGlkZUxvYWRpbmcoKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvL+abtOaWsGF1dGhjb29raWVcbiAgICAgICAgICAgICAgICBzZXNzaW9uLlNlc3Npb24uc2V0KHNlc3Npb24uU0VTU0lPTl9BVVRIX0tFWSwgYXV0aGNvb2tpZSlcbiAgICAgICAgICAgICAgICB0aGlzLm11dGlWZXJpZnlGbGFnID0gdHJ1ZTtcblxuICAgICAgICAgICAgICAgIGdldEFwcCgpLmVtaXR0ZXIuZW1pdCgnaGlkZU11dGlEaWFsb2cnKVxuICAgICAgICAgICAgICAgIC8vdG9hc3Tmj5DnpLpcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dNdXRpQWNjb3VudFRvYXN0KCk7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgJ211dGlVc2VyTmFtZSc6IG5pY2tuYW1lXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICB0aGlzLnZlcmlmeS5yZXF1ZXN0aW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgLy/ov5Tlm57ljp/pobXpnaJcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcblxuICAgICAgICAgICAgICAgICAgICBzd2FuLm5hdmlnYXRlQmFjayh7XG4gICAgICAgICAgICAgICAgICAgICAgICBkZWx0YTogMlxuICAgICAgICAgICAgICAgICAgICB9KVxuXG4gICAgICAgICAgICAgICAgfSwgMzAwMClcblxuICAgICAgICAgICAgfSkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMudmVyaWZ5LnJlcXVlc3RpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB0aGlzLnNldERhdGEoJ2luZm8ucGhvbmVjb2RlJywgJycpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YSgnaW5mby5vcmlnaW5jb2RlJywgJycpO1xuICAgICAgICAgICAgICAgIGlmKHN3YW4uaGlkZUxvYWRpbmcpIHtcbiAgICAgICAgICAgICAgICAgICAgc3dhbi5oaWRlTG9hZGluZygpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8q5o+Q56S65paH5qGIKi9cbiAgICAgICAgICAgICAgICBsZXQgdG9hc3RNc2cgPSAn5YiH5o2i5aSx6LSl77yM6K+36YeN6K+VJztcbiAgICAgICAgICAgICAgICBpZihfLmlzT2JqZWN0KGVycikgJiYgKHR5cGVvZiBlcnIuY29kZSA9PSAnc3RyaW5nJykgJiYgKGVyci5jb2RlLmluZGV4T2YoJ0ZFQycpID09IC0xKSkge1xuICAgICAgICAgICAgICAgICAgICB0b2FzdE1zZyA9IGVyci5tc2cgPyBlcnIubXNnIDogdG9hc3RNc2c7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHN3YW4uaGlkZVRvYXN0KCk7XG4gICAgICAgICAgICAgICAgc3dhbi5zaG93VG9hc3Qoe1xuICAgICAgICAgICAgICAgICAgICB0aXRsZTogdG9hc3RNc2csXG4gICAgICAgICAgICAgICAgICAgIGljb246ICdub25lJ1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgIH0sXG4gICAganVtcChldmVudCkge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgICAgICBjb25zdCB1cmwgPSB0YXJnZXQuZGF0YXNldC51cmw7XG4gICAgICAgIF8uanVtcCh1cmwpO1xuICAgIH1cbn1cblxuXG5QYWdlKE9iamVjdC5hc3NpZ24oe30sIHBhZ2UpKVxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAvVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9wYWdlcy9tZXNzYWdlQ29kZUlucHV0L21lc3NhZ2VDb2RlSW5wdXQuanMiXSwic291cmNlUm9vdCI6IiJ9