

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave '.swan' file compiled runtime js
 * @author houyu(houyu01@baidu.com)
 */
(function (global, san) {
    global.errorMsg = [];

    // 自定义模板区域

    var templateComponents = Object.assign({}, {});

    var param = {};
    var filterArr = JSON.parse('[]');

    function processTemplateModule(filterTemplateArrs, filterModule) {
        eval(filterModule);
        var modules = {};
        var templateFiltersObj = {};
        filterTemplateArrs && filterTemplateArrs.forEach(function (element) {
            var filterName = element.filterName,
                func = element.func,
                module = element.module;

            modules[module] = eval(module);
            templateFiltersObj[filterName] = function () {
                var _modules$module;

                return (_modules$module = modules[module])[func].apply(_modules$module, arguments);
            };
        });
        return templateFiltersObj;
    }

    try {

        filterArr && filterArr.forEach(function (item) {
            param[item.module] = eval(item.module);
        });

        var pageContent = '<view class="main"><view class="mesCode_top"><text class="message_tip">\u5DF2\u53D1\u9001\u77ED\u4FE1\u9A8C\u8BC1\u7801\u81F3\uFF1A</text><view class="user_phone_info"><text class="zone_code">+{{info.area_code}}</text><text >{{info.showPhone}}</text></view><view class="empty-line"></view><view class="input_box"><view class="wallets-password" on-bindtap="eventHappen(\'tap\', $event, \'set_Focus\', \'\', \'bind\')"><view class="input-content-wrap"><view class="input-password-wrap"><view class="password_dot"><i s-if="{{info.phonecode.length>=1}}">{{info.phonecode[0]}}</i></view><view class="password_dot"><i s-if="{{info.phonecode.length>=2}}">{{info.phonecode[1]}}</i></view><view class="password_dot"><i s-if="{{info.phonecode.length>=3}}">{{info.phonecode[2]}}</i></view><view class="password_dot"><i s-if="{{info.phonecode.length>=4}}">{{info.phonecode[3]}}</i></view><view class="password_dot"><i s-if="{{info.phonecode.length>=5}}">{{info.phonecode[4]}}</i></view><view class="password_dot"><i s-if="{{info.phonecode.length>=6}}">{{info.phonecode[5]}}</i></view></view></view><input value="{{info.origincode}}" class="input-content" type="number" focus="{{isFocus}}" maxlength="6" on-bindinput="eventHappen(\'input\', $event, \'set_phonecode\', \'\', \'bind\')" on-bindblur="eventHappen(\'blur\', $event, \'set_notFocus\', \'\', \'bind\')" /></view></view></view></view><view class="cover" s-if="{{bindinfo && bindinfo.name}}"></view><view class="phone_tips" s-if="{{bindinfo && bindinfo.name}}"><view class="tips_title">\u63D0\u793A</view><view class="tips_info"><text class="c-des">\u8BE5\u624B\u673A\u5DF2\u7ED1\u5B9A\u4E86{{bindinfo.name}}\uFF0C\u662F\u5426\u5C06\u767E\u5EA6\u8D26\u53F7\u5173\u8054\u6B64\u8D26\u53F7</text><view class="info-link"><text class="resend" on-bindtap="eventHappen(\'tap\', $event, \'bindLogin\', \'\', \'bind\')">\u5173\u8054\u5FAE\u4FE1\u53F7\u5E76\u767B\u5F55{{bindinfo.name}}\u8D26\u53F7</text></view><view class="tips_btn"><text class="c-btn-link c-btn-link-block" on-bindtap="eventHappen(\'tap\', $event, \'registLogin\', \'\', \'bind\')">\u53D6\u6D88</text></view></view></view><view class="tips-toast" hidden="{{!mutiToastFlag}}"><text class="tips-toast-content">\u4E0B\u6B21\u8BF7\u4F7F\u7528{{mutiUserName}}\u8D26\u53F7\u767B\u5F55</text></view>';

        // 新的渲染逻辑
        var renderPage = function renderPage(filters, modules) {
            var componentFactory = global.componentFactory;
            // 获取所有内置组件 + 自定义组件的fragment
            var componentFragments = componentFactory.getAllComponents();

            // 所有的自定义组件
            ;

            // 路径与该组件映射
            var customAbsolutePathMap = {};

            // 当前页面使用的自定义组件
            var pageUsingComponentMap = JSON.parse('{}');

            // 生成该页面引用的自定义组件
            var customComponents = Object.keys(pageUsingComponentMap).reduce(function (customComponents, customName) {
                customComponents[customName] = customAbsolutePathMap[pageUsingComponentMap[customName]];
                return customComponents;
            }, {});

            // 启动页面渲染逻辑
            global.pageRender(pageContent, templateComponents, customComponents, filters, modules);
        };

        // 兼容旧的swan-core
        var oldPatch = function oldPatch(PageComponent) {
            Object.assign(PageComponent.components, {});
            // 渲染整个页面的顶层组件，template会在编译时被替换为用户的swan模板

            var Index = function (_PageComponent) {
                _inherits(Index, _PageComponent);

                function Index(options) {
                    _classCallCheck(this, Index);

                    var _this = _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));

                    _this.components = PageComponent.components;
                    return _this;
                }

                return Index;
            }(PageComponent);
            // 初始化页面对象


            Index.template = '<swan-wrapper tabindex="-1">' + pageContent + '</swan-wrapper>';
            var index = new Index();
            // 调用页面对象的加载完成通知
            index.slaveLoaded();
            // 监听等待initData，进行渲染
            index.communicator.onMessage('initData', function (params) {
                // 根据master传递的data，设定初始数据，并进行渲染
                index.setInitData(params);
                // 真正的页面渲染，发生在initData之后
                index.attach(document.body);
            }, { listenPreviousEvent: true });
        };

        if (global.pageRender) {
            renderPage(filterArr, param);
        } else {
            oldPatch(window.PageComponent);
        }
    } catch (e) {
        global.errorMsg['execError'] = e;
        throw e;
    }
})(window, window.san);

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvbWVzc2FnZUNvZGVJbnB1dC9tZXNzYWdlQ29kZUlucHV0LnN3YW4iXSwibmFtZXMiOlsiZ2xvYmFsIiwic2FuIiwiZXJyb3JNc2ciLCJ0ZW1wbGF0ZUNvbXBvbmVudHMiLCJPYmplY3QiLCJhc3NpZ24iLCJwYXJhbSIsImZpbHRlckFyciIsIkpTT04iLCJwYXJzZSIsInByb2Nlc3NUZW1wbGF0ZU1vZHVsZSIsImZpbHRlclRlbXBsYXRlQXJycyIsImZpbHRlck1vZHVsZSIsImV2YWwiLCJtb2R1bGVzIiwidGVtcGxhdGVGaWx0ZXJzT2JqIiwiZm9yRWFjaCIsImZpbHRlck5hbWUiLCJlbGVtZW50IiwiZnVuYyIsIm1vZHVsZSIsIml0ZW0iLCJwYWdlQ29udGVudCIsInJlbmRlclBhZ2UiLCJmaWx0ZXJzIiwiY29tcG9uZW50RmFjdG9yeSIsImNvbXBvbmVudEZyYWdtZW50cyIsImdldEFsbENvbXBvbmVudHMiLCJjdXN0b21BYnNvbHV0ZVBhdGhNYXAiLCJwYWdlVXNpbmdDb21wb25lbnRNYXAiLCJjdXN0b21Db21wb25lbnRzIiwia2V5cyIsInJlZHVjZSIsImN1c3RvbU5hbWUiLCJwYWdlUmVuZGVyIiwib2xkUGF0Y2giLCJQYWdlQ29tcG9uZW50IiwiY29tcG9uZW50cyIsIkluZGV4Iiwib3B0aW9ucyIsInRlbXBsYXRlIiwiaW5kZXgiLCJzbGF2ZUxvYWRlZCIsImNvbW11bmljYXRvciIsIm9uTWVzc2FnZSIsInNldEluaXREYXRhIiwicGFyYW1zIiwiYXR0YWNoIiwiZG9jdW1lbnQiLCJib2R5IiwibGlzdGVuUHJldmlvdXNFdmVudCIsIndpbmRvdyIsImUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUE7Ozs7QUFJQSxDQUFDLFVBQUNBLE1BQUQsRUFBU0MsR0FBVCxFQUFnQjtBQUNiRCxXQUFPRSxRQUFQLEdBQWtCLEVBQWxCOztBQUVBOztBQUVBLFFBQU1DLHFCQUFxQkMsT0FBT0MsTUFBUCxDQUFjLEVBQWQsRUFBa0IsRUFBbEIsQ0FBM0I7O0FBRUEsUUFBSUMsUUFBUSxFQUFaO0FBQ0EsUUFBTUMsWUFBWUMsS0FBS0MsS0FBTCxDQUFXLElBQVgsQ0FBbEI7O0FBR0EsYUFBU0MscUJBQVQsQ0FBK0JDLGtCQUEvQixFQUFtREMsWUFBbkQsRUFBaUU7QUFDN0RDLGFBQUtELFlBQUw7QUFDQSxZQUFJRSxVQUFVLEVBQWQ7QUFDQSxZQUFJQyxxQkFBcUIsRUFBekI7QUFDQUosOEJBQXNCQSxtQkFBbUJLLE9BQW5CLENBQTJCLG1CQUFVO0FBQUEsZ0JBQ2xEQyxVQURrRCxHQUN0QkMsT0FEc0IsQ0FDbERELFVBRGtEO0FBQUEsZ0JBQ3RDRSxJQURzQyxHQUN0QkQsT0FEc0IsQ0FDdENDLElBRHNDO0FBQUEsZ0JBQ2hDQyxNQURnQyxHQUN0QkYsT0FEc0IsQ0FDaENFLE1BRGdDOztBQUV2RE4sb0JBQVFNLE1BQVIsSUFBa0JQLEtBQUtPLE1BQUwsQ0FBbEI7QUFDQUwsK0JBQW1CRSxVQUFuQixJQUFpQztBQUFBOztBQUFBLHVCQUFZLDJCQUFRRyxNQUFSLEdBQWdCRCxJQUFoQixtQ0FBWjtBQUFBLGFBQWpDO0FBQ0gsU0FKcUIsQ0FBdEI7QUFLQSxlQUFPSixrQkFBUDtBQUNIOztBQUVELFFBQUk7O0FBRUFSLHFCQUFhQSxVQUFVUyxPQUFWLENBQWtCLGdCQUFPO0FBQ2xDVixrQkFBTWUsS0FBS0QsTUFBWCxJQUFxQlAsS0FBS1EsS0FBS0QsTUFBVixDQUFyQjtBQUNILFNBRlksQ0FBYjs7QUFJQSxZQUFNRSx5d0VBQU47O0FBRUE7QUFDQSxZQUFNQyxhQUFhLFNBQWJBLFVBQWEsQ0FBQ0MsT0FBRCxFQUFVVixPQUFWLEVBQXFCO0FBQ3BDLGdCQUFNVyxtQkFBbUJ6QixPQUFPeUIsZ0JBQWhDO0FBQ0E7QUFDQSxnQkFBTUMscUJBQXFCRCxpQkFBaUJFLGdCQUFqQixFQUEzQjs7QUFFQTtBQUNBOztBQUVBO0FBQ0EsZ0JBQUlDLHdCQUF3QixFQUE1Qjs7QUFFQTtBQUNBLGdCQUFNQyx3QkFBd0JyQixLQUFLQyxLQUFMLE1BQTlCOztBQUVBO0FBQ0EsZ0JBQU1xQixtQkFBbUIxQixPQUFPMkIsSUFBUCxDQUFZRixxQkFBWixFQUFtQ0csTUFBbkMsQ0FBMEMsVUFBQ0YsZ0JBQUQsRUFBbUJHLFVBQW5CLEVBQWlDO0FBQ2hHSCxpQ0FBaUJHLFVBQWpCLElBQStCTCxzQkFBc0JDLHNCQUFzQkksVUFBdEIsQ0FBdEIsQ0FBL0I7QUFDQSx1QkFBT0gsZ0JBQVA7QUFDSCxhQUh3QixFQUd0QixFQUhzQixDQUF6Qjs7QUFLQTtBQUNBOUIsbUJBQU9rQyxVQUFQLENBQWtCWixXQUFsQixFQUErQm5CLGtCQUEvQixFQUFtRDJCLGdCQUFuRCxFQUFxRU4sT0FBckUsRUFBOEVWLE9BQTlFO0FBQ0gsU0F0QkQ7O0FBd0JBO0FBQ0EsWUFBTXFCLFdBQVcsU0FBWEEsUUFBVyxnQkFBZ0I7QUFDN0IvQixtQkFBT0MsTUFBUCxDQUFjK0IsY0FBY0MsVUFBNUIsRUFBd0MsRUFBeEM7QUFDQTs7QUFGNkIsZ0JBR3ZCQyxLQUh1QjtBQUFBOztBQUl6QiwrQkFBWUMsT0FBWixFQUFxQjtBQUFBOztBQUFBLDhIQUNYQSxPQURXOztBQUVqQiwwQkFBS0YsVUFBTCxHQUFrQkQsY0FBY0MsVUFBaEM7QUFGaUI7QUFHcEI7O0FBUHdCO0FBQUEsY0FHVEQsYUFIUztBQVU3Qjs7O0FBUE1FLGlCQUh1QixDQVFsQkUsUUFSa0Isb0NBUXdCbEIsV0FSeEI7QUFXN0IsZ0JBQU1tQixRQUFRLElBQUlILEtBQUosRUFBZDtBQUNBO0FBQ0FHLGtCQUFNQyxXQUFOO0FBQ0E7QUFDQUQsa0JBQU1FLFlBQU4sQ0FBbUJDLFNBQW5CLENBQTZCLFVBQTdCLEVBQXlDLGtCQUFTO0FBQzlDO0FBQ0FILHNCQUFNSSxXQUFOLENBQWtCQyxNQUFsQjtBQUNBO0FBQ0FMLHNCQUFNTSxNQUFOLENBQWFDLFNBQVNDLElBQXRCO0FBQ0gsYUFMRCxFQUtHLEVBQUNDLHFCQUFxQixJQUF0QixFQUxIO0FBTUgsU0FyQkQ7O0FBdUJBLFlBQUlsRCxPQUFPa0MsVUFBWCxFQUF1QjtBQUNuQlgsdUJBQVdoQixTQUFYLEVBQXNCRCxLQUF0QjtBQUNILFNBRkQsTUFHSztBQUNENkIscUJBQVNnQixPQUFPZixhQUFoQjtBQUNIO0FBQ0osS0EvREQsQ0FnRUEsT0FBT2dCLENBQVAsRUFBVTtBQUNOcEQsZUFBT0UsUUFBUCxDQUFnQixXQUFoQixJQUErQmtELENBQS9CO0FBQ0EsY0FBTUEsQ0FBTjtBQUNIO0FBQ0osQ0EzRkQsRUEyRkdELE1BM0ZILEVBMkZXQSxPQUFPbEQsR0EzRmxCLEUiLCJmaWxlIjoicGFnZXMvbWVzc2FnZUNvZGVJbnB1dC9tZXNzYWdlQ29kZUlucHV0LnN3YW4uanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBmaWxlIHN3YW4ncyBzbGF2ZSAnLnN3YW4nIGZpbGUgY29tcGlsZWQgcnVudGltZSBqc1xuICogQGF1dGhvciBob3V5dShob3V5dTAxQGJhaWR1LmNvbSlcbiAqL1xuKChnbG9iYWwsIHNhbikgPT57XG4gICAgZ2xvYmFsLmVycm9yTXNnID0gW107XG5cbiAgICAvLyDoh6rlrprkuYnmqKHmnb/ljLrln59cbiAgICBcbiAgICBjb25zdCB0ZW1wbGF0ZUNvbXBvbmVudHMgPSBPYmplY3QuYXNzaWduKHt9LCB7fSk7XG5cbiAgICBsZXQgcGFyYW0gPSB7fTtcbiAgICBjb25zdCBmaWx0ZXJBcnIgPSBKU09OLnBhcnNlKCdbXScpO1xuICAgIFxuXG4gICAgZnVuY3Rpb24gcHJvY2Vzc1RlbXBsYXRlTW9kdWxlKGZpbHRlclRlbXBsYXRlQXJycywgZmlsdGVyTW9kdWxlKSB7XG4gICAgICAgIGV2YWwoZmlsdGVyTW9kdWxlKTtcbiAgICAgICAgbGV0IG1vZHVsZXMgPSB7fTtcbiAgICAgICAgbGV0IHRlbXBsYXRlRmlsdGVyc09iaiA9IHt9O1xuICAgICAgICBmaWx0ZXJUZW1wbGF0ZUFycnMgJiYgZmlsdGVyVGVtcGxhdGVBcnJzLmZvckVhY2goZWxlbWVudCA9PntcbiAgICAgICAgICAgIGxldCB7ZmlsdGVyTmFtZSwgZnVuYywgbW9kdWxlfSA9IGVsZW1lbnQ7XG4gICAgICAgICAgICBtb2R1bGVzW21vZHVsZV0gPSBldmFsKG1vZHVsZSk7XG4gICAgICAgICAgICB0ZW1wbGF0ZUZpbHRlcnNPYmpbZmlsdGVyTmFtZV0gPSAoLi4uYXJncykgPT5tb2R1bGVzW21vZHVsZV1bZnVuY10oLi4uYXJncyk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdGVtcGxhdGVGaWx0ZXJzT2JqO1xuICAgIH1cblxuICAgIHRyeSB7XG5cbiAgICAgICAgZmlsdGVyQXJyICYmIGZpbHRlckFyci5mb3JFYWNoKGl0ZW0gPT57XG4gICAgICAgICAgICBwYXJhbVtpdGVtLm1vZHVsZV0gPSBldmFsKGl0ZW0ubW9kdWxlKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3QgcGFnZUNvbnRlbnQgPSBgPHZpZXcgY2xhc3M9XCJtYWluXCI+PHZpZXcgY2xhc3M9XCJtZXNDb2RlX3RvcFwiPjx0ZXh0IGNsYXNzPVwibWVzc2FnZV90aXBcIj7lt7Llj5HpgIHnn63kv6Hpqozor4HnoIHoh7PvvJo8L3RleHQ+PHZpZXcgY2xhc3M9XCJ1c2VyX3Bob25lX2luZm9cIj48dGV4dCBjbGFzcz1cInpvbmVfY29kZVwiPit7e2luZm8uYXJlYV9jb2RlfX08L3RleHQ+PHRleHQgPnt7aW5mby5zaG93UGhvbmV9fTwvdGV4dD48L3ZpZXc+PHZpZXcgY2xhc3M9XCJlbXB0eS1saW5lXCI+PC92aWV3Pjx2aWV3IGNsYXNzPVwiaW5wdXRfYm94XCI+PHZpZXcgY2xhc3M9XCJ3YWxsZXRzLXBhc3N3b3JkXCIgb24tYmluZHRhcD1cImV2ZW50SGFwcGVuKCd0YXAnLCAkZXZlbnQsICdzZXRfRm9jdXMnLCAnJywgJ2JpbmQnKVwiPjx2aWV3IGNsYXNzPVwiaW5wdXQtY29udGVudC13cmFwXCI+PHZpZXcgY2xhc3M9XCJpbnB1dC1wYXNzd29yZC13cmFwXCI+PHZpZXcgY2xhc3M9XCJwYXNzd29yZF9kb3RcIj48aSBzLWlmPVwie3tpbmZvLnBob25lY29kZS5sZW5ndGg+PTF9fVwiPnt7aW5mby5waG9uZWNvZGVbMF19fTwvaT48L3ZpZXc+PHZpZXcgY2xhc3M9XCJwYXNzd29yZF9kb3RcIj48aSBzLWlmPVwie3tpbmZvLnBob25lY29kZS5sZW5ndGg+PTJ9fVwiPnt7aW5mby5waG9uZWNvZGVbMV19fTwvaT48L3ZpZXc+PHZpZXcgY2xhc3M9XCJwYXNzd29yZF9kb3RcIj48aSBzLWlmPVwie3tpbmZvLnBob25lY29kZS5sZW5ndGg+PTN9fVwiPnt7aW5mby5waG9uZWNvZGVbMl19fTwvaT48L3ZpZXc+PHZpZXcgY2xhc3M9XCJwYXNzd29yZF9kb3RcIj48aSBzLWlmPVwie3tpbmZvLnBob25lY29kZS5sZW5ndGg+PTR9fVwiPnt7aW5mby5waG9uZWNvZGVbM119fTwvaT48L3ZpZXc+PHZpZXcgY2xhc3M9XCJwYXNzd29yZF9kb3RcIj48aSBzLWlmPVwie3tpbmZvLnBob25lY29kZS5sZW5ndGg+PTV9fVwiPnt7aW5mby5waG9uZWNvZGVbNF19fTwvaT48L3ZpZXc+PHZpZXcgY2xhc3M9XCJwYXNzd29yZF9kb3RcIj48aSBzLWlmPVwie3tpbmZvLnBob25lY29kZS5sZW5ndGg+PTZ9fVwiPnt7aW5mby5waG9uZWNvZGVbNV19fTwvaT48L3ZpZXc+PC92aWV3Pjwvdmlldz48aW5wdXQgdmFsdWU9XCJ7e2luZm8ub3JpZ2luY29kZX19XCIgY2xhc3M9XCJpbnB1dC1jb250ZW50XCIgdHlwZT1cIm51bWJlclwiIGZvY3VzPVwie3tpc0ZvY3VzfX1cIiBtYXhsZW5ndGg9XCI2XCIgb24tYmluZGlucHV0PVwiZXZlbnRIYXBwZW4oJ2lucHV0JywgJGV2ZW50LCAnc2V0X3Bob25lY29kZScsICcnLCAnYmluZCcpXCIgb24tYmluZGJsdXI9XCJldmVudEhhcHBlbignYmx1cicsICRldmVudCwgJ3NldF9ub3RGb2N1cycsICcnLCAnYmluZCcpXCIgLz48L3ZpZXc+PC92aWV3Pjwvdmlldz48L3ZpZXc+PHZpZXcgY2xhc3M9XCJjb3ZlclwiIHMtaWY9XCJ7e2JpbmRpbmZvICYmIGJpbmRpbmZvLm5hbWV9fVwiPjwvdmlldz48dmlldyBjbGFzcz1cInBob25lX3RpcHNcIiBzLWlmPVwie3tiaW5kaW5mbyAmJiBiaW5kaW5mby5uYW1lfX1cIj48dmlldyBjbGFzcz1cInRpcHNfdGl0bGVcIj7mj5DnpLo8L3ZpZXc+PHZpZXcgY2xhc3M9XCJ0aXBzX2luZm9cIj48dGV4dCBjbGFzcz1cImMtZGVzXCI+6K+l5omL5py65bey57uR5a6a5LqGe3tiaW5kaW5mby5uYW1lfX3vvIzmmK/lkKblsIbnmb7luqbotKblj7flhbPogZTmraTotKblj7c8L3RleHQ+PHZpZXcgY2xhc3M9XCJpbmZvLWxpbmtcIj48dGV4dCBjbGFzcz1cInJlc2VuZFwiIG9uLWJpbmR0YXA9XCJldmVudEhhcHBlbigndGFwJywgJGV2ZW50LCAnYmluZExvZ2luJywgJycsICdiaW5kJylcIj7lhbPogZTlvq7kv6Hlj7flubbnmbvlvZV7e2JpbmRpbmZvLm5hbWV9fei0puWPtzwvdGV4dD48L3ZpZXc+PHZpZXcgY2xhc3M9XCJ0aXBzX2J0blwiPjx0ZXh0IGNsYXNzPVwiYy1idG4tbGluayBjLWJ0bi1saW5rLWJsb2NrXCIgb24tYmluZHRhcD1cImV2ZW50SGFwcGVuKCd0YXAnLCAkZXZlbnQsICdyZWdpc3RMb2dpbicsICcnLCAnYmluZCcpXCI+5Y+W5raIPC90ZXh0Pjwvdmlldz48L3ZpZXc+PC92aWV3Pjx2aWV3IGNsYXNzPVwidGlwcy10b2FzdFwiIGhpZGRlbj1cInt7IW11dGlUb2FzdEZsYWd9fVwiPjx0ZXh0IGNsYXNzPVwidGlwcy10b2FzdC1jb250ZW50XCI+5LiL5qyh6K+35L2/55Soe3ttdXRpVXNlck5hbWV9fei0puWPt+eZu+W9lTwvdGV4dD48L3ZpZXc+YDtcblxuICAgICAgICAvLyDmlrDnmoTmuLLmn5PpgLvovpFcbiAgICAgICAgY29uc3QgcmVuZGVyUGFnZSA9IChmaWx0ZXJzLCBtb2R1bGVzKSA9PntcbiAgICAgICAgICAgIGNvbnN0IGNvbXBvbmVudEZhY3RvcnkgPSBnbG9iYWwuY29tcG9uZW50RmFjdG9yeTtcbiAgICAgICAgICAgIC8vIOiOt+WPluaJgOacieWGhee9rue7hOS7tiArIOiHquWumuS5iee7hOS7tueahGZyYWdtZW50XG4gICAgICAgICAgICBjb25zdCBjb21wb25lbnRGcmFnbWVudHMgPSBjb21wb25lbnRGYWN0b3J5LmdldEFsbENvbXBvbmVudHMoKTtcblxuICAgICAgICAgICAgLy8g5omA5pyJ55qE6Ieq5a6a5LmJ57uE5Lu2XG4gICAgICAgICAgICA7XG5cbiAgICAgICAgICAgIC8vIOi3r+W+hOS4juivpee7hOS7tuaYoOWwhFxuICAgICAgICAgICAgdmFyIGN1c3RvbUFic29sdXRlUGF0aE1hcCA9IHt9O1xuXG4gICAgICAgICAgICAvLyDlvZPliY3pobXpnaLkvb/nlKjnmoToh6rlrprkuYnnu4Tku7ZcbiAgICAgICAgICAgIGNvbnN0IHBhZ2VVc2luZ0NvbXBvbmVudE1hcCA9IEpTT04ucGFyc2UoYHt9YCk7XG5cbiAgICAgICAgICAgIC8vIOeUn+aIkOivpemhtemdouW8leeUqOeahOiHquWumuS5iee7hOS7tlxuICAgICAgICAgICAgY29uc3QgY3VzdG9tQ29tcG9uZW50cyA9IE9iamVjdC5rZXlzKHBhZ2VVc2luZ0NvbXBvbmVudE1hcCkucmVkdWNlKChjdXN0b21Db21wb25lbnRzLCBjdXN0b21OYW1lKSA9PntcbiAgICAgICAgICAgICAgICBjdXN0b21Db21wb25lbnRzW2N1c3RvbU5hbWVdID0gY3VzdG9tQWJzb2x1dGVQYXRoTWFwW3BhZ2VVc2luZ0NvbXBvbmVudE1hcFtjdXN0b21OYW1lXV07XG4gICAgICAgICAgICAgICAgcmV0dXJuIGN1c3RvbUNvbXBvbmVudHM7XG4gICAgICAgICAgICB9LCB7fSk7XG5cbiAgICAgICAgICAgIC8vIOWQr+WKqOmhtemdoua4suafk+mAu+i+kVxuICAgICAgICAgICAgZ2xvYmFsLnBhZ2VSZW5kZXIocGFnZUNvbnRlbnQsIHRlbXBsYXRlQ29tcG9uZW50cywgY3VzdG9tQ29tcG9uZW50cywgZmlsdGVycywgbW9kdWxlcyk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8g5YW85a655pen55qEc3dhbi1jb3JlXG4gICAgICAgIGNvbnN0IG9sZFBhdGNoID0gUGFnZUNvbXBvbmVudCA9PntcbiAgICAgICAgICAgIE9iamVjdC5hc3NpZ24oUGFnZUNvbXBvbmVudC5jb21wb25lbnRzLCB7fSk7XG4gICAgICAgICAgICAvLyDmuLLmn5PmlbTkuKrpobXpnaLnmoTpobblsYLnu4Tku7bvvIx0ZW1wbGF0ZeS8muWcqOe8luivkeaXtuiiq+abv+aNouS4uueUqOaIt+eahHN3YW7mqKHmnb9cbiAgICAgICAgICAgIGNsYXNzIEluZGV4IGV4dGVuZHMgUGFnZUNvbXBvbmVudCB7XG4gICAgICAgICAgICAgICAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgICAgICAgICAgICAgICAgICBzdXBlcihvcHRpb25zKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jb21wb25lbnRzID0gUGFnZUNvbXBvbmVudC5jb21wb25lbnRzO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBzdGF0aWMgdGVtcGxhdGUgPSBgPHN3YW4td3JhcHBlciB0YWJpbmRleD1cIi0xXCI+JHtwYWdlQ29udGVudH08L3N3YW4td3JhcHBlcj5gO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8g5Yid5aeL5YyW6aG16Z2i5a+56LGhXG4gICAgICAgICAgICBjb25zdCBpbmRleCA9IG5ldyBJbmRleCgpO1xuICAgICAgICAgICAgLy8g6LCD55So6aG16Z2i5a+56LGh55qE5Yqg6L295a6M5oiQ6YCa55+lXG4gICAgICAgICAgICBpbmRleC5zbGF2ZUxvYWRlZCgpO1xuICAgICAgICAgICAgLy8g55uR5ZCs562J5b6FaW5pdERhdGHvvIzov5vooYzmuLLmn5NcbiAgICAgICAgICAgIGluZGV4LmNvbW11bmljYXRvci5vbk1lc3NhZ2UoJ2luaXREYXRhJywgcGFyYW1zID0+e1xuICAgICAgICAgICAgICAgIC8vIOagueaNrm1hc3RlcuS8oOmAkueahGRhdGHvvIzorr7lrprliJ3lp4vmlbDmja7vvIzlubbov5vooYzmuLLmn5NcbiAgICAgICAgICAgICAgICBpbmRleC5zZXRJbml0RGF0YShwYXJhbXMpO1xuICAgICAgICAgICAgICAgIC8vIOecn+ato+eahOmhtemdoua4suafk++8jOWPkeeUn+WcqGluaXREYXRh5LmL5ZCOXG4gICAgICAgICAgICAgICAgaW5kZXguYXR0YWNoKGRvY3VtZW50LmJvZHkpO1xuICAgICAgICAgICAgfSwge2xpc3RlblByZXZpb3VzRXZlbnQ6IHRydWV9KTtcbiAgICAgICAgfTtcblxuICAgICAgICBpZiAoZ2xvYmFsLnBhZ2VSZW5kZXIpIHtcbiAgICAgICAgICAgIHJlbmRlclBhZ2UoZmlsdGVyQXJyLCBwYXJhbSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBvbGRQYXRjaCh3aW5kb3cuUGFnZUNvbXBvbmVudCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgZ2xvYmFsLmVycm9yTXNnWydleGVjRXJyb3InXSA9IGU7XG4gICAgICAgIHRocm93IGU7XG4gICAgfVxufSkod2luZG93LCB3aW5kb3cuc2FuKTtcblxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAvVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9wYWdlcy9tZXNzYWdlQ29kZUlucHV0L21lc3NhZ2VDb2RlSW5wdXQuc3dhbiJdLCJzb3VyY2VSb290IjoiIn0=