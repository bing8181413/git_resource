window.define('126', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _user = __webpack_require__(29);

var _user2 = _interopRequireDefault(_user);

var _index = __webpack_require__(127);

var _index2 = _interopRequireDefault(_index);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var app = getApp();
var page = {
    data: {
        load: 'none',
        record: {
            edite: true,
            showDelete: true,
            total: 10,
            list: []
        }
    },
    onPullDownRefresh: function onPullDownRefresh() {
        // 下拉刷新
        this.onLoad();
    },
    onShow: function onShow() {
        this.loadPage();
    },
    onReady: function onReady() {},
    onLoad: function onLoad() {
        this.loadPage();
    },
    loadPage: function loadPage() {
        var _this = this;

        // _.record(this.data.records);
        _util2.default.record().then(function (data) {
            var formateRecord = _index2.default.getFormateRecord(data);
            _this.setData({ records: formateRecord });
            _this.setData({ 'record.list': data, 'record.total': data.length });
        });
    },
    _loadedPage: function _loadedPage(data) {
        _util2.default.seo(); //默认 SEO 
    },
    playVideo: function playVideo(event) {
        var target = event.currentTarget;
        var roomId = target.dataset.roomId;
        var liveType = target.dataset.liveType;
        if (!roomId) {
            swan.showToast({
                icon: 'none',
                title: '数据异常'
            });
            return false;
        }
        var url = "pages/w/room?roomId=" + roomId;
        if (liveType == 2) {
            url = "pages/s/room?roomId=" + roomId;
        }
        _util2.default.jump(url);
    }
};

Page(Object.assign({}, page));
});
window.__swanRoute='subPackage/pages/my/playLog';window.usingComponents=[];require('126');

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvc3ViUGFja2FnZS9wYWdlcy9teS9wbGF5TG9nLmpzIl0sIm5hbWVzIjpbImFwcCIsImdldEFwcCIsInBhZ2UiLCJkYXRhIiwibG9hZCIsInJlY29yZCIsImVkaXRlIiwic2hvd0RlbGV0ZSIsInRvdGFsIiwibGlzdCIsIm9uUHVsbERvd25SZWZyZXNoIiwib25Mb2FkIiwib25TaG93IiwibG9hZFBhZ2UiLCJvblJlYWR5IiwiXyIsInRoZW4iLCJmb3JtYXRlUmVjb3JkIiwiYWN0aW9ucyIsImdldEZvcm1hdGVSZWNvcmQiLCJzZXREYXRhIiwicmVjb3JkcyIsImxlbmd0aCIsIl9sb2FkZWRQYWdlIiwic2VvIiwicGxheVZpZGVvIiwiZXZlbnQiLCJ0YXJnZXQiLCJjdXJyZW50VGFyZ2V0Iiwicm9vbUlkIiwiZGF0YXNldCIsImxpdmVUeXBlIiwic3dhbiIsInNob3dUb2FzdCIsImljb24iLCJ0aXRsZSIsInVybCIsImp1bXAiLCJQYWdlIiwiT2JqZWN0IiwiYXNzaWduIl0sIm1hcHBpbmdzIjoiOzs7QUFBQTs7OztBQUNBOzs7O0FBQ0E7Ozs7OztBQUVBLElBQU1BLE1BQU1DLFFBQVo7QUFDQSxJQUFNQyxPQUFPO0FBQ1RDLFVBQU07QUFDRkMsY0FBTSxNQURKO0FBRUZDLGdCQUFRO0FBQ0pDLG1CQUFPLElBREg7QUFFSkMsd0JBQVksSUFGUjtBQUdKQyxtQkFBTyxFQUhIO0FBSUpDLGtCQUFNO0FBSkY7QUFGTixLQURHO0FBVVRDLHFCQVZTLCtCQVVXO0FBQ2hCO0FBQ0EsYUFBS0MsTUFBTDtBQUNILEtBYlE7QUFjVEMsVUFkUyxvQkFjQTtBQUNMLGFBQUtDLFFBQUw7QUFDSCxLQWhCUTtBQWlCVEMsV0FqQlMscUJBaUJDLENBQUUsQ0FqQkg7QUFrQlRILFVBbEJTLG9CQWtCQTtBQUNMLGFBQUtFLFFBQUw7QUFDSCxLQXBCUTtBQXFCVEEsWUFyQlMsc0JBcUJFO0FBQUE7O0FBQ1A7QUFDQUUsdUJBQUVWLE1BQUYsR0FBV1csSUFBWCxDQUFnQixVQUFDYixJQUFELEVBQVU7QUFDdEIsZ0JBQUljLGdCQUFnQkMsZ0JBQVFDLGdCQUFSLENBQXlCaEIsSUFBekIsQ0FBcEI7QUFDQSxrQkFBS2lCLE9BQUwsQ0FBYSxFQUFFQyxTQUFTSixhQUFYLEVBQWI7QUFDQSxrQkFBS0csT0FBTCxDQUFhLEVBQUUsZUFBZWpCLElBQWpCLEVBQXVCLGdCQUFnQkEsS0FBS21CLE1BQTVDLEVBQWI7QUFDSCxTQUpEO0FBS0gsS0E1QlE7QUE2QlRDLGVBN0JTLHVCQTZCR3BCLElBN0JILEVBNkJTO0FBQ2RZLHVCQUFFUyxHQUFGLEdBRGMsQ0FDTDtBQUNaLEtBL0JRO0FBZ0NUQyxhQWhDUyxxQkFnQ0NDLEtBaENELEVBZ0NRO0FBQ2IsWUFBTUMsU0FBU0QsTUFBTUUsYUFBckI7QUFDQSxZQUFNQyxTQUFTRixPQUFPRyxPQUFQLENBQWVELE1BQTlCO0FBQ0EsWUFBTUUsV0FBV0osT0FBT0csT0FBUCxDQUFlQyxRQUFoQztBQUNBLFlBQUksQ0FBQ0YsTUFBTCxFQUFhO0FBQ1RHLGlCQUFLQyxTQUFMLENBQWU7QUFDWEMsc0JBQU0sTUFESztBQUVYQyx1QkFBTztBQUZJLGFBQWY7QUFJQSxtQkFBTyxLQUFQO0FBQ0g7QUFDRCxZQUFJQywrQkFBNkJQLE1BQWpDO0FBQ0EsWUFBSUUsWUFBWSxDQUFoQixFQUFtQjtBQUNmSywyQ0FBNkJQLE1BQTdCO0FBQ0g7QUFDRGQsdUJBQUVzQixJQUFGLENBQU9ELEdBQVA7QUFDSDtBQWhEUSxDQUFiOztBQW9EQUUsS0FBS0MsT0FBT0MsTUFBUCxDQUFjLEVBQWQsRUFBa0J0QyxJQUFsQixDQUFMLEUiLCJmaWxlIjoic3ViUGFja2FnZS9wYWdlcy9teS9wbGF5TG9nLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHVzZXIgZnJvbSBcIi4uLy4uLy4uL2NvbW1vbi91c2VyL3VzZXJcIjtcbmltcG9ydCBhY3Rpb25zIGZyb20gXCIuL2FjdGlvbnMvaW5kZXhcIjtcbmltcG9ydCBfIGZyb20gXCIuLi8uLi8uLi9jb21tb24vdXRpbHMvdXRpbFwiO1xuXG5jb25zdCBhcHAgPSBnZXRBcHAoKTtcbmNvbnN0IHBhZ2UgPSB7XG4gICAgZGF0YToge1xuICAgICAgICBsb2FkOiAnbm9uZScsXG4gICAgICAgIHJlY29yZDoge1xuICAgICAgICAgICAgZWRpdGU6IHRydWUsXG4gICAgICAgICAgICBzaG93RGVsZXRlOiB0cnVlLFxuICAgICAgICAgICAgdG90YWw6IDEwLFxuICAgICAgICAgICAgbGlzdDogW11cbiAgICAgICAgfSxcbiAgICB9LFxuICAgIG9uUHVsbERvd25SZWZyZXNoKCkge1xuICAgICAgICAvLyDkuIvmi4nliLfmlrBcbiAgICAgICAgdGhpcy5vbkxvYWQoKTtcbiAgICB9LFxuICAgIG9uU2hvdygpIHtcbiAgICAgICAgdGhpcy5sb2FkUGFnZSgpO1xuICAgIH0sXG4gICAgb25SZWFkeSgpIHt9LFxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5sb2FkUGFnZSgpO1xuICAgIH0sXG4gICAgbG9hZFBhZ2UoKSB7XG4gICAgICAgIC8vIF8ucmVjb3JkKHRoaXMuZGF0YS5yZWNvcmRzKTtcbiAgICAgICAgXy5yZWNvcmQoKS50aGVuKChkYXRhKSA9PiB7XG4gICAgICAgICAgICBsZXQgZm9ybWF0ZVJlY29yZCA9IGFjdGlvbnMuZ2V0Rm9ybWF0ZVJlY29yZChkYXRhKTtcbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7IHJlY29yZHM6IGZvcm1hdGVSZWNvcmQgfSk7XG4gICAgICAgICAgICB0aGlzLnNldERhdGEoeyAncmVjb3JkLmxpc3QnOiBkYXRhLCAncmVjb3JkLnRvdGFsJzogZGF0YS5sZW5ndGggfSk7XG4gICAgICAgIH0pXG4gICAgfSxcbiAgICBfbG9hZGVkUGFnZShkYXRhKSB7XG4gICAgICAgIF8uc2VvKCk7IC8v6buY6K6kIFNFTyBcbiAgICB9LFxuICAgIHBsYXlWaWRlbyhldmVudCkge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgICAgICBjb25zdCByb29tSWQgPSB0YXJnZXQuZGF0YXNldC5yb29tSWQ7XG4gICAgICAgIGNvbnN0IGxpdmVUeXBlID0gdGFyZ2V0LmRhdGFzZXQubGl2ZVR5cGU7XG4gICAgICAgIGlmICghcm9vbUlkKSB7XG4gICAgICAgICAgICBzd2FuLnNob3dUb2FzdCh7XG4gICAgICAgICAgICAgICAgaWNvbjogJ25vbmUnLFxuICAgICAgICAgICAgICAgIHRpdGxlOiAn5pWw5o2u5byC5bi4J1xuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgdXJsID0gYHBhZ2VzL3cvcm9vbT9yb29tSWQ9JHtyb29tSWR9YDtcbiAgICAgICAgaWYgKGxpdmVUeXBlID09IDIpIHtcbiAgICAgICAgICAgIHVybCA9IGBwYWdlcy9zL3Jvb20/cm9vbUlkPSR7cm9vbUlkfWA7XG4gICAgICAgIH1cbiAgICAgICAgXy5qdW1wKHVybCk7XG4gICAgfSxcbn1cblxuXG5QYWdlKE9iamVjdC5hc3NpZ24oe30sIHBhZ2UpKVxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAvVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9zdWJQYWNrYWdlL3BhZ2VzL215L3BsYXlMb2cuanMiXSwic291cmNlUm9vdCI6IiJ9