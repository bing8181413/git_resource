

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave '.swan' file compiled runtime js
 * @author houyu(houyu01@baidu.com)
 */
(function (global, san) {
    global.errorMsg = [];

    // 自定义模板区域

    var templateComponents = Object.assign({}, {});

    var param = {};
    var filterArr = JSON.parse('[]');

    function processTemplateModule(filterTemplateArrs, filterModule) {
        eval(filterModule);
        var modules = {};
        var templateFiltersObj = {};
        filterTemplateArrs && filterTemplateArrs.forEach(function (element) {
            var filterName = element.filterName,
                func = element.func,
                module = element.module;

            modules[module] = eval(module);
            templateFiltersObj[filterName] = function () {
                var _modules$module;

                return (_modules$module = modules[module])[func].apply(_modules$module, arguments);
            };
        });
        return templateFiltersObj;
    }

    try {

        filterArr && filterArr.forEach(function (item) {
            param[item.module] = eval(item.module);
        });

        var pageContent = '<view class="container"><view class="t t-big">\u516C\u53F8\u4ECB\u7ECD</view><text class="c">\u7231\u5947\u827A\uFF0C\u4E2D\u56FD\u9AD8\u54C1\u8D28\u89C6\u9891\u5A31\u4E50\u670D\u52A1\u63D0\u4F9B\u8005\u30022010\u5E744\u670822\u65E5\u6B63\u5F0F\u4E0A\u7EBF\uFF0C\u79C9\u627F\u201C\u60A6\u4EAB\u54C1\u8D28\u201D\u7684\u54C1\u724C\u53E3\u53F7\uFF0C\u79EF\u6781\u63A8\u52A8\u4EA7\u54C1\u3001\u6280\u672F\u3001\u5185\u5BB9\u3001\u8425\u9500\u7B49\u5168\u65B9\u4F4D\u521B\u65B0\uFF0C\u4E3A\u7528\u6237\u63D0\u4F9B\u4E30\u5BCC\u3001\u9AD8\u6E05\u3001\u6D41\u7545\u7684\u4E13\u4E1A\u89C6\u9891\u4F53\u9A8C\uFF0C\u81F4\u529B\u4E8E\u8BA9\u4EBA\u4EEC\u5E73\u7B49\u3001\u4FBF\u6377\u5730\u83B7\u5F97\u66F4\u591A\u3001\u66F4\u597D\u7684\u89C6\u9891\u3002\u76EE\u524D\uFF0C\u7231\u5947\u827A\u5DF2\u6210\u529F\u6784\u5EFA\u4E86\u5305\u542B\u7535\u5546\u3001\u6E38\u620F\u3001\u7535\u5F71\u7968\u7B49\u4E1A\u52A1\u5728\u5185\u3001\u8FDE\u63A5\u4EBA\u4E0E\u670D\u52A1\u7684\u89C6\u9891\u5546\u4E1A\u751F\u6001\uFF0C\u5F15\u9886\u89C6\u9891\u7F51\u7AD9\u5546\u4E1A\u6A21\u5F0F\u7684\u591A\u5143\u5316\u53D1\u5C55\u3002\n    </text><text class="c">\u7231\u5947\u827A\u54C1\u8D28\u3001\u9752\u6625\u3001\u65F6\u5C1A\u7684\u54C1\u724C\u8C03\u6027\u6DF1\u5165\u4EBA\u5FC3\uFF0C\u7F51\u7F57\u4E86\u5168\u7403\u5E7F\u5927\u7684\u5E74\u8F7B\u7528\u6237\u7FA4\u4F53\u3002\u7231\u5947\u827A\u6253\u9020\u6DB5\u76D6\u7535\u5F71\u3001\u7535\u89C6\u5267\u3001\u7EFC\u827A\u3001\u52A8\u6F2B\u5728\u5185\u7684\u5341\u4F59\u79CD\u7C7B\u578B\u7684\u4E30\u5BCC\u7684\u6B63\u7248\u89C6\u9891\u5185\u5BB9\u5E93\uFF0C\u5E76\u901A\u8FC7\u201C\u7231\u5947\u827A\u51FA\u54C1\u201D\u6218\u7565\u7684\u6301\u7EED\u63A8\u52A8\uFF0C\u8BA9\u201C\u7EAF\u7F51\u5185\u5BB9\u201D\u8FDB\u5165\u771F\u6B63\u610F\u4E49\u4E0A\u7684\u5168\u7C7B\u522B\u3001\u9AD8\u54C1\u8D28\u65F6\u4EE3\u3002\u540C\u65F6\uFF0C\u4F5C\u4E3A\u62E5\u6709\u6D77\u91CF\u4ED8\u8D39\u7528\u6237\u7684\u89C6\u9891\u7F51\u7AD9\uFF0C\u7231\u5947\u827A\u5021\u5BFC\u201C\u8F7B\u5962\u65B0\u4E3B\u4E49\u201D\u7684VIP\u4F1A\u5458\u7406\u5FF5\uFF0C\u4E3B\u5F20\u4EBA\u4EEC\u5BF9\u9AD8\u54C1\u8D28\u751F\u6D3B\u7EC6\u8282\u7684\u8FFD\u6C42\uFF0C\u575A\u6301\u4E3A\u5E7F\u5927VIP\u4F1A\u5458\u63D0\u4F9B\u4E13\u5C5E\u7684\u6D77\u91CF\u7CBE\u54C1\u5185\u5BB9\uFF0C\u6781\u81F4\u7684\u89C6\u542C\u4F53\u9A8C\uFF0C\u4EE5\u53CA\u72EC\u6709\u7684\u7EBF\u4E0B\u4F1A\u5458\u670D\u52A1\u3002\n    </text><text class="c">2014\u5E74\uFF0C\u7231\u5947\u827A\u5728\u5168\u7403\u8303\u56F4\u5185\u5EFA\u7ACB\u8D77\u57FA\u4E8E\u641C\u7D22\u548C\u89C6\u9891\u6570\u636E\u7406\u89E3\u4EBA\u7C7B\u884C\u4E3A\u7684\u89C6\u9891\u5927\u8111\u2014\u2014\u7231\u5947\u827A\u5927\u8111\uFF0C\u7528\u5927\u6570\u636E\u6307\u5BFC\u5185\u5BB9\u7684\u5236\u4F5C\u3001\u751F\u4EA7\u3001\u8FD0\u8425\u3001\u6D88\u8D39\u3002\u5E76\u901A\u8FC7\u5F3A\u5927\u7684\u4E91\u8BA1\u7B97\u80FD\u529B\u3001\u5E26\u5BBD\u50A8\u5907\u4EE5\u53CA\u5168\u7403\u6027\u7684\u89C6\u9891\u5206\u53D1\u7F51\u7EDC\uFF0C\u4E3A\u7528\u6237\u63D0\u4F9B\u66F4\u597D\u7684\u89C6\u9891\u670D\u52A1\u3002\u5728\u6280\u672F\u4E0E\u5185\u5BB9\u53CC\u6838\u9A71\u52A8\u7684\u65B0\u4F53\u9A8C\u8425\u9500\u65F6\u4EE3\uFF0C\u7231\u5947\u827A\u521B\u9020\u6027\u5730\u63D0\u51FA\u4E86\u201CiJOY\u60A6\u4EAB\u8425\u9500\u201D\u5BA2\u6237\u670D\u52A1\u4EF7\u503C\u89C2\u548C\u65B9\u6CD5\u8BBA\u3002\u901A\u8FC7\u591A\u5C4F\u89E6\u70B9\u3001\u521B\u610F\u5185\u5BB9\u3001\u6280\u672F\u4F18\u5316\u3001\u4E92\u52A8\u53C2\u4E0E\u3001\u5B9E\u73B0\u8D2D\u4E70\u7B49\u8DEF\u5F84\u5168\u9762\u63D0\u5347ROI\uFF0C\u8BA9\u5BA2\u6237\u4EAB\u53D7\u5230\u521B\u65B0\u8425\u9500\u5E26\u6765\u7684\u6210\u529F\u4E0E\u5FEB\u4E50\u3002\n    </text><text class="c">\u672A\u6765\uFF0C\u7231\u5947\u827A\u5C06\u5728\u591A\u5143\u5316\u7684\u5185\u5BB9\u50A8\u5907\u3001\u4E2A\u6027\u5316\u7684\u4EA7\u54C1\u4F53\u9A8C\u3001\u5B9A\u5236\u5316\u8425\u9500\u670D\u52A1\u9886\u57DF\u7EE7\u7EED\u53D1\u529B\uFF0C\u5F15\u9886\u89C6\u9891\u4F53\u9A8C\u9769\u547D\u3002\u4E0D\u65AD\u63D0\u5347\u8FDE\u63A5\u4EBA\u4E0E\u670D\u52A1\u7684\u80FD\u529B\uFF0C\u66F4\u597D\u7684\u6539\u53D8\u4EBA\u4EEC\u7684\u751F\u6D3B\u3002</text><view class="t">\u54C1\u724C\u53E3\u53F7</view><text class="c">\u60A6\u4EAB\u54C1\u8D28</text><view class="t">\u54C1\u724C\u5173\u952E\u8BCD</view><text class="c">\u54C1\u8D28 \u9752\u6625 \u65F6\u5C1A</text><view class="t">VIP\u4F1A\u5458\u7406\u5FF5</view><text class="c">\u8F7B\u5962\u65B0\u4E3B\u4E49\u2014\u20142015\u5E746\u670816\u65E5 \u5728\u201C\u4ED8\u8D39\u7684\u529B\u91CF\u201D\u7231\u5947\u827AVIP\u4F1A\u5458\u6218\u7565\u53D1\u5E03\u4F1A\u4E0A\uFF0C\u7231\u5947\u827A\u201C\u8F7B\u5962\u65B0\u4E3B\u4E49\u201D\u4F1A\u5458\u54C1\u724C\u53E3\u53F7\u6B63\u5F0F\u53D1\u5E03\u3002\u201C\u8F7B\u5962\u65B0\u4E3B\u4E49\u201D\u662F\u7231\u5947\u827A\u201C\u60A6\u4EAB\u54C1\u8D28\u201D\u54C1\u724C\u53E3\u53F7\u7684\u5EF6\u5C55\u3002 \u6211\u4EEC\u63A8\u5D07\u7CBE\u81F4\u800C\u5B9E\u7528\u7684\u751F\u6D3B\u6001\u5EA6\uFF0C\u5021\u5BFC\u683C\u8C03\u4E0E\u4E50\u8DA3\u7684\u53CC\u91CD\u8D28\u611F\u3002\u8F7B\u5962\u201C\u4E0E\u8D22\u5BCC\u591A\u5BE1\u3001\u5730\u4F4D\u9AD8\u4F4E\u201D\u65E0\u5173\uFF0C\u4EE3\u8868\u7740\u5BF9\u9AD8\u54C1\u8D28\u751F\u6D3B\u7EC6\u8282\u7684\u8FFD\u6C42\u3002</text><view class="t">\u4F01\u4E1A\u613F\u666F</view><text class="c">\u505A\u4E00\u5BB6\u4EE5\u79D1\u6280\u521B\u65B0\u4E3A\u9A71\u52A8\u7684\u4F1F\u5927\u5A31\u4E50\u516C\u53F8</text><view class="t">\u4F01\u4E1A\u6587\u5316</view><text class="c">\u7B80\u5355\u60F3 \u7B80\u5355\u505A</text><view style="display: block;margin-top: 6.666666666666667vw;"><image src="/assets/logo/logo_live.png" class="footer-logo" style="display:block;margin:auto;width: 27.866666666666667vw;height:6.266666666666667vw;" /></view><view class="version"><text class="t">\u7248\u672C\u53F7:{{version}}</text></view></view>';

        // 新的渲染逻辑
        var renderPage = function renderPage(filters, modules) {
            var componentFactory = global.componentFactory;
            // 获取所有内置组件 + 自定义组件的fragment
            var componentFragments = componentFactory.getAllComponents();

            // 所有的自定义组件
            ;

            // 路径与该组件映射
            var customAbsolutePathMap = {};

            // 当前页面使用的自定义组件
            var pageUsingComponentMap = JSON.parse('{}');

            // 生成该页面引用的自定义组件
            var customComponents = Object.keys(pageUsingComponentMap).reduce(function (customComponents, customName) {
                customComponents[customName] = customAbsolutePathMap[pageUsingComponentMap[customName]];
                return customComponents;
            }, {});

            // 启动页面渲染逻辑
            global.pageRender(pageContent, templateComponents, customComponents, filters, modules);
        };

        // 兼容旧的swan-core
        var oldPatch = function oldPatch(PageComponent) {
            Object.assign(PageComponent.components, {});
            // 渲染整个页面的顶层组件，template会在编译时被替换为用户的swan模板

            var Index = function (_PageComponent) {
                _inherits(Index, _PageComponent);

                function Index(options) {
                    _classCallCheck(this, Index);

                    var _this = _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));

                    _this.components = PageComponent.components;
                    return _this;
                }

                return Index;
            }(PageComponent);
            // 初始化页面对象


            Index.template = '<swan-wrapper tabindex="-1">' + pageContent + '</swan-wrapper>';
            var index = new Index();
            // 调用页面对象的加载完成通知
            index.slaveLoaded();
            // 监听等待initData，进行渲染
            index.communicator.onMessage('initData', function (params) {
                // 根据master传递的data，设定初始数据，并进行渲染
                index.setInitData(params);
                // 真正的页面渲染，发生在initData之后
                index.attach(document.body);
            }, { listenPreviousEvent: true });
        };

        if (global.pageRender) {
            renderPage(filterArr, param);
        } else {
            oldPatch(window.PageComponent);
        }
    } catch (e) {
        global.errorMsg['execError'] = e;
        throw e;
    }
})(window, window.san);

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvc3ViUGFja2FnZS9wYWdlcy9teS9hYm91dC5zd2FuIl0sIm5hbWVzIjpbImdsb2JhbCIsInNhbiIsImVycm9yTXNnIiwidGVtcGxhdGVDb21wb25lbnRzIiwiT2JqZWN0IiwiYXNzaWduIiwicGFyYW0iLCJmaWx0ZXJBcnIiLCJKU09OIiwicGFyc2UiLCJwcm9jZXNzVGVtcGxhdGVNb2R1bGUiLCJmaWx0ZXJUZW1wbGF0ZUFycnMiLCJmaWx0ZXJNb2R1bGUiLCJldmFsIiwibW9kdWxlcyIsInRlbXBsYXRlRmlsdGVyc09iaiIsImZvckVhY2giLCJmaWx0ZXJOYW1lIiwiZWxlbWVudCIsImZ1bmMiLCJtb2R1bGUiLCJpdGVtIiwicGFnZUNvbnRlbnQiLCJyZW5kZXJQYWdlIiwiZmlsdGVycyIsImNvbXBvbmVudEZhY3RvcnkiLCJjb21wb25lbnRGcmFnbWVudHMiLCJnZXRBbGxDb21wb25lbnRzIiwiY3VzdG9tQWJzb2x1dGVQYXRoTWFwIiwicGFnZVVzaW5nQ29tcG9uZW50TWFwIiwiY3VzdG9tQ29tcG9uZW50cyIsImtleXMiLCJyZWR1Y2UiLCJjdXN0b21OYW1lIiwicGFnZVJlbmRlciIsIm9sZFBhdGNoIiwiUGFnZUNvbXBvbmVudCIsImNvbXBvbmVudHMiLCJJbmRleCIsIm9wdGlvbnMiLCJ0ZW1wbGF0ZSIsImluZGV4Iiwic2xhdmVMb2FkZWQiLCJjb21tdW5pY2F0b3IiLCJvbk1lc3NhZ2UiLCJzZXRJbml0RGF0YSIsInBhcmFtcyIsImF0dGFjaCIsImRvY3VtZW50IiwiYm9keSIsImxpc3RlblByZXZpb3VzRXZlbnQiLCJ3aW5kb3ciLCJlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBOzs7O0FBSUEsQ0FBQyxVQUFDQSxNQUFELEVBQVNDLEdBQVQsRUFBZ0I7QUFDYkQsV0FBT0UsUUFBUCxHQUFrQixFQUFsQjs7QUFFQTs7QUFFQSxRQUFNQyxxQkFBcUJDLE9BQU9DLE1BQVAsQ0FBYyxFQUFkLEVBQWtCLEVBQWxCLENBQTNCOztBQUVBLFFBQUlDLFFBQVEsRUFBWjtBQUNBLFFBQU1DLFlBQVlDLEtBQUtDLEtBQUwsQ0FBVyxJQUFYLENBQWxCOztBQUdBLGFBQVNDLHFCQUFULENBQStCQyxrQkFBL0IsRUFBbURDLFlBQW5ELEVBQWlFO0FBQzdEQyxhQUFLRCxZQUFMO0FBQ0EsWUFBSUUsVUFBVSxFQUFkO0FBQ0EsWUFBSUMscUJBQXFCLEVBQXpCO0FBQ0FKLDhCQUFzQkEsbUJBQW1CSyxPQUFuQixDQUEyQixtQkFBVTtBQUFBLGdCQUNsREMsVUFEa0QsR0FDdEJDLE9BRHNCLENBQ2xERCxVQURrRDtBQUFBLGdCQUN0Q0UsSUFEc0MsR0FDdEJELE9BRHNCLENBQ3RDQyxJQURzQztBQUFBLGdCQUNoQ0MsTUFEZ0MsR0FDdEJGLE9BRHNCLENBQ2hDRSxNQURnQzs7QUFFdkROLG9CQUFRTSxNQUFSLElBQWtCUCxLQUFLTyxNQUFMLENBQWxCO0FBQ0FMLCtCQUFtQkUsVUFBbkIsSUFBaUM7QUFBQTs7QUFBQSx1QkFBWSwyQkFBUUcsTUFBUixHQUFnQkQsSUFBaEIsbUNBQVo7QUFBQSxhQUFqQztBQUNILFNBSnFCLENBQXRCO0FBS0EsZUFBT0osa0JBQVA7QUFDSDs7QUFFRCxRQUFJOztBQUVBUixxQkFBYUEsVUFBVVMsT0FBVixDQUFrQixnQkFBTztBQUNsQ1Ysa0JBQU1lLEtBQUtELE1BQVgsSUFBcUJQLEtBQUtRLEtBQUtELE1BQVYsQ0FBckI7QUFDSCxTQUZZLENBQWI7O0FBSUEsWUFBTUUsMnVMQUFOOztBQUtBO0FBQ0EsWUFBTUMsYUFBYSxTQUFiQSxVQUFhLENBQUNDLE9BQUQsRUFBVVYsT0FBVixFQUFxQjtBQUNwQyxnQkFBTVcsbUJBQW1CekIsT0FBT3lCLGdCQUFoQztBQUNBO0FBQ0EsZ0JBQU1DLHFCQUFxQkQsaUJBQWlCRSxnQkFBakIsRUFBM0I7O0FBRUE7QUFDQTs7QUFFQTtBQUNBLGdCQUFJQyx3QkFBd0IsRUFBNUI7O0FBRUE7QUFDQSxnQkFBTUMsd0JBQXdCckIsS0FBS0MsS0FBTCxNQUE5Qjs7QUFFQTtBQUNBLGdCQUFNcUIsbUJBQW1CMUIsT0FBTzJCLElBQVAsQ0FBWUYscUJBQVosRUFBbUNHLE1BQW5DLENBQTBDLFVBQUNGLGdCQUFELEVBQW1CRyxVQUFuQixFQUFpQztBQUNoR0gsaUNBQWlCRyxVQUFqQixJQUErQkwsc0JBQXNCQyxzQkFBc0JJLFVBQXRCLENBQXRCLENBQS9CO0FBQ0EsdUJBQU9ILGdCQUFQO0FBQ0gsYUFId0IsRUFHdEIsRUFIc0IsQ0FBekI7O0FBS0E7QUFDQTlCLG1CQUFPa0MsVUFBUCxDQUFrQlosV0FBbEIsRUFBK0JuQixrQkFBL0IsRUFBbUQyQixnQkFBbkQsRUFBcUVOLE9BQXJFLEVBQThFVixPQUE5RTtBQUNILFNBdEJEOztBQXdCQTtBQUNBLFlBQU1xQixXQUFXLFNBQVhBLFFBQVcsZ0JBQWdCO0FBQzdCL0IsbUJBQU9DLE1BQVAsQ0FBYytCLGNBQWNDLFVBQTVCLEVBQXdDLEVBQXhDO0FBQ0E7O0FBRjZCLGdCQUd2QkMsS0FIdUI7QUFBQTs7QUFJekIsK0JBQVlDLE9BQVosRUFBcUI7QUFBQTs7QUFBQSw4SEFDWEEsT0FEVzs7QUFFakIsMEJBQUtGLFVBQUwsR0FBa0JELGNBQWNDLFVBQWhDO0FBRmlCO0FBR3BCOztBQVB3QjtBQUFBLGNBR1RELGFBSFM7QUFVN0I7OztBQVBNRSxpQkFIdUIsQ0FRbEJFLFFBUmtCLG9DQVF3QmxCLFdBUnhCO0FBVzdCLGdCQUFNbUIsUUFBUSxJQUFJSCxLQUFKLEVBQWQ7QUFDQTtBQUNBRyxrQkFBTUMsV0FBTjtBQUNBO0FBQ0FELGtCQUFNRSxZQUFOLENBQW1CQyxTQUFuQixDQUE2QixVQUE3QixFQUF5QyxrQkFBUztBQUM5QztBQUNBSCxzQkFBTUksV0FBTixDQUFrQkMsTUFBbEI7QUFDQTtBQUNBTCxzQkFBTU0sTUFBTixDQUFhQyxTQUFTQyxJQUF0QjtBQUNILGFBTEQsRUFLRyxFQUFDQyxxQkFBcUIsSUFBdEIsRUFMSDtBQU1ILFNBckJEOztBQXVCQSxZQUFJbEQsT0FBT2tDLFVBQVgsRUFBdUI7QUFDbkJYLHVCQUFXaEIsU0FBWCxFQUFzQkQsS0FBdEI7QUFDSCxTQUZELE1BR0s7QUFDRDZCLHFCQUFTZ0IsT0FBT2YsYUFBaEI7QUFDSDtBQUNKLEtBbEVELENBbUVBLE9BQU9nQixDQUFQLEVBQVU7QUFDTnBELGVBQU9FLFFBQVAsQ0FBZ0IsV0FBaEIsSUFBK0JrRCxDQUEvQjtBQUNBLGNBQU1BLENBQU47QUFDSDtBQUNKLENBOUZELEVBOEZHRCxNQTlGSCxFQThGV0EsT0FBT2xELEdBOUZsQixFIiwiZmlsZSI6InN1YlBhY2thZ2UvcGFnZXMvbXkvYWJvdXQuc3dhbi5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgc3dhbidzIHNsYXZlICcuc3dhbicgZmlsZSBjb21waWxlZCBydW50aW1lIGpzXG4gKiBAYXV0aG9yIGhvdXl1KGhvdXl1MDFAYmFpZHUuY29tKVxuICovXG4oKGdsb2JhbCwgc2FuKSA9PntcbiAgICBnbG9iYWwuZXJyb3JNc2cgPSBbXTtcblxuICAgIC8vIOiHquWumuS5ieaooeadv+WMuuWfn1xuICAgIFxuICAgIGNvbnN0IHRlbXBsYXRlQ29tcG9uZW50cyA9IE9iamVjdC5hc3NpZ24oe30sIHt9KTtcblxuICAgIGxldCBwYXJhbSA9IHt9O1xuICAgIGNvbnN0IGZpbHRlckFyciA9IEpTT04ucGFyc2UoJ1tdJyk7XG4gICAgXG5cbiAgICBmdW5jdGlvbiBwcm9jZXNzVGVtcGxhdGVNb2R1bGUoZmlsdGVyVGVtcGxhdGVBcnJzLCBmaWx0ZXJNb2R1bGUpIHtcbiAgICAgICAgZXZhbChmaWx0ZXJNb2R1bGUpO1xuICAgICAgICBsZXQgbW9kdWxlcyA9IHt9O1xuICAgICAgICBsZXQgdGVtcGxhdGVGaWx0ZXJzT2JqID0ge307XG4gICAgICAgIGZpbHRlclRlbXBsYXRlQXJycyAmJiBmaWx0ZXJUZW1wbGF0ZUFycnMuZm9yRWFjaChlbGVtZW50ID0+e1xuICAgICAgICAgICAgbGV0IHtmaWx0ZXJOYW1lLCBmdW5jLCBtb2R1bGV9ID0gZWxlbWVudDtcbiAgICAgICAgICAgIG1vZHVsZXNbbW9kdWxlXSA9IGV2YWwobW9kdWxlKTtcbiAgICAgICAgICAgIHRlbXBsYXRlRmlsdGVyc09ialtmaWx0ZXJOYW1lXSA9ICguLi5hcmdzKSA9Pm1vZHVsZXNbbW9kdWxlXVtmdW5jXSguLi5hcmdzKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB0ZW1wbGF0ZUZpbHRlcnNPYmo7XG4gICAgfVxuXG4gICAgdHJ5IHtcblxuICAgICAgICBmaWx0ZXJBcnIgJiYgZmlsdGVyQXJyLmZvckVhY2goaXRlbSA9PntcbiAgICAgICAgICAgIHBhcmFtW2l0ZW0ubW9kdWxlXSA9IGV2YWwoaXRlbS5tb2R1bGUpO1xuICAgICAgICB9KTtcblxuICAgICAgICBjb25zdCBwYWdlQ29udGVudCA9IGA8dmlldyBjbGFzcz1cImNvbnRhaW5lclwiPjx2aWV3IGNsYXNzPVwidCB0LWJpZ1wiPuWFrOWPuOS7i+e7jTwvdmlldz48dGV4dCBjbGFzcz1cImNcIj7niLHlpYfoibrvvIzkuK3lm73pq5jlk4HotKjop4bpopHlqLHkuZDmnI3liqHmj5DkvpvogIXjgIIyMDEw5bm0NOaciDIy5pel5q2j5byP5LiK57q/77yM56eJ5om/4oCc5oKm5Lqr5ZOB6LSo4oCd55qE5ZOB54mM5Y+j5Y+377yM56ev5p6B5o6o5Yqo5Lqn5ZOB44CB5oqA5pyv44CB5YaF5a6544CB6JCl6ZSA562J5YWo5pa55L2N5Yib5paw77yM5Li655So5oi35o+Q5L6b5Liw5a+M44CB6auY5riF44CB5rWB55WF55qE5LiT5Lia6KeG6aKR5L2T6aqM77yM6Ie05Yqb5LqO6K6p5Lq65Lus5bmz562J44CB5L6/5o235Zyw6I635b6X5pu05aSa44CB5pu05aW955qE6KeG6aKR44CC55uu5YmN77yM54ix5aWH6Im65bey5oiQ5Yqf5p6E5bu65LqG5YyF5ZCr55S15ZWG44CB5ri45oiP44CB55S15b2x56Wo562J5Lia5Yqh5Zyo5YaF44CB6L+e5o6l5Lq65LiO5pyN5Yqh55qE6KeG6aKR5ZWG5Lia55Sf5oCB77yM5byV6aKG6KeG6aKR572R56uZ5ZWG5Lia5qih5byP55qE5aSa5YWD5YyW5Y+R5bGV44CCXG4gICAgPC90ZXh0Pjx0ZXh0IGNsYXNzPVwiY1wiPueIseWlh+iJuuWTgei0qOOAgemdkuaYpeOAgeaXtuWwmueahOWTgeeJjOiwg+aAp+a3seWFpeS6uuW/g++8jOe9kee9l+S6huWFqOeQg+W5v+Wkp+eahOW5tOi9u+eUqOaIt+e+pOS9k+OAgueIseWlh+iJuuaJk+mAoOa2teeblueUteW9seOAgeeUteinhuWJp+OAgee7vOiJuuOAgeWKqOa8q+WcqOWGheeahOWNgeS9meenjeexu+Wei+eahOS4sOWvjOeahOato+eJiOinhumikeWGheWuueW6k++8jOW5tumAmui/h+KAnOeIseWlh+iJuuWHuuWTgeKAneaImOeVpeeahOaMgee7reaOqOWKqO+8jOiuqeKAnOe6r+e9keWGheWuueKAnei/m+WFpeecn+ato+aEj+S5ieS4iueahOWFqOexu+WIq+OAgemrmOWTgei0qOaXtuS7o+OAguWQjOaXtu+8jOS9nOS4uuaLpeaciea1t+mHj+S7mOi0ueeUqOaIt+eahOinhumikee9keerme+8jOeIseWlh+iJuuWAoeWvvOKAnOi9u+WlouaWsOS4u+S5ieKAneeahFZJUOS8muWRmOeQhuW/te+8jOS4u+W8oOS6uuS7rOWvuemrmOWTgei0qOeUn+a0u+e7huiKgueahOi/veaxgu+8jOWdmuaMgeS4uuW5v+Wkp1ZJUOS8muWRmOaPkOS+m+S4k+WxnueahOa1t+mHj+eyvuWTgeWGheWuue+8jOaegeiHtOeahOinhuWQrOS9k+mqjO+8jOS7peWPiueLrOacieeahOe6v+S4i+S8muWRmOacjeWKoeOAglxuICAgIDwvdGV4dD48dGV4dCBjbGFzcz1cImNcIj4yMDE05bm077yM54ix5aWH6Im65Zyo5YWo55CD6IyD5Zu05YaF5bu656uL6LW35Z+65LqO5pCc57Si5ZKM6KeG6aKR5pWw5o2u55CG6Kej5Lq657G76KGM5Li655qE6KeG6aKR5aSn6ISR4oCU4oCU54ix5aWH6Im65aSn6ISR77yM55So5aSn5pWw5o2u5oyH5a+85YaF5a6555qE5Yi25L2c44CB55Sf5Lqn44CB6L+Q6JCl44CB5raI6LS544CC5bm26YCa6L+H5by65aSn55qE5LqR6K6h566X6IO95Yqb44CB5bim5a695YKo5aSH5Lul5Y+K5YWo55CD5oCn55qE6KeG6aKR5YiG5Y+R572R57uc77yM5Li655So5oi35o+Q5L6b5pu05aW955qE6KeG6aKR5pyN5Yqh44CC5Zyo5oqA5pyv5LiO5YaF5a655Y+M5qC46amx5Yqo55qE5paw5L2T6aqM6JCl6ZSA5pe25Luj77yM54ix5aWH6Im65Yib6YCg5oCn5Zyw5o+Q5Ye65LqG4oCcaUpPWeaCpuS6q+iQpemUgOKAneWuouaIt+acjeWKoeS7t+WAvOinguWSjOaWueazleiuuuOAgumAmui/h+WkmuWxj+inpueCueOAgeWIm+aEj+WGheWuueOAgeaKgOacr+S8mOWMluOAgeS6kuWKqOWPguS4juOAgeWunueOsOi0reS5sOetiei3r+W+hOWFqOmdouaPkOWNh1JPSe+8jOiuqeWuouaIt+S6q+WPl+WIsOWIm+aWsOiQpemUgOW4puadpeeahOaIkOWKn+S4juW/q+S5kOOAglxuICAgIDwvdGV4dD48dGV4dCBjbGFzcz1cImNcIj7mnKrmnaXvvIzniLHlpYfoibrlsIblnKjlpJrlhYPljJbnmoTlhoXlrrnlgqjlpIfjgIHkuKrmgKfljJbnmoTkuqflk4HkvZPpqozjgIHlrprliLbljJbokKXplIDmnI3liqHpoobln5/nu6fnu63lj5HlipvvvIzlvJXpoobop4bpopHkvZPpqozpnanlkb3jgILkuI3mlq3mj5DljYfov57mjqXkurrkuI7mnI3liqHnmoTog73lipvvvIzmm7Tlpb3nmoTmlLnlj5jkurrku6znmoTnlJ/mtLvjgII8L3RleHQ+PHZpZXcgY2xhc3M9XCJ0XCI+5ZOB54mM5Y+j5Y+3PC92aWV3Pjx0ZXh0IGNsYXNzPVwiY1wiPuaCpuS6q+WTgei0qDwvdGV4dD48dmlldyBjbGFzcz1cInRcIj7lk4HniYzlhbPplK7or408L3ZpZXc+PHRleHQgY2xhc3M9XCJjXCI+5ZOB6LSoIOmdkuaYpSDml7blsJo8L3RleHQ+PHZpZXcgY2xhc3M9XCJ0XCI+VklQ5Lya5ZGY55CG5b+1PC92aWV3Pjx0ZXh0IGNsYXNzPVwiY1wiPui9u+WlouaWsOS4u+S5ieKAlOKAlDIwMTXlubQ25pyIMTbml6Ug5Zyo4oCc5LuY6LS555qE5Yqb6YeP4oCd54ix5aWH6Im6VklQ5Lya5ZGY5oiY55Wl5Y+R5biD5Lya5LiK77yM54ix5aWH6Im64oCc6L275aWi5paw5Li75LmJ4oCd5Lya5ZGY5ZOB54mM5Y+j5Y+35q2j5byP5Y+R5biD44CC4oCc6L275aWi5paw5Li75LmJ4oCd5piv54ix5aWH6Im64oCc5oKm5Lqr5ZOB6LSo4oCd5ZOB54mM5Y+j5Y+355qE5bu25bGV44CCIOaIkeS7rOaOqOW0h+eyvuiHtOiAjOWunueUqOeahOeUn+a0u+aAgeW6pu+8jOWAoeWvvOagvOiwg+S4juS5kOi2o+eahOWPjOmHjei0qOaEn+OAgui9u+WlouKAnOS4jui0ouWvjOWkmuWvoeOAgeWcsOS9jemrmOS9juKAneaXoOWFs++8jOS7o+ihqOedgOWvuemrmOWTgei0qOeUn+a0u+e7huiKgueahOi/veaxguOAgjwvdGV4dD48dmlldyBjbGFzcz1cInRcIj7kvIHkuJrmhL/mma88L3ZpZXc+PHRleHQgY2xhc3M9XCJjXCI+5YGa5LiA5a625Lul56eR5oqA5Yib5paw5Li66amx5Yqo55qE5Lyf5aSn5aix5LmQ5YWs5Y+4PC90ZXh0Pjx2aWV3IGNsYXNzPVwidFwiPuS8geS4muaWh+WMljwvdmlldz48dGV4dCBjbGFzcz1cImNcIj7nroDljZXmg7Mg566A5Y2V5YGaPC90ZXh0Pjx2aWV3IHN0eWxlPVwiZGlzcGxheTogYmxvY2s7bWFyZ2luLXRvcDogNi42NjY2NjY2NjY2NjY2Njd2dztcIj48aW1hZ2Ugc3JjPVwiL2Fzc2V0cy9sb2dvL2xvZ29fbGl2ZS5wbmdcIiBjbGFzcz1cImZvb3Rlci1sb2dvXCIgc3R5bGU9XCJkaXNwbGF5OmJsb2NrO21hcmdpbjphdXRvO3dpZHRoOiAyNy44NjY2NjY2NjY2NjY2Njd2dztoZWlnaHQ6Ni4yNjY2NjY2NjY2NjY2Njd2dztcIiAvPjwvdmlldz48dmlldyBjbGFzcz1cInZlcnNpb25cIj48dGV4dCBjbGFzcz1cInRcIj7niYjmnKzlj7c6e3t2ZXJzaW9ufX08L3RleHQ+PC92aWV3Pjwvdmlldz5gO1xuXG4gICAgICAgIC8vIOaWsOeahOa4suafk+mAu+i+kVxuICAgICAgICBjb25zdCByZW5kZXJQYWdlID0gKGZpbHRlcnMsIG1vZHVsZXMpID0+e1xuICAgICAgICAgICAgY29uc3QgY29tcG9uZW50RmFjdG9yeSA9IGdsb2JhbC5jb21wb25lbnRGYWN0b3J5O1xuICAgICAgICAgICAgLy8g6I635Y+W5omA5pyJ5YaF572u57uE5Lu2ICsg6Ieq5a6a5LmJ57uE5Lu255qEZnJhZ21lbnRcbiAgICAgICAgICAgIGNvbnN0IGNvbXBvbmVudEZyYWdtZW50cyA9IGNvbXBvbmVudEZhY3RvcnkuZ2V0QWxsQ29tcG9uZW50cygpO1xuXG4gICAgICAgICAgICAvLyDmiYDmnInnmoToh6rlrprkuYnnu4Tku7ZcbiAgICAgICAgICAgIDtcblxuICAgICAgICAgICAgLy8g6Lev5b6E5LiO6K+l57uE5Lu25pig5bCEXG4gICAgICAgICAgICB2YXIgY3VzdG9tQWJzb2x1dGVQYXRoTWFwID0ge307XG5cbiAgICAgICAgICAgIC8vIOW9k+WJjemhtemdouS9v+eUqOeahOiHquWumuS5iee7hOS7tlxuICAgICAgICAgICAgY29uc3QgcGFnZVVzaW5nQ29tcG9uZW50TWFwID0gSlNPTi5wYXJzZShge31gKTtcblxuICAgICAgICAgICAgLy8g55Sf5oiQ6K+l6aG16Z2i5byV55So55qE6Ieq5a6a5LmJ57uE5Lu2XG4gICAgICAgICAgICBjb25zdCBjdXN0b21Db21wb25lbnRzID0gT2JqZWN0LmtleXMocGFnZVVzaW5nQ29tcG9uZW50TWFwKS5yZWR1Y2UoKGN1c3RvbUNvbXBvbmVudHMsIGN1c3RvbU5hbWUpID0+e1xuICAgICAgICAgICAgICAgIGN1c3RvbUNvbXBvbmVudHNbY3VzdG9tTmFtZV0gPSBjdXN0b21BYnNvbHV0ZVBhdGhNYXBbcGFnZVVzaW5nQ29tcG9uZW50TWFwW2N1c3RvbU5hbWVdXTtcbiAgICAgICAgICAgICAgICByZXR1cm4gY3VzdG9tQ29tcG9uZW50cztcbiAgICAgICAgICAgIH0sIHt9KTtcblxuICAgICAgICAgICAgLy8g5ZCv5Yqo6aG16Z2i5riy5p+T6YC76L6RXG4gICAgICAgICAgICBnbG9iYWwucGFnZVJlbmRlcihwYWdlQ29udGVudCwgdGVtcGxhdGVDb21wb25lbnRzLCBjdXN0b21Db21wb25lbnRzLCBmaWx0ZXJzLCBtb2R1bGVzKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvLyDlhbzlrrnml6fnmoRzd2FuLWNvcmVcbiAgICAgICAgY29uc3Qgb2xkUGF0Y2ggPSBQYWdlQ29tcG9uZW50ID0+e1xuICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihQYWdlQ29tcG9uZW50LmNvbXBvbmVudHMsIHt9KTtcbiAgICAgICAgICAgIC8vIOa4suafk+aVtOS4qumhtemdoueahOmhtuWxgue7hOS7tu+8jHRlbXBsYXRl5Lya5Zyo57yW6K+R5pe26KKr5pu/5o2i5Li655So5oi355qEc3dhbuaooeadv1xuICAgICAgICAgICAgY2xhc3MgSW5kZXggZXh0ZW5kcyBQYWdlQ29tcG9uZW50IHtcbiAgICAgICAgICAgICAgICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgICAgICAgICAgICAgICAgIHN1cGVyKG9wdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbXBvbmVudHMgPSBQYWdlQ29tcG9uZW50LmNvbXBvbmVudHM7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHN0YXRpYyB0ZW1wbGF0ZSA9IGA8c3dhbi13cmFwcGVyIHRhYmluZGV4PVwiLTFcIj4ke3BhZ2VDb250ZW50fTwvc3dhbi13cmFwcGVyPmA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyDliJ3lp4vljJbpobXpnaLlr7nosaFcbiAgICAgICAgICAgIGNvbnN0IGluZGV4ID0gbmV3IEluZGV4KCk7XG4gICAgICAgICAgICAvLyDosIPnlKjpobXpnaLlr7nosaHnmoTliqDovb3lrozmiJDpgJrnn6VcbiAgICAgICAgICAgIGluZGV4LnNsYXZlTG9hZGVkKCk7XG4gICAgICAgICAgICAvLyDnm5HlkKznrYnlvoVpbml0RGF0Ye+8jOi/m+ihjOa4suafk1xuICAgICAgICAgICAgaW5kZXguY29tbXVuaWNhdG9yLm9uTWVzc2FnZSgnaW5pdERhdGEnLCBwYXJhbXMgPT57XG4gICAgICAgICAgICAgICAgLy8g5qC55o2ubWFzdGVy5Lyg6YCS55qEZGF0Ye+8jOiuvuWumuWIneWni+aVsOaNru+8jOW5tui/m+ihjOa4suafk1xuICAgICAgICAgICAgICAgIGluZGV4LnNldEluaXREYXRhKHBhcmFtcyk7XG4gICAgICAgICAgICAgICAgLy8g55yf5q2j55qE6aG16Z2i5riy5p+T77yM5Y+R55Sf5ZyoaW5pdERhdGHkuYvlkI5cbiAgICAgICAgICAgICAgICBpbmRleC5hdHRhY2goZG9jdW1lbnQuYm9keSk7XG4gICAgICAgICAgICB9LCB7bGlzdGVuUHJldmlvdXNFdmVudDogdHJ1ZX0pO1xuICAgICAgICB9O1xuXG4gICAgICAgIGlmIChnbG9iYWwucGFnZVJlbmRlcikge1xuICAgICAgICAgICAgcmVuZGVyUGFnZShmaWx0ZXJBcnIsIHBhcmFtKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIG9sZFBhdGNoKHdpbmRvdy5QYWdlQ29tcG9uZW50KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjYXRjaCAoZSkge1xuICAgICAgICBnbG9iYWwuZXJyb3JNc2dbJ2V4ZWNFcnJvciddID0gZTtcbiAgICAgICAgdGhyb3cgZTtcbiAgICB9XG59KSh3aW5kb3csIHdpbmRvdy5zYW4pO1xuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC9Vc2Vycy9ob3ViaW5nYmluZy9jb2RlL2lxaXlpL3FsaXZlX21pbmlwcm9ncmFtL2JhaWR1L3N1YlBhY2thZ2UvcGFnZXMvbXkvYWJvdXQuc3dhbiJdLCJzb3VyY2VSb290IjoiIn0=