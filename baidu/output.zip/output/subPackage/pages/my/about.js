window.define('128', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var app = getApp();
var page = {
    onShow: function onShow() {},
    onReady: function onReady() {},
    onLoad: function onLoad() {
        var version = app.globalData.version;
        this.setData('version', version);
    }
};

Page(Object.assign({}, page));
});
window.__swanRoute='subPackage/pages/my/about';window.usingComponents=[];require('128');

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvc3ViUGFja2FnZS9wYWdlcy9teS9hYm91dC5qcyJdLCJuYW1lcyI6WyJhcHAiLCJnZXRBcHAiLCJwYWdlIiwib25TaG93Iiwib25SZWFkeSIsIm9uTG9hZCIsInZlcnNpb24iLCJnbG9iYWxEYXRhIiwic2V0RGF0YSIsIlBhZ2UiLCJPYmplY3QiLCJhc3NpZ24iXSwibWFwcGluZ3MiOiI7OztBQUFBLElBQUlBLE1BQU1DLFFBQVY7QUFDQSxJQUFNQyxPQUFPO0FBQ1RDLFVBRFMsb0JBQ0EsQ0FBRSxDQURGO0FBRVRDLFdBRlMscUJBRUMsQ0FBRSxDQUZIO0FBR1RDLFVBSFMsb0JBR0E7QUFDTCxZQUFJQyxVQUFVTixJQUFJTyxVQUFKLENBQWVELE9BQTdCO0FBQ0EsYUFBS0UsT0FBTCxDQUFhLFNBQWIsRUFBdUJGLE9BQXZCO0FBQ0g7QUFOUSxDQUFiOztBQVNBRyxLQUFLQyxPQUFPQyxNQUFQLENBQWMsRUFBZCxFQUFrQlQsSUFBbEIsQ0FBTCxFIiwiZmlsZSI6InN1YlBhY2thZ2UvcGFnZXMvbXkvYWJvdXQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJsZXQgYXBwID0gZ2V0QXBwKCk7XG5jb25zdCBwYWdlID0ge1xuICAgIG9uU2hvdygpIHt9LFxuICAgIG9uUmVhZHkoKSB7fSxcbiAgICBvbkxvYWQoKSB7XG4gICAgICAgIGxldCB2ZXJzaW9uID0gYXBwLmdsb2JhbERhdGEudmVyc2lvbjtcbiAgICAgICAgdGhpcy5zZXREYXRhKCd2ZXJzaW9uJyx2ZXJzaW9uKTtcbiAgICB9LFxufVxuXG5QYWdlKE9iamVjdC5hc3NpZ24oe30sIHBhZ2UpKVxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAvVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9zdWJQYWNrYWdlL3BhZ2VzL215L2Fib3V0LmpzIl0sInNvdXJjZVJvb3QiOiIifQ==