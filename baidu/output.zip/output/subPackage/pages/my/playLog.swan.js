

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave '.swan' file compiled runtime js
 * @author houyu(houyu01@baidu.com)
 */
(function (global, san) {
    global.errorMsg = [];

    // 自定义模板区域

    var templateComponents = Object.assign({}, {});

    var param = {};
    var filterArr = JSON.parse('[]');

    function processTemplateModule(filterTemplateArrs, filterModule) {
        eval(filterModule);
        var modules = {};
        var templateFiltersObj = {};
        filterTemplateArrs && filterTemplateArrs.forEach(function (element) {
            var filterName = element.filterName,
                func = element.func,
                module = element.module;

            modules[module] = eval(module);
            templateFiltersObj[filterName] = function () {
                var _modules$module;

                return (_modules$module = modules[module])[func].apply(_modules$module, arguments);
            };
        });
        return templateFiltersObj;
    }

    try {

        filterArr && filterArr.forEach(function (item) {
            param[item.module] = eval(item.module);
        });

        var pageContent = '\n<view class="container page-home"><template s-for="item in records"><view s-if="item.list.length>0" class="m-list"><view class="m-title"><text class="m-title_h">{{item.title}}</text></view><view class="m-list-horizontal_content"><template s-for="roomObj in item.list"><view class="m-list-horizontal_item" data-room-id="{{roomObj.roomId}}" data-live-type="{{roomObj.liveType}}" on-bindtap="eventHappen(\'tap\', $event, \'playVideo\', \'\', \'catch\')"><view class="button-in-form" hover-class="none"><view class="m-list-horizontal_item-pic"><image src="{{roomObj.coverImageUrl}}" class="m-list_item-pic_image" width="124" height="165" mode="aspectFill" /><view class="m-list_c-rb"><view class="m-list_c-name text-ellips" s-if="roomObj.nickname">{{roomObj.nickname}}\n                </view><view class="m-list_c-date" s-if="roomObj.playNumber"><image src="/assets/common/c-icon-doubleMan.png" class="c-icon-doubleMan" />{{roomObj.playNumber}}\n                </view></view></view><view class="m-list-pic_sub"><text >{{roomObj.title}}</text></view></view></view></template></view></view></template><view class="m-box-cover" s-if="record.total == 0"><view class="m-tips"><image src="/assets/common/c-icon-tips.png" width="90" height="90" class="c-icon-tips" /><text class="m-tips_tx">\u4F60\u8FD8\u6CA1\u6709\u64AD\u653E\u8BB0\u5F55\u54E6</text></view></view><view style="display: block;margin-top: 6.666666666666667vw;margin-bottom:6.666666666666667vw;"><image src="/assets/logo/logo_live.png" class="footer-logo" style="display:block;margin:auto;width: 27.866666666666667vw;height:6.266666666666667vw;" /></view></view>';

        // 新的渲染逻辑
        var renderPage = function renderPage(filters, modules) {
            var componentFactory = global.componentFactory;
            // 获取所有内置组件 + 自定义组件的fragment
            var componentFragments = componentFactory.getAllComponents();

            // 所有的自定义组件
            ;

            // 路径与该组件映射
            var customAbsolutePathMap = {};

            // 当前页面使用的自定义组件
            var pageUsingComponentMap = JSON.parse('{}');

            // 生成该页面引用的自定义组件
            var customComponents = Object.keys(pageUsingComponentMap).reduce(function (customComponents, customName) {
                customComponents[customName] = customAbsolutePathMap[pageUsingComponentMap[customName]];
                return customComponents;
            }, {});

            // 启动页面渲染逻辑
            global.pageRender(pageContent, templateComponents, customComponents, filters, modules);
        };

        // 兼容旧的swan-core
        var oldPatch = function oldPatch(PageComponent) {
            Object.assign(PageComponent.components, {});
            // 渲染整个页面的顶层组件，template会在编译时被替换为用户的swan模板

            var Index = function (_PageComponent) {
                _inherits(Index, _PageComponent);

                function Index(options) {
                    _classCallCheck(this, Index);

                    var _this = _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));

                    _this.components = PageComponent.components;
                    return _this;
                }

                return Index;
            }(PageComponent);
            // 初始化页面对象


            Index.template = '<swan-wrapper tabindex="-1">' + pageContent + '</swan-wrapper>';
            var index = new Index();
            // 调用页面对象的加载完成通知
            index.slaveLoaded();
            // 监听等待initData，进行渲染
            index.communicator.onMessage('initData', function (params) {
                // 根据master传递的data，设定初始数据，并进行渲染
                index.setInitData(params);
                // 真正的页面渲染，发生在initData之后
                index.attach(document.body);
            }, { listenPreviousEvent: true });
        };

        if (global.pageRender) {
            renderPage(filterArr, param);
        } else {
            oldPatch(window.PageComponent);
        }
    } catch (e) {
        global.errorMsg['execError'] = e;
        throw e;
    }
})(window, window.san);

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvc3ViUGFja2FnZS9wYWdlcy9teS9wbGF5TG9nLnN3YW4iXSwibmFtZXMiOlsiZ2xvYmFsIiwic2FuIiwiZXJyb3JNc2ciLCJ0ZW1wbGF0ZUNvbXBvbmVudHMiLCJPYmplY3QiLCJhc3NpZ24iLCJwYXJhbSIsImZpbHRlckFyciIsIkpTT04iLCJwYXJzZSIsInByb2Nlc3NUZW1wbGF0ZU1vZHVsZSIsImZpbHRlclRlbXBsYXRlQXJycyIsImZpbHRlck1vZHVsZSIsImV2YWwiLCJtb2R1bGVzIiwidGVtcGxhdGVGaWx0ZXJzT2JqIiwiZm9yRWFjaCIsImZpbHRlck5hbWUiLCJlbGVtZW50IiwiZnVuYyIsIm1vZHVsZSIsIml0ZW0iLCJwYWdlQ29udGVudCIsInJlbmRlclBhZ2UiLCJmaWx0ZXJzIiwiY29tcG9uZW50RmFjdG9yeSIsImNvbXBvbmVudEZyYWdtZW50cyIsImdldEFsbENvbXBvbmVudHMiLCJjdXN0b21BYnNvbHV0ZVBhdGhNYXAiLCJwYWdlVXNpbmdDb21wb25lbnRNYXAiLCJjdXN0b21Db21wb25lbnRzIiwia2V5cyIsInJlZHVjZSIsImN1c3RvbU5hbWUiLCJwYWdlUmVuZGVyIiwib2xkUGF0Y2giLCJQYWdlQ29tcG9uZW50IiwiY29tcG9uZW50cyIsIkluZGV4Iiwib3B0aW9ucyIsInRlbXBsYXRlIiwiaW5kZXgiLCJzbGF2ZUxvYWRlZCIsImNvbW11bmljYXRvciIsIm9uTWVzc2FnZSIsInNldEluaXREYXRhIiwicGFyYW1zIiwiYXR0YWNoIiwiZG9jdW1lbnQiLCJib2R5IiwibGlzdGVuUHJldmlvdXNFdmVudCIsIndpbmRvdyIsImUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUE7Ozs7QUFJQSxDQUFDLFVBQUNBLE1BQUQsRUFBU0MsR0FBVCxFQUFnQjtBQUNiRCxXQUFPRSxRQUFQLEdBQWtCLEVBQWxCOztBQUVBOztBQUVBLFFBQU1DLHFCQUFxQkMsT0FBT0MsTUFBUCxDQUFjLEVBQWQsRUFBa0IsRUFBbEIsQ0FBM0I7O0FBRUEsUUFBSUMsUUFBUSxFQUFaO0FBQ0EsUUFBTUMsWUFBWUMsS0FBS0MsS0FBTCxDQUFXLElBQVgsQ0FBbEI7O0FBR0EsYUFBU0MscUJBQVQsQ0FBK0JDLGtCQUEvQixFQUFtREMsWUFBbkQsRUFBaUU7QUFDN0RDLGFBQUtELFlBQUw7QUFDQSxZQUFJRSxVQUFVLEVBQWQ7QUFDQSxZQUFJQyxxQkFBcUIsRUFBekI7QUFDQUosOEJBQXNCQSxtQkFBbUJLLE9BQW5CLENBQTJCLG1CQUFVO0FBQUEsZ0JBQ2xEQyxVQURrRCxHQUN0QkMsT0FEc0IsQ0FDbERELFVBRGtEO0FBQUEsZ0JBQ3RDRSxJQURzQyxHQUN0QkQsT0FEc0IsQ0FDdENDLElBRHNDO0FBQUEsZ0JBQ2hDQyxNQURnQyxHQUN0QkYsT0FEc0IsQ0FDaENFLE1BRGdDOztBQUV2RE4sb0JBQVFNLE1BQVIsSUFBa0JQLEtBQUtPLE1BQUwsQ0FBbEI7QUFDQUwsK0JBQW1CRSxVQUFuQixJQUFpQztBQUFBOztBQUFBLHVCQUFZLDJCQUFRRyxNQUFSLEdBQWdCRCxJQUFoQixtQ0FBWjtBQUFBLGFBQWpDO0FBQ0gsU0FKcUIsQ0FBdEI7QUFLQSxlQUFPSixrQkFBUDtBQUNIOztBQUVELFFBQUk7O0FBRUFSLHFCQUFhQSxVQUFVUyxPQUFWLENBQWtCLGdCQUFPO0FBQ2xDVixrQkFBTWUsS0FBS0QsTUFBWCxJQUFxQlAsS0FBS1EsS0FBS0QsTUFBVixDQUFyQjtBQUNILFNBRlksQ0FBYjs7QUFJQSxZQUFNRSxxbURBQU47O0FBS0E7QUFDQSxZQUFNQyxhQUFhLFNBQWJBLFVBQWEsQ0FBQ0MsT0FBRCxFQUFVVixPQUFWLEVBQXFCO0FBQ3BDLGdCQUFNVyxtQkFBbUJ6QixPQUFPeUIsZ0JBQWhDO0FBQ0E7QUFDQSxnQkFBTUMscUJBQXFCRCxpQkFBaUJFLGdCQUFqQixFQUEzQjs7QUFFQTtBQUNBOztBQUVBO0FBQ0EsZ0JBQUlDLHdCQUF3QixFQUE1Qjs7QUFFQTtBQUNBLGdCQUFNQyx3QkFBd0JyQixLQUFLQyxLQUFMLE1BQTlCOztBQUVBO0FBQ0EsZ0JBQU1xQixtQkFBbUIxQixPQUFPMkIsSUFBUCxDQUFZRixxQkFBWixFQUFtQ0csTUFBbkMsQ0FBMEMsVUFBQ0YsZ0JBQUQsRUFBbUJHLFVBQW5CLEVBQWlDO0FBQ2hHSCxpQ0FBaUJHLFVBQWpCLElBQStCTCxzQkFBc0JDLHNCQUFzQkksVUFBdEIsQ0FBdEIsQ0FBL0I7QUFDQSx1QkFBT0gsZ0JBQVA7QUFDSCxhQUh3QixFQUd0QixFQUhzQixDQUF6Qjs7QUFLQTtBQUNBOUIsbUJBQU9rQyxVQUFQLENBQWtCWixXQUFsQixFQUErQm5CLGtCQUEvQixFQUFtRDJCLGdCQUFuRCxFQUFxRU4sT0FBckUsRUFBOEVWLE9BQTlFO0FBQ0gsU0F0QkQ7O0FBd0JBO0FBQ0EsWUFBTXFCLFdBQVcsU0FBWEEsUUFBVyxnQkFBZ0I7QUFDN0IvQixtQkFBT0MsTUFBUCxDQUFjK0IsY0FBY0MsVUFBNUIsRUFBd0MsRUFBeEM7QUFDQTs7QUFGNkIsZ0JBR3ZCQyxLQUh1QjtBQUFBOztBQUl6QiwrQkFBWUMsT0FBWixFQUFxQjtBQUFBOztBQUFBLDhIQUNYQSxPQURXOztBQUVqQiwwQkFBS0YsVUFBTCxHQUFrQkQsY0FBY0MsVUFBaEM7QUFGaUI7QUFHcEI7O0FBUHdCO0FBQUEsY0FHVEQsYUFIUztBQVU3Qjs7O0FBUE1FLGlCQUh1QixDQVFsQkUsUUFSa0Isb0NBUXdCbEIsV0FSeEI7QUFXN0IsZ0JBQU1tQixRQUFRLElBQUlILEtBQUosRUFBZDtBQUNBO0FBQ0FHLGtCQUFNQyxXQUFOO0FBQ0E7QUFDQUQsa0JBQU1FLFlBQU4sQ0FBbUJDLFNBQW5CLENBQTZCLFVBQTdCLEVBQXlDLGtCQUFTO0FBQzlDO0FBQ0FILHNCQUFNSSxXQUFOLENBQWtCQyxNQUFsQjtBQUNBO0FBQ0FMLHNCQUFNTSxNQUFOLENBQWFDLFNBQVNDLElBQXRCO0FBQ0gsYUFMRCxFQUtHLEVBQUNDLHFCQUFxQixJQUF0QixFQUxIO0FBTUgsU0FyQkQ7O0FBdUJBLFlBQUlsRCxPQUFPa0MsVUFBWCxFQUF1QjtBQUNuQlgsdUJBQVdoQixTQUFYLEVBQXNCRCxLQUF0QjtBQUNILFNBRkQsTUFHSztBQUNENkIscUJBQVNnQixPQUFPZixhQUFoQjtBQUNIO0FBQ0osS0FsRUQsQ0FtRUEsT0FBT2dCLENBQVAsRUFBVTtBQUNOcEQsZUFBT0UsUUFBUCxDQUFnQixXQUFoQixJQUErQmtELENBQS9CO0FBQ0EsY0FBTUEsQ0FBTjtBQUNIO0FBQ0osQ0E5RkQsRUE4RkdELE1BOUZILEVBOEZXQSxPQUFPbEQsR0E5RmxCLEUiLCJmaWxlIjoic3ViUGFja2FnZS9wYWdlcy9teS9wbGF5TG9nLnN3YW4uanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBmaWxlIHN3YW4ncyBzbGF2ZSAnLnN3YW4nIGZpbGUgY29tcGlsZWQgcnVudGltZSBqc1xuICogQGF1dGhvciBob3V5dShob3V5dTAxQGJhaWR1LmNvbSlcbiAqL1xuKChnbG9iYWwsIHNhbikgPT57XG4gICAgZ2xvYmFsLmVycm9yTXNnID0gW107XG5cbiAgICAvLyDoh6rlrprkuYnmqKHmnb/ljLrln59cbiAgICBcbiAgICBjb25zdCB0ZW1wbGF0ZUNvbXBvbmVudHMgPSBPYmplY3QuYXNzaWduKHt9LCB7fSk7XG5cbiAgICBsZXQgcGFyYW0gPSB7fTtcbiAgICBjb25zdCBmaWx0ZXJBcnIgPSBKU09OLnBhcnNlKCdbXScpO1xuICAgIFxuXG4gICAgZnVuY3Rpb24gcHJvY2Vzc1RlbXBsYXRlTW9kdWxlKGZpbHRlclRlbXBsYXRlQXJycywgZmlsdGVyTW9kdWxlKSB7XG4gICAgICAgIGV2YWwoZmlsdGVyTW9kdWxlKTtcbiAgICAgICAgbGV0IG1vZHVsZXMgPSB7fTtcbiAgICAgICAgbGV0IHRlbXBsYXRlRmlsdGVyc09iaiA9IHt9O1xuICAgICAgICBmaWx0ZXJUZW1wbGF0ZUFycnMgJiYgZmlsdGVyVGVtcGxhdGVBcnJzLmZvckVhY2goZWxlbWVudCA9PntcbiAgICAgICAgICAgIGxldCB7ZmlsdGVyTmFtZSwgZnVuYywgbW9kdWxlfSA9IGVsZW1lbnQ7XG4gICAgICAgICAgICBtb2R1bGVzW21vZHVsZV0gPSBldmFsKG1vZHVsZSk7XG4gICAgICAgICAgICB0ZW1wbGF0ZUZpbHRlcnNPYmpbZmlsdGVyTmFtZV0gPSAoLi4uYXJncykgPT5tb2R1bGVzW21vZHVsZV1bZnVuY10oLi4uYXJncyk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdGVtcGxhdGVGaWx0ZXJzT2JqO1xuICAgIH1cblxuICAgIHRyeSB7XG5cbiAgICAgICAgZmlsdGVyQXJyICYmIGZpbHRlckFyci5mb3JFYWNoKGl0ZW0gPT57XG4gICAgICAgICAgICBwYXJhbVtpdGVtLm1vZHVsZV0gPSBldmFsKGl0ZW0ubW9kdWxlKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3QgcGFnZUNvbnRlbnQgPSBgXG48dmlldyBjbGFzcz1cImNvbnRhaW5lciBwYWdlLWhvbWVcIj48dGVtcGxhdGUgcy1mb3I9XCJpdGVtIGluIHJlY29yZHNcIj48dmlldyBzLWlmPVwiaXRlbS5saXN0Lmxlbmd0aD4wXCIgY2xhc3M9XCJtLWxpc3RcIj48dmlldyBjbGFzcz1cIm0tdGl0bGVcIj48dGV4dCBjbGFzcz1cIm0tdGl0bGVfaFwiPnt7aXRlbS50aXRsZX19PC90ZXh0Pjwvdmlldz48dmlldyBjbGFzcz1cIm0tbGlzdC1ob3Jpem9udGFsX2NvbnRlbnRcIj48dGVtcGxhdGUgcy1mb3I9XCJyb29tT2JqIGluIGl0ZW0ubGlzdFwiPjx2aWV3IGNsYXNzPVwibS1saXN0LWhvcml6b250YWxfaXRlbVwiIGRhdGEtcm9vbS1pZD1cInt7cm9vbU9iai5yb29tSWR9fVwiIGRhdGEtbGl2ZS10eXBlPVwie3tyb29tT2JqLmxpdmVUeXBlfX1cIiBvbi1iaW5kdGFwPVwiZXZlbnRIYXBwZW4oJ3RhcCcsICRldmVudCwgJ3BsYXlWaWRlbycsICcnLCAnY2F0Y2gnKVwiPjx2aWV3IGNsYXNzPVwiYnV0dG9uLWluLWZvcm1cIiBob3Zlci1jbGFzcz1cIm5vbmVcIj48dmlldyBjbGFzcz1cIm0tbGlzdC1ob3Jpem9udGFsX2l0ZW0tcGljXCI+PGltYWdlIHNyYz1cInt7cm9vbU9iai5jb3ZlckltYWdlVXJsfX1cIiBjbGFzcz1cIm0tbGlzdF9pdGVtLXBpY19pbWFnZVwiIHdpZHRoPVwiMTI0XCIgaGVpZ2h0PVwiMTY1XCIgbW9kZT1cImFzcGVjdEZpbGxcIiAvPjx2aWV3IGNsYXNzPVwibS1saXN0X2MtcmJcIj48dmlldyBjbGFzcz1cIm0tbGlzdF9jLW5hbWUgdGV4dC1lbGxpcHNcIiBzLWlmPVwicm9vbU9iai5uaWNrbmFtZVwiPnt7cm9vbU9iai5uaWNrbmFtZX19XG4gICAgICAgICAgICAgICAgPC92aWV3Pjx2aWV3IGNsYXNzPVwibS1saXN0X2MtZGF0ZVwiIHMtaWY9XCJyb29tT2JqLnBsYXlOdW1iZXJcIj48aW1hZ2Ugc3JjPVwiL2Fzc2V0cy9jb21tb24vYy1pY29uLWRvdWJsZU1hbi5wbmdcIiBjbGFzcz1cImMtaWNvbi1kb3VibGVNYW5cIiAvPnt7cm9vbU9iai5wbGF5TnVtYmVyfX1cbiAgICAgICAgICAgICAgICA8L3ZpZXc+PC92aWV3Pjwvdmlldz48dmlldyBjbGFzcz1cIm0tbGlzdC1waWNfc3ViXCI+PHRleHQgPnt7cm9vbU9iai50aXRsZX19PC90ZXh0Pjwvdmlldz48L3ZpZXc+PC92aWV3PjwvdGVtcGxhdGU+PC92aWV3Pjwvdmlldz48L3RlbXBsYXRlPjx2aWV3IGNsYXNzPVwibS1ib3gtY292ZXJcIiBzLWlmPVwicmVjb3JkLnRvdGFsID09IDBcIj48dmlldyBjbGFzcz1cIm0tdGlwc1wiPjxpbWFnZSBzcmM9XCIvYXNzZXRzL2NvbW1vbi9jLWljb24tdGlwcy5wbmdcIiB3aWR0aD1cIjkwXCIgaGVpZ2h0PVwiOTBcIiBjbGFzcz1cImMtaWNvbi10aXBzXCIgLz48dGV4dCBjbGFzcz1cIm0tdGlwc190eFwiPuS9oOi/mOayoeacieaSreaUvuiusOW9leWTpjwvdGV4dD48L3ZpZXc+PC92aWV3Pjx2aWV3IHN0eWxlPVwiZGlzcGxheTogYmxvY2s7bWFyZ2luLXRvcDogNi42NjY2NjY2NjY2NjY2Njd2dzttYXJnaW4tYm90dG9tOjYuNjY2NjY2NjY2NjY2NjY3dnc7XCI+PGltYWdlIHNyYz1cIi9hc3NldHMvbG9nby9sb2dvX2xpdmUucG5nXCIgY2xhc3M9XCJmb290ZXItbG9nb1wiIHN0eWxlPVwiZGlzcGxheTpibG9jazttYXJnaW46YXV0bzt3aWR0aDogMjcuODY2NjY2NjY2NjY2NjY3dnc7aGVpZ2h0OjYuMjY2NjY2NjY2NjY2NjY3dnc7XCIgLz48L3ZpZXc+PC92aWV3PmA7XG5cbiAgICAgICAgLy8g5paw55qE5riy5p+T6YC76L6RXG4gICAgICAgIGNvbnN0IHJlbmRlclBhZ2UgPSAoZmlsdGVycywgbW9kdWxlcykgPT57XG4gICAgICAgICAgICBjb25zdCBjb21wb25lbnRGYWN0b3J5ID0gZ2xvYmFsLmNvbXBvbmVudEZhY3Rvcnk7XG4gICAgICAgICAgICAvLyDojrflj5bmiYDmnInlhoXnva7nu4Tku7YgKyDoh6rlrprkuYnnu4Tku7bnmoRmcmFnbWVudFxuICAgICAgICAgICAgY29uc3QgY29tcG9uZW50RnJhZ21lbnRzID0gY29tcG9uZW50RmFjdG9yeS5nZXRBbGxDb21wb25lbnRzKCk7XG5cbiAgICAgICAgICAgIC8vIOaJgOacieeahOiHquWumuS5iee7hOS7tlxuICAgICAgICAgICAgO1xuXG4gICAgICAgICAgICAvLyDot6/lvoTkuI7or6Xnu4Tku7bmmKDlsIRcbiAgICAgICAgICAgIHZhciBjdXN0b21BYnNvbHV0ZVBhdGhNYXAgPSB7fTtcblxuICAgICAgICAgICAgLy8g5b2T5YmN6aG16Z2i5L2/55So55qE6Ieq5a6a5LmJ57uE5Lu2XG4gICAgICAgICAgICBjb25zdCBwYWdlVXNpbmdDb21wb25lbnRNYXAgPSBKU09OLnBhcnNlKGB7fWApO1xuXG4gICAgICAgICAgICAvLyDnlJ/miJDor6XpobXpnaLlvJXnlKjnmoToh6rlrprkuYnnu4Tku7ZcbiAgICAgICAgICAgIGNvbnN0IGN1c3RvbUNvbXBvbmVudHMgPSBPYmplY3Qua2V5cyhwYWdlVXNpbmdDb21wb25lbnRNYXApLnJlZHVjZSgoY3VzdG9tQ29tcG9uZW50cywgY3VzdG9tTmFtZSkgPT57XG4gICAgICAgICAgICAgICAgY3VzdG9tQ29tcG9uZW50c1tjdXN0b21OYW1lXSA9IGN1c3RvbUFic29sdXRlUGF0aE1hcFtwYWdlVXNpbmdDb21wb25lbnRNYXBbY3VzdG9tTmFtZV1dO1xuICAgICAgICAgICAgICAgIHJldHVybiBjdXN0b21Db21wb25lbnRzO1xuICAgICAgICAgICAgfSwge30pO1xuXG4gICAgICAgICAgICAvLyDlkK/liqjpobXpnaLmuLLmn5PpgLvovpFcbiAgICAgICAgICAgIGdsb2JhbC5wYWdlUmVuZGVyKHBhZ2VDb250ZW50LCB0ZW1wbGF0ZUNvbXBvbmVudHMsIGN1c3RvbUNvbXBvbmVudHMsIGZpbHRlcnMsIG1vZHVsZXMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8vIOWFvOWuueaXp+eahHN3YW4tY29yZVxuICAgICAgICBjb25zdCBvbGRQYXRjaCA9IFBhZ2VDb21wb25lbnQgPT57XG4gICAgICAgICAgICBPYmplY3QuYXNzaWduKFBhZ2VDb21wb25lbnQuY29tcG9uZW50cywge30pO1xuICAgICAgICAgICAgLy8g5riy5p+T5pW05Liq6aG16Z2i55qE6aG25bGC57uE5Lu277yMdGVtcGxhdGXkvJrlnKjnvJbor5Hml7booqvmm7/mjaLkuLrnlKjmiLfnmoRzd2Fu5qih5p2/XG4gICAgICAgICAgICBjbGFzcyBJbmRleCBleHRlbmRzIFBhZ2VDb21wb25lbnQge1xuICAgICAgICAgICAgICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICAgICAgICAgICAgICAgICAgc3VwZXIob3B0aW9ucyk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY29tcG9uZW50cyA9IFBhZ2VDb21wb25lbnQuY29tcG9uZW50cztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgc3RhdGljIHRlbXBsYXRlID0gYDxzd2FuLXdyYXBwZXIgdGFiaW5kZXg9XCItMVwiPiR7cGFnZUNvbnRlbnR9PC9zd2FuLXdyYXBwZXI+YDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIOWIneWni+WMlumhtemdouWvueixoVxuICAgICAgICAgICAgY29uc3QgaW5kZXggPSBuZXcgSW5kZXgoKTtcbiAgICAgICAgICAgIC8vIOiwg+eUqOmhtemdouWvueixoeeahOWKoOi9veWujOaIkOmAmuefpVxuICAgICAgICAgICAgaW5kZXguc2xhdmVMb2FkZWQoKTtcbiAgICAgICAgICAgIC8vIOebkeWQrOetieW+hWluaXREYXRh77yM6L+b6KGM5riy5p+TXG4gICAgICAgICAgICBpbmRleC5jb21tdW5pY2F0b3Iub25NZXNzYWdlKCdpbml0RGF0YScsIHBhcmFtcyA9PntcbiAgICAgICAgICAgICAgICAvLyDmoLnmja5tYXN0ZXLkvKDpgJLnmoRkYXRh77yM6K6+5a6a5Yid5aeL5pWw5o2u77yM5bm26L+b6KGM5riy5p+TXG4gICAgICAgICAgICAgICAgaW5kZXguc2V0SW5pdERhdGEocGFyYW1zKTtcbiAgICAgICAgICAgICAgICAvLyDnnJ/mraPnmoTpobXpnaLmuLLmn5PvvIzlj5HnlJ/lnKhpbml0RGF0YeS5i+WQjlxuICAgICAgICAgICAgICAgIGluZGV4LmF0dGFjaChkb2N1bWVudC5ib2R5KTtcbiAgICAgICAgICAgIH0sIHtsaXN0ZW5QcmV2aW91c0V2ZW50OiB0cnVlfSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgaWYgKGdsb2JhbC5wYWdlUmVuZGVyKSB7XG4gICAgICAgICAgICByZW5kZXJQYWdlKGZpbHRlckFyciwgcGFyYW0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgb2xkUGF0Y2god2luZG93LlBhZ2VDb21wb25lbnQpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIGdsb2JhbC5lcnJvck1zZ1snZXhlY0Vycm9yJ10gPSBlO1xuICAgICAgICB0aHJvdyBlO1xuICAgIH1cbn0pKHdpbmRvdywgd2luZG93LnNhbik7XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvc3ViUGFja2FnZS9wYWdlcy9teS9wbGF5TG9nLnN3YW4iXSwic291cmNlUm9vdCI6IiJ9