

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave '.swan' file compiled runtime js
 * @author houyu(houyu01@baidu.com)
 */
(function (global, san) {
    global.errorMsg = [];

    // 自定义模板区域

    var templateComponents = Object.assign({}, {});

    var param = {};
    var filterArr = JSON.parse('[]');

    function processTemplateModule(filterTemplateArrs, filterModule) {
        eval(filterModule);
        var modules = {};
        var templateFiltersObj = {};
        filterTemplateArrs && filterTemplateArrs.forEach(function (element) {
            var filterName = element.filterName,
                func = element.func,
                module = element.module;

            modules[module] = eval(module);
            templateFiltersObj[filterName] = function () {
                var _modules$module;

                return (_modules$module = modules[module])[func].apply(_modules$module, arguments);
            };
        });
        return templateFiltersObj;
    }

    try {

        filterArr && filterArr.forEach(function (item) {
            param[item.module] = eval(item.module);
        });

        var pageContent = '<web-view src="https://m-live.iqiyi.com/press/zt/ysxy.html"></web-view>';

        // 新的渲染逻辑
        var renderPage = function renderPage(filters, modules) {
            var componentFactory = global.componentFactory;
            // 获取所有内置组件 + 自定义组件的fragment
            var componentFragments = componentFactory.getAllComponents();

            // 所有的自定义组件
            ;

            // 路径与该组件映射
            var customAbsolutePathMap = {};

            // 当前页面使用的自定义组件
            var pageUsingComponentMap = JSON.parse('{}');

            // 生成该页面引用的自定义组件
            var customComponents = Object.keys(pageUsingComponentMap).reduce(function (customComponents, customName) {
                customComponents[customName] = customAbsolutePathMap[pageUsingComponentMap[customName]];
                return customComponents;
            }, {});

            // 启动页面渲染逻辑
            global.pageRender(pageContent, templateComponents, customComponents, filters, modules);
        };

        // 兼容旧的swan-core
        var oldPatch = function oldPatch(PageComponent) {
            Object.assign(PageComponent.components, {});
            // 渲染整个页面的顶层组件，template会在编译时被替换为用户的swan模板

            var Index = function (_PageComponent) {
                _inherits(Index, _PageComponent);

                function Index(options) {
                    _classCallCheck(this, Index);

                    var _this = _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));

                    _this.components = PageComponent.components;
                    return _this;
                }

                return Index;
            }(PageComponent);
            // 初始化页面对象


            Index.template = '<swan-wrapper tabindex="-1">' + pageContent + '</swan-wrapper>';
            var index = new Index();
            // 调用页面对象的加载完成通知
            index.slaveLoaded();
            // 监听等待initData，进行渲染
            index.communicator.onMessage('initData', function (params) {
                // 根据master传递的data，设定初始数据，并进行渲染
                index.setInitData(params);
                // 真正的页面渲染，发生在initData之后
                index.attach(document.body);
            }, { listenPreviousEvent: true });
        };

        if (global.pageRender) {
            renderPage(filterArr, param);
        } else {
            oldPatch(window.PageComponent);
        }
    } catch (e) {
        global.errorMsg['execError'] = e;
        throw e;
    }
})(window, window.san);

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvc3ViUGFja2FnZS9wYWdlcy9sb2dpbi9sb2dpblByb3RvY29sLnN3YW4iXSwibmFtZXMiOlsiZ2xvYmFsIiwic2FuIiwiZXJyb3JNc2ciLCJ0ZW1wbGF0ZUNvbXBvbmVudHMiLCJPYmplY3QiLCJhc3NpZ24iLCJwYXJhbSIsImZpbHRlckFyciIsIkpTT04iLCJwYXJzZSIsInByb2Nlc3NUZW1wbGF0ZU1vZHVsZSIsImZpbHRlclRlbXBsYXRlQXJycyIsImZpbHRlck1vZHVsZSIsImV2YWwiLCJtb2R1bGVzIiwidGVtcGxhdGVGaWx0ZXJzT2JqIiwiZm9yRWFjaCIsImZpbHRlck5hbWUiLCJlbGVtZW50IiwiZnVuYyIsIm1vZHVsZSIsIml0ZW0iLCJwYWdlQ29udGVudCIsInJlbmRlclBhZ2UiLCJmaWx0ZXJzIiwiY29tcG9uZW50RmFjdG9yeSIsImNvbXBvbmVudEZyYWdtZW50cyIsImdldEFsbENvbXBvbmVudHMiLCJjdXN0b21BYnNvbHV0ZVBhdGhNYXAiLCJwYWdlVXNpbmdDb21wb25lbnRNYXAiLCJjdXN0b21Db21wb25lbnRzIiwia2V5cyIsInJlZHVjZSIsImN1c3RvbU5hbWUiLCJwYWdlUmVuZGVyIiwib2xkUGF0Y2giLCJQYWdlQ29tcG9uZW50IiwiY29tcG9uZW50cyIsIkluZGV4Iiwib3B0aW9ucyIsInRlbXBsYXRlIiwiaW5kZXgiLCJzbGF2ZUxvYWRlZCIsImNvbW11bmljYXRvciIsIm9uTWVzc2FnZSIsInNldEluaXREYXRhIiwicGFyYW1zIiwiYXR0YWNoIiwiZG9jdW1lbnQiLCJib2R5IiwibGlzdGVuUHJldmlvdXNFdmVudCIsIndpbmRvdyIsImUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUE7Ozs7QUFJQSxDQUFDLFVBQUNBLE1BQUQsRUFBU0MsR0FBVCxFQUFnQjtBQUNiRCxXQUFPRSxRQUFQLEdBQWtCLEVBQWxCOztBQUVBOztBQUVBLFFBQU1DLHFCQUFxQkMsT0FBT0MsTUFBUCxDQUFjLEVBQWQsRUFBa0IsRUFBbEIsQ0FBM0I7O0FBRUEsUUFBSUMsUUFBUSxFQUFaO0FBQ0EsUUFBTUMsWUFBWUMsS0FBS0MsS0FBTCxDQUFXLElBQVgsQ0FBbEI7O0FBR0EsYUFBU0MscUJBQVQsQ0FBK0JDLGtCQUEvQixFQUFtREMsWUFBbkQsRUFBaUU7QUFDN0RDLGFBQUtELFlBQUw7QUFDQSxZQUFJRSxVQUFVLEVBQWQ7QUFDQSxZQUFJQyxxQkFBcUIsRUFBekI7QUFDQUosOEJBQXNCQSxtQkFBbUJLLE9BQW5CLENBQTJCLG1CQUFVO0FBQUEsZ0JBQ2xEQyxVQURrRCxHQUN0QkMsT0FEc0IsQ0FDbERELFVBRGtEO0FBQUEsZ0JBQ3RDRSxJQURzQyxHQUN0QkQsT0FEc0IsQ0FDdENDLElBRHNDO0FBQUEsZ0JBQ2hDQyxNQURnQyxHQUN0QkYsT0FEc0IsQ0FDaENFLE1BRGdDOztBQUV2RE4sb0JBQVFNLE1BQVIsSUFBa0JQLEtBQUtPLE1BQUwsQ0FBbEI7QUFDQUwsK0JBQW1CRSxVQUFuQixJQUFpQztBQUFBOztBQUFBLHVCQUFZLDJCQUFRRyxNQUFSLEdBQWdCRCxJQUFoQixtQ0FBWjtBQUFBLGFBQWpDO0FBQ0gsU0FKcUIsQ0FBdEI7QUFLQSxlQUFPSixrQkFBUDtBQUNIOztBQUVELFFBQUk7O0FBRUFSLHFCQUFhQSxVQUFVUyxPQUFWLENBQWtCLGdCQUFPO0FBQ2xDVixrQkFBTWUsS0FBS0QsTUFBWCxJQUFxQlAsS0FBS1EsS0FBS0QsTUFBVixDQUFyQjtBQUNILFNBRlksQ0FBYjs7QUFJQSxZQUFNRSx1RkFBTjs7QUFFQTtBQUNBLFlBQU1DLGFBQWEsU0FBYkEsVUFBYSxDQUFDQyxPQUFELEVBQVVWLE9BQVYsRUFBcUI7QUFDcEMsZ0JBQU1XLG1CQUFtQnpCLE9BQU95QixnQkFBaEM7QUFDQTtBQUNBLGdCQUFNQyxxQkFBcUJELGlCQUFpQkUsZ0JBQWpCLEVBQTNCOztBQUVBO0FBQ0E7O0FBRUE7QUFDQSxnQkFBSUMsd0JBQXdCLEVBQTVCOztBQUVBO0FBQ0EsZ0JBQU1DLHdCQUF3QnJCLEtBQUtDLEtBQUwsTUFBOUI7O0FBRUE7QUFDQSxnQkFBTXFCLG1CQUFtQjFCLE9BQU8yQixJQUFQLENBQVlGLHFCQUFaLEVBQW1DRyxNQUFuQyxDQUEwQyxVQUFDRixnQkFBRCxFQUFtQkcsVUFBbkIsRUFBaUM7QUFDaEdILGlDQUFpQkcsVUFBakIsSUFBK0JMLHNCQUFzQkMsc0JBQXNCSSxVQUF0QixDQUF0QixDQUEvQjtBQUNBLHVCQUFPSCxnQkFBUDtBQUNILGFBSHdCLEVBR3RCLEVBSHNCLENBQXpCOztBQUtBO0FBQ0E5QixtQkFBT2tDLFVBQVAsQ0FBa0JaLFdBQWxCLEVBQStCbkIsa0JBQS9CLEVBQW1EMkIsZ0JBQW5ELEVBQXFFTixPQUFyRSxFQUE4RVYsT0FBOUU7QUFDSCxTQXRCRDs7QUF3QkE7QUFDQSxZQUFNcUIsV0FBVyxTQUFYQSxRQUFXLGdCQUFnQjtBQUM3Qi9CLG1CQUFPQyxNQUFQLENBQWMrQixjQUFjQyxVQUE1QixFQUF3QyxFQUF4QztBQUNBOztBQUY2QixnQkFHdkJDLEtBSHVCO0FBQUE7O0FBSXpCLCtCQUFZQyxPQUFaLEVBQXFCO0FBQUE7O0FBQUEsOEhBQ1hBLE9BRFc7O0FBRWpCLDBCQUFLRixVQUFMLEdBQWtCRCxjQUFjQyxVQUFoQztBQUZpQjtBQUdwQjs7QUFQd0I7QUFBQSxjQUdURCxhQUhTO0FBVTdCOzs7QUFQTUUsaUJBSHVCLENBUWxCRSxRQVJrQixvQ0FRd0JsQixXQVJ4QjtBQVc3QixnQkFBTW1CLFFBQVEsSUFBSUgsS0FBSixFQUFkO0FBQ0E7QUFDQUcsa0JBQU1DLFdBQU47QUFDQTtBQUNBRCxrQkFBTUUsWUFBTixDQUFtQkMsU0FBbkIsQ0FBNkIsVUFBN0IsRUFBeUMsa0JBQVM7QUFDOUM7QUFDQUgsc0JBQU1JLFdBQU4sQ0FBa0JDLE1BQWxCO0FBQ0E7QUFDQUwsc0JBQU1NLE1BQU4sQ0FBYUMsU0FBU0MsSUFBdEI7QUFDSCxhQUxELEVBS0csRUFBQ0MscUJBQXFCLElBQXRCLEVBTEg7QUFNSCxTQXJCRDs7QUF1QkEsWUFBSWxELE9BQU9rQyxVQUFYLEVBQXVCO0FBQ25CWCx1QkFBV2hCLFNBQVgsRUFBc0JELEtBQXRCO0FBQ0gsU0FGRCxNQUdLO0FBQ0Q2QixxQkFBU2dCLE9BQU9mLGFBQWhCO0FBQ0g7QUFDSixLQS9ERCxDQWdFQSxPQUFPZ0IsQ0FBUCxFQUFVO0FBQ05wRCxlQUFPRSxRQUFQLENBQWdCLFdBQWhCLElBQStCa0QsQ0FBL0I7QUFDQSxjQUFNQSxDQUFOO0FBQ0g7QUFDSixDQTNGRCxFQTJGR0QsTUEzRkgsRUEyRldBLE9BQU9sRCxHQTNGbEIsRSIsImZpbGUiOiJzdWJQYWNrYWdlL3BhZ2VzL2xvZ2luL2xvZ2luUHJvdG9jb2wuc3dhbi5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgc3dhbidzIHNsYXZlICcuc3dhbicgZmlsZSBjb21waWxlZCBydW50aW1lIGpzXG4gKiBAYXV0aG9yIGhvdXl1KGhvdXl1MDFAYmFpZHUuY29tKVxuICovXG4oKGdsb2JhbCwgc2FuKSA9PntcbiAgICBnbG9iYWwuZXJyb3JNc2cgPSBbXTtcblxuICAgIC8vIOiHquWumuS5ieaooeadv+WMuuWfn1xuICAgIFxuICAgIGNvbnN0IHRlbXBsYXRlQ29tcG9uZW50cyA9IE9iamVjdC5hc3NpZ24oe30sIHt9KTtcblxuICAgIGxldCBwYXJhbSA9IHt9O1xuICAgIGNvbnN0IGZpbHRlckFyciA9IEpTT04ucGFyc2UoJ1tdJyk7XG4gICAgXG5cbiAgICBmdW5jdGlvbiBwcm9jZXNzVGVtcGxhdGVNb2R1bGUoZmlsdGVyVGVtcGxhdGVBcnJzLCBmaWx0ZXJNb2R1bGUpIHtcbiAgICAgICAgZXZhbChmaWx0ZXJNb2R1bGUpO1xuICAgICAgICBsZXQgbW9kdWxlcyA9IHt9O1xuICAgICAgICBsZXQgdGVtcGxhdGVGaWx0ZXJzT2JqID0ge307XG4gICAgICAgIGZpbHRlclRlbXBsYXRlQXJycyAmJiBmaWx0ZXJUZW1wbGF0ZUFycnMuZm9yRWFjaChlbGVtZW50ID0+e1xuICAgICAgICAgICAgbGV0IHtmaWx0ZXJOYW1lLCBmdW5jLCBtb2R1bGV9ID0gZWxlbWVudDtcbiAgICAgICAgICAgIG1vZHVsZXNbbW9kdWxlXSA9IGV2YWwobW9kdWxlKTtcbiAgICAgICAgICAgIHRlbXBsYXRlRmlsdGVyc09ialtmaWx0ZXJOYW1lXSA9ICguLi5hcmdzKSA9Pm1vZHVsZXNbbW9kdWxlXVtmdW5jXSguLi5hcmdzKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB0ZW1wbGF0ZUZpbHRlcnNPYmo7XG4gICAgfVxuXG4gICAgdHJ5IHtcblxuICAgICAgICBmaWx0ZXJBcnIgJiYgZmlsdGVyQXJyLmZvckVhY2goaXRlbSA9PntcbiAgICAgICAgICAgIHBhcmFtW2l0ZW0ubW9kdWxlXSA9IGV2YWwoaXRlbS5tb2R1bGUpO1xuICAgICAgICB9KTtcblxuICAgICAgICBjb25zdCBwYWdlQ29udGVudCA9IGA8d2ViLXZpZXcgc3JjPVwiaHR0cHM6Ly9tLWxpdmUuaXFpeWkuY29tL3ByZXNzL3p0L3lzeHkuaHRtbFwiPjwvd2ViLXZpZXc+YDtcblxuICAgICAgICAvLyDmlrDnmoTmuLLmn5PpgLvovpFcbiAgICAgICAgY29uc3QgcmVuZGVyUGFnZSA9IChmaWx0ZXJzLCBtb2R1bGVzKSA9PntcbiAgICAgICAgICAgIGNvbnN0IGNvbXBvbmVudEZhY3RvcnkgPSBnbG9iYWwuY29tcG9uZW50RmFjdG9yeTtcbiAgICAgICAgICAgIC8vIOiOt+WPluaJgOacieWGhee9rue7hOS7tiArIOiHquWumuS5iee7hOS7tueahGZyYWdtZW50XG4gICAgICAgICAgICBjb25zdCBjb21wb25lbnRGcmFnbWVudHMgPSBjb21wb25lbnRGYWN0b3J5LmdldEFsbENvbXBvbmVudHMoKTtcblxuICAgICAgICAgICAgLy8g5omA5pyJ55qE6Ieq5a6a5LmJ57uE5Lu2XG4gICAgICAgICAgICA7XG5cbiAgICAgICAgICAgIC8vIOi3r+W+hOS4juivpee7hOS7tuaYoOWwhFxuICAgICAgICAgICAgdmFyIGN1c3RvbUFic29sdXRlUGF0aE1hcCA9IHt9O1xuXG4gICAgICAgICAgICAvLyDlvZPliY3pobXpnaLkvb/nlKjnmoToh6rlrprkuYnnu4Tku7ZcbiAgICAgICAgICAgIGNvbnN0IHBhZ2VVc2luZ0NvbXBvbmVudE1hcCA9IEpTT04ucGFyc2UoYHt9YCk7XG5cbiAgICAgICAgICAgIC8vIOeUn+aIkOivpemhtemdouW8leeUqOeahOiHquWumuS5iee7hOS7tlxuICAgICAgICAgICAgY29uc3QgY3VzdG9tQ29tcG9uZW50cyA9IE9iamVjdC5rZXlzKHBhZ2VVc2luZ0NvbXBvbmVudE1hcCkucmVkdWNlKChjdXN0b21Db21wb25lbnRzLCBjdXN0b21OYW1lKSA9PntcbiAgICAgICAgICAgICAgICBjdXN0b21Db21wb25lbnRzW2N1c3RvbU5hbWVdID0gY3VzdG9tQWJzb2x1dGVQYXRoTWFwW3BhZ2VVc2luZ0NvbXBvbmVudE1hcFtjdXN0b21OYW1lXV07XG4gICAgICAgICAgICAgICAgcmV0dXJuIGN1c3RvbUNvbXBvbmVudHM7XG4gICAgICAgICAgICB9LCB7fSk7XG5cbiAgICAgICAgICAgIC8vIOWQr+WKqOmhtemdoua4suafk+mAu+i+kVxuICAgICAgICAgICAgZ2xvYmFsLnBhZ2VSZW5kZXIocGFnZUNvbnRlbnQsIHRlbXBsYXRlQ29tcG9uZW50cywgY3VzdG9tQ29tcG9uZW50cywgZmlsdGVycywgbW9kdWxlcyk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8g5YW85a655pen55qEc3dhbi1jb3JlXG4gICAgICAgIGNvbnN0IG9sZFBhdGNoID0gUGFnZUNvbXBvbmVudCA9PntcbiAgICAgICAgICAgIE9iamVjdC5hc3NpZ24oUGFnZUNvbXBvbmVudC5jb21wb25lbnRzLCB7fSk7XG4gICAgICAgICAgICAvLyDmuLLmn5PmlbTkuKrpobXpnaLnmoTpobblsYLnu4Tku7bvvIx0ZW1wbGF0ZeS8muWcqOe8luivkeaXtuiiq+abv+aNouS4uueUqOaIt+eahHN3YW7mqKHmnb9cbiAgICAgICAgICAgIGNsYXNzIEluZGV4IGV4dGVuZHMgUGFnZUNvbXBvbmVudCB7XG4gICAgICAgICAgICAgICAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgICAgICAgICAgICAgICAgICBzdXBlcihvcHRpb25zKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jb21wb25lbnRzID0gUGFnZUNvbXBvbmVudC5jb21wb25lbnRzO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBzdGF0aWMgdGVtcGxhdGUgPSBgPHN3YW4td3JhcHBlciB0YWJpbmRleD1cIi0xXCI+JHtwYWdlQ29udGVudH08L3N3YW4td3JhcHBlcj5gO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8g5Yid5aeL5YyW6aG16Z2i5a+56LGhXG4gICAgICAgICAgICBjb25zdCBpbmRleCA9IG5ldyBJbmRleCgpO1xuICAgICAgICAgICAgLy8g6LCD55So6aG16Z2i5a+56LGh55qE5Yqg6L295a6M5oiQ6YCa55+lXG4gICAgICAgICAgICBpbmRleC5zbGF2ZUxvYWRlZCgpO1xuICAgICAgICAgICAgLy8g55uR5ZCs562J5b6FaW5pdERhdGHvvIzov5vooYzmuLLmn5NcbiAgICAgICAgICAgIGluZGV4LmNvbW11bmljYXRvci5vbk1lc3NhZ2UoJ2luaXREYXRhJywgcGFyYW1zID0+e1xuICAgICAgICAgICAgICAgIC8vIOagueaNrm1hc3RlcuS8oOmAkueahGRhdGHvvIzorr7lrprliJ3lp4vmlbDmja7vvIzlubbov5vooYzmuLLmn5NcbiAgICAgICAgICAgICAgICBpbmRleC5zZXRJbml0RGF0YShwYXJhbXMpO1xuICAgICAgICAgICAgICAgIC8vIOecn+ato+eahOmhtemdoua4suafk++8jOWPkeeUn+WcqGluaXREYXRh5LmL5ZCOXG4gICAgICAgICAgICAgICAgaW5kZXguYXR0YWNoKGRvY3VtZW50LmJvZHkpO1xuICAgICAgICAgICAgfSwge2xpc3RlblByZXZpb3VzRXZlbnQ6IHRydWV9KTtcbiAgICAgICAgfTtcblxuICAgICAgICBpZiAoZ2xvYmFsLnBhZ2VSZW5kZXIpIHtcbiAgICAgICAgICAgIHJlbmRlclBhZ2UoZmlsdGVyQXJyLCBwYXJhbSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBvbGRQYXRjaCh3aW5kb3cuUGFnZUNvbXBvbmVudCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgZ2xvYmFsLmVycm9yTXNnWydleGVjRXJyb3InXSA9IGU7XG4gICAgICAgIHRocm93IGU7XG4gICAgfVxufSkod2luZG93LCB3aW5kb3cuc2FuKTtcblxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAvVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9zdWJQYWNrYWdlL3BhZ2VzL2xvZ2luL2xvZ2luUHJvdG9jb2wuc3dhbiJdLCJzb3VyY2VSb290IjoiIn0=