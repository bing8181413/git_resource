

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * @file swan's slave '.swan' file compiled runtime js
 * @author houyu(houyu01@baidu.com)
 */
(function (global, san) {
    global.errorMsg = [];

    // 自定义模板区域

    var templateComponents = Object.assign({}, {});

    var param = {};
    var filterArr = JSON.parse('[]');

    function processTemplateModule(filterTemplateArrs, filterModule) {
        eval(filterModule);
        var modules = {};
        var templateFiltersObj = {};
        filterTemplateArrs && filterTemplateArrs.forEach(function (element) {
            var filterName = element.filterName,
                func = element.func,
                module = element.module;

            modules[module] = eval(module);
            templateFiltersObj[filterName] = function () {
                var _modules$module;

                return (_modules$module = modules[module])[func].apply(_modules$module, arguments);
            };
        });
        return templateFiltersObj;
    }

    try {

        filterArr && filterArr.forEach(function (item) {
            param[item.module] = eval(item.module);
        });

        var pageContent = '<web-view src="https://m-live.iqiyi.com/press/zt/yszc.html"></web-view>';

        // 新的渲染逻辑
        var renderPage = function renderPage(filters, modules) {
            var componentFactory = global.componentFactory;
            // 获取所有内置组件 + 自定义组件的fragment
            var componentFragments = componentFactory.getAllComponents();

            // 所有的自定义组件
            ;

            // 路径与该组件映射
            var customAbsolutePathMap = {};

            // 当前页面使用的自定义组件
            var pageUsingComponentMap = JSON.parse('{}');

            // 生成该页面引用的自定义组件
            var customComponents = Object.keys(pageUsingComponentMap).reduce(function (customComponents, customName) {
                customComponents[customName] = customAbsolutePathMap[pageUsingComponentMap[customName]];
                return customComponents;
            }, {});

            // 启动页面渲染逻辑
            global.pageRender(pageContent, templateComponents, customComponents, filters, modules);
        };

        // 兼容旧的swan-core
        var oldPatch = function oldPatch(PageComponent) {
            Object.assign(PageComponent.components, {});
            // 渲染整个页面的顶层组件，template会在编译时被替换为用户的swan模板

            var Index = function (_PageComponent) {
                _inherits(Index, _PageComponent);

                function Index(options) {
                    _classCallCheck(this, Index);

                    var _this = _possibleConstructorReturn(this, (Index.__proto__ || Object.getPrototypeOf(Index)).call(this, options));

                    _this.components = PageComponent.components;
                    return _this;
                }

                return Index;
            }(PageComponent);
            // 初始化页面对象


            Index.template = '<swan-wrapper tabindex="-1">' + pageContent + '</swan-wrapper>';
            var index = new Index();
            // 调用页面对象的加载完成通知
            index.slaveLoaded();
            // 监听等待initData，进行渲染
            index.communicator.onMessage('initData', function (params) {
                // 根据master传递的data，设定初始数据，并进行渲染
                index.setInitData(params);
                // 真正的页面渲染，发生在initData之后
                index.attach(document.body);
            }, { listenPreviousEvent: true });
        };

        if (global.pageRender) {
            renderPage(filterArr, param);
        } else {
            oldPatch(window.PageComponent);
        }
    } catch (e) {
        global.errorMsg['execError'] = e;
        throw e;
    }
})(window, window.san);

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvc3ViUGFja2FnZS9wYWdlcy9sb2dpbi9wcml2YXRlSDUuc3dhbiJdLCJuYW1lcyI6WyJnbG9iYWwiLCJzYW4iLCJlcnJvck1zZyIsInRlbXBsYXRlQ29tcG9uZW50cyIsIk9iamVjdCIsImFzc2lnbiIsInBhcmFtIiwiZmlsdGVyQXJyIiwiSlNPTiIsInBhcnNlIiwicHJvY2Vzc1RlbXBsYXRlTW9kdWxlIiwiZmlsdGVyVGVtcGxhdGVBcnJzIiwiZmlsdGVyTW9kdWxlIiwiZXZhbCIsIm1vZHVsZXMiLCJ0ZW1wbGF0ZUZpbHRlcnNPYmoiLCJmb3JFYWNoIiwiZmlsdGVyTmFtZSIsImVsZW1lbnQiLCJmdW5jIiwibW9kdWxlIiwiaXRlbSIsInBhZ2VDb250ZW50IiwicmVuZGVyUGFnZSIsImZpbHRlcnMiLCJjb21wb25lbnRGYWN0b3J5IiwiY29tcG9uZW50RnJhZ21lbnRzIiwiZ2V0QWxsQ29tcG9uZW50cyIsImN1c3RvbUFic29sdXRlUGF0aE1hcCIsInBhZ2VVc2luZ0NvbXBvbmVudE1hcCIsImN1c3RvbUNvbXBvbmVudHMiLCJrZXlzIiwicmVkdWNlIiwiY3VzdG9tTmFtZSIsInBhZ2VSZW5kZXIiLCJvbGRQYXRjaCIsIlBhZ2VDb21wb25lbnQiLCJjb21wb25lbnRzIiwiSW5kZXgiLCJvcHRpb25zIiwidGVtcGxhdGUiLCJpbmRleCIsInNsYXZlTG9hZGVkIiwiY29tbXVuaWNhdG9yIiwib25NZXNzYWdlIiwic2V0SW5pdERhdGEiLCJwYXJhbXMiLCJhdHRhY2giLCJkb2N1bWVudCIsImJvZHkiLCJsaXN0ZW5QcmV2aW91c0V2ZW50Iiwid2luZG93IiwiZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQTs7OztBQUlBLENBQUMsVUFBQ0EsTUFBRCxFQUFTQyxHQUFULEVBQWdCO0FBQ2JELFdBQU9FLFFBQVAsR0FBa0IsRUFBbEI7O0FBRUE7O0FBRUEsUUFBTUMscUJBQXFCQyxPQUFPQyxNQUFQLENBQWMsRUFBZCxFQUFrQixFQUFsQixDQUEzQjs7QUFFQSxRQUFJQyxRQUFRLEVBQVo7QUFDQSxRQUFNQyxZQUFZQyxLQUFLQyxLQUFMLENBQVcsSUFBWCxDQUFsQjs7QUFHQSxhQUFTQyxxQkFBVCxDQUErQkMsa0JBQS9CLEVBQW1EQyxZQUFuRCxFQUFpRTtBQUM3REMsYUFBS0QsWUFBTDtBQUNBLFlBQUlFLFVBQVUsRUFBZDtBQUNBLFlBQUlDLHFCQUFxQixFQUF6QjtBQUNBSiw4QkFBc0JBLG1CQUFtQkssT0FBbkIsQ0FBMkIsbUJBQVU7QUFBQSxnQkFDbERDLFVBRGtELEdBQ3RCQyxPQURzQixDQUNsREQsVUFEa0Q7QUFBQSxnQkFDdENFLElBRHNDLEdBQ3RCRCxPQURzQixDQUN0Q0MsSUFEc0M7QUFBQSxnQkFDaENDLE1BRGdDLEdBQ3RCRixPQURzQixDQUNoQ0UsTUFEZ0M7O0FBRXZETixvQkFBUU0sTUFBUixJQUFrQlAsS0FBS08sTUFBTCxDQUFsQjtBQUNBTCwrQkFBbUJFLFVBQW5CLElBQWlDO0FBQUE7O0FBQUEsdUJBQVksMkJBQVFHLE1BQVIsR0FBZ0JELElBQWhCLG1DQUFaO0FBQUEsYUFBakM7QUFDSCxTQUpxQixDQUF0QjtBQUtBLGVBQU9KLGtCQUFQO0FBQ0g7O0FBRUQsUUFBSTs7QUFFQVIscUJBQWFBLFVBQVVTLE9BQVYsQ0FBa0IsZ0JBQU87QUFDbENWLGtCQUFNZSxLQUFLRCxNQUFYLElBQXFCUCxLQUFLUSxLQUFLRCxNQUFWLENBQXJCO0FBQ0gsU0FGWSxDQUFiOztBQUlBLFlBQU1FLHVGQUFOOztBQUVBO0FBQ0EsWUFBTUMsYUFBYSxTQUFiQSxVQUFhLENBQUNDLE9BQUQsRUFBVVYsT0FBVixFQUFxQjtBQUNwQyxnQkFBTVcsbUJBQW1CekIsT0FBT3lCLGdCQUFoQztBQUNBO0FBQ0EsZ0JBQU1DLHFCQUFxQkQsaUJBQWlCRSxnQkFBakIsRUFBM0I7O0FBRUE7QUFDQTs7QUFFQTtBQUNBLGdCQUFJQyx3QkFBd0IsRUFBNUI7O0FBRUE7QUFDQSxnQkFBTUMsd0JBQXdCckIsS0FBS0MsS0FBTCxNQUE5Qjs7QUFFQTtBQUNBLGdCQUFNcUIsbUJBQW1CMUIsT0FBTzJCLElBQVAsQ0FBWUYscUJBQVosRUFBbUNHLE1BQW5DLENBQTBDLFVBQUNGLGdCQUFELEVBQW1CRyxVQUFuQixFQUFpQztBQUNoR0gsaUNBQWlCRyxVQUFqQixJQUErQkwsc0JBQXNCQyxzQkFBc0JJLFVBQXRCLENBQXRCLENBQS9CO0FBQ0EsdUJBQU9ILGdCQUFQO0FBQ0gsYUFId0IsRUFHdEIsRUFIc0IsQ0FBekI7O0FBS0E7QUFDQTlCLG1CQUFPa0MsVUFBUCxDQUFrQlosV0FBbEIsRUFBK0JuQixrQkFBL0IsRUFBbUQyQixnQkFBbkQsRUFBcUVOLE9BQXJFLEVBQThFVixPQUE5RTtBQUNILFNBdEJEOztBQXdCQTtBQUNBLFlBQU1xQixXQUFXLFNBQVhBLFFBQVcsZ0JBQWdCO0FBQzdCL0IsbUJBQU9DLE1BQVAsQ0FBYytCLGNBQWNDLFVBQTVCLEVBQXdDLEVBQXhDO0FBQ0E7O0FBRjZCLGdCQUd2QkMsS0FIdUI7QUFBQTs7QUFJekIsK0JBQVlDLE9BQVosRUFBcUI7QUFBQTs7QUFBQSw4SEFDWEEsT0FEVzs7QUFFakIsMEJBQUtGLFVBQUwsR0FBa0JELGNBQWNDLFVBQWhDO0FBRmlCO0FBR3BCOztBQVB3QjtBQUFBLGNBR1RELGFBSFM7QUFVN0I7OztBQVBNRSxpQkFIdUIsQ0FRbEJFLFFBUmtCLG9DQVF3QmxCLFdBUnhCO0FBVzdCLGdCQUFNbUIsUUFBUSxJQUFJSCxLQUFKLEVBQWQ7QUFDQTtBQUNBRyxrQkFBTUMsV0FBTjtBQUNBO0FBQ0FELGtCQUFNRSxZQUFOLENBQW1CQyxTQUFuQixDQUE2QixVQUE3QixFQUF5QyxrQkFBUztBQUM5QztBQUNBSCxzQkFBTUksV0FBTixDQUFrQkMsTUFBbEI7QUFDQTtBQUNBTCxzQkFBTU0sTUFBTixDQUFhQyxTQUFTQyxJQUF0QjtBQUNILGFBTEQsRUFLRyxFQUFDQyxxQkFBcUIsSUFBdEIsRUFMSDtBQU1ILFNBckJEOztBQXVCQSxZQUFJbEQsT0FBT2tDLFVBQVgsRUFBdUI7QUFDbkJYLHVCQUFXaEIsU0FBWCxFQUFzQkQsS0FBdEI7QUFDSCxTQUZELE1BR0s7QUFDRDZCLHFCQUFTZ0IsT0FBT2YsYUFBaEI7QUFDSDtBQUNKLEtBL0RELENBZ0VBLE9BQU9nQixDQUFQLEVBQVU7QUFDTnBELGVBQU9FLFFBQVAsQ0FBZ0IsV0FBaEIsSUFBK0JrRCxDQUEvQjtBQUNBLGNBQU1BLENBQU47QUFDSDtBQUNKLENBM0ZELEVBMkZHRCxNQTNGSCxFQTJGV0EsT0FBT2xELEdBM0ZsQixFIiwiZmlsZSI6InN1YlBhY2thZ2UvcGFnZXMvbG9naW4vcHJpdmF0ZUg1LnN3YW4uanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBmaWxlIHN3YW4ncyBzbGF2ZSAnLnN3YW4nIGZpbGUgY29tcGlsZWQgcnVudGltZSBqc1xuICogQGF1dGhvciBob3V5dShob3V5dTAxQGJhaWR1LmNvbSlcbiAqL1xuKChnbG9iYWwsIHNhbikgPT57XG4gICAgZ2xvYmFsLmVycm9yTXNnID0gW107XG5cbiAgICAvLyDoh6rlrprkuYnmqKHmnb/ljLrln59cbiAgICBcbiAgICBjb25zdCB0ZW1wbGF0ZUNvbXBvbmVudHMgPSBPYmplY3QuYXNzaWduKHt9LCB7fSk7XG5cbiAgICBsZXQgcGFyYW0gPSB7fTtcbiAgICBjb25zdCBmaWx0ZXJBcnIgPSBKU09OLnBhcnNlKCdbXScpO1xuICAgIFxuXG4gICAgZnVuY3Rpb24gcHJvY2Vzc1RlbXBsYXRlTW9kdWxlKGZpbHRlclRlbXBsYXRlQXJycywgZmlsdGVyTW9kdWxlKSB7XG4gICAgICAgIGV2YWwoZmlsdGVyTW9kdWxlKTtcbiAgICAgICAgbGV0IG1vZHVsZXMgPSB7fTtcbiAgICAgICAgbGV0IHRlbXBsYXRlRmlsdGVyc09iaiA9IHt9O1xuICAgICAgICBmaWx0ZXJUZW1wbGF0ZUFycnMgJiYgZmlsdGVyVGVtcGxhdGVBcnJzLmZvckVhY2goZWxlbWVudCA9PntcbiAgICAgICAgICAgIGxldCB7ZmlsdGVyTmFtZSwgZnVuYywgbW9kdWxlfSA9IGVsZW1lbnQ7XG4gICAgICAgICAgICBtb2R1bGVzW21vZHVsZV0gPSBldmFsKG1vZHVsZSk7XG4gICAgICAgICAgICB0ZW1wbGF0ZUZpbHRlcnNPYmpbZmlsdGVyTmFtZV0gPSAoLi4uYXJncykgPT5tb2R1bGVzW21vZHVsZV1bZnVuY10oLi4uYXJncyk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdGVtcGxhdGVGaWx0ZXJzT2JqO1xuICAgIH1cblxuICAgIHRyeSB7XG5cbiAgICAgICAgZmlsdGVyQXJyICYmIGZpbHRlckFyci5mb3JFYWNoKGl0ZW0gPT57XG4gICAgICAgICAgICBwYXJhbVtpdGVtLm1vZHVsZV0gPSBldmFsKGl0ZW0ubW9kdWxlKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3QgcGFnZUNvbnRlbnQgPSBgPHdlYi12aWV3IHNyYz1cImh0dHBzOi8vbS1saXZlLmlxaXlpLmNvbS9wcmVzcy96dC95c3pjLmh0bWxcIj48L3dlYi12aWV3PmA7XG5cbiAgICAgICAgLy8g5paw55qE5riy5p+T6YC76L6RXG4gICAgICAgIGNvbnN0IHJlbmRlclBhZ2UgPSAoZmlsdGVycywgbW9kdWxlcykgPT57XG4gICAgICAgICAgICBjb25zdCBjb21wb25lbnRGYWN0b3J5ID0gZ2xvYmFsLmNvbXBvbmVudEZhY3Rvcnk7XG4gICAgICAgICAgICAvLyDojrflj5bmiYDmnInlhoXnva7nu4Tku7YgKyDoh6rlrprkuYnnu4Tku7bnmoRmcmFnbWVudFxuICAgICAgICAgICAgY29uc3QgY29tcG9uZW50RnJhZ21lbnRzID0gY29tcG9uZW50RmFjdG9yeS5nZXRBbGxDb21wb25lbnRzKCk7XG5cbiAgICAgICAgICAgIC8vIOaJgOacieeahOiHquWumuS5iee7hOS7tlxuICAgICAgICAgICAgO1xuXG4gICAgICAgICAgICAvLyDot6/lvoTkuI7or6Xnu4Tku7bmmKDlsIRcbiAgICAgICAgICAgIHZhciBjdXN0b21BYnNvbHV0ZVBhdGhNYXAgPSB7fTtcblxuICAgICAgICAgICAgLy8g5b2T5YmN6aG16Z2i5L2/55So55qE6Ieq5a6a5LmJ57uE5Lu2XG4gICAgICAgICAgICBjb25zdCBwYWdlVXNpbmdDb21wb25lbnRNYXAgPSBKU09OLnBhcnNlKGB7fWApO1xuXG4gICAgICAgICAgICAvLyDnlJ/miJDor6XpobXpnaLlvJXnlKjnmoToh6rlrprkuYnnu4Tku7ZcbiAgICAgICAgICAgIGNvbnN0IGN1c3RvbUNvbXBvbmVudHMgPSBPYmplY3Qua2V5cyhwYWdlVXNpbmdDb21wb25lbnRNYXApLnJlZHVjZSgoY3VzdG9tQ29tcG9uZW50cywgY3VzdG9tTmFtZSkgPT57XG4gICAgICAgICAgICAgICAgY3VzdG9tQ29tcG9uZW50c1tjdXN0b21OYW1lXSA9IGN1c3RvbUFic29sdXRlUGF0aE1hcFtwYWdlVXNpbmdDb21wb25lbnRNYXBbY3VzdG9tTmFtZV1dO1xuICAgICAgICAgICAgICAgIHJldHVybiBjdXN0b21Db21wb25lbnRzO1xuICAgICAgICAgICAgfSwge30pO1xuXG4gICAgICAgICAgICAvLyDlkK/liqjpobXpnaLmuLLmn5PpgLvovpFcbiAgICAgICAgICAgIGdsb2JhbC5wYWdlUmVuZGVyKHBhZ2VDb250ZW50LCB0ZW1wbGF0ZUNvbXBvbmVudHMsIGN1c3RvbUNvbXBvbmVudHMsIGZpbHRlcnMsIG1vZHVsZXMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8vIOWFvOWuueaXp+eahHN3YW4tY29yZVxuICAgICAgICBjb25zdCBvbGRQYXRjaCA9IFBhZ2VDb21wb25lbnQgPT57XG4gICAgICAgICAgICBPYmplY3QuYXNzaWduKFBhZ2VDb21wb25lbnQuY29tcG9uZW50cywge30pO1xuICAgICAgICAgICAgLy8g5riy5p+T5pW05Liq6aG16Z2i55qE6aG25bGC57uE5Lu277yMdGVtcGxhdGXkvJrlnKjnvJbor5Hml7booqvmm7/mjaLkuLrnlKjmiLfnmoRzd2Fu5qih5p2/XG4gICAgICAgICAgICBjbGFzcyBJbmRleCBleHRlbmRzIFBhZ2VDb21wb25lbnQge1xuICAgICAgICAgICAgICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICAgICAgICAgICAgICAgICAgc3VwZXIob3B0aW9ucyk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY29tcG9uZW50cyA9IFBhZ2VDb21wb25lbnQuY29tcG9uZW50cztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgc3RhdGljIHRlbXBsYXRlID0gYDxzd2FuLXdyYXBwZXIgdGFiaW5kZXg9XCItMVwiPiR7cGFnZUNvbnRlbnR9PC9zd2FuLXdyYXBwZXI+YDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIOWIneWni+WMlumhtemdouWvueixoVxuICAgICAgICAgICAgY29uc3QgaW5kZXggPSBuZXcgSW5kZXgoKTtcbiAgICAgICAgICAgIC8vIOiwg+eUqOmhtemdouWvueixoeeahOWKoOi9veWujOaIkOmAmuefpVxuICAgICAgICAgICAgaW5kZXguc2xhdmVMb2FkZWQoKTtcbiAgICAgICAgICAgIC8vIOebkeWQrOetieW+hWluaXREYXRh77yM6L+b6KGM5riy5p+TXG4gICAgICAgICAgICBpbmRleC5jb21tdW5pY2F0b3Iub25NZXNzYWdlKCdpbml0RGF0YScsIHBhcmFtcyA9PntcbiAgICAgICAgICAgICAgICAvLyDmoLnmja5tYXN0ZXLkvKDpgJLnmoRkYXRh77yM6K6+5a6a5Yid5aeL5pWw5o2u77yM5bm26L+b6KGM5riy5p+TXG4gICAgICAgICAgICAgICAgaW5kZXguc2V0SW5pdERhdGEocGFyYW1zKTtcbiAgICAgICAgICAgICAgICAvLyDnnJ/mraPnmoTpobXpnaLmuLLmn5PvvIzlj5HnlJ/lnKhpbml0RGF0YeS5i+WQjlxuICAgICAgICAgICAgICAgIGluZGV4LmF0dGFjaChkb2N1bWVudC5ib2R5KTtcbiAgICAgICAgICAgIH0sIHtsaXN0ZW5QcmV2aW91c0V2ZW50OiB0cnVlfSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgaWYgKGdsb2JhbC5wYWdlUmVuZGVyKSB7XG4gICAgICAgICAgICByZW5kZXJQYWdlKGZpbHRlckFyciwgcGFyYW0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgb2xkUGF0Y2god2luZG93LlBhZ2VDb21wb25lbnQpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIGdsb2JhbC5lcnJvck1zZ1snZXhlY0Vycm9yJ10gPSBlO1xuICAgICAgICB0aHJvdyBlO1xuICAgIH1cbn0pKHdpbmRvdywgd2luZG93LnNhbik7XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvc3ViUGFja2FnZS9wYWdlcy9sb2dpbi9wcml2YXRlSDUuc3dhbiJdLCJzb3VyY2VSb290IjoiIn0=