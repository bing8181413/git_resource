window.define('77', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _user = __webpack_require__(29);

var _user2 = _interopRequireDefault(_user);

var _index = __webpack_require__(93);

var _index2 = _interopRequireDefault(_index);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var app = getApp(); // import searchLayout from "../../components/searchLayout/searchLayout";

var page = {
    data: {
        load: 'none',
        bannerIndex: 1,
        selectedLiveSubtypeId: 0,
        // banner: [],
        channels_a_other: {},
        channels_a_roomList: [],
        channels_b_roomList: []
        // channels: []
    },
    onPullDownRefresh: function onPullDownRefresh() {
        // 下拉刷新
        this.onLoad();
    },
    onShow: function onShow() {
        // let _channels = this.getData('channels');
        // if (!_channels) {
        //     this.onLoad();
        // }
        // console.log('onShow...');
    },
    onReady: function onReady() {
        // swan.showToast({ title: 'onReady ! ' });
        // console.log('onReady...');
    },
    onLoad: function onLoad() {
        // console.error(JSON.stringify(this.data));
        // user.init();
        this.loadPage();
        // console.log('onLoad...');
    },
    loadPage: function loadPage() {
        var _this = this;

        setTimeout(function () {
            var isLogin = _user2.default.isLogin();
            _index2.default.getIndexData(isLogin, _this);
            _this.loadPage = function () {
                var isLogin = _user2.default.isLogin();
                _index2.default.getIndexData(isLogin, _this);
            };
        }, 0);
    },
    _loadedPage: function _loadedPage(data) {
        // 渲染后回调
        swan.stopPullDownRefresh && swan.stopPullDownRefresh();
        swan.hideLoading();
        _util2.default.seo(); //默认 SEO
    },
    swiperChange: function swiperChange(event) {
        var banner = this.getData('banner')[event.detail.current];
        // console.log('banner', banner);
        // 点亮 swiper-dot
        this.setData({
            bannerIndex: event.detail.current + 1
        });
    },
    selectedBtnRoom: function selectedBtnRoom(event) {
        var target = event.currentTarget;
        // swan.showToast({ title: target.dataset.liveSubtypeName });
        this.setData('selectedLiveSubtypeId', target.dataset.liveSubtypeId);
    },
    redirectCateMore: function redirectCateMore(event) {
        var target = event.currentTarget;
        var obj = target.dataset.obj;
        // console.log(obj.liveChannelName, obj.channelType, obj.liveTypeId);
        app.globalData.tabCategory = {
            liveTypeId: obj.liveTypeId,
            liveChannelName: obj.liveChannelName,
            channelType: obj.channelType,
            liveSubTypeId: obj.liveSubTypeId || 0
        };
        // console.log(app.globalData.tabCategory);
        _util2.default.jump('/pages/category/category');
    },
    playVideo: function playVideo(event) {
        var target = event.currentTarget;
        var roomId = target.dataset.roomId;
        var liveType = target.dataset.liveType;
        // const obj = target.dataset.obj;
        // console.log(obj);
        // _.record({ ...obj, recordTime: new Date().getTime() });
        if (!roomId) {
            swan.showToast({
                icon: 'none',
                title: '数据异常'
            });
            return false;
        }
        var url = "pages/w/room?roomId=" + roomId;
        if (liveType == 2) {
            url = "pages/s/room?roomId=" + roomId;
        }
        _util2.default.jump(url);
    },
    updateVersion: function updateVersion() {
        // const updateManager = swan.getUpdateManager();
        // console.log(updateManager);
        // updateManager.onCheckForUpdate(function(res) {
        //     // 请求完新版本信息的回调
        //     console.log(res);
        //     console.log(res.hasUpdate);
        //     swan.showModal({ title: '更新提示', content: JSON.stringify(res) });
        // });
        // updateManager.onUpdateReady(function(res) {
        //     swan.showModal({
        //         title: '更新提示',
        //         content: '新版本已经准备好，是否重启应用？',
        //         success(res) {
        //             console.log(res);
        //             if (res.confirm) {
        //                 // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
        //                 updateManager.applyUpdate();
        //             }
        //         }
        //     });

        // });
        // updateManager.onUpdateFailed(function(res) {
        //     // 新的版本下载失败
        //     console.log(res);
        // });
    }
};

Page(Object.assign({}, page));
});
window.define('95', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _index = __webpack_require__(96);

var _index2 = _interopRequireDefault(_index);

var _user = __webpack_require__(29);

var _user2 = _interopRequireDefault(_user);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

var _switchCateAction = __webpack_require__(97);

var _switchCateAction2 = _interopRequireDefault(_switchCateAction);

var _promise = __webpack_require__(30);

var _promise2 = _interopRequireDefault(_promise);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var app = getApp(); // global object
var page = {
    data: {
        list: [],
        hotSubList: [], // hot 前几个热门分类
        categoryList: [], // 所有:一二级总分类 
        currentPage: 0,
        currOption: {
            liveTypeId: 4,
            liveChannelName: '游戏直播',
            liveSubTypeId: 0
        },
        openCateStatus: 0, // 打开分类按钮 0 :未打开; 1: 打开
        changeSearchStatus: false, // 是否改变了分类查询条件 确定是否从第一页加载
        pullDownRefreshStatus: false // 下拉刷新状态 false :非下拉刷新  true : 是下拉刷新
    },
    _getGlobalSelectCate: function _getGlobalSelectCate() {
        var _this = this;

        // :: 小程序直接到当前页面时,可能会有 categoryList 未获取到,需要二次获取 防止延迟导致的数据不显示
        var categoryList = app.globalData.categoryList;
        // console.log(new Date().getTime());
        if (categoryList && categoryList.length > 0) {
            return new _promise2.default(function (resolve, reject) {
                console.log(categoryList.length + " \u6761\u5206\u7C7B\u6570\u636E");
                _this.setData({ 'categoryList': categoryList }, function () {
                    resolve('success');
                });
            });
        } else {
            return new _promise2.default(function (resolve, reject) {
                app._getCategory(false, function (categoryList) {
                    console.log(categoryList.length + " \u6761\u5206\u7C7B\u6570\u636E  \u4E8C\u6B21\u8BF7\u6C42");
                    _this.setData({ 'categoryList': categoryList }, function () {
                        resolve('success');
                    });
                });
            });
        }
    },
    _setQuery: function _setQuery() {
        // 获取最新参数
        this.setData({
            'query': app.globalData.tabCategory
        });
    },

    // onPullDownRefresh() {
    //     this.data.pullDownRefreshStatus = true;
    //     this.onShow();
    // },
    onShow: function onShow() {
        // console.log('onShow==');
        // setTimeout(() => {
        //     // 筛选当前全局 cate 的 type
        //     this._getGlobalSelectCate();
        //     let globCateOption = app.globalData.tabCategory;
        //     let currOption = this.data.currOption;
        //     if(currOption.liveTypeId !== globCateOption.liveTypeId || currOption.liveSubTypeId !== globCateOption.liveSubTypeId || this.data.pullDownRefreshStatus) {
        //         this.data.pullDownRefreshStatus = false; // 恢复下拉刷新的状态为 false
        //         this.data.changeSearchStatus = true;
        //         this.data.currentPage = 0;
        //         this.loadPage();
        //     }
        // }, 1000);
        if (this.switchCateComponents && this.switchCateComponents.initStatus) {
            // 组件初始化后 执行
            this.switchSubCateHandle();
        }
    },
    myCatchTouch: function myCatchTouch(e) {
        if (this.data.openCateStatus === 1) {
            return false;
        }
    },
    _setScrollTop: function _setScrollTop() {
        swan.pageScrollTo({
            scrollTop: 0,
            duration: 300
        });
    },
    onReady: function onReady() {},
    onHide: function onHide() {},
    onTabItemTap: function onTabItemTap(item) {
        console.log('onTabItemTap:\t', item);
    },
    onLoad: function onLoad() {
        _util2.default.seo();
        this.switchCateComponents = new _switchCateAction2.default(this);
        // setTimeout(() => {
        //     this.switchCateComponents = new switchCateControl(this);
        // }, 200)
    },
    loadPage: function loadPage() {
        var _this2 = this;

        var isLogin = _user2.default.isLogin();
        _index2.default.getIndexData(this, isLogin);
        this.loadPage = function () {
            swan.showLoading({ title: "\u52A0\u8F7D\u4E2D..", mask: true });
            var isLogin = _user2.default.isLogin();
            _index2.default.getIndexData(_this2, isLogin);
        };
    },
    _loadedPage: function _loadedPage(data) {
        this.updateCateOption();
        this.data.changeSearchStatus = false;
        swan.hideLoading();
        // console.log('_loadedPage:\t', data.list[0]);
    },
    updateCateOption: function updateCateOption() {
        var cateOption = {
            liveTypeId: app.globalData.tabCategory.liveTypeId,
            liveChannelName: app.globalData.tabCategory.liveChannelName,
            liveSubTypeId: app.globalData.tabCategory.liveSubTypeId
        };
        this.setData({
            currOption: cateOption
        });
    },
    bindscrolltolower: function bindscrolltolower() {
        console.log('bindscrolltolower');
        var isLogin = _user2.default.isLogin();
        _index2.default.getIndexData(this, isLogin);
    },
    onReachBottom: function onReachBottom() {
        // console.log('onReachBottom');
        var isLogin = _user2.default.isLogin();
        if (this.data.openCateStatus === 1) {
            return false;
        } else {
            _index2.default.getIndexData(this, isLogin);
        }
    },
    openCateHandle: function openCateHandle(status) {
        var _openCateStatus = this.getData('openCateStatus');
        this.setData('openCateStatus', Object.prototype.toString.call(status) === '[object Number]' ? status : _openCateStatus === 1 ? 0 : 1);
    },
    playVideo: function playVideo(event) {
        var target = event.currentTarget;
        var roomId = target.dataset.roomId;
        if (!roomId) {
            return false;
        }
        var url = "pages/w/room?roomId=" + roomId;
        _util2.default.jump(url);
    }
};

Page(Object.assign({}, page));
});
window.define('98', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _index = __webpack_require__(99);

var _index2 = _interopRequireDefault(_index);

var _user = __webpack_require__(29);

var _user2 = _interopRequireDefault(_user);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var app = getApp(); // global object
var page = {
    data: {
        dataList: [],
        rankTypeList: [],
        currOption: {
            rankTypeId: 0,
            title: ''
        }
    },
    onShow: function onShow() {
        var rankTypeList = this.data.rankTypeList;
        var rankTypeId = this.data.currOption.rankTypeId;
        if (rankTypeList && rankTypeId != 0) {
            this.setData('currOption.rankTypeId', 0);
            this.loadPage();
        }
    },

    onTabItemTap: function onTabItemTap(item) {
        console.log(item);
    },
    onLoad: function onLoad() {
        this.loadType();
        this.loadPage();
    },
    loadType: function loadType() {
        var isLogin = _user2.default.isLogin();
        _index2.default.getRankTypeData(this, isLogin);
    },
    loadPage: function loadPage() {
        var _this = this;

        setTimeout(function () {
            swan.showLoading({ title: "\u52A0\u8F7D\u4E2D.." });
            var isLogin = _user2.default.isLogin();
            _index2.default.getIndexData(_this, isLogin);
            _util2.default.seo(); //第一次加载 使用一次就够了
            _this.loadPage = function () {
                swan.showLoading({ title: "\u52A0\u8F7D\u4E2D.." });
                var isLogin = _user2.default.isLogin();
                _index2.default.getIndexData(_this, isLogin);
            };
        }, 0);
    },
    _loadedPage: function _loadedPage(data) {
        this.setData({
            'dataList': data.dataList,
            'currOption.title': data.dataList[0].title
        });
        swan.hideLoading();
    },
    _loadedRankType: function _loadedRankType(data) {
        this.setData('rankTypeList', data);
    },
    switchRankHandle: function switchRankHandle(event) {
        var target = event.currentTarget;
        this.setData('currOption.rankTypeId', target.dataset.rankTypeId);
        this.loadPage();
    },
    switchTitleHandle: function switchTitleHandle(event) {
        var target = event.currentTarget;
        this.setData('currOption.title', target.dataset.title);
    },
    playVideo: function playVideo(event) {
        var target = event.currentTarget;
        var roomId = target.dataset.roomId;
        if (!roomId) {
            return false;
        }
        var url = "pages/w/room?roomId=" + roomId;
        _util2.default.jump(url);
    }
};

Page(Object.assign({}, page));
});
window.define('100', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _userInfo = __webpack_require__(36);

var user = _interopRequireWildcard(_userInfo);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

var _reqService = __webpack_require__(101);

var _reqService2 = _interopRequireDefault(_reqService);

var _session = __webpack_require__(32);

var _session2 = _interopRequireDefault(_session);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var app = getApp();
var globalData = app.globalData;
var originIcon = '../../assets/my/avatar-144.png';
var page = {
    data: {
        load: 'none',
        records: [],
        options: {
            needLogin: false, //页面打开后是否需要登录吗?
            authCookie: ''
        },
        loginInfo: {
            isLogin: false,
            user: {
                icon: originIcon,
                nickname: '',
                isVip: false
            }
        }
    },
    onShow: function onShow() {
        this.loadPage();
        // this._getUserInfo('91lLqbrla3ve9WkFf5kuAXekJxZQZa7jnlMkfVoqZjveWPMnMtfnlwPdpYm2zgjDCdN5c');//TODO test DELETE
        if (globalData.needLogin) {
            // swan.showToast({ title: `${app.globalData.needLogin}~~${app.globalData.authCookie}` });
            this.data.options.needLogin = app.globalData.needLogin; //TODO 由于 swan.switchTab  跳转传参会导致页面报错假死 就写入全局变量中执行
            this.data.options.authCookie = app.globalData.authCookie;

            this.setData('loginInfo.isLogin', false);
            this._needLogin();
        } else if (globalData.authCookie.length === 0) {
            this._updateUserInfo();
        }
    },
    onLoad: function onLoad() {
        // TODO
        // globalData.needLogin = 1;
        // globalData.authCookie = 'BAtVCBS3Xd7loPuNJ70bR5m3DIqzpZPdSASleIam3Wm31oOTEl7W3ebTZEFcG5cYrEF9JZvUB0SDNwBm1QwzxtA4AMx5gtCMu40hQMfRXiZSVdqrVHCNzqm1FUg';
    },
    initUpdateData: function initUpdateData() {
        this.data.options.needLogin = globalData.authCookie;
    },
    _needLogin: function _needLogin() {
        var authCookie = this.data.options.authCookie; //获取 options

        if (authCookie && authCookie !== '') {
            this._getUserInfo(authCookie);
            this.data.options.needLogin = false;
            app.globalData.needLogin = false;
        } else {
            this._updateUserInfo();
            swan.showToast({ title: '请点击登录' });
            console.log("\u672A\u767B\u5F55");
        }
    },
    _getUserInfo: function _getUserInfo(authCookie) {
        var _this = this;

        var getUserInfo = user.getUserInfo();
        // console.log(getUserInfo);
        if (getUserInfo && Object.keys(getUserInfo).length > 0) {
            console.log(getUserInfo);
        }

        _reqService2.default.getUserInfo({ authcookie: authCookie }).then(function (data) {
            console.warn("\u767B\u5F55 \u6210\u529F!");
            _this._updateUserInfo(data, authCookie);
        }, function (err) {
            _this.loginOut();
            console.error(err);
        });
    },
    loginOut: function loginOut() {
        return false;
    },
    _updateUserInfo: function _updateUserInfo(data, authCookie) {
        if (!data) {
            //登出
            this.setData('loginInfo.isLogin', false);
            this.setData('loginInfo.user.icon', originIcon);
            this.setData('loginInfo.user.nickname', '');
            this.setData('loginInfo.user.isVip', false);
            _session2.default.Session.clear();
        } else {
            // 登录 success
            var _data$userinfo = data.userinfo,
                nickname = _data$userinfo.nickname,
                icon = _data$userinfo.icon;

            var isVip = (data.qiyi_vip_info || {}).level > 1;
            // [isVip] = qiyi_vip_info.level > 1
            console.log(nickname, icon);
            this.setData('loginInfo.isLogin', true);
            this.setData('loginInfo.user.icon', icon);
            this.setData('loginInfo.user.nickname', nickname);
            this.setData('loginInfo.user.isVip', isVip || false);

            _session2.default.Session.set(_session2.default.SESSION_AUTH_KEY, authCookie);
            _session2.default.Session.set(_session2.default.SESSION_INFO_KEY, data);
            swan.showToast({ title: "\u767B\u5F55\u6210\u529F" });
        }
    },
    loadPage: function loadPage() {
        var _this2 = this;

        // _.jump('subPackage/pages/my/about');
        // _.jump('subPackage/pages/my/playLog');
        _util2.default.record().then(function (data) {
            _this2.setData({ 'records': data && data.reverse().splice(0, 4) });
        });
    },
    _loadedPage: function _loadedPage(data) {
        // 渲染后回调
        _util2.default.seo(); //默认 SEO 
    },
    jump: function jump(event) {
        var target = event.currentTarget;
        var url = target.dataset.url;
        // console.log(target);
        _util2.default.jump(url);
    },
    playVideo: function playVideo(event) {
        var target = event.currentTarget;
        var roomId = target.dataset.roomId;
        var liveType = target.dataset.liveType;
        if (!roomId) {
            swan.showToast({
                icon: 'none',
                title: '数据异常'
            });
            return false;
        }
        var url = "pages/w/room?roomId=" + roomId;
        if (liveType == 2) {
            url = "pages/s/room?roomId=" + roomId;
        }
        _util2.default.jump(url);
    },
    clearRecord: function clearRecord(event) {
        var _this3 = this;

        swan.showModal({
            title: '提示',
            content: '删除观看历史',
            cancelColor: '#999999',
            confirmColor: '#0099cc',
            success: function success(res) {
                if (res.confirm) {
                    console.log('删除观看记录 storyage');
                    swan.showToast({ title: '删除成功' });
                    _util2.default.record([]).then(function (res) {
                        _this3.loadPage();
                    });
                } else if (res.cancel) {
                    console.log('用户点击了取消');
                }
            }
        });
    }
};

Page(Object.assign({}, page));
});
window.define('102', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _roomAction = __webpack_require__(103);

var room = _interopRequireWildcard(_roomAction);

var _reqService = __webpack_require__(44);

var req = _interopRequireWildcard(_reqService);

var _playerAction = __webpack_require__(70);

var _playerAction2 = _interopRequireDefault(_playerAction);

var _msgAction = __webpack_require__(67);

var _msgAction2 = _interopRequireDefault(_msgAction);

var _sendMsgAction = __webpack_require__(66);

var _sendMsgAction2 = _interopRequireDefault(_sendMsgAction);

var _utils = __webpack_require__(51);

var utils = _interopRequireWildcard(_utils);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

var _Emitter = __webpack_require__(53);

var _Emitter2 = _interopRequireDefault(_Emitter);

var _jsSensor = __webpack_require__(59);

var _jsSensor2 = _interopRequireDefault(_jsSensor);

var _user = __webpack_require__(37);

var user = _interopRequireWildcard(_user);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

// import mutiAccount from '../../../components/mutiAccount/mutiAccount'

var app = getApp();

var page = {
    /**
     * 页面的初始数据
     */
    data: {
        errorTip: true,
        activeTab: "chat",
        roomId: null,
        hostInfo: null,
        msgList: [{
            type: 0,
            content: "正在准备弹幕"
        }],
        scrollHeight: 100,
        scrollHideLoadMore: true,
        scrollAnimation: false,
        inputFocus: false,
        inputText: "",
        inputAvailable: "",
        showKeyboard: "",
        videoBodyTop: 0,
        video: {
            needVIP: false,
            needLogin: false,
            show: false,
            offline: false
        },
        previewCover: 'http://www.iqiyipic.com/common/fix/wx-iqiyi/player-tip-bg.jpg',
        roomStatus: 0,
        followed: false,
        recommendList: [],
        tab: {
            host: false,
            chat: false
        },
        keyboardHeight: 0
    },

    clickShowHost: function clickShowHost() {
        this.setData({
            activeTab: "host"
        });
        room.getRecommendList(this);
    },

    clickShowChat: function clickShowChat() {
        this.setData({
            activeTab: "chat"
        });
    },

    clickFollow: function clickFollow() {
        console.log('暂时不能订阅!');
        swan.showToast({ title: '订阅成功' });
        this.clickFollow = function () {
            swan.showToast({ title: '已订阅' });
        };
        // room.clickFollow(this);
    },


    clickRecommend: function clickRecommend(e) {
        room.redirectTo(e.currentTarget.dataset);
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function onShareAppMessage() {
        var shareData = {
            title: this.roomInfo.shareInfo.programName,
            imageUrl: this.roomInfo.shareInfo.cover.replace("_480_270", "_480_360"),
            path: 'pages/w/room?roomId=' + this.roomInfo.roomId
        };
        return shareData;
    },

    onClickShare: function onClickShare() {
        var shareData = {
            title: this.roomInfo.shareInfo.programName,
            content: this.roomInfo.shareInfo.description,
            imageUrl: this.roomInfo.shareInfo.cover.replace("_480_270", "_480_360"),
            path: 'pages/w/room?roomId=' + this.roomInfo.roomId
        };
        swan.openShare(shareData);
    },

    /**
     * 生命周期函数--监听页面加载
     */
    store: {
        dispatch: function dispatch() {}
    },
    // isMultiAccount: mutiAccount.isMultiAccount,
    seo: function seo() {
        _util2.default.seo({
            desc: this.roomInfo.anchorNickname + '_' + this.roomInfo.roomTitle + '_' + this.roomInfo.subTitle + '\u76F4\u64AD_\u7231\u5947\u827A\u76F4\u64AD-\u7231\u5947\u827A',
            keywords: this.roomInfo.anchorNickname + ',' + this.roomInfo.anchorNickname + '\u76F4\u64AD,' + this.roomInfo.anchorNickname + '\u76F4\u64AD\u95F4,' + this.roomInfo.anchorNickname + '\u76F4\u64AD\u5730\u5740\uFF0C' + this.roomInfo.anchorNickname + ' ' + this.roomInfo.subTitle + '\uFF0C' + this.roomInfo.anchorNickname + ' ' + this.roomInfo.subTitle + '\u76F4\u64AD\uFF0C' + this.roomInfo.anchorNickname + ' ' + this.roomInfo.subTitle + '\u89C6\u9891',
            title: this.roomInfo.anchorNickname + '_' + this.roomInfo.roomTitle + '_' + this.roomInfo.subTitle + '\u76F4\u64AD_\u7231\u5947\u827A\u76F4\u64AD-\u7231\u5947\u827A',
            video: {
                url: 'pages/w/room?roomId=' + this.roomInfo.roomId,
                duration: 3600,
                image: this.roomInfo.shareInfo.cover.replace("_480_270", "_480_360")
            }
        });
    },
    onLoad: function onLoad(opt) {
        this.trigger = new _Emitter2.default();
        this.roomInfo = {};
        this.components = {};
        this.setData({
            "roomId": opt.roomId,
            "reqSuccess": false
        });
        this.sensor = {};
        this.sensorInit();
        this.reqInit();
    },
    sensorInit: function sensorInit() {
        var globalData = getApp().globalData;
        this.sensor = new _jsSensor2.default({
            pl: globalData.pl || '2_24_200_3',
            t: globalData.tl || 'bd_ios',
            version: globalData.version || '2.01.05', //baidu mini pro version 
            device_id: user.getDeviceId() || '',
            userId: '',
            url: '/v1/live/initial',
            roomId: this.data.roomId
        }, swan);
    },
    reqInit: function reqInit() {
        var _this = this;

        var conStart = new Date().getTime();
        req.getRoomInfo(this.data.roomId).then(function (res) {
            _this.setData({
                "reqSuccess": true
            });
            var conEnd = new Date().getTime();
            _this.sensor.push(_this.sensor.CODE.ROOM_INITIAL_SUCCESS, res.code, conEnd - conStart, 0, '', '' + res.msg);

            if (res.code === "A00000") {
                _this.roomInfo = res.data;
                _this.roomInfo.qpId = res.data.programInfo.qipuId;
                _this.roomInfo.roomStatus = res.data.programInfo.playStatus;
                _this.roomInfo.roomId = res.data.programInfo.roomId;
                _this.roomInfo.liveTypeId = res.data.programInfo.liveTypeId;
                _this.roomInfo.liveSubTypeId = res.data.programInfo.liveSubTypeId;
                _this.roomInfo.chatRoomId = res.data.chatInfo.chatRoomId;

                _this.roomInfo.anchorNickname = res.data.anchorInfo.anchorNickName;
                _this.roomInfo.roomTitle = res.data.programInfo.programName;
                _this.roomInfo.subTitle = res.data.programInfo.liveTypeName;

                _this.roomInfo.shareInfo = res.data.shareInfo;

                _this._tabDisplay(res.data.tabControl);
                //添加到本地缓存历史记录
                _util2.default.record({
                    roomId: res.data.programInfo.roomId,
                    qipuId: res.data.programInfo.qipuId,
                    coverImageUrl: res.data.programInfo.coverImageUrl || res.data.shareInfo.cover.replace("_480_270", "_480_360"),
                    liveType: 1,
                    playNumber: res.data.programInfo.playNumber,
                    title: res.data.programInfo.programName || res.data.programInfo.description,
                    nickname: res.data.anchorInfo.anchorNickName,
                    recordTime: new Date().getTime()
                });

                var params = {
                    roomTitle: res.data.programInfo.programName,
                    roomStatus: res.data.programInfo.playStatus, //0: 未知, 1：未开始，2：直播，3:回看中,4:回看结束 （新增）,5:轮播中, -1 禁播中  ### 对应合并 "roomStatus": 1, // 0.停播中 1.直播中 2禁播中 3轮播中,
                    followed: res.data.anchorInfo.isFollowed,
                    followNum: utils.shortNum(res.data.anchorInfo.anchorFollowerNum),
                    liveTypeName: res.data.programInfo.liveTypeName,
                    liveSubTypeName: res.data.programInfo.liveSubTypeName,
                    hostInfo: {
                        "anchorIcon": res.data.anchorInfo.anchorIcon,
                        "nickname": res.data.anchorInfo.anchorNickName,
                        // "wallet": utils.shortNum(res.data.wallet),// 身价
                        // "populaty": utils.shortNum(res.data.populaty), // 热度
                        "info": res.data.programInfo.description
                    }
                };
                _this.seo();
                _this.setData(params);
                _this.setData({ 'previewCover': res.data.programInfo.coverImageUrl || 'http://www.iqiyipic.com/common/fix/wx-iqiyi/player-tip-bg.jpg' });
                swan.setNavigationBarTitle({
                    title: res.data.programInfo.programName
                });
                _this.components.playerControl = new _playerAction2.default(_this);
                // 拉取最后几条聊天记录
                req.getLatestMsg(_this.roomInfo.chatRoomId).then(function (data) {
                    _this.roomInfo.latestMsg = data;
                    _this.components.sendBox = new _sendMsgAction2.default(_this);
                    _this.components.msgBox = new _msgAction2.default(_this, res.data.chatInfo.chatRoomId);
                }).catch(function (err) {
                    console.error(err);
                });
                _this.eventTester("canplaythrough", function (e) {
                    console.log('canplaythrough');
                });
            } else {
                if (res.code === "A00005") {
                    console.error('\u9700\u8981\u6295\u9012\u7684', res.msg); // TODO 投递
                    _this.sensor.push(_this.sensor.CODE.ROOM_INITIAL_ERR, res.code, conEnd - conStart, 0, '', '' + res.msg);
                }
                _this.components.playerControl = new _playerAction2.default(_this);
                _this.setData({
                    errRoom: true, //房间错误
                    video: {
                        show: false,
                        errorInfo: true,
                        errorMsg: res.msg || '视频不能播放'
                    },
                    previewCover: 'http://www.iqiyipic.com/common/fix/wx-iqiyi/player-tip-bg.jpg'
                });
            }
        }, function (res) {
            console.log(res);
        });
    },
    otherSmartProgram: function otherSmartProgram() {
        swan.navigateToSmartProgram({
            appKey: 'FSTodu0UiA5MGU5CUp31WyvmZtxt905Y', // 要打开的小程序 App Key
            path: 'pages/w/room?roomId=' + this.roomInfo.roomId,
            // path: '', // 打开的页面路径，如果为空则打开首页
            extraData: {
                // roomId: 52581
            },
            success: function success(res) {
                console.log(res);
                // 打开成功
            },
            complete: function complete() {
                swan.showModal({ title: '123321' });
                // 打开成功
            }
        });
    },
    _tabDisplay: function _tabDisplay(tabList) {
        var _this2 = this;

        tabList.forEach(function (item) {
            if (item.displayName === '主播' && item.enable) {
                _this2.data.tab.host = true;
            } else if (item.displayName === '聊天' && item.enable) {
                _this2.data.tab.chat = true;
            }
            _this2.setData({ tab: _this2.data.tab });
        });
        if (!this.data.tab.chat && this.data.tab.host) {
            this.data.activeTab = 'host';
            this.setData({ activeTab: 'host' });
            room.getRecommendList(this);
        }
    },

    eventTester: function eventTester(e, eventHanler) {
        var Media = document.getElementById('videoId');
        Media.addEventListener(e, function () {
            eventHanler && eventHanler();
            out.debug(new Date().getTime(), e);
        }, false);
    },

    afterLoginTrigger: function afterLoginTrigger() {
        swan.showToast({
            title: '\u767B\u5F55\u6210\u529F',
            icon: 'none'
        });
        room.refreshInfo(this);
        this.trigger.emit("afterLoginSuccess");
    },

    afterLogoutTrigger: function afterLogoutTrigger() {
        room.resetFollowBtn(this);
        this.trigger.emit("afterLogoutSuccess");
    },

    loginSuccess: function loginSuccess() {
        this.trigger.emit("afterGetUserInfo");
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function onReady() {
        // console.log('onReady');
        var page = this;
        // this.setData({
        //     scrollHeight: room.getScrollHeight(),
        //     roomInfoHeight: room.getRoomInfoHeight(),
        //     inputFitClass: room.getInputFitClass()
        // });
        room.getScrollHeight(page);
        room.getRoomInfoHeight(page);
        room.getInputFitClass(page);
        // getApp().emitter.on("afterLoginSuccess", this.afterLoginTrigger);
        // getApp().emitter.on("afterLogoutSuccess", this.afterLogoutTrigger);
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function onShow() {
        this.trigger.emit("showPage");
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function onHide() {
        // getApp().emitter.emit("hidePage");
        this.trigger.emit("hidePage");
    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function onUnload() {
        this.trigger.emit("pageUnload");
        // console.log(this.trigger);
        this.trigger.off();
        this.setData({
            errorTip: true,
            activeTab: "chat",
            // roomId: null,
            hostInfo: null,
            // msgList: [{
            //     type: 0,
            //     content: "正在准备弹幕"
            // }],
            scrollHeight: 100,
            scrollHideLoadMore: true,
            scrollAnimation: false,
            inputFocus: false,
            inputText: "",
            inputAvailable: "",
            showKeyboard: "",
            videoBodyTop: 0,
            keyboardHeight: 0,
            video: {
                needVIP: false,
                needLogin: false,
                show: false,
                offline: false,
                url: ""
            }
        });
        // getApp().emitter.off("afterLoginSuccess", this.afterLoginTrigger);
        // getApp().emitter.off("afterLogoutSuccess", this.afterLogoutTrigger);
    }
};
Page(Object.assign({}, page));
});
window.define('113', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _roomAction = __webpack_require__(114);

var room = _interopRequireWildcard(_roomAction);

var _reqService = __webpack_require__(40);

var req = _interopRequireWildcard(_reqService);

var _playerAction = __webpack_require__(75);

var _playerAction2 = _interopRequireDefault(_playerAction);

var _msgAction = __webpack_require__(74);

var _msgAction2 = _interopRequireDefault(_msgAction);

var _sendMsgAction = __webpack_require__(73);

var _sendMsgAction2 = _interopRequireDefault(_sendMsgAction);

var _praiseAction = __webpack_require__(116);

var _praiseAction2 = _interopRequireDefault(_praiseAction);

var _utils = __webpack_require__(54);

var utils = _interopRequireWildcard(_utils);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

var _Emitter = __webpack_require__(53);

var _Emitter2 = _interopRequireDefault(_Emitter);

var _jsSensor = __webpack_require__(59);

var _jsSensor2 = _interopRequireDefault(_jsSensor);

var _user = __webpack_require__(38);

var user = _interopRequireWildcard(_user);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

// import mutiAccount from '../../../components/mutiAccount/mutiAccount'

var app = getApp();
// import PlayerControl from './actions/playerAction';

var page = {
    /**
     * 页面的初始数据
     */
    data: {
        errorTip: true,
        activeTab: "chat",
        roomId: null,
        hostInfo: null,
        msgList: [{
            type: 0,
            content: "正在链接聊天室......"
        }],
        scrollHeight: 100,
        scrollHideLoadMore: true,
        scrollAnimation: false,
        inputFocus: false,
        inputText: "",
        inputAvailable: "",
        showKeyboard: "",
        videoBodyTop: 0,
        video: {
            needVIP: false,
            needLogin: false,
            show: false,
            offline: false
        },
        previewCover: '',
        roomStatus: 0,
        followed: false,
        recommendList: [],
        keyboardHeight: 0,
        open: false,
        errRoom: false, //房间 init error 
        canPraise: false // 是否可以点赞 
    },
    clickFollow: function clickFollow() {
        console.log('不能订阅!');
        return;
        room.clickFollow(this);
    },
    clickRecommend: function clickRecommend(e) {
        room.redirectTo(e.currentTarget.dataset);
    },
    destroyed: function destroyed() {
        // 销毁 定时器事件
        this.components.playerControl && this.components.playerControl.destroyed && this.components.playerControl.destroyed();
        this.components.msgBox && this.components.msgBox.destroyed && this.components.msgBox.destroyed();
    },

    clickMultiLive: function clickMultiLive(e) {
        this.destroyed();
        var dataset = e.currentTarget.dataset;
        if (dataset.roomid == this.data.roomId) {
            return;
        }
        _util2.default.jump('/pages/s/room?roomId=' + dataset.roomid);
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function onShareAppMessage() {
        var shareData = {
            title: this.roomInfo.shareInfo.programName,
            content: this.roomInfo.shareInfo.description,
            imageUrl: this.roomInfo.shareInfo.cover.replace("_480_270", "_480_360"),
            path: 'pages/s/room?roomId=' + this.roomInfo.roomId
        };
        return shareData;
    },

    onClickShare: function onClickShare() {
        var shareData = {
            title: this.roomInfo.shareInfo.programName,
            content: this.roomInfo.shareInfo.description,
            imageUrl: this.roomInfo.shareInfo.cover.replace("_480_270", "_480_360"),
            path: 'pages/s/room?roomId=' + this.roomInfo.roomId
        };
        swan.openShare(shareData);
    },
    /**
     * 生命周期函数--监听页面加载
     */
    store: {
        dispatch: function dispatch() {}
    },
    // isMultiAccount: mutiAccount.isMultiAccount,
    seo: function seo() {
        _util2.default.seo({
            desc: this.roomInfo.roomTitle + '_\u76F4\u64AD_\u7231\u5947\u827A\u76F4\u64AD-\u7231\u5947\u827A',
            keywords: this.roomInfo.roomTitle + ',' + this.roomInfo.roomTitle + '_\u76F4\u64AD,' + this.roomInfo.roomTitle + '\u76F4\u64AD\u95F4,' + this.roomInfo.roomTitle + '\u76F4\u64AD\u5730\u5740\uFF0C' + this.roomInfo.roomTitle + '\u76F4\u64AD\uFF0C' + this.roomInfo.roomTitle + '\u89C6\u9891',
            title: this.roomInfo.roomTitle + '_\u76F4\u64AD_\u7231\u5947\u827A\u76F4\u64AD-\u7231\u5947\u827A'
        });
    },
    sensorInit: function sensorInit() {
        var globalData = getApp().globalData;
        this.sensor = new _jsSensor2.default({
            pl: globalData.pl || '2_24_200_3',
            t: globalData.tl || 'bd_ios',
            version: globalData.version || '2.01.05', //baidu mini pro version 
            device_id: user.getDeviceId() || '',
            userId: '',
            url: '/v1/live/initial',
            roomId: this.data.roomId
        }, swan);
    },
    canPraiseHandler: function canPraiseHandler(bool) {
        this.setData({
            "canPraise": bool || false
        });
    },
    onLoad: function onLoad(opt) {
        // console.log('opt:\t', opt);
        // opt.roomId = '37542';
        opt = { roomId: opt && opt.roomId || this.roomInfo && this.roomInfo.qipuId || '' };
        this.trigger = new _Emitter2.default();
        getApp().emitter = this.trigger;
        this.roomInfo = {};
        this.components = {};
        this.setData({
            "roomId": opt.roomId
        });
        this.canPraiseHandler(); //默认不能点赞
        if (opt.env) {
            req.setENV("test");
        }
        this.sensor = {};
        this.sensorInit();
        this.reqInit(opt);
    },
    reqInit: function reqInit(opt) {
        var _this = this;

        var conStart = new Date().getTime();
        req.getRoomInfo(opt.roomId).then(function (res) {
            var conEnd = new Date().getTime();
            _this.sensor.push(_this.sensor.CODE.ROOM_INITIAL_SUCCESS, res.code, conEnd - conStart, 0, '', '' + res.msg);

            if (res.code === "A00000") {
                _this.roomInfo = res.data;
                _this.roomInfo.roomId = res.data.programInfo.qipuId;
                _this.roomInfo.qpId = res.data.programInfo.qipuId;
                _this.roomInfo.qipuId = res.data.programInfo.qipuId;
                _this.roomInfo.liveChannelId = res.data.programInfo.liveChannelId;
                _this.roomInfo.roomStatus = res.data.programInfo.playStatus;
                _this.roomInfo.playStatus = res.data.programInfo.playStatus;
                // this.roomInfo.roomId = res.data.programInfo.roomId;//pgc 独有
                // this.roomInfo.liveTypeId = res.data.programInfo.liveTypeId;//pgc 独有
                // this.roomInfo.liveSubTypeId = res.data.programInfo.liveSubTypeId;//pgc 独有
                _this.roomInfo.chatRoomId = res.data.chatInfo.chatRoomId;
                _this.roomInfo.startPlayTime = res.data.chatInfo.chatRoomId;

                // this.roomInfo.anchorNickname = res.data.anchorInfo.anchorNickName;//pgc 独有
                // this.roomInfo.subTitle = res.data.programInfo.liveTypeName;//pgc 独有

                _this.roomInfo.shareInfo = res.data.shareInfo;
                var recordObj = {
                    roomId: res.data.programInfo.roomId || res.data.programInfo.qipuId,
                    qipuId: res.data.programInfo.qipuId || res.data.programInfo.roomId,
                    coverImageUrl: res.data.programInfo.coverImageUrl || res.data.shareInfo.cover.replace("_480_270", "_480_360"),
                    liveType: 2,
                    playNumber: res.data.programInfo.playNumber,
                    title: res.data.programInfo.programName || res.data.programInfo.description,
                    // nickname: res.data.anchorInfo.anchorNickName,//不能添加这个字段 因为这个字段的对象不存在 会导致后续代码崩溃 停止执行
                    recordTime: new Date().getTime()
                };
                _util2.default.record(recordObj);
                var params = {
                    qipuId: res.data.programInfo.qipuId,
                    roomTitle: res.data.programInfo.programName || res.data.programInfo.description,
                    roomStatus: res.data.programInfo.playStatus, //0: 未知, 1：未开始，2：直播，3:回看中,4:回看结束 （新增）,5:轮播中, -1 禁播中  ### 对应合并 "roomStatus": 1, // 0.停播中 1.直播中 2禁播中 3轮播中,
                    // followed: res.data.anchorInfo.isFollowed,//pgc 独有
                    // followNum: utils.shortNum(res.data.anchorInfo.anchorFollowerNum),//pgc 独有
                    // liveTypeName: res.data.programInfo.liveTypeName,//pgc 独有
                    // liveSubTypeName: res.data.programInfo.liveSubTypeName,//pgc 独有
                    hostInfo: {
                        // "anchorIcon": res.data.anchorInfo.anchorIcon,//pgc 独有
                        // "nickname": res.data.anchorInfo.anchorNickName,//pgc 独有
                        // "wallet": utils.shortNum(res.data.wallet),// 身价
                        // "populaty": utils.shortNum(res.data.populaty), // 热度
                        "info": res.data.programInfo.description || res.data.programInfo.programName,
                        "hot": res.data.programInfo.playNumber
                    },
                    multiLiveInfo: res.data.multiLiveInfo, // 多机位数据
                    chatShouldDisplay: res.data.chatInfo.shouldDisplay,
                    switcher: res.data.switcher //很多开关  包括 点赞总开关
                    // startPlayTime: _.time.format(res.data.programInfo.startPlayTime, 'yyyy-MM-dd hh:mm')
                };

                var startPlayTime = new Date(res.data.programInfo && res.data.programInfo.startPlayTime || null);
                params['startPlayTime'] = _util2.default.time.format(startPlayTime, 'MM-dd hh:mm');

                _this.seo();
                _this.setData(params);

                // this.setData({ 'previewCover': res.data.programInfo.coverImageUrl || 'http://www.iqiyipic.com/common/fix/wx-iqiyi/player-tip-bg.jpg' })
                _this.setData({ 'previewCover': res.data.shareInfo.cover || 'http://www.iqiyipic.com/common/fix/wx-iqiyi/player-tip-bg.jpg' });
                swan.setNavigationBarTitle({
                    title: res.data.programInfo.programName
                });
                _this.components.praiseControl = new _praiseAction2.default(_this, res.data.praiseInfo);
                _this.components.playerControl = new _playerAction2.default(_this);
                // 拉取最后几条聊天记录
                // 聊天的是否需要展示 不展示 也需要 WS 链接
                req.getLatestMsg(_this.roomInfo.chatRoomId).then(function (data) {
                    _this.roomInfo.latestMsg = data;
                    _this.components.sendBox = new _sendMsgAction2.default(_this);
                    _this.components.msgBox = new _msgAction2.default(_this, res.data.chatInfo.chatRoomId);
                }).catch(function (err) {
                    console.error(err);
                    if (params.multiLiveInfo) {
                        _this.swchOpen(); // 打开多机位
                    }
                });
                _this.eventTester("canplaythrough", function (e) {
                    console.log('canplaythrough');
                });
            } else {
                if (res.code === "A00005") {
                    console.error('\u9700\u8981\u6295\u9012\u7684', res.msg); // TODO 投递
                    _this.sensor.push(_this.sensor.CODE.ROOM_INITIAL_ERR, res.code, conEnd - conStart, 0, '', '' + res.msg);
                }
                _this.components.playerControl = new _playerAction2.default(_this);
                _this.setData({
                    errRoom: true, //房间错误
                    video: {
                        show: false,
                        errorInfo: true,
                        errorMsg: res.msg || '视频不能播放'
                    },
                    previewCover: 'http://www.iqiyipic.com/common/fix/wx-iqiyi/player-tip-bg.jpg'
                });
            }
        }, function (res) {
            console.log(res);
        });
    },

    eventTester: function eventTester(e, eventHanler) {
        var Media = document.getElementById('videoId');
        Media.addEventListener(e, function () {
            eventHanler && eventHanler();
            out.debug(new Date().getTime(), e);
        }, false);
    },
    swchOpen: function swchOpen() {
        var _this2 = this;

        // 切换机位显示
        this.setData({ 'open': !this.data.open }, function () {
            if (_this2.data.multiLiveInfo) {
                if (!_this2.data.open) {
                    room.getRoomInfoHeight(_this2, false);
                } else {
                    room.getRoomInfoHeight(_this2, true);
                }
            } else {
                room.getRoomInfoHeight(_this2);
            }
        });
    },

    afterLoginTrigger: function afterLoginTrigger() {
        swan.showToast({
            title: '\u767B\u5F55\u6210\u529F',
            icon: 'none'
        });
        room.refreshInfo(this);
        this.trigger.emit("afterLoginSuccess");
    },

    afterLogoutTrigger: function afterLogoutTrigger() {
        room.resetFollowBtn(this);
        this.trigger.emit("afterLogoutSuccess");
    },

    loginSuccess: function loginSuccess() {
        this.trigger.emit("afterGetUserInfo");
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function onReady() {
        var page = this;
        // this.setData({
        //     scrollHeight: room.getScrollHeight(),
        //     roomInfoHeight: room.getRoomInfoHeight(),
        //     inputFitClass: room.getInputFitClass()
        // });
        room.getScrollHeight(page);
        room.getRoomInfoHeight(page);
        room.getInputFitClass(page);
        // getApp().emitter.on("afterLoginSuccess", this.afterLoginTrigger);
        // getApp().emitter.on("afterLogoutSuccess", this.afterLogoutTrigger);
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function onShow() {
        this.trigger.emit("showPage");
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function onHide() {
        getApp().emitter.emit("hidePage");
        this.trigger.emit("hidePage");
    },

    onError: function onError(aaa) {
        console.warn(aaa);
    },


    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function onUnload() {
        this.trigger.emit("pageUnload");
        this.trigger.off();
        this.setData({
            errorTip: true,
            activeTab: "chat",
            roomId: null,
            hostInfo: null,
            msgList: [{
                type: 0,
                content: "正在链接聊天室......"
            }],
            scrollHeight: 100,
            scrollHideLoadMore: true,
            scrollAnimation: false,
            inputFocus: false,
            inputText: "",
            inputAvailable: "",
            showKeyboard: "",
            videoBodyTop: 0,
            keyboardHeight: 0,
            video: {
                needVIP: false,
                needLogin: false,
                show: false,
                offline: false,
                url: ""
            }
        });
        // getApp().emitter.off("afterLoginSuccess",this.afterLoginTrigger);
        // getApp().emitter.off("afterLogoutSuccess", this.afterLogoutTrigger);
    }
};
Page(Object.assign({}, page));
});
window.define('120', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _userInfo = __webpack_require__(36);

var user = _interopRequireWildcard(_userInfo);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

var _phonenumberLib = __webpack_require__(121);

var _phonenumberLib2 = _interopRequireDefault(_phonenumberLib);

var _reqService = __webpack_require__(122);

var req = _interopRequireWildcard(_reqService);

var _rsaUtil = __webpack_require__(42);

var _rsaUtil2 = _interopRequireDefault(_rsaUtil);

var _session = __webpack_require__(32);

var _session2 = _interopRequireDefault(_session);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
// import actions from "./actions/index"


var app = getApp();

var isPhone = function isPhone(username) {
    var font = /[\u4E00-\u9FA5]/;
    var char = /[A-Za-z]/;
    return !(char.test(username) || font.test(username));
};

var page = {
    data: {
        area_idx: 0,
        area_range: req.getDefaultArea(),
        curpage: 'swan_zhlogin',
        error: {
            show: false,
            msg: ''
        },
        login_disabled: true,
        username: '', //17621037089
        img_code: {
            show: false,
            code: '',
            value: ''
        },
        userInfo: {}
    },

    onShow: function onShow() {},
    onReady: function onReady() {},
    onLoad: function onLoad() {
        this.loadPage();
    },
    loadPage: function loadPage() {
        this._getAreaInfo({ local: 1, enable_oversea: 1 });
    },
    _loadedPage: function _loadedPage(data) {
        // 渲染后回调
        _util2.default.seo(); //默认 SEO
    },
    jump: function jump(event) {
        // swan.switchTab({url:'/pages/my/my'});
        // _.jump(`pages/my/my`);
        // return;
        var target = event.currentTarget;
        var url = target.dataset.url;
        _util2.default.jump(url);
    },

    // init area range
    _getAreaInfo: function _getAreaInfo(params) {
        var _this = this;

        req.getAreaCode(params).then(function (data) {
            // console.log(req.formatArea(data));
            _this.setData(Object.assign({}, req.formatArea(data)), function () {
                _this.validate();
            });
        });
    },
    // hanle area change
    areaChange: function areaChange(e) {
        var area_idx = e.detail.value;

        this.setData({ area_idx: area_idx });
    },
    // handle input change
    inputChange: function inputChange(e) {
        var _setData;

        // console.log(e);
        var type = e.currentTarget.dataset.type,
            _e$detail$value = e.detail.value,
            value = _e$detail$value === undefined ? '' : _e$detail$value;
        var error = this.data.error;
        // 输入时取消错误提示

        error.show && (error.show = false);
        this.setData((_setData = {}, _defineProperty(_setData, type, value), _defineProperty(_setData, "error", error), _setData));
        this.validate();
    },
    // handle input blur
    inputBlur: function inputBlur(e) {
        var _data = this.data,
            error = _data.error,
            login_disabled = _data.login_disabled;

        if (!login_disabled) return;
        error.show = true;
        this.setData({ error: error });
    },
    // validate username & pwd
    validate: function validate() {
        var _data2 = this.data,
            username = _data2.username,
            area_range = _data2.area_range,
            area_idx = _data2.area_idx,
            error = _data2.error;
        var acode = area_range[area_idx].acode;

        var login_disabled = false;

        if (!username) {
            login_disabled = true;
            error.msg = '手机号不能为空';
        } else {
            if (isPhone(username)) {
                var _phonenumberLib$phone = _phonenumberLib2.default.phoneNumberParser(username.replace(/[^0-9]+/g, ''), acode),
                    reason = _phonenumberLib$phone.reason,
                    isPossible = _phonenumberLib$phone.isPossible,
                    isNumberValid = _phonenumberLib$phone.isNumberValid;

                if (!!reason || !isPossible || !isNumberValid) {
                    login_disabled = true;
                    error.msg = '手机号格式错误,请重新输入';
                }
            }
        }
        this.setData({ error: error, login_disabled: login_disabled });
        return { error: error, login_disabled: login_disabled };
    },
    // goto login
    getMessage: function getMessage() {
        var _this2 = this;

        var _data3 = this.data,
            username = _data3.username,
            area_range = _data3.area_range,
            area_idx = _data3.area_idx,
            error = _data3.error;
        var acode = area_range[area_idx].acode;


        var tokens = this.data.tokens || '';
        var pagefrom = this.data.pagefrom || '';
        var delta = this.data.delta || '';

        var phoneNum = this.data.username || '';

        var login_disabled = this.data.login_disabled;

        if (login_disabled) {
            return;
        }

        var phoneType = this.data.phoneType || '';
        var requestType = 22;
        var params = {
            requestType: requestType,
            // qd_sc:// 加密函数
            // agenttype
            // ptid
            cellphoneNumber: _rsaUtil2.default.RSAEncryption(phoneNum),
            area_code: acode,
            serviceId: 1,
            dfp: user.getDeviceId(),
            QC005: user.getDeviceId(),
            nr: 1
        };

        if (this.getMessage.requesting) {
            return;
        }
        this.getMessage.requesting = true;

        if (swan.showLoading) {
            swan.showLoading({
                title: '加载中',
                mask: true
            });
        }

        var messageCodeInputUrl = "pages/messageCodeInput/messageCodeInput?tokens=" + tokens + "&area_code=" + acode + "&phone=" + phoneNum + "&requestType=" + requestType + "&pagefrom=" + pagefrom + "&delta=" + delta + "&phoneType=" + phoneType;

        // swan.hideLoading();//TODO 测试不获取验证码 直接跳转过去
        // _.jump(messageCodeInputUrl)
        // return;

        req.getPhoneCodeInfo(params).then(function (data) {
            console.log(data);
            if (swan.hideLoading) {
                swan.hideLoading();
            }
            if (data.code === 'A00000') {
                _util2.default.jump(messageCodeInputUrl);
            } else {
                if (data.code === 'P00223') {
                    swan.showToast({
                        title: "\u8D26\u53F7\u5B58\u5728\u5B89\u5168\u98CE\u9669\uFF0C\u8BF7\u5C3D\u5FEB\u9000\u767B\u5176\u4ED6\u8BBE\u5907\u6216\u7ACB\u5373\u4FEE\u6539\u5BC6\u7801",
                        icon: 'none'
                    });
                } else {
                    swan.showToast({
                        title: "" + data.msg,
                        icon: 'none'
                    });
                }
            }

            //改变按钮状态
            _this2.data.login_disabled = false;
            _this2.setData({ login_disabled: _this2.data.login_disabled });
            setTimeout(function () {
                _this2.getMessage.requesting = false;
            }, 0);
        }, function (error) {
            console.error(error);
            _this2.getMessage.requesting = false;
            swan.showToast({
                title: "" + error.msg,
                icon: 'none'
            });
            //改变按钮状态
            _this2.data.login_disabled = false;
            _this2.setData({ login_disabled: _this2.data.login_disabled });
        });
    }

};

Page(Object.assign({}, page));
});
window.define('124', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _session = __webpack_require__(32);

var _session2 = _interopRequireDefault(_session);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var app = getApp();
var globalData = app.globalData;
var originIcon = 'https://www.iqiyipic.com/common/fix/headicons/male-130.png';

var page = {
    data: {},
    onShow: function onShow() {},
    loginOut: function loginOut() {
        var _this = this;

        console.log(globalData);
        swan.showModal({
            title: '退出登录',
            cancelColor: '#999999',
            confirmColor: '#0099cc',
            success: function success(res) {
                if (res.confirm) {
                    console.log('用户点击了确定');
                    _this._updateUserInfo();
                } else if (res.cancel) {
                    console.log('用户点击了取消');
                }
            }
        });
    },
    _updateUserInfo: function _updateUserInfo() {
        this.setData('loginInfo.isLogin', false);
        this.setData('loginInfo.user.icon', originIcon);
        this.setData('loginInfo.user.nickname', '');
        this.setData('loginInfo.user.isVip', false);
        globalData.authCookie = '';
        _session2.default.Session.clear();
        _util2.default.jump({ 'type': 'back' });
    },
    jump: function jump(event) {
        var target = event.currentTarget;
        var url = target.dataset.url;
        // console.log(target);
        _util2.default.jump(url);
    },
    onReady: function onReady() {},
    onLoad: function onLoad() {
        // user.init();
    }
};

Page(Object.assign({}, page));
});
window.define('125', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

var _runMacine = __webpack_require__(35);

var _runMacine2 = _interopRequireDefault(_runMacine);

var _jump = __webpack_require__(61);

var _jump2 = _interopRequireDefault(_jump);

var _userInfo = __webpack_require__(36);

var user = _interopRequireWildcard(_userInfo);

var _rsaUtil = __webpack_require__(42);

var _rsaUtil2 = _interopRequireDefault(_rsaUtil);

var _serviceApi = __webpack_require__(31);

var serviceApi = _interopRequireWildcard(_serviceApi);

var _session = __webpack_require__(32);

var _session2 = _interopRequireDefault(_session);

var _object = __webpack_require__(39);

var object = _interopRequireWildcard(_object);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var app = getApp();
var CELLPHONE_LOGIN_URL = _util2.default.OUTERHOST.PASSPORT + '/apis/reglogin/cellphone_authcode_login.action';
var page = {
    data: {
        options: {},
        info: {
            area_code: 86,
            phone: '13899997777',
            showPhone: '138****7777',
            phonecode: '',
            resend: false
        },
        isFocus: true
    },
    onShow: function onShow(event) {
        var _this = this;

        // this.loadPage();
        setTimeout(function () {
            _this.set_Focus();
        }, 200);
    },
    onReady: function onReady() {},
    onLoad: function onLoad(options) {
        this.data.options = options;
        console.log(options);
        this.init();
    },
    loadPage: function loadPage() {
        console.log(12333);
    },
    _loadedPage: function _loadedPage(data) {},
    init: function init() {
        var _data$options = this.data.options,
            tokens = _data$options.tokens,
            area_code = _data$options.area_code,
            phone = _data$options.phone,
            requestType = _data$options.requestType,
            pagefrom = _data$options.pagefrom,
            delta = _data$options.delta,
            phoneType = _data$options.phoneType;

        var showPhone = phone;
        if (area_code + '' === '86') {
            showPhone = phone.substring(0, 3) + '****' + phone.substring(7);
        }
        this.data.showphone = phone;
        this.setData('info.area_code', area_code);
        this.setData('info.phone', phone);
        this.setData('info.showPhone', showPhone);
        this.setData('info.requestType', requestType);
        this.setData('info.tokens', tokens);
        this.setData('info.resend', false);
        this.countDown();
    },
    countDown: function countDown() {
        var _this2 = this;

        var time = 5;
        if (this.runObj) {
            this.setData('info.resend', true);
            _runMacine2.default.clear(this.runObj);
        }
        this.data.counts = time;
        this.runObj = _runMacine2.default.run(function () {
            if (_this2.data.counts <= 1) {
                _this2.data.counts = 0;
                _this2.setData('info.resend', true);
            }
            _this2.data.counts--;
            _this2.setData({ counts: _this2.data.counts });
        }, 1000, time);
    },
    resend: function resend() {
        _util2.default.jump({ type: 'back' });
    },
    set_Focus: function set_Focus() {
        //聚焦input
        this.setData({ isFocus: true });
        console.log('聚焦');
    },
    set_notFocus: function set_notFocus() {
        //失去焦点
        this.setData({ isFocus: false });
        console.error('失去焦点!');
    },
    set_phonecode: function set_phonecode(event) {
        var value = event.detail.value;
        if (this.verify.requesting) {
            return;
        }
        this.data.info.phonecode = value + '';
        this.setData('info.phonecode', value);
        if (value && value.length === 6) {
            this.set_notFocus();
            this.verify(value);
        }
    },
    verify: function verify(value) {
        var _this3 = this;

        var state = this.data;
        var area_code = state.info.area_code || '';
        var authCode = state.info.origincode;
        var phone = state.info.phone;
        var requestType = state.info.requestType || '';
        var tokens = state.info.tokens || '';

        var params = {
            // qd_sc:''
            agenttype: app.globalData.agenttype,
            ptid: app.globalData.ptid,
            cellphoneNumber: phone,
            area_code: area_code,
            serviceId: 1,
            device_id: user.getDeviceId(),
            dfp: user.getDeviceId(),
            authCode: value, //验证码
            requestType: requestType,
            QC005: user.getDeviceId()
        };

        params.qd_sc = _rsaUtil2.default.getQiyiQtsc(params);

        if (this.verify.requesting) {
            return;
        }
        this.verify.requesting = true;

        if (swan.showLoading) {
            swan.showLoading({
                title: '加载中',
                mask: true
            });
        }

        // let res = {
        //     authcookie: "9dPYP4iRHKTlm3syE4i9cWfOeFyrK8eExOLjpEnom1xfm2qPtV6A8MDiw67nXYSm2kzm3C314",
        //     isNewUser: false
        // }
        // this.verifySuccessHandle(res);
        // return;


        if (requestType == 22) {
            serviceApi.commonPostRequest({
                url: CELLPHONE_LOGIN_URL,
                reqParams: params
            }, true).then(function (data) {
                if (data.code === 'A00000') {
                    console.log('login success');
                    _this3.setData('info.phonecode', '');
                    _this3.setData('info.origincode', '');

                    // session.Session.set(session.SESSION_PHONE_NUMBER, phone);//写入手机号码

                    var res = data.data || {};

                    // let tempAuthCookie = '9dPYP4iRHKTlm3syE4i9cWfOeFyrK8eExOLjpEnom1xfm2qPtV6A8MDiw67nXYSm2kzm3C314';//TODO TEST authCookie
                    // let authCookie = res && res.authcookie ? res.authcookie : tempAuthCookie;
                    // http://wiki.qiyi.domain/pages/viewpage.action?pageId=176152245#id-%E5%A4%A7%E7%9B%B4%E6%92%ADEdge%E6%8E%A5%E5%8F%A3(V1)-20%E4%B8%AA%E4%BA%BA%E4%B8%AD%E5%BF%83

                    if (!res.isNewuser) {
                        console.log('\u8001\u7528\u6237');
                    } else {
                        console.log('\u6211\u662F\u65B0\u7528\u6237');
                    }
                    var _app = getApp();
                    _app.globalData.needLogin = 1;
                    _app.globalData.authCookie = res && res.authcookie || '';
                    _app.globalData.phone = phone;
                    console.log(_app.globalData);
                    // swan.switchTab({ url: '/pages/my/my' });//跳转到个人页面 ?needLogin=1&authCookie=${res && res.authcookie}&isNewuser=${res && res.isNewuser}
                    _util2.default.jump('pages/my/my');
                } else {
                    swan.showToast({ title: '' + data.msg, icon: 'none' });
                    console.log(data.msg);
                }
                setTimeout(function () {
                    swan.hideLoading && swan.hideLoading();
                    _this3.verify.requesting = false;
                }, 0);
            }, function (err) {
                if (swan.hideLoading) {
                    swan.hideLoading();
                }
                console.log(err);
                if (err.code === 'FEC000') {
                    swan.showToast({ title: '\u7F51\u7EDC\u5F02\u5E38', icon: 'none' });
                } else {
                    swan.showToast({ title: err.msg || '\u670D\u52A1\u5F02\u5E38', icon: 'none' });
                }
                _this3.verify.requesting = false;
            });
        } else if (requestType == 26) {
            phoneService.verifyPhoneCodeInfo(params).then(function (data) {
                if (swan.hideLoading) {
                    swan.hideLoading();
                }
                _this3.setData('info.phonecode', '');
                _this3.setData('info.origincode', '');
                if (data.code === 'A00000') {
                    _this3.verifySuccessHandle(data, value);
                } else {
                    swan.showToast({
                        title: '' + data.msg,
                        icon: 'none'
                    });
                }
                setTimeout(function () {
                    _this3.verify.requesting = false;
                }, 0);
            }, function (error) {
                if (swan.hideLoading) {
                    swan.hideLoading();
                }
                swan.showToast({
                    title: '\u670D\u52A1\u5F02\u5E38',
                    icon: 'none'
                });
                _this3.verify.requesting = false;
            });
        } else if (requestType == 30) {
            var deviceId = user.getAnonymousUid();
            params = Object.assign({}, params, {
                device_id: deviceId,
                authcookie: this.app.globalData.mutiAuthcookie,
                cellphoneNumber: _rsaUtil2.default.RSAEncryption(phone)
            });
            if (swan.showLoading) {
                swan.showLoading({
                    title: '加载中'
                });
            }
            this.verifyLogin(params).then(function () {
                var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

                var authcookie = _util2.default.isObject(data) ? data.authcookie : '';
                var nickname = _util2.default.isObject(data) ? data.nickname ? data.nickname : '' : '';
                if (swan.hideLoading) {
                    swan.hideLoading();
                }
                //更新authcookie
                _session2.default.Session.set(_session2.default.SESSION_AUTH_KEY, authcookie);
                _this3.mutiVerifyFlag = true;

                getApp().emitter.emit('hideMutiDialog');
                //toast提示
                _this3.showMutiAccountToast();
                _this3.setData({
                    'mutiUserName': nickname
                });
                _this3.verify.requesting = false;
                //返回原页面
                setTimeout(function () {

                    swan.navigateBack({
                        delta: 2
                    });
                }, 3000);
            }).catch(function (err) {
                _this3.verify.requesting = false;
                _this3.setData('info.phonecode', '');
                _this3.setData('info.origincode', '');
                if (swan.hideLoading) {
                    swan.hideLoading();
                }
                /*提示文案*/
                var toastMsg = '切换失败，请重试';
                if (_util2.default.isObject(err) && typeof err.code == 'string' && err.code.indexOf('FEC') == -1) {
                    toastMsg = err.msg ? err.msg : toastMsg;
                }
                swan.hideToast();
                swan.showToast({
                    title: toastMsg,
                    icon: 'none'
                });
            });
        }
    },
    jump: function jump(event) {
        var target = event.currentTarget;
        var url = target.dataset.url;
        _util2.default.jump(url);
    }
};

Page(Object.assign({}, page));
});
window.define('126', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var _user = __webpack_require__(29);

var _user2 = _interopRequireDefault(_user);

var _index = __webpack_require__(127);

var _index2 = _interopRequireDefault(_index);

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var app = getApp();
var page = {
    data: {
        load: 'none',
        record: {
            edite: true,
            showDelete: true,
            total: 10,
            list: []
        }
    },
    onPullDownRefresh: function onPullDownRefresh() {
        // 下拉刷新
        this.onLoad();
    },
    onShow: function onShow() {
        this.loadPage();
    },
    onReady: function onReady() {},
    onLoad: function onLoad() {
        this.loadPage();
    },
    loadPage: function loadPage() {
        var _this = this;

        // _.record(this.data.records);
        _util2.default.record().then(function (data) {
            var formateRecord = _index2.default.getFormateRecord(data);
            _this.setData({ records: formateRecord });
            _this.setData({ 'record.list': data, 'record.total': data.length });
        });
    },
    _loadedPage: function _loadedPage(data) {
        _util2.default.seo(); //默认 SEO 
    },
    playVideo: function playVideo(event) {
        var target = event.currentTarget;
        var roomId = target.dataset.roomId;
        var liveType = target.dataset.liveType;
        if (!roomId) {
            swan.showToast({
                icon: 'none',
                title: '数据异常'
            });
            return false;
        }
        var url = "pages/w/room?roomId=" + roomId;
        if (liveType == 2) {
            url = "pages/s/room?roomId=" + roomId;
        }
        _util2.default.jump(url);
    }
};

Page(Object.assign({}, page));
});
window.define('128', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var app = getApp();
var page = {
    onShow: function onShow() {},
    onReady: function onReady() {},
    onLoad: function onLoad() {
        var version = app.globalData.version;
        this.setData('version', version);
    }
};

Page(Object.assign({}, page));
});
window.define('129', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var app = getApp();
var page = {
    onShow: function onShow() {},
    onReady: function onReady() {},
    onLoad: function onLoad() {}
};

Page(Object.assign({}, page));
});
window.define('130', function (__webpack_require__, module, exports, define, swan, getApp, window, document, frames, self, location, navigator, localStorage, history, Caches, swaninterface) {


var app = getApp();
var page = {
    onShow: function onShow() {},
    onReady: function onReady() {},
    onLoad: function onLoad() {}
};

Page(Object.assign({}, page));
});
window.__swanRoute='pages/category/category';window.usingComponents=[];require('95');
window.__swanRoute='pages/rank/rank';window.usingComponents=[];require('98');
window.__swanRoute='pages/my/my';window.usingComponents=[];require('100');
window.__swanRoute='pages/w/room';window.usingComponents=[];require('102');
window.__swanRoute='pages/s/room';window.usingComponents=[];require('113');
window.__swanRoute='pages/login/login';window.usingComponents=[];require('120');
window.__swanRoute='pages/config/config';window.usingComponents=[];require('124');
window.__swanRoute='pages/messageCodeInput/messageCodeInput';window.usingComponents=[];require('125');
window.__swanRoute='subPackage/pages/my/playLog';window.usingComponents=[];require('126');
window.__swanRoute='subPackage/pages/my/about';window.usingComponents=[];require('128');
window.__swanRoute='subPackage/pages/login/loginProtocol';window.usingComponents=[];require('129');
window.__swanRoute='subPackage/pages/login/privateH5';window.usingComponents=[];require('130');
window.__swanRoute='pages/home/home';window.usingComponents=[];require('77');

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvaG9tZS9ob21lLmpzIiwid2VicGFjazovLy8vVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9wYWdlcy9jYXRlZ29yeS9jYXRlZ29yeS5qcyIsIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvcmFuay9yYW5rLmpzIiwid2VicGFjazovLy8vVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9wYWdlcy9teS9teS5qcyIsIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvdy9yb29tLmpzIiwid2VicGFjazovLy8vVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9wYWdlcy9zL3Jvb20uanMiLCJ3ZWJwYWNrOi8vLy9Vc2Vycy9ob3ViaW5nYmluZy9jb2RlL2lxaXlpL3FsaXZlX21pbmlwcm9ncmFtL2JhaWR1L3BhZ2VzL2xvZ2luL2xvZ2luLmpzIiwid2VicGFjazovLy8vVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9wYWdlcy9jb25maWcvY29uZmlnLmpzIiwid2VicGFjazovLy8vVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9wYWdlcy9tZXNzYWdlQ29kZUlucHV0L21lc3NhZ2VDb2RlSW5wdXQuanMiLCJ3ZWJwYWNrOi8vLy9Vc2Vycy9ob3ViaW5nYmluZy9jb2RlL2lxaXlpL3FsaXZlX21pbmlwcm9ncmFtL2JhaWR1L3N1YlBhY2thZ2UvcGFnZXMvbXkvcGxheUxvZy5qcyIsIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvc3ViUGFja2FnZS9wYWdlcy9teS9hYm91dC5qcyIsIndlYnBhY2s6Ly8vL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvc3ViUGFja2FnZS9wYWdlcy9sb2dpbi9sb2dpblByb3RvY29sLmpzIiwid2VicGFjazovLy8vVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9zdWJQYWNrYWdlL3BhZ2VzL2xvZ2luL3ByaXZhdGVINS5qcyJdLCJuYW1lcyI6WyJhcHAiLCJnZXRBcHAiLCJwYWdlIiwiZGF0YSIsImxvYWQiLCJiYW5uZXJJbmRleCIsInNlbGVjdGVkTGl2ZVN1YnR5cGVJZCIsImNoYW5uZWxzX2Ffb3RoZXIiLCJjaGFubmVsc19hX3Jvb21MaXN0IiwiY2hhbm5lbHNfYl9yb29tTGlzdCIsIm9uUHVsbERvd25SZWZyZXNoIiwib25Mb2FkIiwib25TaG93Iiwib25SZWFkeSIsImxvYWRQYWdlIiwic2V0VGltZW91dCIsImlzTG9naW4iLCJ1c2VyIiwiYWN0aW9ucyIsImdldEluZGV4RGF0YSIsIl9sb2FkZWRQYWdlIiwic3dhbiIsInN0b3BQdWxsRG93blJlZnJlc2giLCJoaWRlTG9hZGluZyIsIl8iLCJzZW8iLCJzd2lwZXJDaGFuZ2UiLCJldmVudCIsImJhbm5lciIsImdldERhdGEiLCJkZXRhaWwiLCJjdXJyZW50Iiwic2V0RGF0YSIsInNlbGVjdGVkQnRuUm9vbSIsInRhcmdldCIsImN1cnJlbnRUYXJnZXQiLCJkYXRhc2V0IiwibGl2ZVN1YnR5cGVJZCIsInJlZGlyZWN0Q2F0ZU1vcmUiLCJvYmoiLCJnbG9iYWxEYXRhIiwidGFiQ2F0ZWdvcnkiLCJsaXZlVHlwZUlkIiwibGl2ZUNoYW5uZWxOYW1lIiwiY2hhbm5lbFR5cGUiLCJsaXZlU3ViVHlwZUlkIiwianVtcCIsInBsYXlWaWRlbyIsInJvb21JZCIsImxpdmVUeXBlIiwic2hvd1RvYXN0IiwiaWNvbiIsInRpdGxlIiwidXJsIiwidXBkYXRlVmVyc2lvbiIsIlBhZ2UiLCJPYmplY3QiLCJhc3NpZ24iLCJsaXN0IiwiaG90U3ViTGlzdCIsImNhdGVnb3J5TGlzdCIsImN1cnJlbnRQYWdlIiwiY3Vyck9wdGlvbiIsIm9wZW5DYXRlU3RhdHVzIiwiY2hhbmdlU2VhcmNoU3RhdHVzIiwicHVsbERvd25SZWZyZXNoU3RhdHVzIiwiX2dldEdsb2JhbFNlbGVjdENhdGUiLCJsZW5ndGgiLCJQcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsImNvbnNvbGUiLCJsb2ciLCJfZ2V0Q2F0ZWdvcnkiLCJfc2V0UXVlcnkiLCJzd2l0Y2hDYXRlQ29tcG9uZW50cyIsImluaXRTdGF0dXMiLCJzd2l0Y2hTdWJDYXRlSGFuZGxlIiwibXlDYXRjaFRvdWNoIiwiZSIsIl9zZXRTY3JvbGxUb3AiLCJwYWdlU2Nyb2xsVG8iLCJzY3JvbGxUb3AiLCJkdXJhdGlvbiIsIm9uSGlkZSIsIm9uVGFiSXRlbVRhcCIsIml0ZW0iLCJzd2l0Y2hDYXRlQ29udHJvbCIsInNob3dMb2FkaW5nIiwibWFzayIsInVwZGF0ZUNhdGVPcHRpb24iLCJjYXRlT3B0aW9uIiwiYmluZHNjcm9sbHRvbG93ZXIiLCJvblJlYWNoQm90dG9tIiwib3BlbkNhdGVIYW5kbGUiLCJzdGF0dXMiLCJfb3BlbkNhdGVTdGF0dXMiLCJwcm90b3R5cGUiLCJ0b1N0cmluZyIsImNhbGwiLCJkYXRhTGlzdCIsInJhbmtUeXBlTGlzdCIsInJhbmtUeXBlSWQiLCJsb2FkVHlwZSIsImdldFJhbmtUeXBlRGF0YSIsIl9sb2FkZWRSYW5rVHlwZSIsInN3aXRjaFJhbmtIYW5kbGUiLCJzd2l0Y2hUaXRsZUhhbmRsZSIsIm9yaWdpbkljb24iLCJyZWNvcmRzIiwib3B0aW9ucyIsIm5lZWRMb2dpbiIsImF1dGhDb29raWUiLCJsb2dpbkluZm8iLCJuaWNrbmFtZSIsImlzVmlwIiwiX25lZWRMb2dpbiIsIl91cGRhdGVVc2VySW5mbyIsImluaXRVcGRhdGVEYXRhIiwiX2dldFVzZXJJbmZvIiwiZ2V0VXNlckluZm8iLCJrZXlzIiwicmVxIiwiYXV0aGNvb2tpZSIsInRoZW4iLCJ3YXJuIiwiZXJyIiwibG9naW5PdXQiLCJlcnJvciIsInNlc3Npb24iLCJTZXNzaW9uIiwiY2xlYXIiLCJ1c2VyaW5mbyIsInFpeWlfdmlwX2luZm8iLCJsZXZlbCIsInNldCIsIlNFU1NJT05fQVVUSF9LRVkiLCJTRVNTSU9OX0lORk9fS0VZIiwicmVjb3JkIiwicmV2ZXJzZSIsInNwbGljZSIsImNsZWFyUmVjb3JkIiwic2hvd01vZGFsIiwiY29udGVudCIsImNhbmNlbENvbG9yIiwiY29uZmlybUNvbG9yIiwic3VjY2VzcyIsInJlcyIsImNvbmZpcm0iLCJjYW5jZWwiLCJyb29tIiwidXRpbHMiLCJlcnJvclRpcCIsImFjdGl2ZVRhYiIsImhvc3RJbmZvIiwibXNnTGlzdCIsInR5cGUiLCJzY3JvbGxIZWlnaHQiLCJzY3JvbGxIaWRlTG9hZE1vcmUiLCJzY3JvbGxBbmltYXRpb24iLCJpbnB1dEZvY3VzIiwiaW5wdXRUZXh0IiwiaW5wdXRBdmFpbGFibGUiLCJzaG93S2V5Ym9hcmQiLCJ2aWRlb0JvZHlUb3AiLCJ2aWRlbyIsIm5lZWRWSVAiLCJzaG93Iiwib2ZmbGluZSIsInByZXZpZXdDb3ZlciIsInJvb21TdGF0dXMiLCJmb2xsb3dlZCIsInJlY29tbWVuZExpc3QiLCJ0YWIiLCJob3N0IiwiY2hhdCIsImtleWJvYXJkSGVpZ2h0IiwiY2xpY2tTaG93SG9zdCIsImdldFJlY29tbWVuZExpc3QiLCJjbGlja1Nob3dDaGF0IiwiY2xpY2tGb2xsb3ciLCJjbGlja1JlY29tbWVuZCIsInJlZGlyZWN0VG8iLCJvblNoYXJlQXBwTWVzc2FnZSIsInNoYXJlRGF0YSIsInJvb21JbmZvIiwic2hhcmVJbmZvIiwicHJvZ3JhbU5hbWUiLCJpbWFnZVVybCIsImNvdmVyIiwicmVwbGFjZSIsInBhdGgiLCJvbkNsaWNrU2hhcmUiLCJkZXNjcmlwdGlvbiIsIm9wZW5TaGFyZSIsInN0b3JlIiwiZGlzcGF0Y2giLCJkZXNjIiwiYW5jaG9yTmlja25hbWUiLCJyb29tVGl0bGUiLCJzdWJUaXRsZSIsImtleXdvcmRzIiwiaW1hZ2UiLCJvcHQiLCJ0cmlnZ2VyIiwiRW1pdHRlciIsImNvbXBvbmVudHMiLCJzZW5zb3IiLCJzZW5zb3JJbml0IiwicmVxSW5pdCIsIlNlbnNvciIsInBsIiwidCIsInRsIiwidmVyc2lvbiIsImRldmljZV9pZCIsImdldERldmljZUlkIiwidXNlcklkIiwiY29uU3RhcnQiLCJEYXRlIiwiZ2V0VGltZSIsImdldFJvb21JbmZvIiwiY29uRW5kIiwicHVzaCIsIkNPREUiLCJST09NX0lOSVRJQUxfU1VDQ0VTUyIsImNvZGUiLCJtc2ciLCJxcElkIiwicHJvZ3JhbUluZm8iLCJxaXB1SWQiLCJwbGF5U3RhdHVzIiwiY2hhdFJvb21JZCIsImNoYXRJbmZvIiwiYW5jaG9ySW5mbyIsImFuY2hvck5pY2tOYW1lIiwibGl2ZVR5cGVOYW1lIiwiX3RhYkRpc3BsYXkiLCJ0YWJDb250cm9sIiwiY292ZXJJbWFnZVVybCIsInBsYXlOdW1iZXIiLCJyZWNvcmRUaW1lIiwicGFyYW1zIiwiaXNGb2xsb3dlZCIsImZvbGxvd051bSIsInNob3J0TnVtIiwiYW5jaG9yRm9sbG93ZXJOdW0iLCJsaXZlU3ViVHlwZU5hbWUiLCJhbmNob3JJY29uIiwic2V0TmF2aWdhdGlvbkJhclRpdGxlIiwicGxheWVyQ29udHJvbCIsIlBsYXllckNvbnRyb2wiLCJnZXRMYXRlc3RNc2ciLCJsYXRlc3RNc2ciLCJzZW5kQm94IiwiU2VuZEJveCIsIm1zZ0JveCIsIk1lc3NhZ2VCb3giLCJjYXRjaCIsImV2ZW50VGVzdGVyIiwiUk9PTV9JTklUSUFMX0VSUiIsImVyclJvb20iLCJlcnJvckluZm8iLCJlcnJvck1zZyIsIm90aGVyU21hcnRQcm9ncmFtIiwibmF2aWdhdGVUb1NtYXJ0UHJvZ3JhbSIsImFwcEtleSIsImV4dHJhRGF0YSIsImNvbXBsZXRlIiwidGFiTGlzdCIsImZvckVhY2giLCJkaXNwbGF5TmFtZSIsImVuYWJsZSIsImV2ZW50SGFubGVyIiwiTWVkaWEiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwiYWRkRXZlbnRMaXN0ZW5lciIsIm91dCIsImRlYnVnIiwiYWZ0ZXJMb2dpblRyaWdnZXIiLCJyZWZyZXNoSW5mbyIsImVtaXQiLCJhZnRlckxvZ291dFRyaWdnZXIiLCJyZXNldEZvbGxvd0J0biIsImxvZ2luU3VjY2VzcyIsImdldFNjcm9sbEhlaWdodCIsImdldFJvb21JbmZvSGVpZ2h0IiwiZ2V0SW5wdXRGaXRDbGFzcyIsIm9uVW5sb2FkIiwib2ZmIiwib3BlbiIsImNhblByYWlzZSIsImRlc3Ryb3llZCIsImNsaWNrTXVsdGlMaXZlIiwicm9vbWlkIiwiY2FuUHJhaXNlSGFuZGxlciIsImJvb2wiLCJlbWl0dGVyIiwiZW52Iiwic2V0RU5WIiwibGl2ZUNoYW5uZWxJZCIsInN0YXJ0UGxheVRpbWUiLCJyZWNvcmRPYmoiLCJtdWx0aUxpdmVJbmZvIiwiY2hhdFNob3VsZERpc3BsYXkiLCJzaG91bGREaXNwbGF5Iiwic3dpdGNoZXIiLCJ0aW1lIiwiZm9ybWF0IiwicHJhaXNlQ29udHJvbCIsInByYWlzZUluZm8iLCJzd2NoT3BlbiIsIm9uRXJyb3IiLCJhYWEiLCJpc1Bob25lIiwidXNlcm5hbWUiLCJmb250IiwiY2hhciIsInRlc3QiLCJhcmVhX2lkeCIsImFyZWFfcmFuZ2UiLCJnZXREZWZhdWx0QXJlYSIsImN1cnBhZ2UiLCJsb2dpbl9kaXNhYmxlZCIsImltZ19jb2RlIiwidmFsdWUiLCJ1c2VySW5mbyIsIl9nZXRBcmVhSW5mbyIsImxvY2FsIiwiZW5hYmxlX292ZXJzZWEiLCJnZXRBcmVhQ29kZSIsImZvcm1hdEFyZWEiLCJ2YWxpZGF0ZSIsImFyZWFDaGFuZ2UiLCJpbnB1dENoYW5nZSIsImlucHV0Qmx1ciIsImFjb2RlIiwicGhvbmVudW1iZXJMaWIiLCJwaG9uZU51bWJlclBhcnNlciIsInJlYXNvbiIsImlzUG9zc2libGUiLCJpc051bWJlclZhbGlkIiwiZ2V0TWVzc2FnZSIsInRva2VucyIsInBhZ2Vmcm9tIiwiZGVsdGEiLCJwaG9uZU51bSIsInBob25lVHlwZSIsInJlcXVlc3RUeXBlIiwiY2VsbHBob25lTnVtYmVyIiwicnNhVXRpbCIsIlJTQUVuY3J5cHRpb24iLCJhcmVhX2NvZGUiLCJzZXJ2aWNlSWQiLCJkZnAiLCJRQzAwNSIsIm5yIiwicmVxdWVzdGluZyIsIm1lc3NhZ2VDb2RlSW5wdXRVcmwiLCJnZXRQaG9uZUNvZGVJbmZvIiwic2VydmljZUFwaSIsIm9iamVjdCIsIkNFTExQSE9ORV9MT0dJTl9VUkwiLCJPVVRFUkhPU1QiLCJQQVNTUE9SVCIsImluZm8iLCJwaG9uZSIsInNob3dQaG9uZSIsInBob25lY29kZSIsInJlc2VuZCIsImlzRm9jdXMiLCJzZXRfRm9jdXMiLCJpbml0Iiwic3Vic3RyaW5nIiwic2hvd3Bob25lIiwiY291bnREb3duIiwicnVuT2JqIiwicnVuTWFjaW5lIiwiY291bnRzIiwicnVuIiwic2V0X25vdEZvY3VzIiwic2V0X3Bob25lY29kZSIsInZlcmlmeSIsInN0YXRlIiwiYXV0aENvZGUiLCJvcmlnaW5jb2RlIiwiYWdlbnR0eXBlIiwicHRpZCIsInFkX3NjIiwiZ2V0UWl5aVF0c2MiLCJjb21tb25Qb3N0UmVxdWVzdCIsInJlcVBhcmFtcyIsImlzTmV3dXNlciIsInBob25lU2VydmljZSIsInZlcmlmeVBob25lQ29kZUluZm8iLCJ2ZXJpZnlTdWNjZXNzSGFuZGxlIiwiZGV2aWNlSWQiLCJnZXRBbm9ueW1vdXNVaWQiLCJtdXRpQXV0aGNvb2tpZSIsInZlcmlmeUxvZ2luIiwiaXNPYmplY3QiLCJtdXRpVmVyaWZ5RmxhZyIsInNob3dNdXRpQWNjb3VudFRvYXN0IiwibmF2aWdhdGVCYWNrIiwidG9hc3RNc2ciLCJpbmRleE9mIiwiaGlkZVRvYXN0IiwiZWRpdGUiLCJzaG93RGVsZXRlIiwidG90YWwiLCJmb3JtYXRlUmVjb3JkIiwiZ2V0Rm9ybWF0ZVJlY29yZCJdLCJtYXBwaW5ncyI6Ijs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7QUFFQSxJQUFNQSxNQUFNQyxRQUFaLEMsQ0FMQTs7QUFNQSxJQUFNQyxPQUFPO0FBQ1RDLFVBQU07QUFDRkMsY0FBTSxNQURKO0FBRUZDLHFCQUFhLENBRlg7QUFHRkMsK0JBQXVCLENBSHJCO0FBSUY7QUFDQUMsMEJBQWtCLEVBTGhCO0FBTUZDLDZCQUFxQixFQU5uQjtBQU9GQyw2QkFBcUI7QUFDckI7QUFSRSxLQURHO0FBV1RDLHFCQVhTLCtCQVdXO0FBQ2hCO0FBQ0EsYUFBS0MsTUFBTDtBQUNILEtBZFE7QUFlVEMsVUFmUyxvQkFlQTtBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSCxLQXJCUTtBQXNCVEMsV0F0QlMscUJBc0JDO0FBQ047QUFDQTtBQUNILEtBekJRO0FBMEJURixVQTFCUyxvQkEwQkE7QUFDTDtBQUNBO0FBQ0EsYUFBS0csUUFBTDtBQUNBO0FBQ0gsS0EvQlE7QUFnQ1RBLFlBaENTLHNCQWdDRTtBQUFBOztBQUNQQyxtQkFBVyxZQUFNO0FBQ2IsZ0JBQUlDLFVBQVVDLGVBQUtELE9BQUwsRUFBZDtBQUNBRSw0QkFBUUMsWUFBUixDQUFxQkgsT0FBckIsRUFBOEIsS0FBOUI7QUFDQSxrQkFBS0YsUUFBTCxHQUFnQixZQUFNO0FBQ2xCLG9CQUFJRSxVQUFVQyxlQUFLRCxPQUFMLEVBQWQ7QUFDQUUsZ0NBQVFDLFlBQVIsQ0FBcUJILE9BQXJCLEVBQThCLEtBQTlCO0FBQ0gsYUFIRDtBQUlILFNBUEQsRUFPRyxDQVBIO0FBUUgsS0F6Q1E7QUEwQ1RJLGVBMUNTLHVCQTBDR2pCLElBMUNILEVBMENTO0FBQ2Q7QUFDQWtCLGFBQUtDLG1CQUFMLElBQTRCRCxLQUFLQyxtQkFBTCxFQUE1QjtBQUNBRCxhQUFLRSxXQUFMO0FBQ0FDLHVCQUFFQyxHQUFGLEdBSmMsQ0FJTDtBQUNaLEtBL0NRO0FBZ0RUQyxnQkFoRFMsd0JBZ0RJQyxLQWhESixFQWdEVztBQUNoQixZQUFNQyxTQUFTLEtBQUtDLE9BQUwsQ0FBYSxRQUFiLEVBQXVCRixNQUFNRyxNQUFOLENBQWFDLE9BQXBDLENBQWY7QUFDQTtBQUNBO0FBQ0EsYUFBS0MsT0FBTCxDQUFhO0FBQ1QzQix5QkFBYXNCLE1BQU1HLE1BQU4sQ0FBYUMsT0FBYixHQUF1QjtBQUQzQixTQUFiO0FBR0gsS0F2RFE7QUF3RFRFLG1CQXhEUywyQkF3RE9OLEtBeERQLEVBd0RjO0FBQ25CLFlBQU1PLFNBQVNQLE1BQU1RLGFBQXJCO0FBQ0E7QUFDQSxhQUFLSCxPQUFMLENBQWEsdUJBQWIsRUFBc0NFLE9BQU9FLE9BQVAsQ0FBZUMsYUFBckQ7QUFDSCxLQTVEUTtBQTZEVEMsb0JBN0RTLDRCQTZEUVgsS0E3RFIsRUE2RGU7QUFDcEIsWUFBTU8sU0FBU1AsTUFBTVEsYUFBckI7QUFDQSxZQUFNSSxNQUFNTCxPQUFPRSxPQUFQLENBQWVHLEdBQTNCO0FBQ0E7QUFDQXZDLFlBQUl3QyxVQUFKLENBQWVDLFdBQWYsR0FBNkI7QUFDekJDLHdCQUFZSCxJQUFJRyxVQURTO0FBRXpCQyw2QkFBaUJKLElBQUlJLGVBRkk7QUFHekJDLHlCQUFhTCxJQUFJSyxXQUhRO0FBSXpCQywyQkFBZU4sSUFBSU0sYUFBSixJQUFxQjtBQUpYLFNBQTdCO0FBTUE7QUFDQXJCLHVCQUFFc0IsSUFBRixDQUFPLDBCQUFQO0FBQ0gsS0F6RVE7QUEwRVRDLGFBMUVTLHFCQTBFQ3BCLEtBMUVELEVBMEVRO0FBQ2IsWUFBTU8sU0FBU1AsTUFBTVEsYUFBckI7QUFDQSxZQUFNYSxTQUFTZCxPQUFPRSxPQUFQLENBQWVZLE1BQTlCO0FBQ0EsWUFBTUMsV0FBV2YsT0FBT0UsT0FBUCxDQUFlYSxRQUFoQztBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQUksQ0FBQ0QsTUFBTCxFQUFhO0FBQ1QzQixpQkFBSzZCLFNBQUwsQ0FBZTtBQUNYQyxzQkFBTSxNQURLO0FBRVhDLHVCQUFPO0FBRkksYUFBZjtBQUlBLG1CQUFPLEtBQVA7QUFDSDtBQUNELFlBQUlDLCtCQUE2QkwsTUFBakM7QUFDQSxZQUFJQyxZQUFZLENBQWhCLEVBQW1CO0FBQ2ZJLDJDQUE2QkwsTUFBN0I7QUFDSDtBQUNEeEIsdUJBQUVzQixJQUFGLENBQU9PLEdBQVA7QUFDSCxLQTdGUTtBQThGVEMsaUJBOUZTLDJCQThGTztBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBekhRLENBQWI7O0FBNkhBQyxLQUFLQyxPQUFPQyxNQUFQLENBQWMsRUFBZCxFQUFrQnZELElBQWxCLENBQUwsRTs7Ozs7QUNuSUE7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7O0FBRUEsSUFBTUYsTUFBTUMsUUFBWixDLENBQXNCO0FBQ3RCLElBQU1DLE9BQU87QUFDVEMsVUFBTTtBQUNGdUQsY0FBTSxFQURKO0FBRUZDLG9CQUFZLEVBRlYsRUFFYTtBQUNmQyxzQkFBYyxFQUhaLEVBR2dCO0FBQ2xCQyxxQkFBYSxDQUpYO0FBS0ZDLG9CQUFZO0FBQ1JwQix3QkFBWSxDQURKO0FBRVJDLDZCQUFpQixNQUZUO0FBR1JFLDJCQUFlO0FBSFAsU0FMVjtBQVVGa0Isd0JBQWdCLENBVmQsRUFVaUI7QUFDbkJDLDRCQUFvQixLQVhsQixFQVd5QjtBQUMzQkMsK0JBQXVCLEtBWnJCLENBWTJCO0FBWjNCLEtBREc7QUFlVEMsd0JBZlMsa0NBZWM7QUFBQTs7QUFDbkI7QUFDQSxZQUFJTixlQUFlNUQsSUFBSXdDLFVBQUosQ0FBZW9CLFlBQWxDO0FBQ0E7QUFDQSxZQUFHQSxnQkFBZ0JBLGFBQWFPLE1BQWIsR0FBc0IsQ0FBekMsRUFBNEM7QUFDeEMsbUJBQU8sSUFBSUMsaUJBQUosQ0FBWSxVQUFDQyxPQUFELEVBQVVDLE1BQVYsRUFBcUI7QUFDcENDLHdCQUFRQyxHQUFSLENBQWVaLGFBQWFPLE1BQTVCO0FBQ0Esc0JBQUtuQyxPQUFMLENBQWEsRUFBRSxnQkFBZ0I0QixZQUFsQixFQUFiLEVBQStDLFlBQU07QUFDakRTLDRCQUFRLFNBQVI7QUFDSCxpQkFGRDtBQUdILGFBTE0sQ0FBUDtBQU1ILFNBUEQsTUFPTztBQUNILG1CQUFPLElBQUlELGlCQUFKLENBQVksVUFBQ0MsT0FBRCxFQUFVQyxNQUFWLEVBQXFCO0FBQ3BDdEUsb0JBQUl5RSxZQUFKLENBQWlCLEtBQWpCLEVBQXdCLFVBQUNiLFlBQUQsRUFBa0I7QUFDdENXLDRCQUFRQyxHQUFSLENBQWVaLGFBQWFPLE1BQTVCO0FBQ0EsMEJBQUtuQyxPQUFMLENBQWEsRUFBRSxnQkFBZ0I0QixZQUFsQixFQUFiLEVBQStDLFlBQU07QUFDakRTLGdDQUFRLFNBQVI7QUFDSCxxQkFGRDtBQUdILGlCQUxEO0FBTUgsYUFQTSxDQUFQO0FBUUg7QUFDSixLQXBDUTtBQXFDVEssYUFyQ1MsdUJBcUNHO0FBQ1I7QUFDQSxhQUFLMUMsT0FBTCxDQUFhO0FBQ1QscUJBQVNoQyxJQUFJd0MsVUFBSixDQUFlQztBQURmLFNBQWI7QUFHSCxLQTFDUTs7QUEyQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTdCLFVBL0NTLG9CQStDQTtBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBRyxLQUFLK0Qsb0JBQUwsSUFBNkIsS0FBS0Esb0JBQUwsQ0FBMEJDLFVBQTFELEVBQXNFO0FBQ2xFO0FBQ0EsaUJBQUtDLG1CQUFMO0FBQ0g7QUFDSixLQWpFUTtBQWtFVEMsZ0JBbEVTLHdCQWtFSUMsQ0FsRUosRUFrRU87QUFDWixZQUFHLEtBQUs1RSxJQUFMLENBQVU0RCxjQUFWLEtBQTZCLENBQWhDLEVBQW1DO0FBQy9CLG1CQUFPLEtBQVA7QUFDSDtBQUNKLEtBdEVRO0FBdUVUaUIsaUJBdkVTLDJCQXVFTztBQUNaM0QsYUFBSzRELFlBQUwsQ0FBa0I7QUFDZEMsdUJBQVcsQ0FERztBQUVkQyxzQkFBVTtBQUZJLFNBQWxCO0FBSUgsS0E1RVE7QUE2RVR0RSxXQTdFUyxxQkE2RUMsQ0FDVCxDQTlFUTtBQStFVHVFLFVBL0VTLG9CQStFQSxDQUNSLENBaEZRO0FBaUZUQyxnQkFqRlMsd0JBaUZJQyxJQWpGSixFQWlGVTtBQUNmZixnQkFBUUMsR0FBUixDQUFZLGlCQUFaLEVBQStCYyxJQUEvQjtBQUNILEtBbkZRO0FBb0ZUM0UsVUFwRlMsb0JBb0ZBO0FBQ0xhLHVCQUFFQyxHQUFGO0FBQ0EsYUFBS2tELG9CQUFMLEdBQTRCLElBQUlZLDBCQUFKLENBQXNCLElBQXRCLENBQTVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0gsS0ExRlE7QUEyRlR6RSxZQTNGUyxzQkEyRkU7QUFBQTs7QUFDUCxZQUFJRSxVQUFVQyxlQUFLRCxPQUFMLEVBQWQ7QUFDQUUsd0JBQVFDLFlBQVIsQ0FBcUIsSUFBckIsRUFBMkJILE9BQTNCO0FBQ0EsYUFBS0YsUUFBTCxHQUFnQixZQUFNO0FBQ2xCTyxpQkFBS21FLFdBQUwsQ0FBaUIsRUFBRXBDLDZCQUFGLEVBQWtCcUMsTUFBTSxJQUF4QixFQUFqQjtBQUNBLGdCQUFJekUsVUFBVUMsZUFBS0QsT0FBTCxFQUFkO0FBQ0FFLDRCQUFRQyxZQUFSLENBQXFCLE1BQXJCLEVBQTJCSCxPQUEzQjtBQUNILFNBSkQ7QUFLSCxLQW5HUTtBQW9HVEksZUFwR1MsdUJBb0dHakIsSUFwR0gsRUFvR1M7QUFDZCxhQUFLdUYsZ0JBQUw7QUFDQSxhQUFLdkYsSUFBTCxDQUFVNkQsa0JBQVYsR0FBK0IsS0FBL0I7QUFDQTNDLGFBQUtFLFdBQUw7QUFDQTtBQUNILEtBekdRO0FBMEdUbUUsb0JBMUdTLDhCQTBHVTtBQUNmLFlBQUlDLGFBQWE7QUFDYmpELHdCQUFZMUMsSUFBSXdDLFVBQUosQ0FBZUMsV0FBZixDQUEyQkMsVUFEMUI7QUFFYkMsNkJBQWlCM0MsSUFBSXdDLFVBQUosQ0FBZUMsV0FBZixDQUEyQkUsZUFGL0I7QUFHYkUsMkJBQWU3QyxJQUFJd0MsVUFBSixDQUFlQyxXQUFmLENBQTJCSTtBQUg3QixTQUFqQjtBQUtBLGFBQUtiLE9BQUwsQ0FBYTtBQUNUOEIsd0JBQVk2QjtBQURILFNBQWI7QUFHSCxLQW5IUTtBQW9IVEMscUJBcEhTLCtCQW9IVztBQUNoQnJCLGdCQUFRQyxHQUFSLENBQVksbUJBQVo7QUFDQSxZQUFJeEQsVUFBVUMsZUFBS0QsT0FBTCxFQUFkO0FBQ0FFLHdCQUFRQyxZQUFSLENBQXFCLElBQXJCLEVBQTJCSCxPQUEzQjtBQUNILEtBeEhRO0FBeUhUNkUsaUJBekhTLDJCQXlITztBQUNaO0FBQ0EsWUFBSTdFLFVBQVVDLGVBQUtELE9BQUwsRUFBZDtBQUNBLFlBQUcsS0FBS2IsSUFBTCxDQUFVNEQsY0FBVixLQUE2QixDQUFoQyxFQUFtQztBQUMvQixtQkFBTyxLQUFQO0FBQ0gsU0FGRCxNQUVPO0FBQ0g3Qyw0QkFBUUMsWUFBUixDQUFxQixJQUFyQixFQUEyQkgsT0FBM0I7QUFDSDtBQUNKLEtBaklRO0FBa0lUOEUsa0JBbElTLDBCQWtJTUMsTUFsSU4sRUFrSWM7QUFDbkIsWUFBSUMsa0JBQWtCLEtBQUtuRSxPQUFMLENBQWEsZ0JBQWIsQ0FBdEI7QUFDQSxhQUFLRyxPQUFMLENBQWEsZ0JBQWIsRUFBK0J3QixPQUFPeUMsU0FBUCxDQUFpQkMsUUFBakIsQ0FBMEJDLElBQTFCLENBQStCSixNQUEvQixNQUEyQyxpQkFBM0MsR0FBK0RBLE1BQS9ELEdBQXlFQyxvQkFBb0IsQ0FBcEIsR0FBd0IsQ0FBeEIsR0FBNEIsQ0FBcEk7QUFDSCxLQXJJUTtBQXNJVGpELGFBdElTLHFCQXNJQ3BCLEtBdElELEVBc0lRO0FBQ2IsWUFBTU8sU0FBU1AsTUFBTVEsYUFBckI7QUFDQSxZQUFNYSxTQUFTZCxPQUFPRSxPQUFQLENBQWVZLE1BQTlCO0FBQ0EsWUFBRyxDQUFDQSxNQUFKLEVBQVk7QUFDUixtQkFBTyxLQUFQO0FBQ0g7QUFDRCxZQUFJSywrQkFBNkJMLE1BQWpDO0FBQ0F4Qix1QkFBRXNCLElBQUYsQ0FBT08sR0FBUDtBQUNIO0FBOUlRLENBQWI7O0FBaUpBRSxLQUFLQyxPQUFPQyxNQUFQLENBQWMsRUFBZCxFQUFrQnZELElBQWxCLENBQUwsRTs7Ozs7QUN4SkE7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7QUFFQSxJQUFNRixNQUFNQyxRQUFaLEMsQ0FBc0I7QUFDdEIsSUFBTUMsT0FBTztBQUNUQyxVQUFNO0FBQ0ZpRyxrQkFBVSxFQURSO0FBRUZDLHNCQUFjLEVBRlo7QUFHRnZDLG9CQUFZO0FBQ1J3Qyx3QkFBWSxDQURKO0FBRVJsRCxtQkFBTztBQUZDO0FBSFYsS0FERztBQVNUeEMsVUFUUyxvQkFTQTtBQUNMLFlBQUl5RixlQUFlLEtBQUtsRyxJQUFMLENBQVVrRyxZQUE3QjtBQUNBLFlBQU1DLGFBQWEsS0FBS25HLElBQUwsQ0FBVTJELFVBQVYsQ0FBcUJ3QyxVQUF4QztBQUNBLFlBQUlELGdCQUFnQkMsY0FBYyxDQUFsQyxFQUFxQztBQUNqQyxpQkFBS3RFLE9BQUwsQ0FBYSx1QkFBYixFQUFzQyxDQUF0QztBQUNBLGlCQUFLbEIsUUFBTDtBQUNIO0FBQ0osS0FoQlE7O0FBaUJUdUUsa0JBQWMsc0JBQVNDLElBQVQsRUFBZTtBQUN6QmYsZ0JBQVFDLEdBQVIsQ0FBWWMsSUFBWjtBQUNILEtBbkJRO0FBb0JUM0UsVUFwQlMsb0JBb0JBO0FBQ0wsYUFBSzRGLFFBQUw7QUFDQSxhQUFLekYsUUFBTDtBQUNILEtBdkJRO0FBd0JUeUYsWUF4QlMsc0JBd0JFO0FBQ1AsWUFBSXZGLFVBQVVDLGVBQUtELE9BQUwsRUFBZDtBQUNBRSx3QkFBUXNGLGVBQVIsQ0FBd0IsSUFBeEIsRUFBOEJ4RixPQUE5QjtBQUVILEtBNUJRO0FBNkJURixZQTdCUyxzQkE2QkU7QUFBQTs7QUFDUEMsbUJBQVcsWUFBTTtBQUNiTSxpQkFBS21FLFdBQUwsQ0FBaUIsRUFBRXBDLDZCQUFGLEVBQWpCO0FBQ0EsZ0JBQUlwQyxVQUFVQyxlQUFLRCxPQUFMLEVBQWQ7QUFDQUUsNEJBQVFDLFlBQVIsQ0FBcUIsS0FBckIsRUFBMkJILE9BQTNCO0FBQ0FRLDJCQUFFQyxHQUFGLEdBSmEsQ0FJTDtBQUNSLGtCQUFLWCxRQUFMLEdBQWdCLFlBQU07QUFDbEJPLHFCQUFLbUUsV0FBTCxDQUFpQixFQUFFcEMsNkJBQUYsRUFBakI7QUFDQSxvQkFBSXBDLFVBQVVDLGVBQUtELE9BQUwsRUFBZDtBQUNBRSxnQ0FBUUMsWUFBUixDQUFxQixLQUFyQixFQUEyQkgsT0FBM0I7QUFDSCxhQUpEO0FBS0gsU0FWRCxFQVVHLENBVkg7QUFZSCxLQTFDUTtBQTJDVEksZUEzQ1MsdUJBMkNHakIsSUEzQ0gsRUEyQ1M7QUFDZCxhQUFLNkIsT0FBTCxDQUFhO0FBQ1Qsd0JBQVk3QixLQUFLaUcsUUFEUjtBQUVULGdDQUFvQmpHLEtBQUtpRyxRQUFMLENBQWMsQ0FBZCxFQUFpQmhEO0FBRjVCLFNBQWI7QUFJQS9CLGFBQUtFLFdBQUw7QUFDSCxLQWpEUTtBQWtEVGtGLG1CQWxEUywyQkFrRE90RyxJQWxEUCxFQWtEYTtBQUNsQixhQUFLNkIsT0FBTCxDQUFhLGNBQWIsRUFBNkI3QixJQUE3QjtBQUNILEtBcERRO0FBcURUdUcsb0JBckRTLDRCQXFEUS9FLEtBckRSLEVBcURlO0FBQ3BCLFlBQU1PLFNBQVNQLE1BQU1RLGFBQXJCO0FBQ0EsYUFBS0gsT0FBTCxDQUFhLHVCQUFiLEVBQXNDRSxPQUFPRSxPQUFQLENBQWVrRSxVQUFyRDtBQUNBLGFBQUt4RixRQUFMO0FBQ0gsS0F6RFE7QUEwRFQ2RixxQkExRFMsNkJBMERTaEYsS0ExRFQsRUEwRGdCO0FBQ3JCLFlBQU1PLFNBQVNQLE1BQU1RLGFBQXJCO0FBQ0EsYUFBS0gsT0FBTCxDQUFhLGtCQUFiLEVBQWlDRSxPQUFPRSxPQUFQLENBQWVnQixLQUFoRDtBQUNILEtBN0RRO0FBOERUTCxhQTlEUyxxQkE4RENwQixLQTlERCxFQThEUTtBQUNiLFlBQU1PLFNBQVNQLE1BQU1RLGFBQXJCO0FBQ0EsWUFBTWEsU0FBU2QsT0FBT0UsT0FBUCxDQUFlWSxNQUE5QjtBQUNBLFlBQUksQ0FBQ0EsTUFBTCxFQUFhO0FBQ1QsbUJBQU8sS0FBUDtBQUNIO0FBQ0QsWUFBSUssK0JBQTZCTCxNQUFqQztBQUNBeEIsdUJBQUVzQixJQUFGLENBQU9PLEdBQVA7QUFDSDtBQXRFUSxDQUFiOztBQXlFQUUsS0FBS0MsT0FBT0MsTUFBUCxDQUFjLEVBQWQsRUFBa0J2RCxJQUFsQixDQUFMLEU7Ozs7O0FDOUVBOztJQUFZZSxJOztBQUNaOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7QUFHQSxJQUFJakIsTUFBTUMsUUFBVjtBQUNBLElBQUl1QyxhQUFheEMsSUFBSXdDLFVBQXJCO0FBQ0EsSUFBTW9FLGFBQWEsZ0NBQW5CO0FBQ0EsSUFBTTFHLE9BQU87QUFDVEMsVUFBTTtBQUNGQyxjQUFNLE1BREo7QUFFRnlHLGlCQUFTLEVBRlA7QUFHRkMsaUJBQVM7QUFDTEMsdUJBQVcsS0FETixFQUNZO0FBQ2pCQyx3QkFBWTtBQUZQLFNBSFA7QUFPRkMsbUJBQVc7QUFDUGpHLHFCQUFTLEtBREY7QUFFUEMsa0JBQU07QUFDRmtDLHNCQUFNeUQsVUFESjtBQUVGTSwwQkFBVSxFQUZSO0FBR0ZDLHVCQUFPO0FBSEw7QUFGQztBQVBULEtBREc7QUFpQlR2RyxVQWpCUyxvQkFpQkE7QUFDTCxhQUFLRSxRQUFMO0FBQ0E7QUFDQSxZQUFHMEIsV0FBV3VFLFNBQWQsRUFBeUI7QUFDckI7QUFDQSxpQkFBSzVHLElBQUwsQ0FBVTJHLE9BQVYsQ0FBa0JDLFNBQWxCLEdBQThCL0csSUFBSXdDLFVBQUosQ0FBZXVFLFNBQTdDLENBRnFCLENBRWtDO0FBQ3ZELGlCQUFLNUcsSUFBTCxDQUFVMkcsT0FBVixDQUFrQkUsVUFBbEIsR0FBK0JoSCxJQUFJd0MsVUFBSixDQUFld0UsVUFBOUM7O0FBRUEsaUJBQUtoRixPQUFMLENBQWEsbUJBQWIsRUFBa0MsS0FBbEM7QUFDQSxpQkFBS29GLFVBQUw7QUFDSCxTQVBELE1BT08sSUFBRzVFLFdBQVd3RSxVQUFYLENBQXNCN0MsTUFBdEIsS0FBaUMsQ0FBcEMsRUFBdUM7QUFDMUMsaUJBQUtrRCxlQUFMO0FBQ0g7QUFDSixLQTlCUTtBQStCVDFHLFVBL0JTLG9CQStCQTtBQUNMO0FBQ0E7QUFDQTtBQUNILEtBbkNRO0FBb0NUMkcsa0JBcENTLDRCQW9DUTtBQUNiLGFBQUtuSCxJQUFMLENBQVUyRyxPQUFWLENBQWtCQyxTQUFsQixHQUE4QnZFLFdBQVd3RSxVQUF6QztBQUNILEtBdENRO0FBdUNUSSxjQXZDUyx3QkF1Q0k7QUFDVCxZQUFJSixhQUFhLEtBQUs3RyxJQUFMLENBQVUyRyxPQUFWLENBQWtCRSxVQUFuQyxDQURTLENBQ3FDOztBQUU5QyxZQUFHQSxjQUFjQSxlQUFlLEVBQWhDLEVBQW9DO0FBQ2hDLGlCQUFLTyxZQUFMLENBQWtCUCxVQUFsQjtBQUNBLGlCQUFLN0csSUFBTCxDQUFVMkcsT0FBVixDQUFrQkMsU0FBbEIsR0FBOEIsS0FBOUI7QUFDQS9HLGdCQUFJd0MsVUFBSixDQUFldUUsU0FBZixHQUEyQixLQUEzQjtBQUNILFNBSkQsTUFJTztBQUNILGlCQUFLTSxlQUFMO0FBQ0FoRyxpQkFBSzZCLFNBQUwsQ0FBZSxFQUFFRSxPQUFPLE9BQVQsRUFBZjtBQUNBbUIsb0JBQVFDLEdBQVI7QUFDSDtBQUNKLEtBbkRRO0FBb0RUK0MsZ0JBcERTLHdCQW9ESVAsVUFwREosRUFvRGdCO0FBQUE7O0FBQ3JCLFlBQUlRLGNBQWN2RyxLQUFLdUcsV0FBTCxFQUFsQjtBQUNBO0FBQ0EsWUFBR0EsZUFBZWhFLE9BQU9pRSxJQUFQLENBQVlELFdBQVosRUFBeUJyRCxNQUF6QixHQUFrQyxDQUFwRCxFQUF1RDtBQUNuREksb0JBQVFDLEdBQVIsQ0FBWWdELFdBQVo7QUFDSDs7QUFFREUsNkJBQUlGLFdBQUosQ0FBZ0IsRUFBRUcsWUFBWVgsVUFBZCxFQUFoQixFQUE0Q1ksSUFBNUMsQ0FBaUQsVUFBQ3pILElBQUQsRUFBVTtBQUN2RG9FLG9CQUFRc0QsSUFBUjtBQUNBLGtCQUFLUixlQUFMLENBQXFCbEgsSUFBckIsRUFBMkI2RyxVQUEzQjtBQUNILFNBSEQsRUFHRyxVQUFDYyxHQUFELEVBQVM7QUFDUixrQkFBS0MsUUFBTDtBQUNBeEQsb0JBQVF5RCxLQUFSLENBQWNGLEdBQWQ7QUFDSCxTQU5EO0FBT0gsS0FsRVE7QUFtRVRDLFlBbkVTLHNCQW1FRTtBQUNQLGVBQU8sS0FBUDtBQUNILEtBckVRO0FBc0VUVixtQkF0RVMsMkJBc0VPbEgsSUF0RVAsRUFzRWE2RyxVQXRFYixFQXNFeUI7QUFDOUIsWUFBRyxDQUFDN0csSUFBSixFQUFVO0FBQUM7QUFDUCxpQkFBSzZCLE9BQUwsQ0FBYSxtQkFBYixFQUFrQyxLQUFsQztBQUNBLGlCQUFLQSxPQUFMLENBQWEscUJBQWIsRUFBb0M0RSxVQUFwQztBQUNBLGlCQUFLNUUsT0FBTCxDQUFhLHlCQUFiLEVBQXdDLEVBQXhDO0FBQ0EsaUJBQUtBLE9BQUwsQ0FBYSxzQkFBYixFQUFxQyxLQUFyQztBQUNBaUcsOEJBQVFDLE9BQVIsQ0FBZ0JDLEtBQWhCO0FBRUgsU0FQRCxNQU9PO0FBQUM7QUFBRCxpQ0FDc0JoSSxLQUFLaUksUUFEM0I7QUFBQSxnQkFDR2xCLFFBREgsa0JBQ0dBLFFBREg7QUFBQSxnQkFDYS9ELElBRGIsa0JBQ2FBLElBRGI7O0FBRUgsZ0JBQUlnRSxRQUFRLENBQUNoSCxLQUFLa0ksYUFBTCxJQUFzQixFQUF2QixFQUEyQkMsS0FBM0IsR0FBbUMsQ0FBL0M7QUFDQTtBQUNBL0Qsb0JBQVFDLEdBQVIsQ0FBWTBDLFFBQVosRUFBc0IvRCxJQUF0QjtBQUNBLGlCQUFLbkIsT0FBTCxDQUFhLG1CQUFiLEVBQWtDLElBQWxDO0FBQ0EsaUJBQUtBLE9BQUwsQ0FBYSxxQkFBYixFQUFvQ21CLElBQXBDO0FBQ0EsaUJBQUtuQixPQUFMLENBQWEseUJBQWIsRUFBd0NrRixRQUF4QztBQUNBLGlCQUFLbEYsT0FBTCxDQUFhLHNCQUFiLEVBQXFDbUYsU0FBUyxLQUE5Qzs7QUFFQWMsOEJBQVFDLE9BQVIsQ0FBZ0JLLEdBQWhCLENBQW9CTixrQkFBUU8sZ0JBQTVCLEVBQThDeEIsVUFBOUM7QUFDQWlCLDhCQUFRQyxPQUFSLENBQWdCSyxHQUFoQixDQUFvQk4sa0JBQVFRLGdCQUE1QixFQUE4Q3RJLElBQTlDO0FBQ0FrQixpQkFBSzZCLFNBQUwsQ0FBZSxFQUFFRSxpQ0FBRixFQUFmO0FBQ0g7QUFDSixLQTVGUTtBQTZGVHRDLFlBN0ZTLHNCQTZGRTtBQUFBOztBQUNQO0FBQ0E7QUFDQVUsdUJBQUVrSCxNQUFGLEdBQVdkLElBQVgsQ0FBZ0IsVUFBQ3pILElBQUQsRUFBVTtBQUN0QixtQkFBSzZCLE9BQUwsQ0FBYSxFQUFFLFdBQVc3QixRQUFRQSxLQUFLd0ksT0FBTCxHQUFlQyxNQUFmLENBQXNCLENBQXRCLEVBQXlCLENBQXpCLENBQXJCLEVBQWI7QUFDSCxTQUZEO0FBSUgsS0FwR1E7QUFxR1R4SCxlQXJHUyx1QkFxR0dqQixJQXJHSCxFQXFHUztBQUNkO0FBQ0FxQix1QkFBRUMsR0FBRixHQUZjLENBRUw7QUFDWixLQXhHUTtBQXlHVHFCLFFBekdTLGdCQXlHSm5CLEtBekdJLEVBeUdHO0FBQ1IsWUFBTU8sU0FBU1AsTUFBTVEsYUFBckI7QUFDQSxZQUFNa0IsTUFBTW5CLE9BQU9FLE9BQVAsQ0FBZWlCLEdBQTNCO0FBQ0E7QUFDQTdCLHVCQUFFc0IsSUFBRixDQUFPTyxHQUFQO0FBQ0gsS0E5R1E7QUErR1ROLGFBL0dTLHFCQStHQ3BCLEtBL0dELEVBK0dRO0FBQ2IsWUFBTU8sU0FBU1AsTUFBTVEsYUFBckI7QUFDQSxZQUFNYSxTQUFTZCxPQUFPRSxPQUFQLENBQWVZLE1BQTlCO0FBQ0EsWUFBTUMsV0FBV2YsT0FBT0UsT0FBUCxDQUFlYSxRQUFoQztBQUNBLFlBQUcsQ0FBQ0QsTUFBSixFQUFZO0FBQ1IzQixpQkFBSzZCLFNBQUwsQ0FBZTtBQUNYQyxzQkFBTSxNQURLO0FBRVhDLHVCQUFPO0FBRkksYUFBZjtBQUlBLG1CQUFPLEtBQVA7QUFDSDtBQUNELFlBQUlDLCtCQUE2QkwsTUFBakM7QUFDQSxZQUFHQyxZQUFZLENBQWYsRUFBa0I7QUFDZEksMkNBQTZCTCxNQUE3QjtBQUNIO0FBQ0R4Qix1QkFBRXNCLElBQUYsQ0FBT08sR0FBUDtBQUNILEtBL0hRO0FBZ0lUd0YsZUFoSVMsdUJBZ0lHbEgsS0FoSUgsRUFnSVU7QUFBQTs7QUFDZk4sYUFBS3lILFNBQUwsQ0FBZTtBQUNYMUYsbUJBQU8sSUFESTtBQUVYMkYscUJBQVMsUUFGRTtBQUdYQyx5QkFBYSxTQUhGO0FBSVhDLDBCQUFjLFNBSkg7QUFLWEMscUJBQVMsaUJBQUNDLEdBQUQsRUFBUztBQUNkLG9CQUFHQSxJQUFJQyxPQUFQLEVBQWdCO0FBQ1o3RSw0QkFBUUMsR0FBUixDQUFZLGlCQUFaO0FBQ0FuRCx5QkFBSzZCLFNBQUwsQ0FBZSxFQUFFRSxPQUFPLE1BQVQsRUFBZjtBQUNBNUIsbUNBQUVrSCxNQUFGLENBQVMsRUFBVCxFQUFhZCxJQUFiLENBQWtCLFVBQUN1QixHQUFELEVBQVM7QUFDdkIsK0JBQUtySSxRQUFMO0FBQ0gscUJBRkQ7QUFHSCxpQkFORCxNQU1PLElBQUdxSSxJQUFJRSxNQUFQLEVBQWU7QUFDbEI5RSw0QkFBUUMsR0FBUixDQUFZLFNBQVo7QUFDSDtBQUNKO0FBZlUsU0FBZjtBQWlCSDtBQWxKUSxDQUFiOztBQXNKQWpCLEtBQUtDLE9BQU9DLE1BQVAsQ0FBYyxFQUFkLEVBQWtCdkQsSUFBbEIsQ0FBTCxFOzs7OztBQy9KQTs7SUFBWW9KLEk7O0FBQ1o7O0lBQVk1QixHOztBQUNaOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOztJQUFZNkIsSzs7QUFDWjs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7SUFBWXRJLEk7Ozs7OztBQUNaOztBQUVBLElBQU1qQixNQUFNQyxRQUFaOztBQUVBLElBQU1DLE9BQU87QUFDVDs7O0FBR0FDLFVBQU07QUFDRnFKLGtCQUFVLElBRFI7QUFFRkMsbUJBQVcsTUFGVDtBQUdGekcsZ0JBQVEsSUFITjtBQUlGMEcsa0JBQVUsSUFKUjtBQUtGQyxpQkFBUyxDQUFDO0FBQ05DLGtCQUFNLENBREE7QUFFTmIscUJBQVM7QUFGSCxTQUFELENBTFA7QUFTRmMsc0JBQWMsR0FUWjtBQVVGQyw0QkFBb0IsSUFWbEI7QUFXRkMseUJBQWlCLEtBWGY7QUFZRkMsb0JBQVksS0FaVjtBQWFGQyxtQkFBVyxFQWJUO0FBY0ZDLHdCQUFnQixFQWRkO0FBZUZDLHNCQUFjLEVBZlo7QUFnQkZDLHNCQUFjLENBaEJaO0FBaUJGQyxlQUFPO0FBQ0hDLHFCQUFTLEtBRE47QUFFSHZELHVCQUFXLEtBRlI7QUFHSHdELGtCQUFNLEtBSEg7QUFJSEMscUJBQVM7QUFKTixTQWpCTDtBQXVCRkMsc0JBQWMsK0RBdkJaO0FBd0JGQyxvQkFBWSxDQXhCVjtBQXlCRkMsa0JBQVUsS0F6QlI7QUEwQkZDLHVCQUFlLEVBMUJiO0FBMkJGQyxhQUFLO0FBQ0RDLGtCQUFNLEtBREw7QUFFREMsa0JBQU07QUFGTCxTQTNCSDtBQStCRkMsd0JBQWdCO0FBL0JkLEtBSkc7O0FBc0NUQyxtQkFBZSx5QkFBVztBQUN0QixhQUFLakosT0FBTCxDQUFhO0FBQ1R5SCx1QkFBVztBQURGLFNBQWI7QUFHQUgsYUFBSzRCLGdCQUFMLENBQXNCLElBQXRCO0FBQ0gsS0EzQ1E7O0FBNkNUQyxtQkFBZSx5QkFBVztBQUN0QixhQUFLbkosT0FBTCxDQUFhO0FBQ1R5SCx1QkFBVztBQURGLFNBQWI7QUFHSCxLQWpEUTs7QUFtRFQyQixlQW5EUyx5QkFtREs7QUFDVjdHLGdCQUFRQyxHQUFSLENBQVksU0FBWjtBQUNBbkQsYUFBSzZCLFNBQUwsQ0FBZSxFQUFFRSxPQUFPLE1BQVQsRUFBZjtBQUNBLGFBQUtnSSxXQUFMLEdBQW1CLFlBQU07QUFDckIvSixpQkFBSzZCLFNBQUwsQ0FBZSxFQUFFRSxPQUFPLEtBQVQsRUFBZjtBQUNILFNBRkQ7QUFHQTtBQUNILEtBMURROzs7QUE0RFRpSSxvQkFBZ0Isd0JBQVN0RyxDQUFULEVBQVk7QUFDeEJ1RSxhQUFLZ0MsVUFBTCxDQUFnQnZHLEVBQUU1QyxhQUFGLENBQWdCQyxPQUFoQztBQUNILEtBOURROztBQWdFVDs7O0FBR0FtSix1QkFBbUIsNkJBQVc7QUFDMUIsWUFBSUMsWUFBWTtBQUNacEksbUJBQU8sS0FBS3FJLFFBQUwsQ0FBY0MsU0FBZCxDQUF3QkMsV0FEbkI7QUFFWkMsc0JBQVUsS0FBS0gsUUFBTCxDQUFjQyxTQUFkLENBQXdCRyxLQUF4QixDQUE4QkMsT0FBOUIsQ0FBc0MsVUFBdEMsRUFBa0QsVUFBbEQsQ0FGRTtBQUdaQyxrQkFBTSx5QkFBeUIsS0FBS04sUUFBTCxDQUFjekk7QUFIakMsU0FBaEI7QUFLQSxlQUFPd0ksU0FBUDtBQUNILEtBMUVROztBQTRFVFEsa0JBQWMsd0JBQVc7QUFDckIsWUFBSVIsWUFBWTtBQUNacEksbUJBQU8sS0FBS3FJLFFBQUwsQ0FBY0MsU0FBZCxDQUF3QkMsV0FEbkI7QUFFWjVDLHFCQUFTLEtBQUswQyxRQUFMLENBQWNDLFNBQWQsQ0FBd0JPLFdBRnJCO0FBR1pMLHNCQUFVLEtBQUtILFFBQUwsQ0FBY0MsU0FBZCxDQUF3QkcsS0FBeEIsQ0FBOEJDLE9BQTlCLENBQXNDLFVBQXRDLEVBQWtELFVBQWxELENBSEU7QUFJWkMsa0JBQU0seUJBQXlCLEtBQUtOLFFBQUwsQ0FBY3pJO0FBSmpDLFNBQWhCO0FBTUEzQixhQUFLNkssU0FBTCxDQUFlVixTQUFmO0FBQ0gsS0FwRlE7O0FBc0ZUOzs7QUFHQVcsV0FBTztBQUNIQyxrQkFBVSxvQkFBVyxDQUFFO0FBRHBCLEtBekZFO0FBNEZUO0FBQ0EzSyxPQTdGUyxpQkE2Rkg7QUFDRkQsdUJBQUVDLEdBQUYsQ0FBTTtBQUNGNEssa0JBQVMsS0FBS1osUUFBTCxDQUFjYSxjQUF2QixTQUF5QyxLQUFLYixRQUFMLENBQWNjLFNBQXZELFNBQXFFLEtBQUtkLFFBQUwsQ0FBY2UsUUFBbkYsbUVBREU7QUFFRkMsc0JBQWEsS0FBS2hCLFFBQUwsQ0FBY2EsY0FBM0IsU0FBNkMsS0FBS2IsUUFBTCxDQUFjYSxjQUEzRCxxQkFBK0UsS0FBS2IsUUFBTCxDQUFjYSxjQUE3RiwyQkFBa0gsS0FBS2IsUUFBTCxDQUFjYSxjQUFoSSxzQ0FBc0osS0FBS2IsUUFBTCxDQUFjYSxjQUFwSyxTQUFzTCxLQUFLYixRQUFMLENBQWNlLFFBQXBNLGNBQWdOLEtBQUtmLFFBQUwsQ0FBY2EsY0FBOU4sU0FBZ1AsS0FBS2IsUUFBTCxDQUFjZSxRQUE5UCwwQkFBNFEsS0FBS2YsUUFBTCxDQUFjYSxjQUExUixTQUE0UyxLQUFLYixRQUFMLENBQWNlLFFBQTFULGlCQUZFO0FBR0ZwSixtQkFBVSxLQUFLcUksUUFBTCxDQUFjYSxjQUF4QixTQUEyQyxLQUFLYixRQUFMLENBQWNjLFNBQXpELFNBQXVFLEtBQUtkLFFBQUwsQ0FBY2UsUUFBckYsbUVBSEU7QUFJRm5DLG1CQUFNO0FBQ0ZoSCxxQkFBSSx5QkFBeUIsS0FBS29JLFFBQUwsQ0FBY3pJLE1BRHpDO0FBRUZtQywwQkFBUyxJQUZQO0FBR0Z1SCx1QkFBTSxLQUFLakIsUUFBTCxDQUFjQyxTQUFkLENBQXdCRyxLQUF4QixDQUE4QkMsT0FBOUIsQ0FBc0MsVUFBdEMsRUFBa0QsVUFBbEQ7QUFISjtBQUpKLFNBQU47QUFVSCxLQXhHUTtBQXlHVG5MLFVBekdTLGtCQXlHRmdNLEdBekdFLEVBeUdHO0FBQ1IsYUFBS0MsT0FBTCxHQUFlLElBQUlDLGlCQUFKLEVBQWY7QUFDQSxhQUFLcEIsUUFBTCxHQUFnQixFQUFoQjtBQUNBLGFBQUtxQixVQUFMLEdBQWtCLEVBQWxCO0FBQ0EsYUFBSzlLLE9BQUwsQ0FBYTtBQUNULHNCQUFVMkssSUFBSTNKLE1BREw7QUFFVCwwQkFBYztBQUZMLFNBQWI7QUFJQSxhQUFLK0osTUFBTCxHQUFjLEVBQWQ7QUFDQSxhQUFLQyxVQUFMO0FBQ0EsYUFBS0MsT0FBTDtBQUNILEtBcEhRO0FBcUhURCxjQXJIUyx3QkFxSEk7QUFDVCxZQUFJeEssYUFBYXZDLFNBQVN1QyxVQUExQjtBQUNBLGFBQUt1SyxNQUFMLEdBQWMsSUFBSUcsa0JBQUosQ0FBVztBQUNyQkMsZ0JBQUkzSyxXQUFXMkssRUFBWCxJQUFpQixZQURBO0FBRXJCQyxlQUFHNUssV0FBVzZLLEVBQVgsSUFBaUIsUUFGQztBQUdyQkMscUJBQVM5SyxXQUFXOEssT0FBWCxJQUFzQixTQUhWLEVBR3FCO0FBQzFDQyx1QkFBV3RNLEtBQUt1TSxXQUFMLE1BQXNCLEVBSlo7QUFLckJDLG9CQUFRLEVBTGE7QUFNckJwSyxpQkFBSyxrQkFOZ0I7QUFPckJMLG9CQUFRLEtBQUs3QyxJQUFMLENBQVU2QztBQVBHLFNBQVgsRUFRWDNCLElBUlcsQ0FBZDtBQVNILEtBaElRO0FBaUlUNEwsV0FqSVMscUJBaUlDO0FBQUE7O0FBQ04sWUFBSVMsV0FBVyxJQUFJQyxJQUFKLEdBQVdDLE9BQVgsRUFBZjtBQUNBbEcsWUFBSW1HLFdBQUosQ0FBZ0IsS0FBSzFOLElBQUwsQ0FBVTZDLE1BQTFCLEVBQWtDNEUsSUFBbEMsQ0FBdUMsZUFBTztBQUMxQyxrQkFBSzVGLE9BQUwsQ0FBYTtBQUNULDhCQUFjO0FBREwsYUFBYjtBQUdBLGdCQUFJOEwsU0FBUyxJQUFJSCxJQUFKLEdBQVdDLE9BQVgsRUFBYjtBQUNBLGtCQUFLYixNQUFMLENBQVlnQixJQUFaLENBQWlCLE1BQUtoQixNQUFMLENBQVlpQixJQUFaLENBQWlCQyxvQkFBbEMsRUFBd0Q5RSxJQUFJK0UsSUFBNUQsRUFBa0VKLFNBQVNKLFFBQTNFLEVBQXFGLENBQXJGLEVBQXdGLEVBQXhGLE9BQStGdkUsSUFBSWdGLEdBQW5HOztBQUVBLGdCQUFJaEYsSUFBSStFLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN2QixzQkFBS3pDLFFBQUwsR0FBZ0J0QyxJQUFJaEosSUFBcEI7QUFDQSxzQkFBS3NMLFFBQUwsQ0FBYzJDLElBQWQsR0FBcUJqRixJQUFJaEosSUFBSixDQUFTa08sV0FBVCxDQUFxQkMsTUFBMUM7QUFDQSxzQkFBSzdDLFFBQUwsQ0FBY2YsVUFBZCxHQUEyQnZCLElBQUloSixJQUFKLENBQVNrTyxXQUFULENBQXFCRSxVQUFoRDtBQUNBLHNCQUFLOUMsUUFBTCxDQUFjekksTUFBZCxHQUF1Qm1HLElBQUloSixJQUFKLENBQVNrTyxXQUFULENBQXFCckwsTUFBNUM7QUFDQSxzQkFBS3lJLFFBQUwsQ0FBYy9JLFVBQWQsR0FBMkJ5RyxJQUFJaEosSUFBSixDQUFTa08sV0FBVCxDQUFxQjNMLFVBQWhEO0FBQ0Esc0JBQUsrSSxRQUFMLENBQWM1SSxhQUFkLEdBQThCc0csSUFBSWhKLElBQUosQ0FBU2tPLFdBQVQsQ0FBcUJ4TCxhQUFuRDtBQUNBLHNCQUFLNEksUUFBTCxDQUFjK0MsVUFBZCxHQUEyQnJGLElBQUloSixJQUFKLENBQVNzTyxRQUFULENBQWtCRCxVQUE3Qzs7QUFFQSxzQkFBSy9DLFFBQUwsQ0FBY2EsY0FBZCxHQUErQm5ELElBQUloSixJQUFKLENBQVN1TyxVQUFULENBQW9CQyxjQUFuRDtBQUNBLHNCQUFLbEQsUUFBTCxDQUFjYyxTQUFkLEdBQTBCcEQsSUFBSWhKLElBQUosQ0FBU2tPLFdBQVQsQ0FBcUIxQyxXQUEvQztBQUNBLHNCQUFLRixRQUFMLENBQWNlLFFBQWQsR0FBeUJyRCxJQUFJaEosSUFBSixDQUFTa08sV0FBVCxDQUFxQk8sWUFBOUM7O0FBRUEsc0JBQUtuRCxRQUFMLENBQWNDLFNBQWQsR0FBMEJ2QyxJQUFJaEosSUFBSixDQUFTdUwsU0FBbkM7O0FBRUEsc0JBQUttRCxXQUFMLENBQWlCMUYsSUFBSWhKLElBQUosQ0FBUzJPLFVBQTFCO0FBQ0E7QUFDQXROLCtCQUFFa0gsTUFBRixDQUFTO0FBQ0wxRiw0QkFBUW1HLElBQUloSixJQUFKLENBQVNrTyxXQUFULENBQXFCckwsTUFEeEI7QUFFTHNMLDRCQUFRbkYsSUFBSWhKLElBQUosQ0FBU2tPLFdBQVQsQ0FBcUJDLE1BRnhCO0FBR0xTLG1DQUFlNUYsSUFBSWhKLElBQUosQ0FBU2tPLFdBQVQsQ0FBcUJVLGFBQXJCLElBQXNDNUYsSUFBSWhKLElBQUosQ0FBU3VMLFNBQVQsQ0FBbUJHLEtBQW5CLENBQXlCQyxPQUF6QixDQUFpQyxVQUFqQyxFQUE2QyxVQUE3QyxDQUhoRDtBQUlMN0ksOEJBQVUsQ0FKTDtBQUtMK0wsZ0NBQVk3RixJQUFJaEosSUFBSixDQUFTa08sV0FBVCxDQUFxQlcsVUFMNUI7QUFNTDVMLDJCQUFPK0YsSUFBSWhKLElBQUosQ0FBU2tPLFdBQVQsQ0FBcUIxQyxXQUFyQixJQUFvQ3hDLElBQUloSixJQUFKLENBQVNrTyxXQUFULENBQXFCcEMsV0FOM0Q7QUFPTC9FLDhCQUFVaUMsSUFBSWhKLElBQUosQ0FBU3VPLFVBQVQsQ0FBb0JDLGNBUHpCO0FBUUxNLGdDQUFZLElBQUl0QixJQUFKLEdBQVdDLE9BQVg7QUFSUCxpQkFBVDs7QUFXQSxvQkFBSXNCLFNBQVM7QUFDVDNDLCtCQUFXcEQsSUFBSWhKLElBQUosQ0FBU2tPLFdBQVQsQ0FBcUIxQyxXQUR2QjtBQUVUakIsZ0NBQVl2QixJQUFJaEosSUFBSixDQUFTa08sV0FBVCxDQUFxQkUsVUFGeEIsRUFFb0M7QUFDN0M1RCw4QkFBVXhCLElBQUloSixJQUFKLENBQVN1TyxVQUFULENBQW9CUyxVQUhyQjtBQUlUQywrQkFBVzdGLE1BQU04RixRQUFOLENBQWVsRyxJQUFJaEosSUFBSixDQUFTdU8sVUFBVCxDQUFvQlksaUJBQW5DLENBSkY7QUFLVFYsa0NBQWN6RixJQUFJaEosSUFBSixDQUFTa08sV0FBVCxDQUFxQk8sWUFMMUI7QUFNVFcscUNBQWlCcEcsSUFBSWhKLElBQUosQ0FBU2tPLFdBQVQsQ0FBcUJrQixlQU43QjtBQU9UN0YsOEJBQVU7QUFDTixzQ0FBY1AsSUFBSWhKLElBQUosQ0FBU3VPLFVBQVQsQ0FBb0JjLFVBRDVCO0FBRU4sb0NBQVlyRyxJQUFJaEosSUFBSixDQUFTdU8sVUFBVCxDQUFvQkMsY0FGMUI7QUFHTjtBQUNBO0FBQ0EsZ0NBQVF4RixJQUFJaEosSUFBSixDQUFTa08sV0FBVCxDQUFxQnBDO0FBTHZCO0FBUEQsaUJBQWI7QUFlQSxzQkFBS3hLLEdBQUw7QUFDQSxzQkFBS08sT0FBTCxDQUFha04sTUFBYjtBQUNBLHNCQUFLbE4sT0FBTCxDQUFhLEVBQUUsZ0JBQWdCbUgsSUFBSWhKLElBQUosQ0FBU2tPLFdBQVQsQ0FBcUJVLGFBQXJCLElBQXNDLCtEQUF4RCxFQUFiO0FBQ0ExTixxQkFBS29PLHFCQUFMLENBQTJCO0FBQ3ZCck0sMkJBQU8rRixJQUFJaEosSUFBSixDQUFTa08sV0FBVCxDQUFxQjFDO0FBREwsaUJBQTNCO0FBR0Esc0JBQUttQixVQUFMLENBQWdCNEMsYUFBaEIsR0FBZ0MsSUFBSUMsc0JBQUosQ0FBa0IsS0FBbEIsQ0FBaEM7QUFDQTtBQUNBakksb0JBQUlrSSxZQUFKLENBQWlCLE1BQUtuRSxRQUFMLENBQWMrQyxVQUEvQixFQUNLNUcsSUFETCxDQUNVLFVBQUN6SCxJQUFELEVBQVU7QUFDWiwwQkFBS3NMLFFBQUwsQ0FBY29FLFNBQWQsR0FBMEIxUCxJQUExQjtBQUNBLDBCQUFLMk0sVUFBTCxDQUFnQmdELE9BQWhCLEdBQTBCLElBQUlDLHVCQUFKLENBQVksS0FBWixDQUExQjtBQUNBLDBCQUFLakQsVUFBTCxDQUFnQmtELE1BQWhCLEdBQXlCLElBQUlDLG1CQUFKLENBQWUsS0FBZixFQUFxQjlHLElBQUloSixJQUFKLENBQVNzTyxRQUFULENBQWtCRCxVQUF2QyxDQUF6QjtBQUNILGlCQUxMLEVBS08wQixLQUxQLENBS2EsVUFBQ3BJLEdBQUQsRUFBUztBQUNkdkQsNEJBQVF5RCxLQUFSLENBQWNGLEdBQWQ7QUFDSCxpQkFQTDtBQVFBLHNCQUFLcUksV0FBTCxDQUFpQixnQkFBakIsRUFBbUMsVUFBU3BMLENBQVQsRUFBWTtBQUMzQ1IsNEJBQVFDLEdBQVIsQ0FBWSxnQkFBWjtBQUNILGlCQUZEO0FBR0gsYUE5REQsTUE4RE87QUFDSCxvQkFBSTJFLElBQUkrRSxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDdkIzSiw0QkFBUXlELEtBQVIsbUNBQXVCbUIsSUFBSWdGLEdBQTNCLEVBRHVCLENBQ1U7QUFDakMsMEJBQUtwQixNQUFMLENBQVlnQixJQUFaLENBQWlCLE1BQUtoQixNQUFMLENBQVlpQixJQUFaLENBQWlCb0MsZ0JBQWxDLEVBQW9EakgsSUFBSStFLElBQXhELEVBQThESixTQUFTSixRQUF2RSxFQUFpRixDQUFqRixFQUFvRixFQUFwRixPQUEyRnZFLElBQUlnRixHQUEvRjtBQUNIO0FBQ0Qsc0JBQUtyQixVQUFMLENBQWdCNEMsYUFBaEIsR0FBZ0MsSUFBSUMsc0JBQUosQ0FBa0IsS0FBbEIsQ0FBaEM7QUFDQSxzQkFBSzNOLE9BQUwsQ0FBYTtBQUNUcU8sNkJBQVMsSUFEQSxFQUNNO0FBQ2ZoRywyQkFBTztBQUNIRSw4QkFBTSxLQURIO0FBRUgrRixtQ0FBVyxJQUZSO0FBR0hDLGtDQUFVcEgsSUFBSWdGLEdBQUosSUFBVztBQUhsQixxQkFGRTtBQU9UMUQsa0NBQWM7QUFQTCxpQkFBYjtBQVNIO0FBQ0osU0FyRkQsRUFxRkcsZUFBTztBQUNObEcsb0JBQVFDLEdBQVIsQ0FBWTJFLEdBQVo7QUFDSCxTQXZGRDtBQXdGSCxLQTNOUTtBQTZOVHFILHFCQTdOUywrQkE2Tlc7QUFDaEJuUCxhQUFLb1Asc0JBQUwsQ0FBNEI7QUFDeEJDLG9CQUFRLGtDQURnQixFQUNvQjtBQUM1QzNFLGtCQUFNLHlCQUF5QixLQUFLTixRQUFMLENBQWN6SSxNQUZyQjtBQUd4QjtBQUNBMk4sdUJBQVc7QUFDUDtBQURPLGFBSmE7QUFPeEJ6SCxxQkFBUyxpQkFBU0MsR0FBVCxFQUFjO0FBQ25CNUUsd0JBQVFDLEdBQVIsQ0FBWTJFLEdBQVo7QUFDQTtBQUNILGFBVnVCO0FBV3hCeUgsc0JBQVUsb0JBQVc7QUFDakJ2UCxxQkFBS3lILFNBQUwsQ0FBZSxFQUFFMUYsT0FBTyxRQUFULEVBQWY7QUFDQTtBQUNIO0FBZHVCLFNBQTVCO0FBZ0JILEtBOU9RO0FBK09UeUwsZUEvT1MsdUJBK09HZ0MsT0EvT0gsRUErT1k7QUFBQTs7QUFDakJBLGdCQUFRQyxPQUFSLENBQWdCLFVBQUN4TCxJQUFELEVBQVU7QUFDdEIsZ0JBQUlBLEtBQUt5TCxXQUFMLEtBQXFCLElBQXJCLElBQTZCekwsS0FBSzBMLE1BQXRDLEVBQThDO0FBQzFDLHVCQUFLN1EsSUFBTCxDQUFVMEssR0FBVixDQUFjQyxJQUFkLEdBQXFCLElBQXJCO0FBQ0gsYUFGRCxNQUVPLElBQUl4RixLQUFLeUwsV0FBTCxLQUFxQixJQUFyQixJQUE2QnpMLEtBQUswTCxNQUF0QyxFQUE4QztBQUNqRCx1QkFBSzdRLElBQUwsQ0FBVTBLLEdBQVYsQ0FBY0UsSUFBZCxHQUFxQixJQUFyQjtBQUNIO0FBQ0QsbUJBQUsvSSxPQUFMLENBQWEsRUFBRTZJLEtBQUssT0FBSzFLLElBQUwsQ0FBVTBLLEdBQWpCLEVBQWI7QUFDSCxTQVBEO0FBUUEsWUFBSSxDQUFDLEtBQUsxSyxJQUFMLENBQVUwSyxHQUFWLENBQWNFLElBQWYsSUFBdUIsS0FBSzVLLElBQUwsQ0FBVTBLLEdBQVYsQ0FBY0MsSUFBekMsRUFBK0M7QUFDM0MsaUJBQUszSyxJQUFMLENBQVVzSixTQUFWLEdBQXNCLE1BQXRCO0FBQ0EsaUJBQUt6SCxPQUFMLENBQWEsRUFBRXlILFdBQVcsTUFBYixFQUFiO0FBQ0FILGlCQUFLNEIsZ0JBQUwsQ0FBc0IsSUFBdEI7QUFDSDtBQUNKLEtBN1BROztBQThQVGlGLGlCQUFhLHFCQUFTcEwsQ0FBVCxFQUFZa00sV0FBWixFQUF5QjtBQUNsQyxZQUFJQyxRQUFRQyxTQUFTQyxjQUFULENBQXdCLFNBQXhCLENBQVo7QUFDQUYsY0FBTUcsZ0JBQU4sQ0FBdUJ0TSxDQUF2QixFQUEwQixZQUFXO0FBQ2pDa00sMkJBQWVBLGFBQWY7QUFDQUssZ0JBQUlDLEtBQUosQ0FBVyxJQUFJNUQsSUFBSixFQUFELENBQWFDLE9BQWIsRUFBVixFQUFrQzdJLENBQWxDO0FBQ0gsU0FIRCxFQUdHLEtBSEg7QUFJSCxLQXBRUTs7QUFzUVR5TSx1QkFBbUIsNkJBQVc7QUFDMUJuUSxhQUFLNkIsU0FBTCxDQUFlO0FBQ1hFLDZDQURXO0FBRVhELGtCQUFNO0FBRkssU0FBZjtBQUlBbUcsYUFBS21JLFdBQUwsQ0FBaUIsSUFBakI7QUFDQSxhQUFLN0UsT0FBTCxDQUFhOEUsSUFBYixDQUFrQixtQkFBbEI7QUFDSCxLQTdRUTs7QUErUVRDLHdCQUFvQiw4QkFBVztBQUMzQnJJLGFBQUtzSSxjQUFMLENBQW9CLElBQXBCO0FBQ0EsYUFBS2hGLE9BQUwsQ0FBYThFLElBQWIsQ0FBa0Isb0JBQWxCO0FBQ0gsS0FsUlE7O0FBb1JURyxrQkFBYyx3QkFBVztBQUNyQixhQUFLakYsT0FBTCxDQUFhOEUsSUFBYixDQUFrQixrQkFBbEI7QUFDSCxLQXRSUTs7QUF3UlQ7OztBQUdBN1EsYUFBUyxtQkFBVztBQUNoQjtBQUNBLFlBQUlYLE9BQU8sSUFBWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQW9KLGFBQUt3SSxlQUFMLENBQXFCNVIsSUFBckI7QUFDQW9KLGFBQUt5SSxpQkFBTCxDQUF1QjdSLElBQXZCO0FBQ0FvSixhQUFLMEksZ0JBQUwsQ0FBc0I5UixJQUF0QjtBQUNBO0FBQ0E7QUFDSCxLQXhTUTs7QUEwU1Q7OztBQUdBVSxZQUFRLGtCQUFXO0FBQ2YsYUFBS2dNLE9BQUwsQ0FBYThFLElBQWIsQ0FBa0IsVUFBbEI7QUFDSCxLQS9TUTs7QUFpVFQ7OztBQUdBdE0sWUFBUSxrQkFBVztBQUNmO0FBQ0EsYUFBS3dILE9BQUwsQ0FBYThFLElBQWIsQ0FBa0IsVUFBbEI7QUFDSCxLQXZUUTs7QUF5VFQ7OztBQUdBTyxjQUFVLG9CQUFXO0FBQ2pCLGFBQUtyRixPQUFMLENBQWE4RSxJQUFiLENBQWtCLFlBQWxCO0FBQ0E7QUFDQSxhQUFLOUUsT0FBTCxDQUFhc0YsR0FBYjtBQUNBLGFBQUtsUSxPQUFMLENBQWE7QUFDVHdILHNCQUFVLElBREQ7QUFFVEMsdUJBQVcsTUFGRjtBQUdUO0FBQ0FDLHNCQUFVLElBSkQ7QUFLVDtBQUNBO0FBQ0E7QUFDQTtBQUNBRywwQkFBYyxHQVRMO0FBVVRDLGdDQUFvQixJQVZYO0FBV1RDLDZCQUFpQixLQVhSO0FBWVRDLHdCQUFZLEtBWkg7QUFhVEMsdUJBQVcsRUFiRjtBQWNUQyw0QkFBZ0IsRUFkUDtBQWVUQywwQkFBYyxFQWZMO0FBZ0JUQywwQkFBYyxDQWhCTDtBQWlCVFksNEJBQWdCLENBakJQO0FBa0JUWCxtQkFBTztBQUNIQyx5QkFBUyxLQUROO0FBRUh2RCwyQkFBVyxLQUZSO0FBR0h3RCxzQkFBTSxLQUhIO0FBSUhDLHlCQUFTLEtBSk47QUFLSG5ILHFCQUFLO0FBTEY7QUFsQkUsU0FBYjtBQTBCQTtBQUNBO0FBQ0g7QUE1VlEsQ0FBYjtBQThWQUUsS0FBS0MsT0FBT0MsTUFBUCxDQUFjLEVBQWQsRUFBa0J2RCxJQUFsQixDQUFMLEU7Ozs7O0FDNVdBOztJQUFZb0osSTs7QUFDWjs7SUFBWTVCLEc7O0FBRVo7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7SUFBWTZCLEs7O0FBQ1o7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7O0lBQVl0SSxJOzs7Ozs7QUFDWjs7QUFFQSxJQUFNakIsTUFBTUMsUUFBWjtBQVpBOztBQWFBLElBQU1DLE9BQU87QUFDVDs7O0FBR0FDLFVBQU07QUFDRnFKLGtCQUFVLElBRFI7QUFFRkMsbUJBQVcsTUFGVDtBQUdGekcsZ0JBQVEsSUFITjtBQUlGMEcsa0JBQVUsSUFKUjtBQUtGQyxpQkFBUyxDQUFDO0FBQ05DLGtCQUFNLENBREE7QUFFTmIscUJBQVM7QUFGSCxTQUFELENBTFA7QUFTRmMsc0JBQWMsR0FUWjtBQVVGQyw0QkFBb0IsSUFWbEI7QUFXRkMseUJBQWlCLEtBWGY7QUFZRkMsb0JBQVksS0FaVjtBQWFGQyxtQkFBVyxFQWJUO0FBY0ZDLHdCQUFnQixFQWRkO0FBZUZDLHNCQUFjLEVBZlo7QUFnQkZDLHNCQUFjLENBaEJaO0FBaUJGQyxlQUFPO0FBQ0hDLHFCQUFTLEtBRE47QUFFSHZELHVCQUFXLEtBRlI7QUFHSHdELGtCQUFNLEtBSEg7QUFJSEMscUJBQVM7QUFKTixTQWpCTDtBQXVCRkMsc0JBQWMsRUF2Qlo7QUF3QkZDLG9CQUFZLENBeEJWO0FBeUJGQyxrQkFBVSxLQXpCUjtBQTBCRkMsdUJBQWUsRUExQmI7QUEyQkZJLHdCQUFnQixDQTNCZDtBQTRCRm1ILGNBQU0sS0E1Qko7QUE2QkY5QixpQkFBUyxLQTdCUCxFQTZCYztBQUNoQitCLG1CQUFXLEtBOUJULENBOEJlO0FBOUJmLEtBSkc7QUFvQ1RoSCxpQkFBYSx1QkFBVztBQUNwQjdHLGdCQUFRQyxHQUFSLENBQVksT0FBWjtBQUNBO0FBQ0E4RSxhQUFLOEIsV0FBTCxDQUFpQixJQUFqQjtBQUNILEtBeENRO0FBeUNUQyxvQkFBZ0Isd0JBQVN0RyxDQUFULEVBQVk7QUFDeEJ1RSxhQUFLZ0MsVUFBTCxDQUFnQnZHLEVBQUU1QyxhQUFGLENBQWdCQyxPQUFoQztBQUNILEtBM0NRO0FBNENUaVEsYUE1Q1MsdUJBNENHO0FBQ1I7QUFDQSxhQUFLdkYsVUFBTCxDQUFnQjRDLGFBQWhCLElBQWlDLEtBQUs1QyxVQUFMLENBQWdCNEMsYUFBaEIsQ0FBOEIyQyxTQUEvRCxJQUE0RSxLQUFLdkYsVUFBTCxDQUFnQjRDLGFBQWhCLENBQThCMkMsU0FBOUIsRUFBNUU7QUFDQSxhQUFLdkYsVUFBTCxDQUFnQmtELE1BQWhCLElBQTBCLEtBQUtsRCxVQUFMLENBQWdCa0QsTUFBaEIsQ0FBdUJxQyxTQUFqRCxJQUE4RCxLQUFLdkYsVUFBTCxDQUFnQmtELE1BQWhCLENBQXVCcUMsU0FBdkIsRUFBOUQ7QUFDSCxLQWhEUTs7QUFpRFRDLG9CQUFnQix3QkFBU3ZOLENBQVQsRUFBWTtBQUN4QixhQUFLc04sU0FBTDtBQUNBLFlBQUlqUSxVQUFVMkMsRUFBRTVDLGFBQUYsQ0FBZ0JDLE9BQTlCO0FBQ0EsWUFBSUEsUUFBUW1RLE1BQVIsSUFBa0IsS0FBS3BTLElBQUwsQ0FBVTZDLE1BQWhDLEVBQXdDO0FBQ3BDO0FBQ0g7QUFDRHhCLHVCQUFFc0IsSUFBRiwyQkFBK0JWLFFBQVFtUSxNQUF2QztBQUNILEtBeERROztBQTBEVDs7O0FBR0FoSCx1QkFBbUIsNkJBQVc7QUFDMUIsWUFBSUMsWUFBWTtBQUNacEksbUJBQU8sS0FBS3FJLFFBQUwsQ0FBY0MsU0FBZCxDQUF3QkMsV0FEbkI7QUFFWjVDLHFCQUFTLEtBQUswQyxRQUFMLENBQWNDLFNBQWQsQ0FBd0JPLFdBRnJCO0FBR1pMLHNCQUFVLEtBQUtILFFBQUwsQ0FBY0MsU0FBZCxDQUF3QkcsS0FBeEIsQ0FBOEJDLE9BQTlCLENBQXNDLFVBQXRDLEVBQWtELFVBQWxELENBSEU7QUFJWkMsa0JBQU0seUJBQXlCLEtBQUtOLFFBQUwsQ0FBY3pJO0FBSmpDLFNBQWhCO0FBTUEsZUFBT3dJLFNBQVA7QUFDSCxLQXJFUTs7QUF1RVRRLGtCQUFjLHdCQUFXO0FBQ3JCLFlBQUlSLFlBQVk7QUFDWnBJLG1CQUFPLEtBQUtxSSxRQUFMLENBQWNDLFNBQWQsQ0FBd0JDLFdBRG5CO0FBRVo1QyxxQkFBUyxLQUFLMEMsUUFBTCxDQUFjQyxTQUFkLENBQXdCTyxXQUZyQjtBQUdaTCxzQkFBVSxLQUFLSCxRQUFMLENBQWNDLFNBQWQsQ0FBd0JHLEtBQXhCLENBQThCQyxPQUE5QixDQUFzQyxVQUF0QyxFQUFrRCxVQUFsRCxDQUhFO0FBSVpDLGtCQUFNLHlCQUF5QixLQUFLTixRQUFMLENBQWN6STtBQUpqQyxTQUFoQjtBQU1BM0IsYUFBSzZLLFNBQUwsQ0FBZVYsU0FBZjtBQUNILEtBL0VRO0FBZ0ZUOzs7QUFHQVcsV0FBTztBQUNIQyxrQkFBVSxvQkFBVyxDQUFFO0FBRHBCLEtBbkZFO0FBc0ZUO0FBQ0EzSyxPQXZGUyxpQkF1Rkg7QUFDRkQsdUJBQUVDLEdBQUYsQ0FBTTtBQUNGNEssa0JBQVMsS0FBS1osUUFBTCxDQUFjYyxTQUF2QixvRUFERTtBQUVGRSxzQkFBYSxLQUFLaEIsUUFBTCxDQUFjYyxTQUEzQixTQUF5QyxLQUFLZCxRQUFMLENBQWNjLFNBQXZELHNCQUF3RSxLQUFLZCxRQUFMLENBQWNjLFNBQXRGLDJCQUF1RyxLQUFLZCxRQUFMLENBQWNjLFNBQXJILHNDQUF1SSxLQUFLZCxRQUFMLENBQWNjLFNBQXJKLDBCQUFxSyxLQUFLZCxRQUFMLENBQWNjLFNBQW5MLGlCQUZFO0FBR0ZuSixtQkFBVSxLQUFLcUksUUFBTCxDQUFjYyxTQUF4QjtBQUhFLFNBQU47QUFLSCxLQTdGUTtBQThGVFMsY0E5RlMsd0JBOEZJO0FBQ1QsWUFBSXhLLGFBQWF2QyxTQUFTdUMsVUFBMUI7QUFDQSxhQUFLdUssTUFBTCxHQUFjLElBQUlHLGtCQUFKLENBQVc7QUFDckJDLGdCQUFJM0ssV0FBVzJLLEVBQVgsSUFBaUIsWUFEQTtBQUVyQkMsZUFBRzVLLFdBQVc2SyxFQUFYLElBQWlCLFFBRkM7QUFHckJDLHFCQUFTOUssV0FBVzhLLE9BQVgsSUFBc0IsU0FIVixFQUdxQjtBQUMxQ0MsdUJBQVd0TSxLQUFLdU0sV0FBTCxNQUFzQixFQUpaO0FBS3JCQyxvQkFBUSxFQUxhO0FBTXJCcEssaUJBQUssa0JBTmdCO0FBT3JCTCxvQkFBUSxLQUFLN0MsSUFBTCxDQUFVNkM7QUFQRyxTQUFYLEVBUVgzQixJQVJXLENBQWQ7QUFTSCxLQXpHUTtBQTBHVG1SLG9CQTFHUyw0QkEwR1FDLElBMUdSLEVBMEdjO0FBQ25CLGFBQUt6USxPQUFMLENBQWE7QUFDVCx5QkFBYXlRLFFBQVE7QUFEWixTQUFiO0FBR0gsS0E5R1E7QUErR1Q5UixVQS9HUyxrQkErR0ZnTSxHQS9HRSxFQStHRztBQUNSO0FBQ0E7QUFDQUEsY0FBTSxFQUFFM0osUUFBUTJKLE9BQU9BLElBQUkzSixNQUFYLElBQXFCLEtBQUt5SSxRQUFMLElBQWlCLEtBQUtBLFFBQUwsQ0FBYzZDLE1BQXBELElBQThELEVBQXhFLEVBQU47QUFDQSxhQUFLMUIsT0FBTCxHQUFlLElBQUlDLGlCQUFKLEVBQWY7QUFDQTVNLGlCQUFTeVMsT0FBVCxHQUFtQixLQUFLOUYsT0FBeEI7QUFDQSxhQUFLbkIsUUFBTCxHQUFnQixFQUFoQjtBQUNBLGFBQUtxQixVQUFMLEdBQWtCLEVBQWxCO0FBQ0EsYUFBSzlLLE9BQUwsQ0FBYTtBQUNULHNCQUFVMkssSUFBSTNKO0FBREwsU0FBYjtBQUdBLGFBQUt3UCxnQkFBTCxHQVhRLENBV2lCO0FBQ3pCLFlBQUk3RixJQUFJZ0csR0FBUixFQUFhO0FBQ1RqTCxnQkFBSWtMLE1BQUosQ0FBVyxNQUFYO0FBQ0g7QUFDRCxhQUFLN0YsTUFBTCxHQUFjLEVBQWQ7QUFDQSxhQUFLQyxVQUFMO0FBQ0EsYUFBS0MsT0FBTCxDQUFhTixHQUFiO0FBQ0gsS0FqSVE7QUFrSVRNLFdBbElTLG1CQWtJRE4sR0FsSUMsRUFrSUk7QUFBQTs7QUFDVCxZQUFJZSxXQUFXLElBQUlDLElBQUosR0FBV0MsT0FBWCxFQUFmO0FBQ0FsRyxZQUFJbUcsV0FBSixDQUFnQmxCLElBQUkzSixNQUFwQixFQUE0QjRFLElBQTVCLENBQWlDLGVBQU87QUFDcEMsZ0JBQUlrRyxTQUFTLElBQUlILElBQUosR0FBV0MsT0FBWCxFQUFiO0FBQ0Esa0JBQUtiLE1BQUwsQ0FBWWdCLElBQVosQ0FBaUIsTUFBS2hCLE1BQUwsQ0FBWWlCLElBQVosQ0FBaUJDLG9CQUFsQyxFQUF3RDlFLElBQUkrRSxJQUE1RCxFQUFrRUosU0FBU0osUUFBM0UsRUFBcUYsQ0FBckYsRUFBd0YsRUFBeEYsT0FBK0Z2RSxJQUFJZ0YsR0FBbkc7O0FBRUEsZ0JBQUloRixJQUFJK0UsSUFBSixLQUFhLFFBQWpCLEVBQTJCO0FBQ3ZCLHNCQUFLekMsUUFBTCxHQUFnQnRDLElBQUloSixJQUFwQjtBQUNBLHNCQUFLc0wsUUFBTCxDQUFjekksTUFBZCxHQUF1Qm1HLElBQUloSixJQUFKLENBQVNrTyxXQUFULENBQXFCQyxNQUE1QztBQUNBLHNCQUFLN0MsUUFBTCxDQUFjMkMsSUFBZCxHQUFxQmpGLElBQUloSixJQUFKLENBQVNrTyxXQUFULENBQXFCQyxNQUExQztBQUNBLHNCQUFLN0MsUUFBTCxDQUFjNkMsTUFBZCxHQUF1Qm5GLElBQUloSixJQUFKLENBQVNrTyxXQUFULENBQXFCQyxNQUE1QztBQUNBLHNCQUFLN0MsUUFBTCxDQUFjb0gsYUFBZCxHQUE4QjFKLElBQUloSixJQUFKLENBQVNrTyxXQUFULENBQXFCd0UsYUFBbkQ7QUFDQSxzQkFBS3BILFFBQUwsQ0FBY2YsVUFBZCxHQUEyQnZCLElBQUloSixJQUFKLENBQVNrTyxXQUFULENBQXFCRSxVQUFoRDtBQUNBLHNCQUFLOUMsUUFBTCxDQUFjOEMsVUFBZCxHQUEyQnBGLElBQUloSixJQUFKLENBQVNrTyxXQUFULENBQXFCRSxVQUFoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFLOUMsUUFBTCxDQUFjK0MsVUFBZCxHQUEyQnJGLElBQUloSixJQUFKLENBQVNzTyxRQUFULENBQWtCRCxVQUE3QztBQUNBLHNCQUFLL0MsUUFBTCxDQUFjcUgsYUFBZCxHQUE4QjNKLElBQUloSixJQUFKLENBQVNzTyxRQUFULENBQWtCRCxVQUFoRDs7QUFFQTtBQUNBOztBQUVBLHNCQUFLL0MsUUFBTCxDQUFjQyxTQUFkLEdBQTBCdkMsSUFBSWhKLElBQUosQ0FBU3VMLFNBQW5DO0FBQ0Esb0JBQUlxSCxZQUFZO0FBQ1ovUCw0QkFBUW1HLElBQUloSixJQUFKLENBQVNrTyxXQUFULENBQXFCckwsTUFBckIsSUFBK0JtRyxJQUFJaEosSUFBSixDQUFTa08sV0FBVCxDQUFxQkMsTUFEaEQ7QUFFWkEsNEJBQVFuRixJQUFJaEosSUFBSixDQUFTa08sV0FBVCxDQUFxQkMsTUFBckIsSUFBK0JuRixJQUFJaEosSUFBSixDQUFTa08sV0FBVCxDQUFxQnJMLE1BRmhEO0FBR1orTCxtQ0FBZTVGLElBQUloSixJQUFKLENBQVNrTyxXQUFULENBQXFCVSxhQUFyQixJQUFzQzVGLElBQUloSixJQUFKLENBQVN1TCxTQUFULENBQW1CRyxLQUFuQixDQUF5QkMsT0FBekIsQ0FBaUMsVUFBakMsRUFBNkMsVUFBN0MsQ0FIekM7QUFJWjdJLDhCQUFVLENBSkU7QUFLWitMLGdDQUFZN0YsSUFBSWhKLElBQUosQ0FBU2tPLFdBQVQsQ0FBcUJXLFVBTHJCO0FBTVo1TCwyQkFBTytGLElBQUloSixJQUFKLENBQVNrTyxXQUFULENBQXFCMUMsV0FBckIsSUFBb0N4QyxJQUFJaEosSUFBSixDQUFTa08sV0FBVCxDQUFxQnBDLFdBTnBEO0FBT1o7QUFDQWdELGdDQUFZLElBQUl0QixJQUFKLEdBQVdDLE9BQVg7QUFSQSxpQkFBaEI7QUFVQXBNLCtCQUFFa0gsTUFBRixDQUFTcUssU0FBVDtBQUNBLG9CQUFJN0QsU0FBUztBQUNUWiw0QkFBUW5GLElBQUloSixJQUFKLENBQVNrTyxXQUFULENBQXFCQyxNQURwQjtBQUVUL0IsK0JBQVdwRCxJQUFJaEosSUFBSixDQUFTa08sV0FBVCxDQUFxQjFDLFdBQXJCLElBQW9DeEMsSUFBSWhKLElBQUosQ0FBU2tPLFdBQVQsQ0FBcUJwQyxXQUYzRDtBQUdUdkIsZ0NBQVl2QixJQUFJaEosSUFBSixDQUFTa08sV0FBVCxDQUFxQkUsVUFIeEIsRUFHb0M7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTdFLDhCQUFVO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBUVAsSUFBSWhKLElBQUosQ0FBU2tPLFdBQVQsQ0FBcUJwQyxXQUFyQixJQUFvQzlDLElBQUloSixJQUFKLENBQVNrTyxXQUFULENBQXFCMUMsV0FMM0Q7QUFNTiwrQkFBT3hDLElBQUloSixJQUFKLENBQVNrTyxXQUFULENBQXFCVztBQU50QixxQkFSRDtBQWdCVGdFLG1DQUFlN0osSUFBSWhKLElBQUosQ0FBUzZTLGFBaEJmLEVBZ0I4QjtBQUN2Q0MsdUNBQW1COUosSUFBSWhKLElBQUosQ0FBU3NPLFFBQVQsQ0FBa0J5RSxhQWpCNUI7QUFrQlRDLDhCQUFVaEssSUFBSWhKLElBQUosQ0FBU2dULFFBbEJWLENBa0JvQjtBQUM3QjtBQW5CUyxpQkFBYjs7QUFzQkEsb0JBQUlMLGdCQUFnQixJQUFJbkYsSUFBSixDQUFTeEUsSUFBSWhKLElBQUosQ0FBU2tPLFdBQVQsSUFBd0JsRixJQUFJaEosSUFBSixDQUFTa08sV0FBVCxDQUFxQnlFLGFBQTdDLElBQThELElBQXZFLENBQXBCO0FBQ0E1RCx1QkFBTyxlQUFQLElBQTBCMU4sZUFBRTRSLElBQUYsQ0FBT0MsTUFBUCxDQUFjUCxhQUFkLEVBQTZCLGFBQTdCLENBQTFCOztBQUVBLHNCQUFLclIsR0FBTDtBQUNBLHNCQUFLTyxPQUFMLENBQWFrTixNQUFiOztBQUVBO0FBQ0Esc0JBQUtsTixPQUFMLENBQWEsRUFBRSxnQkFBZ0JtSCxJQUFJaEosSUFBSixDQUFTdUwsU0FBVCxDQUFtQkcsS0FBbkIsSUFBNEIsK0RBQTlDLEVBQWI7QUFDQXhLLHFCQUFLb08scUJBQUwsQ0FBMkI7QUFDdkJyTSwyQkFBTytGLElBQUloSixJQUFKLENBQVNrTyxXQUFULENBQXFCMUM7QUFETCxpQkFBM0I7QUFHQSxzQkFBS21CLFVBQUwsQ0FBZ0J3RyxhQUFoQixHQUFnQyxJQUFJQSxzQkFBSixDQUFrQixLQUFsQixFQUF3Qm5LLElBQUloSixJQUFKLENBQVNvVCxVQUFqQyxDQUFoQztBQUNBLHNCQUFLekcsVUFBTCxDQUFnQjRDLGFBQWhCLEdBQWdDLElBQUlDLHNCQUFKLENBQWtCLEtBQWxCLENBQWhDO0FBQ0E7QUFDQTtBQUNBakksb0JBQUlrSSxZQUFKLENBQWlCLE1BQUtuRSxRQUFMLENBQWMrQyxVQUEvQixFQUNLNUcsSUFETCxDQUNVLFVBQUN6SCxJQUFELEVBQVU7QUFDWiwwQkFBS3NMLFFBQUwsQ0FBY29FLFNBQWQsR0FBMEIxUCxJQUExQjtBQUNBLDBCQUFLMk0sVUFBTCxDQUFnQmdELE9BQWhCLEdBQTBCLElBQUlDLHVCQUFKLENBQVksS0FBWixDQUExQjtBQUNBLDBCQUFLakQsVUFBTCxDQUFnQmtELE1BQWhCLEdBQXlCLElBQUlDLG1CQUFKLENBQWUsS0FBZixFQUFxQjlHLElBQUloSixJQUFKLENBQVNzTyxRQUFULENBQWtCRCxVQUF2QyxDQUF6QjtBQUNILGlCQUxMLEVBS08wQixLQUxQLENBS2EsVUFBQ3BJLEdBQUQsRUFBUztBQUNkdkQsNEJBQVF5RCxLQUFSLENBQWNGLEdBQWQ7QUFDQSx3QkFBSW9ILE9BQU84RCxhQUFYLEVBQTBCO0FBQ3RCLDhCQUFLUSxRQUFMLEdBRHNCLENBQ0w7QUFDcEI7QUFDSixpQkFWTDtBQVdBLHNCQUFLckQsV0FBTCxDQUFpQixnQkFBakIsRUFBbUMsVUFBU3BMLENBQVQsRUFBWTtBQUMzQ1IsNEJBQVFDLEdBQVIsQ0FBWSxnQkFBWjtBQUNILGlCQUZEO0FBR0gsYUFoRkQsTUFnRk87QUFDSCxvQkFBSTJFLElBQUkrRSxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDdkIzSiw0QkFBUXlELEtBQVIsbUNBQXVCbUIsSUFBSWdGLEdBQTNCLEVBRHVCLENBQ1U7QUFDakMsMEJBQUtwQixNQUFMLENBQVlnQixJQUFaLENBQWlCLE1BQUtoQixNQUFMLENBQVlpQixJQUFaLENBQWlCb0MsZ0JBQWxDLEVBQW9EakgsSUFBSStFLElBQXhELEVBQThESixTQUFTSixRQUF2RSxFQUFpRixDQUFqRixFQUFvRixFQUFwRixPQUEyRnZFLElBQUlnRixHQUEvRjtBQUNIO0FBQ0Qsc0JBQUtyQixVQUFMLENBQWdCNEMsYUFBaEIsR0FBZ0MsSUFBSUMsc0JBQUosQ0FBa0IsS0FBbEIsQ0FBaEM7QUFDQSxzQkFBSzNOLE9BQUwsQ0FBYTtBQUNUcU8sNkJBQVMsSUFEQSxFQUNNO0FBQ2ZoRywyQkFBTztBQUNIRSw4QkFBTSxLQURIO0FBRUgrRixtQ0FBVyxJQUZSO0FBR0hDLGtDQUFVcEgsSUFBSWdGLEdBQUosSUFBVztBQUhsQixxQkFGRTtBQU9UMUQsa0NBQWM7QUFQTCxpQkFBYjtBQVNIO0FBQ0osU0FwR0QsRUFvR0csZUFBTztBQUNObEcsb0JBQVFDLEdBQVIsQ0FBWTJFLEdBQVo7QUFDSCxTQXRHRDtBQXVHSCxLQTNPUTs7QUE0T1RnSCxpQkFBYSxxQkFBU3BMLENBQVQsRUFBWWtNLFdBQVosRUFBeUI7QUFDbEMsWUFBSUMsUUFBUUMsU0FBU0MsY0FBVCxDQUF3QixTQUF4QixDQUFaO0FBQ0FGLGNBQU1HLGdCQUFOLENBQXVCdE0sQ0FBdkIsRUFBMEIsWUFBVztBQUNqQ2tNLDJCQUFlQSxhQUFmO0FBQ0FLLGdCQUFJQyxLQUFKLENBQVcsSUFBSTVELElBQUosRUFBRCxDQUFhQyxPQUFiLEVBQVYsRUFBa0M3SSxDQUFsQztBQUNILFNBSEQsRUFHRyxLQUhIO0FBSUgsS0FsUFE7QUFtUFR5TyxZQW5QUyxzQkFtUEU7QUFBQTs7QUFDUDtBQUNBLGFBQUt4UixPQUFMLENBQWEsRUFBRSxRQUFRLENBQUMsS0FBSzdCLElBQUwsQ0FBVWdTLElBQXJCLEVBQWIsRUFBMEMsWUFBTTtBQUM1QyxnQkFBSSxPQUFLaFMsSUFBTCxDQUFVNlMsYUFBZCxFQUE2QjtBQUN6QixvQkFBSSxDQUFDLE9BQUs3UyxJQUFMLENBQVVnUyxJQUFmLEVBQXFCO0FBQ2pCN0kseUJBQUt5SSxpQkFBTCxDQUF1QixNQUF2QixFQUE2QixLQUE3QjtBQUNILGlCQUZELE1BRU87QUFDSHpJLHlCQUFLeUksaUJBQUwsQ0FBdUIsTUFBdkIsRUFBNkIsSUFBN0I7QUFDSDtBQUNKLGFBTkQsTUFNTztBQUNIekkscUJBQUt5SSxpQkFBTCxDQUF1QixNQUF2QjtBQUNIO0FBRUosU0FYRDtBQVlILEtBalFROztBQWtRVFAsdUJBQW1CLDZCQUFXO0FBQzFCblEsYUFBSzZCLFNBQUwsQ0FBZTtBQUNYRSw2Q0FEVztBQUVYRCxrQkFBTTtBQUZLLFNBQWY7QUFJQW1HLGFBQUttSSxXQUFMLENBQWlCLElBQWpCO0FBQ0EsYUFBSzdFLE9BQUwsQ0FBYThFLElBQWIsQ0FBa0IsbUJBQWxCO0FBQ0gsS0F6UVE7O0FBMlFUQyx3QkFBb0IsOEJBQVc7QUFDM0JySSxhQUFLc0ksY0FBTCxDQUFvQixJQUFwQjtBQUNBLGFBQUtoRixPQUFMLENBQWE4RSxJQUFiLENBQWtCLG9CQUFsQjtBQUNILEtBOVFROztBQWdSVEcsa0JBQWMsd0JBQVc7QUFDckIsYUFBS2pGLE9BQUwsQ0FBYThFLElBQWIsQ0FBa0Isa0JBQWxCO0FBQ0gsS0FsUlE7O0FBb1JUOzs7QUFHQTdRLGFBQVMsbUJBQVc7QUFDaEIsWUFBSVgsT0FBTyxJQUFYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBb0osYUFBS3dJLGVBQUwsQ0FBcUI1UixJQUFyQjtBQUNBb0osYUFBS3lJLGlCQUFMLENBQXVCN1IsSUFBdkI7QUFDQW9KLGFBQUswSSxnQkFBTCxDQUFzQjlSLElBQXRCO0FBQ0E7QUFDQTtBQUNILEtBblNROztBQXFTVDs7O0FBR0FVLFlBQVEsa0JBQVc7QUFDZixhQUFLZ00sT0FBTCxDQUFhOEUsSUFBYixDQUFrQixVQUFsQjtBQUNILEtBMVNROztBQTRTVDs7O0FBR0F0TSxZQUFRLGtCQUFXO0FBQ2ZuRixpQkFBU3lTLE9BQVQsQ0FBaUJoQixJQUFqQixDQUFzQixVQUF0QjtBQUNBLGFBQUs5RSxPQUFMLENBQWE4RSxJQUFiLENBQWtCLFVBQWxCO0FBQ0gsS0FsVFE7O0FBb1RUK0IsV0FwVFMsbUJBb1REQyxHQXBUQyxFQW9USTtBQUNUblAsZ0JBQVFzRCxJQUFSLENBQWE2TCxHQUFiO0FBQ0gsS0F0VFE7OztBQXdUVDs7O0FBR0F6QixjQUFVLG9CQUFXO0FBQ2pCLGFBQUtyRixPQUFMLENBQWE4RSxJQUFiLENBQWtCLFlBQWxCO0FBQ0EsYUFBSzlFLE9BQUwsQ0FBYXNGLEdBQWI7QUFDQSxhQUFLbFEsT0FBTCxDQUFhO0FBQ1R3SCxzQkFBVSxJQUREO0FBRVRDLHVCQUFXLE1BRkY7QUFHVHpHLG9CQUFRLElBSEM7QUFJVDBHLHNCQUFVLElBSkQ7QUFLVEMscUJBQVMsQ0FBQztBQUNOQyxzQkFBTSxDQURBO0FBRU5iLHlCQUFTO0FBRkgsYUFBRCxDQUxBO0FBU1RjLDBCQUFjLEdBVEw7QUFVVEMsZ0NBQW9CLElBVlg7QUFXVEMsNkJBQWlCLEtBWFI7QUFZVEMsd0JBQVksS0FaSDtBQWFUQyx1QkFBVyxFQWJGO0FBY1RDLDRCQUFnQixFQWRQO0FBZVRDLDBCQUFjLEVBZkw7QUFnQlRDLDBCQUFjLENBaEJMO0FBaUJUWSw0QkFBZ0IsQ0FqQlA7QUFrQlRYLG1CQUFPO0FBQ0hDLHlCQUFTLEtBRE47QUFFSHZELDJCQUFXLEtBRlI7QUFHSHdELHNCQUFNLEtBSEg7QUFJSEMseUJBQVMsS0FKTjtBQUtIbkgscUJBQUs7QUFMRjtBQWxCRSxTQUFiO0FBMEJBO0FBQ0E7QUFDSDtBQTFWUSxDQUFiO0FBNFZBRSxLQUFLQyxPQUFPQyxNQUFQLENBQWMsRUFBZCxFQUFrQnZELElBQWxCLENBQUwsRTs7Ozs7QUMzV0E7O0lBQVllLEk7O0FBRVo7Ozs7QUFDQTs7OztBQUNBOztJQUFZeUcsRzs7QUFDWjs7OztBQUNBOzs7Ozs7Ozs7QUFMQTs7O0FBUUEsSUFBTTFILE1BQU1DLFFBQVo7O0FBRUEsSUFBTTBULFVBQVUsU0FBVkEsT0FBVSxDQUFDQyxRQUFELEVBQWM7QUFDMUIsUUFBSUMsT0FBTyxpQkFBWDtBQUNBLFFBQUlDLE9BQU8sVUFBWDtBQUNBLFdBQU8sRUFBRUEsS0FBS0MsSUFBTCxDQUFVSCxRQUFWLEtBQXVCQyxLQUFLRSxJQUFMLENBQVVILFFBQVYsQ0FBekIsQ0FBUDtBQUNILENBSkQ7O0FBTUEsSUFBTTFULE9BQU87QUFDVEMsVUFBTTtBQUNGNlQsa0JBQVUsQ0FEUjtBQUVGQyxvQkFBWXZNLElBQUl3TSxjQUFKLEVBRlY7QUFHRkMsaUJBQVMsY0FIUDtBQUlGbk0sZUFBTztBQUNIdUMsa0JBQU0sS0FESDtBQUVINEQsaUJBQUs7QUFGRixTQUpMO0FBUUZpRyx3QkFBZ0IsSUFSZDtBQVNGUixrQkFBVSxFQVRSLEVBU1c7QUFDYlMsa0JBQVU7QUFDTjlKLGtCQUFNLEtBREE7QUFFTjJELGtCQUFNLEVBRkE7QUFHTm9HLG1CQUFPO0FBSEQsU0FWUjtBQWVGQyxrQkFBVTtBQWZSLEtBREc7O0FBbUJUM1QsVUFuQlMsb0JBbUJBLENBRVIsQ0FyQlE7QUFzQlRDLFdBdEJTLHFCQXNCQyxDQUNULENBdkJRO0FBd0JURixVQXhCUyxvQkF3QkE7QUFDTCxhQUFLRyxRQUFMO0FBQ0gsS0ExQlE7QUEyQlRBLFlBM0JTLHNCQTJCRTtBQUNQLGFBQUswVCxZQUFMLENBQWtCLEVBQUVDLE9BQU8sQ0FBVCxFQUFZQyxnQkFBZ0IsQ0FBNUIsRUFBbEI7QUFDSCxLQTdCUTtBQThCVHRULGVBOUJTLHVCQThCR2pCLElBOUJILEVBOEJTO0FBQ2Q7QUFDQXFCLHVCQUFFQyxHQUFGLEdBRmMsQ0FFTDtBQUNaLEtBakNRO0FBa0NUcUIsUUFsQ1MsZ0JBa0NKbkIsS0FsQ0ksRUFrQ0c7QUFDUjtBQUNBO0FBQ0E7QUFDQSxZQUFNTyxTQUFTUCxNQUFNUSxhQUFyQjtBQUNBLFlBQU1rQixNQUFNbkIsT0FBT0UsT0FBUCxDQUFlaUIsR0FBM0I7QUFDQTdCLHVCQUFFc0IsSUFBRixDQUFPTyxHQUFQO0FBQ0gsS0F6Q1E7O0FBMENUO0FBQ0FtUixrQkFBYyxzQkFBVXRGLE1BQVYsRUFBa0I7QUFBQTs7QUFDNUJ4SCxZQUFJaU4sV0FBSixDQUFnQnpGLE1BQWhCLEVBQXdCdEgsSUFBeEIsQ0FBNkIsZ0JBQVE7QUFDakM7QUFDQSxrQkFBSzVGLE9BQUwsbUJBQWtCMEYsSUFBSWtOLFVBQUosQ0FBZXpVLElBQWYsQ0FBbEIsR0FBMEMsWUFBTTtBQUM1QyxzQkFBSzBVLFFBQUw7QUFDSCxhQUZEO0FBR0gsU0FMRDtBQU1ILEtBbERRO0FBbURUO0FBQ0FDLGdCQUFZLG9CQUFVL1AsQ0FBVixFQUFhO0FBQUEsWUFDRWlQLFFBREYsR0FDaUJqUCxDQURqQixDQUNmakQsTUFEZSxDQUNMd1MsS0FESzs7QUFFckIsYUFBS3RTLE9BQUwsQ0FBYSxFQUFFZ1Msa0JBQUYsRUFBYjtBQUNILEtBdkRRO0FBd0RUO0FBQ0FlLGlCQUFhLHFCQUFVaFEsQ0FBVixFQUFhO0FBQUE7O0FBQ3RCO0FBRHNCLFlBRVk2RSxJQUZaLEdBRWlEN0UsQ0FGakQsQ0FFaEI1QyxhQUZnQixDQUVDQyxPQUZELENBRVl3SCxJQUZaO0FBQUEsOEJBRWlEN0UsQ0FGakQsQ0FFc0JqRCxNQUZ0QixDQUVnQ3dTLEtBRmhDO0FBQUEsWUFFZ0NBLEtBRmhDLG1DQUV3QyxFQUZ4QztBQUFBLFlBR2hCdE0sS0FIZ0IsR0FHTixLQUFLN0gsSUFIQyxDQUdoQjZILEtBSGdCO0FBSXRCOztBQUNBQSxjQUFNdUMsSUFBTixLQUFldkMsTUFBTXVDLElBQU4sR0FBYSxLQUE1QjtBQUNBLGFBQUt2SSxPQUFMLDJDQUFnQjRILElBQWhCLEVBQXVCMEssS0FBdkIsc0NBQThCdE0sS0FBOUI7QUFDQSxhQUFLNk0sUUFBTDtBQUNILEtBakVRO0FBa0VUO0FBQ0FHLGVBQVcsbUJBQVVqUSxDQUFWLEVBQWE7QUFBQSxvQkFDWSxLQUFLNUUsSUFEakI7QUFBQSxZQUNkNkgsS0FEYyxTQUNkQSxLQURjO0FBQUEsWUFDUG9NLGNBRE8sU0FDUEEsY0FETzs7QUFFcEIsWUFBRyxDQUFDQSxjQUFKLEVBQW9CO0FBQ3BCcE0sY0FBTXVDLElBQU4sR0FBYSxJQUFiO0FBQ0EsYUFBS3ZJLE9BQUwsQ0FBYSxFQUFFZ0csWUFBRixFQUFiO0FBQ0gsS0F4RVE7QUF5RVQ7QUFDQTZNLGNBQVUsb0JBQVk7QUFBQSxxQkFDOEIsS0FBSzFVLElBRG5DO0FBQUEsWUFDWnlULFFBRFksVUFDWkEsUUFEWTtBQUFBLFlBQ0ZLLFVBREUsVUFDRkEsVUFERTtBQUFBLFlBQ1VELFFBRFYsVUFDVUEsUUFEVjtBQUFBLFlBQ29CaE0sS0FEcEIsVUFDb0JBLEtBRHBCO0FBQUEsWUFFWmlOLEtBRlksR0FFRmhCLFdBQVdELFFBQVgsQ0FGRSxDQUVaaUIsS0FGWTs7QUFHbEIsWUFBSWIsaUJBQWlCLEtBQXJCOztBQUVBLFlBQUcsQ0FBQ1IsUUFBSixFQUFjO0FBQ1ZRLDZCQUFpQixJQUFqQjtBQUNBcE0sa0JBQU1tRyxHQUFOLEdBQVksU0FBWjtBQUNILFNBSEQsTUFHTztBQUNILGdCQUFHd0YsUUFBUUMsUUFBUixDQUFILEVBQXNCO0FBQUEsNENBQzBCc0IseUJBQWVDLGlCQUFmLENBQWlDdkIsU0FBUzlILE9BQVQsQ0FBaUIsVUFBakIsRUFBNkIsRUFBN0IsQ0FBakMsRUFBbUVtSixLQUFuRSxDQUQxQjtBQUFBLG9CQUNaRyxNQURZLHlCQUNaQSxNQURZO0FBQUEsb0JBQ0pDLFVBREkseUJBQ0pBLFVBREk7QUFBQSxvQkFDUUMsYUFEUix5QkFDUUEsYUFEUjs7QUFFbEIsb0JBQUcsQ0FBQyxDQUFDRixNQUFGLElBQVksQ0FBQ0MsVUFBYixJQUEyQixDQUFDQyxhQUEvQixFQUE4QztBQUMxQ2xCLHFDQUFpQixJQUFqQjtBQUNBcE0sMEJBQU1tRyxHQUFOLEdBQVksZUFBWjtBQUNIO0FBQ0o7QUFDSjtBQUNELGFBQUtuTSxPQUFMLENBQWEsRUFBRWdHLFlBQUYsRUFBU29NLDhCQUFULEVBQWI7QUFDQSxlQUFPLEVBQUVwTSxZQUFGLEVBQVNvTSw4QkFBVCxFQUFQO0FBQ0gsS0E3RlE7QUE4RlQ7QUFDQW1CLGdCQUFZLHNCQUFZO0FBQUE7O0FBQUEscUJBQzRCLEtBQUtwVixJQURqQztBQUFBLFlBQ2R5VCxRQURjLFVBQ2RBLFFBRGM7QUFBQSxZQUNKSyxVQURJLFVBQ0pBLFVBREk7QUFBQSxZQUNRRCxRQURSLFVBQ1FBLFFBRFI7QUFBQSxZQUNrQmhNLEtBRGxCLFVBQ2tCQSxLQURsQjtBQUFBLFlBRWRpTixLQUZjLEdBRUpoQixXQUFXRCxRQUFYLENBRkksQ0FFZGlCLEtBRmM7OztBQUlwQixZQUFNTyxTQUFTLEtBQUtyVixJQUFMLENBQVVxVixNQUFWLElBQW9CLEVBQW5DO0FBQ0EsWUFBTUMsV0FBVyxLQUFLdFYsSUFBTCxDQUFVc1YsUUFBVixJQUFzQixFQUF2QztBQUNBLFlBQU1DLFFBQVEsS0FBS3ZWLElBQUwsQ0FBVXVWLEtBQVYsSUFBbUIsRUFBakM7O0FBRUEsWUFBSUMsV0FBVyxLQUFLeFYsSUFBTCxDQUFVeVQsUUFBVixJQUFzQixFQUFyQzs7QUFFQSxZQUFNUSxpQkFBaUIsS0FBS2pVLElBQUwsQ0FBVWlVLGNBQWpDOztBQUVBLFlBQUdBLGNBQUgsRUFBbUI7QUFDZjtBQUNIOztBQUVELFlBQUl3QixZQUFZLEtBQUt6VixJQUFMLENBQVV5VixTQUFWLElBQXVCLEVBQXZDO0FBQ0EsWUFBSUMsY0FBYyxFQUFsQjtBQUNBLFlBQUkzRyxTQUFTO0FBQ1QyRyx5QkFBYUEsV0FESjtBQUVUO0FBQ0E7QUFDQTtBQUNBQyw2QkFBaUJDLGtCQUFRQyxhQUFSLENBQXNCTCxRQUF0QixDQUxSO0FBTVRNLHVCQUFXaEIsS0FORjtBQU9UaUIsdUJBQVcsQ0FQRjtBQVFUQyxpQkFBS2xWLEtBQUt1TSxXQUFMLEVBUkk7QUFTVDRJLG1CQUFPblYsS0FBS3VNLFdBQUwsRUFURTtBQVVUNkksZ0JBQUk7QUFWSyxTQUFiOztBQWFBLFlBQUcsS0FBS2QsVUFBTCxDQUFnQmUsVUFBbkIsRUFBK0I7QUFDM0I7QUFDSDtBQUNELGFBQUtmLFVBQUwsQ0FBZ0JlLFVBQWhCLEdBQTZCLElBQTdCOztBQUVBLFlBQUdqVixLQUFLbUUsV0FBUixFQUFxQjtBQUNqQm5FLGlCQUFLbUUsV0FBTCxDQUFpQjtBQUNicEMsdUJBQU8sS0FETTtBQUVicUMsc0JBQU07QUFGTyxhQUFqQjtBQUlIOztBQUVELFlBQUk4USwwRUFBd0VmLE1BQXhFLG1CQUE0RlAsS0FBNUYsZUFBMkdVLFFBQTNHLHFCQUFtSUUsV0FBbkksa0JBQTJKSixRQUEzSixlQUE2S0MsS0FBN0ssbUJBQWdNRSxTQUFwTTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUFsTyxZQUFJOE8sZ0JBQUosQ0FBcUJ0SCxNQUFyQixFQUE2QnRILElBQTdCLENBQWtDLFVBQUN6SCxJQUFELEVBQVU7QUFDeENvRSxvQkFBUUMsR0FBUixDQUFZckUsSUFBWjtBQUNBLGdCQUFHa0IsS0FBS0UsV0FBUixFQUFxQjtBQUNqQkYscUJBQUtFLFdBQUw7QUFDSDtBQUNELGdCQUFHcEIsS0FBSytOLElBQUwsS0FBYyxRQUFqQixFQUEyQjtBQUN2QjFNLCtCQUFFc0IsSUFBRixDQUFPeVQsbUJBQVA7QUFDSCxhQUZELE1BRU87QUFDSCxvQkFBR3BXLEtBQUsrTixJQUFMLEtBQWMsUUFBakIsRUFBMkI7QUFDdkI3TSx5QkFBSzZCLFNBQUwsQ0FBZTtBQUNYRSx1TEFEVztBQUVYRCw4QkFBTTtBQUZLLHFCQUFmO0FBSUgsaUJBTEQsTUFLTztBQUNIOUIseUJBQUs2QixTQUFMLENBQWU7QUFDWEUsb0NBQVVqRCxLQUFLZ08sR0FESjtBQUVYaEwsOEJBQU07QUFGSyxxQkFBZjtBQUlIO0FBQ0o7O0FBRUQ7QUFDQSxtQkFBS2hELElBQUwsQ0FBVWlVLGNBQVYsR0FBMkIsS0FBM0I7QUFDQSxtQkFBS3BTLE9BQUwsQ0FBYSxFQUFFb1MsZ0JBQWdCLE9BQUtqVSxJQUFMLENBQVVpVSxjQUE1QixFQUFiO0FBQ0FyVCx1QkFBVyxZQUFNO0FBQ2IsdUJBQUt3VSxVQUFMLENBQWdCZSxVQUFoQixHQUE2QixLQUE3QjtBQUNILGFBRkQsRUFFRyxDQUZIO0FBR0gsU0EzQkQsRUEyQkcsVUFBQ3RPLEtBQUQsRUFBVztBQUNWekQsb0JBQVF5RCxLQUFSLENBQWNBLEtBQWQ7QUFDQSxtQkFBS3VOLFVBQUwsQ0FBZ0JlLFVBQWhCLEdBQTZCLEtBQTdCO0FBQ0FqVixpQkFBSzZCLFNBQUwsQ0FBZTtBQUNYRSw0QkFBVTRFLE1BQU1tRyxHQURMO0FBRVhoTCxzQkFBTTtBQUZLLGFBQWY7QUFJQTtBQUNBLG1CQUFLaEQsSUFBTCxDQUFVaVUsY0FBVixHQUEyQixLQUEzQjtBQUNBLG1CQUFLcFMsT0FBTCxDQUFhLEVBQUVvUyxnQkFBZ0IsT0FBS2pVLElBQUwsQ0FBVWlVLGNBQTVCLEVBQWI7QUFDSCxTQXJDRDtBQXNDSDs7QUF0TFEsQ0FBYjs7QUE0TEE3USxLQUFLQyxPQUFPQyxNQUFQLENBQWMsRUFBZCxFQUFrQnZELElBQWxCLENBQUwsRTs7Ozs7QUM3TUE7Ozs7QUFDQTs7Ozs7O0FBR0EsSUFBSUYsTUFBTUMsUUFBVjtBQUNBLElBQUl1QyxhQUFheEMsSUFBSXdDLFVBQXJCO0FBQ0EsSUFBTW9FLGFBQWEsNERBQW5COztBQUVBLElBQU0xRyxPQUFPO0FBQ1RDLFVBQU0sRUFERztBQUVUUyxVQUZTLG9CQUVBLENBQ1IsQ0FIUTtBQUlUbUgsWUFKUyxzQkFJRTtBQUFBOztBQUNQeEQsZ0JBQVFDLEdBQVIsQ0FBWWhDLFVBQVo7QUFDQW5CLGFBQUt5SCxTQUFMLENBQWU7QUFDWDFGLG1CQUFPLE1BREk7QUFFWDRGLHlCQUFhLFNBRkY7QUFHWEMsMEJBQWMsU0FISDtBQUlYQyxxQkFBUyxpQkFBQ0MsR0FBRCxFQUFTO0FBQ2Qsb0JBQUdBLElBQUlDLE9BQVAsRUFBZ0I7QUFDWjdFLDRCQUFRQyxHQUFSLENBQVksU0FBWjtBQUNBLDBCQUFLNkMsZUFBTDtBQUNILGlCQUhELE1BR08sSUFBRzhCLElBQUlFLE1BQVAsRUFBZTtBQUNsQjlFLDRCQUFRQyxHQUFSLENBQVksU0FBWjtBQUNIO0FBQ0o7QUFYVSxTQUFmO0FBYUgsS0FuQlE7QUFvQlQ2QyxtQkFwQlMsNkJBb0JTO0FBQ2QsYUFBS3JGLE9BQUwsQ0FBYSxtQkFBYixFQUFrQyxLQUFsQztBQUNBLGFBQUtBLE9BQUwsQ0FBYSxxQkFBYixFQUFvQzRFLFVBQXBDO0FBQ0EsYUFBSzVFLE9BQUwsQ0FBYSx5QkFBYixFQUF3QyxFQUF4QztBQUNBLGFBQUtBLE9BQUwsQ0FBYSxzQkFBYixFQUFxQyxLQUFyQztBQUNBUSxtQkFBV3dFLFVBQVgsR0FBd0IsRUFBeEI7QUFDQWlCLDBCQUFRQyxPQUFSLENBQWdCQyxLQUFoQjtBQUNBM0csdUJBQUVzQixJQUFGLENBQU8sRUFBQyxRQUFPLE1BQVIsRUFBUDtBQUNILEtBNUJRO0FBNkJUQSxRQTdCUyxnQkE2QkpuQixLQTdCSSxFQTZCRztBQUNSLFlBQU1PLFNBQVNQLE1BQU1RLGFBQXJCO0FBQ0EsWUFBTWtCLE1BQU1uQixPQUFPRSxPQUFQLENBQWVpQixHQUEzQjtBQUNBO0FBQ0E3Qix1QkFBRXNCLElBQUYsQ0FBT08sR0FBUDtBQUNILEtBbENRO0FBbUNUeEMsV0FuQ1MscUJBbUNDLENBQ1QsQ0FwQ1E7QUFxQ1RGLFVBckNTLG9CQXFDQTtBQUNMO0FBQ0g7QUF2Q1EsQ0FBYjs7QUEyQ0E0QyxLQUFLQyxPQUFPQyxNQUFQLENBQWMsRUFBZCxFQUFrQnZELElBQWxCLENBQUwsRTs7Ozs7QUNuREE7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7O0lBQVllLEk7O0FBQ1o7Ozs7QUFDQTs7SUFBWXdWLFU7O0FBQ1o7Ozs7QUFDQTs7SUFBWUMsTTs7Ozs7O0FBRVosSUFBTTFXLE1BQU1DLFFBQVo7QUFDQSxJQUFNMFcsc0JBQXlCblYsZUFBRW9WLFNBQUYsQ0FBWUMsUUFBckMsbURBQU47QUFDQSxJQUFNM1csT0FBTztBQUNUQyxVQUFNO0FBQ0YyRyxpQkFBUyxFQURQO0FBRUZnUSxjQUFNO0FBQ0ZiLHVCQUFXLEVBRFQ7QUFFRmMsbUJBQU8sYUFGTDtBQUdGQyx1QkFBVyxhQUhUO0FBSUZDLHVCQUFXLEVBSlQ7QUFLRkMsb0JBQVE7QUFMTixTQUZKO0FBU0ZDLGlCQUFTO0FBVFAsS0FERztBQVlUdlcsVUFaUyxrQkFZRmUsS0FaRSxFQVlLO0FBQUE7O0FBQ1Y7QUFDQVosbUJBQVcsWUFBTTtBQUNiLGtCQUFLcVcsU0FBTDtBQUNILFNBRkQsRUFFRyxHQUZIO0FBR0gsS0FqQlE7QUFrQlR2VyxXQWxCUyxxQkFrQkMsQ0FDVCxDQW5CUTtBQW9CVEYsVUFwQlMsa0JBb0JGbUcsT0FwQkUsRUFvQk87QUFDWixhQUFLM0csSUFBTCxDQUFVMkcsT0FBVixHQUFvQkEsT0FBcEI7QUFDQXZDLGdCQUFRQyxHQUFSLENBQVlzQyxPQUFaO0FBQ0EsYUFBS3VRLElBQUw7QUFDSCxLQXhCUTtBQXlCVHZXLFlBekJTLHNCQXlCRTtBQUNQeUQsZ0JBQVFDLEdBQVIsQ0FBWSxLQUFaO0FBQ0gsS0EzQlE7QUE0QlRwRCxlQTVCUyx1QkE0QkdqQixJQTVCSCxFQTRCUyxDQUVqQixDQTlCUTtBQStCVGtYLFFBL0JTLGtCQStCRjtBQUFBLDRCQUN5RSxLQUFLbFgsSUFBTCxDQUFVMkcsT0FEbkY7QUFBQSxZQUNHME8sTUFESCxpQkFDR0EsTUFESDtBQUFBLFlBQ1dTLFNBRFgsaUJBQ1dBLFNBRFg7QUFBQSxZQUNzQmMsS0FEdEIsaUJBQ3NCQSxLQUR0QjtBQUFBLFlBQzZCbEIsV0FEN0IsaUJBQzZCQSxXQUQ3QjtBQUFBLFlBQzBDSixRQUQxQyxpQkFDMENBLFFBRDFDO0FBQUEsWUFDb0RDLEtBRHBELGlCQUNvREEsS0FEcEQ7QUFBQSxZQUMyREUsU0FEM0QsaUJBQzJEQSxTQUQzRDs7QUFFSCxZQUFJb0IsWUFBWUQsS0FBaEI7QUFDQSxZQUFJZCxZQUFZLEVBQWIsS0FBcUIsSUFBeEIsRUFBOEI7QUFDMUJlLHdCQUFZRCxNQUFNTyxTQUFOLENBQWdCLENBQWhCLEVBQW1CLENBQW5CLElBQXdCLE1BQXhCLEdBQWlDUCxNQUFNTyxTQUFOLENBQWdCLENBQWhCLENBQTdDO0FBQ0g7QUFDRCxhQUFLblgsSUFBTCxDQUFVb1gsU0FBVixHQUFzQlIsS0FBdEI7QUFDQSxhQUFLL1UsT0FBTCxDQUFhLGdCQUFiLEVBQStCaVUsU0FBL0I7QUFDQSxhQUFLalUsT0FBTCxDQUFhLFlBQWIsRUFBMkIrVSxLQUEzQjtBQUNBLGFBQUsvVSxPQUFMLENBQWEsZ0JBQWIsRUFBK0JnVixTQUEvQjtBQUNBLGFBQUtoVixPQUFMLENBQWEsa0JBQWIsRUFBaUM2VCxXQUFqQztBQUNBLGFBQUs3VCxPQUFMLENBQWEsYUFBYixFQUE0QndULE1BQTVCO0FBQ0EsYUFBS3hULE9BQUwsQ0FBYSxhQUFiLEVBQTRCLEtBQTVCO0FBQ0EsYUFBS3dWLFNBQUw7QUFDSCxLQTdDUTtBQThDVEEsYUE5Q1MsdUJBOENHO0FBQUE7O0FBQ1IsWUFBTXBFLE9BQU8sQ0FBYjtBQUNBLFlBQUcsS0FBS3FFLE1BQVIsRUFBZ0I7QUFDWixpQkFBS3pWLE9BQUwsQ0FBYSxhQUFiLEVBQTRCLElBQTVCO0FBQ0EwVixnQ0FBVXZQLEtBQVYsQ0FBZ0IsS0FBS3NQLE1BQXJCO0FBQ0g7QUFDRCxhQUFLdFgsSUFBTCxDQUFVd1gsTUFBVixHQUFtQnZFLElBQW5CO0FBQ0EsYUFBS3FFLE1BQUwsR0FBY0Msb0JBQVVFLEdBQVYsQ0FBYyxZQUFNO0FBQzlCLGdCQUFHLE9BQUt6WCxJQUFMLENBQVV3WCxNQUFWLElBQW9CLENBQXZCLEVBQTBCO0FBQ3RCLHVCQUFLeFgsSUFBTCxDQUFVd1gsTUFBVixHQUFtQixDQUFuQjtBQUNBLHVCQUFLM1YsT0FBTCxDQUFhLGFBQWIsRUFBNEIsSUFBNUI7QUFDSDtBQUNELG1CQUFLN0IsSUFBTCxDQUFVd1gsTUFBVjtBQUNBLG1CQUFLM1YsT0FBTCxDQUFhLEVBQUUyVixRQUFRLE9BQUt4WCxJQUFMLENBQVV3WCxNQUFwQixFQUFiO0FBQ0gsU0FQYSxFQU9YLElBUFcsRUFPTHZFLElBUEssQ0FBZDtBQVFILEtBN0RRO0FBOERUOEQsVUE5RFMsb0JBOERBO0FBQ0wxVix1QkFBRXNCLElBQUYsQ0FBTyxFQUFFOEcsTUFBTSxNQUFSLEVBQVA7QUFDSCxLQWhFUTtBQWlFVHdOLGFBakVTLHVCQWlFRztBQUFFO0FBQ1YsYUFBS3BWLE9BQUwsQ0FBYSxFQUFFbVYsU0FBUyxJQUFYLEVBQWI7QUFDQTVTLGdCQUFRQyxHQUFSLENBQVksSUFBWjtBQUNILEtBcEVRO0FBcUVUcVQsZ0JBckVTLDBCQXFFTTtBQUFFO0FBQ2IsYUFBSzdWLE9BQUwsQ0FBYSxFQUFFbVYsU0FBUyxLQUFYLEVBQWI7QUFDQTVTLGdCQUFReUQsS0FBUixDQUFjLE9BQWQ7QUFDSCxLQXhFUTtBQXlFVDhQLGlCQXpFUyx5QkF5RUtuVyxLQXpFTCxFQXlFWTtBQUNqQixZQUFJMlMsUUFBUTNTLE1BQU1HLE1BQU4sQ0FBYXdTLEtBQXpCO0FBQ0EsWUFBRyxLQUFLeUQsTUFBTCxDQUFZekIsVUFBZixFQUEyQjtBQUN2QjtBQUNIO0FBQ0QsYUFBS25XLElBQUwsQ0FBVTJXLElBQVYsQ0FBZUcsU0FBZixHQUEyQjNDLFFBQVEsRUFBbkM7QUFDQSxhQUFLdFMsT0FBTCxDQUFhLGdCQUFiLEVBQStCc1MsS0FBL0I7QUFDQSxZQUFHQSxTQUFTQSxNQUFNblEsTUFBTixLQUFpQixDQUE3QixFQUFnQztBQUM1QixpQkFBSzBULFlBQUw7QUFDQSxpQkFBS0UsTUFBTCxDQUFZekQsS0FBWjtBQUNIO0FBQ0osS0FwRlE7QUFxRlR5RCxVQXJGUyxrQkFxRkZ6RCxLQXJGRSxFQXFGSztBQUFBOztBQUNWLFlBQUkwRCxRQUFRLEtBQUs3WCxJQUFqQjtBQUNBLFlBQUk4VixZQUFZK0IsTUFBTWxCLElBQU4sQ0FBV2IsU0FBWCxJQUF3QixFQUF4QztBQUNBLFlBQUlnQyxXQUFXRCxNQUFNbEIsSUFBTixDQUFXb0IsVUFBMUI7QUFDQSxZQUFJbkIsUUFBUWlCLE1BQU1sQixJQUFOLENBQVdDLEtBQXZCO0FBQ0EsWUFBSWxCLGNBQWNtQyxNQUFNbEIsSUFBTixDQUFXakIsV0FBWCxJQUEwQixFQUE1QztBQUNBLFlBQUlMLFNBQVN3QyxNQUFNbEIsSUFBTixDQUFXdEIsTUFBWCxJQUFxQixFQUFsQzs7QUFFQSxZQUFJdEcsU0FBUztBQUNUO0FBQ0FpSix1QkFBV25ZLElBQUl3QyxVQUFKLENBQWUyVixTQUZqQjtBQUdUQyxrQkFBTXBZLElBQUl3QyxVQUFKLENBQWU0VixJQUhaO0FBSVR0Qyw2QkFBaUJpQixLQUpSO0FBS1RkLHVCQUFXQSxTQUxGO0FBTVRDLHVCQUFXLENBTkY7QUFPVDNJLHVCQUFXdE0sS0FBS3VNLFdBQUwsRUFQRjtBQVFUMkksaUJBQUtsVixLQUFLdU0sV0FBTCxFQVJJO0FBU1R5SyxzQkFBVTNELEtBVEQsRUFTTztBQUNoQnVCLHlCQUFhQSxXQVZKO0FBV1RPLG1CQUFPblYsS0FBS3VNLFdBQUw7QUFYRSxTQUFiOztBQWNBMEIsZUFBT21KLEtBQVAsR0FBZXRDLGtCQUFRdUMsV0FBUixDQUFvQnBKLE1BQXBCLENBQWY7O0FBRUEsWUFBRyxLQUFLNkksTUFBTCxDQUFZekIsVUFBZixFQUEyQjtBQUN2QjtBQUNIO0FBQ0QsYUFBS3lCLE1BQUwsQ0FBWXpCLFVBQVosR0FBeUIsSUFBekI7O0FBRUEsWUFBR2pWLEtBQUttRSxXQUFSLEVBQXFCO0FBQ2pCbkUsaUJBQUttRSxXQUFMLENBQWlCO0FBQ2JwQyx1QkFBTyxLQURNO0FBRWJxQyxzQkFBTTtBQUZPLGFBQWpCO0FBSUg7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQSxZQUFHb1EsZUFBZSxFQUFsQixFQUFzQjtBQUNsQlksdUJBQVc4QixpQkFBWCxDQUE2QjtBQUN6QmxWLHFCQUFLc1QsbUJBRG9CO0FBRXpCNkIsMkJBQVd0SjtBQUZjLGFBQTdCLEVBR0csSUFISCxFQUdTdEgsSUFIVCxDQUdjLFVBQUN6SCxJQUFELEVBQVU7QUFDcEIsb0JBQUdBLEtBQUsrTixJQUFMLEtBQWMsUUFBakIsRUFBMkI7QUFDdkIzSiw0QkFBUUMsR0FBUixDQUFZLGVBQVo7QUFDQSwyQkFBS3hDLE9BQUwsQ0FBYSxnQkFBYixFQUErQixFQUEvQjtBQUNBLDJCQUFLQSxPQUFMLENBQWEsaUJBQWIsRUFBZ0MsRUFBaEM7O0FBRUE7O0FBRUEsd0JBQUltSCxNQUFNaEosS0FBS0EsSUFBTCxJQUFhLEVBQXZCOztBQUVBO0FBQ0E7QUFDQTs7QUFFQSx3QkFBRyxDQUFDZ0osSUFBSXNQLFNBQVIsRUFBbUI7QUFDZmxVLGdDQUFRQyxHQUFSO0FBQ0gscUJBRkQsTUFFTztBQUNIRCxnQ0FBUUMsR0FBUjtBQUNIO0FBQ0Qsd0JBQUl4RSxPQUFNQyxRQUFWO0FBQ0FELHlCQUFJd0MsVUFBSixDQUFldUUsU0FBZixHQUEyQixDQUEzQjtBQUNBL0cseUJBQUl3QyxVQUFKLENBQWV3RSxVQUFmLEdBQTRCbUMsT0FBT0EsSUFBSXhCLFVBQVgsSUFBeUIsRUFBckQ7QUFDQTNILHlCQUFJd0MsVUFBSixDQUFldVUsS0FBZixHQUF1QkEsS0FBdkI7QUFDQXhTLDRCQUFRQyxHQUFSLENBQVl4RSxLQUFJd0MsVUFBaEI7QUFDQTtBQUNBaEIsbUNBQUVzQixJQUFGO0FBRUgsaUJBMUJELE1BMEJPO0FBQ0h6Qix5QkFBSzZCLFNBQUwsQ0FBZSxFQUFFRSxZQUFVakQsS0FBS2dPLEdBQWpCLEVBQXdCaEwsTUFBTSxNQUE5QixFQUFmO0FBQ0FvQiw0QkFBUUMsR0FBUixDQUFZckUsS0FBS2dPLEdBQWpCO0FBQ0g7QUFDRHBOLDJCQUFXLFlBQU07QUFDYk0seUJBQUtFLFdBQUwsSUFBb0JGLEtBQUtFLFdBQUwsRUFBcEI7QUFDQSwyQkFBS3dXLE1BQUwsQ0FBWXpCLFVBQVosR0FBeUIsS0FBekI7QUFDSCxpQkFIRCxFQUdHLENBSEg7QUFJSCxhQXRDRCxFQXNDRyxVQUFDeE8sR0FBRCxFQUFTO0FBQ1Isb0JBQUd6RyxLQUFLRSxXQUFSLEVBQXFCO0FBQ2pCRix5QkFBS0UsV0FBTDtBQUNIO0FBQ0RnRCx3QkFBUUMsR0FBUixDQUFZc0QsR0FBWjtBQUNBLG9CQUFHQSxJQUFJb0csSUFBSixLQUFhLFFBQWhCLEVBQTBCO0FBQ3RCN00seUJBQUs2QixTQUFMLENBQWUsRUFBRUUsaUNBQUYsRUFBaUJELE1BQU0sTUFBdkIsRUFBZjtBQUNILGlCQUZELE1BRU87QUFDSDlCLHlCQUFLNkIsU0FBTCxDQUFlLEVBQUVFLE9BQU8wRSxJQUFJcUcsR0FBSiw4QkFBVCxFQUE0QmhMLE1BQU0sTUFBbEMsRUFBZjtBQUNIO0FBQ0QsdUJBQUs0VSxNQUFMLENBQVl6QixVQUFaLEdBQXlCLEtBQXpCO0FBQ0gsYUFqREQ7QUFrREgsU0FuREQsTUFtRE8sSUFBR1QsZUFBZSxFQUFsQixFQUFzQjtBQUN6QjZDLHlCQUFhQyxtQkFBYixDQUFpQ3pKLE1BQWpDLEVBQXlDdEgsSUFBekMsQ0FBOEMsVUFBQ3pILElBQUQsRUFBVTtBQUNwRCxvQkFBR2tCLEtBQUtFLFdBQVIsRUFBcUI7QUFDakJGLHlCQUFLRSxXQUFMO0FBQ0g7QUFDRCx1QkFBS1MsT0FBTCxDQUFhLGdCQUFiLEVBQStCLEVBQS9CO0FBQ0EsdUJBQUtBLE9BQUwsQ0FBYSxpQkFBYixFQUFnQyxFQUFoQztBQUNBLG9CQUFHN0IsS0FBSytOLElBQUwsS0FBYyxRQUFqQixFQUEyQjtBQUN2QiwyQkFBSzBLLG1CQUFMLENBQXlCelksSUFBekIsRUFBK0JtVSxLQUEvQjtBQUNILGlCQUZELE1BRU87QUFDSGpULHlCQUFLNkIsU0FBTCxDQUFlO0FBQ1hFLG9DQUFVakQsS0FBS2dPLEdBREo7QUFFWGhMLDhCQUFNO0FBRksscUJBQWY7QUFJSDtBQUNEcEMsMkJBQVcsWUFBTTtBQUNiLDJCQUFLZ1gsTUFBTCxDQUFZekIsVUFBWixHQUF5QixLQUF6QjtBQUNILGlCQUZELEVBRUcsQ0FGSDtBQUdILGFBakJELEVBaUJHLFVBQUN0TyxLQUFELEVBQVc7QUFDVixvQkFBRzNHLEtBQUtFLFdBQVIsRUFBcUI7QUFDakJGLHlCQUFLRSxXQUFMO0FBQ0g7QUFDREYscUJBQUs2QixTQUFMLENBQWU7QUFDWEUscURBRFc7QUFFWEQsMEJBQU07QUFGSyxpQkFBZjtBQUlBLHVCQUFLNFUsTUFBTCxDQUFZekIsVUFBWixHQUF5QixLQUF6QjtBQUNILGFBMUJEO0FBMkJILFNBNUJNLE1BNEJBLElBQUdULGVBQWUsRUFBbEIsRUFBc0I7QUFDekIsZ0JBQUlnRCxXQUFXNVgsS0FBSzZYLGVBQUwsRUFBZjtBQUNBNUoscUJBQVMxTCxPQUFPQyxNQUFQLENBQWMsRUFBZCxFQUFrQnlMLE1BQWxCLEVBQTBCO0FBQy9CM0IsMkJBQVdzTCxRQURvQjtBQUUvQmxSLDRCQUFZLEtBQUszSCxHQUFMLENBQVN3QyxVQUFULENBQW9CdVcsY0FGRDtBQUcvQmpELGlDQUFpQkMsa0JBQVFDLGFBQVIsQ0FBc0JlLEtBQXRCO0FBSGMsYUFBMUIsQ0FBVDtBQUtBLGdCQUFHMVYsS0FBS21FLFdBQVIsRUFBcUI7QUFDakJuRSxxQkFBS21FLFdBQUwsQ0FBaUI7QUFDYnBDLDJCQUFPO0FBRE0saUJBQWpCO0FBR0g7QUFDRCxpQkFBSzRWLFdBQUwsQ0FBaUI5SixNQUFqQixFQUF5QnRILElBQXpCLENBQThCLFlBQWU7QUFBQSxvQkFBZHpILElBQWMsdUVBQVAsRUFBTzs7QUFDekMsb0JBQUl3SCxhQUFhbkcsZUFBRXlYLFFBQUYsQ0FBVzlZLElBQVgsSUFBbUJBLEtBQUt3SCxVQUF4QixHQUFxQyxFQUF0RDtBQUNBLG9CQUFJVCxXQUFXMUYsZUFBRXlYLFFBQUYsQ0FBVzlZLElBQVgsSUFBb0JBLEtBQUsrRyxRQUFMLEdBQWdCL0csS0FBSytHLFFBQXJCLEdBQWdDLEVBQXBELEdBQTBELEVBQXpFO0FBQ0Esb0JBQUc3RixLQUFLRSxXQUFSLEVBQXFCO0FBQ2pCRix5QkFBS0UsV0FBTDtBQUNIO0FBQ0Q7QUFDQTBHLGtDQUFRQyxPQUFSLENBQWdCSyxHQUFoQixDQUFvQk4sa0JBQVFPLGdCQUE1QixFQUE4Q2IsVUFBOUM7QUFDQSx1QkFBS3VSLGNBQUwsR0FBc0IsSUFBdEI7O0FBRUFqWix5QkFBU3lTLE9BQVQsQ0FBaUJoQixJQUFqQixDQUFzQixnQkFBdEI7QUFDQTtBQUNBLHVCQUFLeUgsb0JBQUw7QUFDQSx1QkFBS25YLE9BQUwsQ0FBYTtBQUNULG9DQUFnQmtGO0FBRFAsaUJBQWI7QUFHQSx1QkFBSzZRLE1BQUwsQ0FBWXpCLFVBQVosR0FBeUIsS0FBekI7QUFDQTtBQUNBdlYsMkJBQVcsWUFBTTs7QUFFYk0seUJBQUsrWCxZQUFMLENBQWtCO0FBQ2QxRCwrQkFBTztBQURPLHFCQUFsQjtBQUlILGlCQU5ELEVBTUcsSUFOSDtBQVFILGFBMUJELEVBMEJHeEYsS0ExQkgsQ0EwQlMsVUFBQ3BJLEdBQUQsRUFBUztBQUNkLHVCQUFLaVEsTUFBTCxDQUFZekIsVUFBWixHQUF5QixLQUF6QjtBQUNBLHVCQUFLdFUsT0FBTCxDQUFhLGdCQUFiLEVBQStCLEVBQS9CO0FBQ0EsdUJBQUtBLE9BQUwsQ0FBYSxpQkFBYixFQUFnQyxFQUFoQztBQUNBLG9CQUFHWCxLQUFLRSxXQUFSLEVBQXFCO0FBQ2pCRix5QkFBS0UsV0FBTDtBQUNIO0FBQ0Q7QUFDQSxvQkFBSThYLFdBQVcsVUFBZjtBQUNBLG9CQUFHN1gsZUFBRXlYLFFBQUYsQ0FBV25SLEdBQVgsS0FBb0IsT0FBT0EsSUFBSW9HLElBQVgsSUFBbUIsUUFBdkMsSUFBcURwRyxJQUFJb0csSUFBSixDQUFTb0wsT0FBVCxDQUFpQixLQUFqQixLQUEyQixDQUFDLENBQXBGLEVBQXdGO0FBQ3BGRCwrQkFBV3ZSLElBQUlxRyxHQUFKLEdBQVVyRyxJQUFJcUcsR0FBZCxHQUFvQmtMLFFBQS9CO0FBQ0g7QUFDRGhZLHFCQUFLa1ksU0FBTDtBQUNBbFkscUJBQUs2QixTQUFMLENBQWU7QUFDWEUsMkJBQU9pVyxRQURJO0FBRVhsVywwQkFBTTtBQUZLLGlCQUFmO0FBSUgsYUEzQ0Q7QUE0Q0g7QUFDSixLQXpRUTtBQTBRVEwsUUExUVMsZ0JBMFFKbkIsS0ExUUksRUEwUUc7QUFDUixZQUFNTyxTQUFTUCxNQUFNUSxhQUFyQjtBQUNBLFlBQU1rQixNQUFNbkIsT0FBT0UsT0FBUCxDQUFlaUIsR0FBM0I7QUFDQTdCLHVCQUFFc0IsSUFBRixDQUFPTyxHQUFQO0FBQ0g7QUE5UVEsQ0FBYjs7QUFrUkFFLEtBQUtDLE9BQU9DLE1BQVAsQ0FBYyxFQUFkLEVBQWtCdkQsSUFBbEIsQ0FBTCxFOzs7OztBQzdSQTs7OztBQUNBOzs7O0FBQ0E7Ozs7OztBQUVBLElBQU1GLE1BQU1DLFFBQVo7QUFDQSxJQUFNQyxPQUFPO0FBQ1RDLFVBQU07QUFDRkMsY0FBTSxNQURKO0FBRUZzSSxnQkFBUTtBQUNKOFEsbUJBQU8sSUFESDtBQUVKQyx3QkFBWSxJQUZSO0FBR0pDLG1CQUFPLEVBSEg7QUFJSmhXLGtCQUFNO0FBSkY7QUFGTixLQURHO0FBVVRoRCxxQkFWUywrQkFVVztBQUNoQjtBQUNBLGFBQUtDLE1BQUw7QUFDSCxLQWJRO0FBY1RDLFVBZFMsb0JBY0E7QUFDTCxhQUFLRSxRQUFMO0FBQ0gsS0FoQlE7QUFpQlRELFdBakJTLHFCQWlCQyxDQUFFLENBakJIO0FBa0JURixVQWxCUyxvQkFrQkE7QUFDTCxhQUFLRyxRQUFMO0FBQ0gsS0FwQlE7QUFxQlRBLFlBckJTLHNCQXFCRTtBQUFBOztBQUNQO0FBQ0FVLHVCQUFFa0gsTUFBRixHQUFXZCxJQUFYLENBQWdCLFVBQUN6SCxJQUFELEVBQVU7QUFDdEIsZ0JBQUl3WixnQkFBZ0J6WSxnQkFBUTBZLGdCQUFSLENBQXlCelosSUFBekIsQ0FBcEI7QUFDQSxrQkFBSzZCLE9BQUwsQ0FBYSxFQUFFNkUsU0FBUzhTLGFBQVgsRUFBYjtBQUNBLGtCQUFLM1gsT0FBTCxDQUFhLEVBQUUsZUFBZTdCLElBQWpCLEVBQXVCLGdCQUFnQkEsS0FBS2dFLE1BQTVDLEVBQWI7QUFDSCxTQUpEO0FBS0gsS0E1QlE7QUE2QlQvQyxlQTdCUyx1QkE2QkdqQixJQTdCSCxFQTZCUztBQUNkcUIsdUJBQUVDLEdBQUYsR0FEYyxDQUNMO0FBQ1osS0EvQlE7QUFnQ1RzQixhQWhDUyxxQkFnQ0NwQixLQWhDRCxFQWdDUTtBQUNiLFlBQU1PLFNBQVNQLE1BQU1RLGFBQXJCO0FBQ0EsWUFBTWEsU0FBU2QsT0FBT0UsT0FBUCxDQUFlWSxNQUE5QjtBQUNBLFlBQU1DLFdBQVdmLE9BQU9FLE9BQVAsQ0FBZWEsUUFBaEM7QUFDQSxZQUFJLENBQUNELE1BQUwsRUFBYTtBQUNUM0IsaUJBQUs2QixTQUFMLENBQWU7QUFDWEMsc0JBQU0sTUFESztBQUVYQyx1QkFBTztBQUZJLGFBQWY7QUFJQSxtQkFBTyxLQUFQO0FBQ0g7QUFDRCxZQUFJQywrQkFBNkJMLE1BQWpDO0FBQ0EsWUFBSUMsWUFBWSxDQUFoQixFQUFtQjtBQUNmSSwyQ0FBNkJMLE1BQTdCO0FBQ0g7QUFDRHhCLHVCQUFFc0IsSUFBRixDQUFPTyxHQUFQO0FBQ0g7QUFoRFEsQ0FBYjs7QUFvREFFLEtBQUtDLE9BQU9DLE1BQVAsQ0FBYyxFQUFkLEVBQWtCdkQsSUFBbEIsQ0FBTCxFOzs7OztBQ3pEQSxJQUFJRixNQUFNQyxRQUFWO0FBQ0EsSUFBTUMsT0FBTztBQUNUVSxVQURTLG9CQUNBLENBQUUsQ0FERjtBQUVUQyxXQUZTLHFCQUVDLENBQUUsQ0FGSDtBQUdURixVQUhTLG9CQUdBO0FBQ0wsWUFBSTJNLFVBQVV0TixJQUFJd0MsVUFBSixDQUFlOEssT0FBN0I7QUFDQSxhQUFLdEwsT0FBTCxDQUFhLFNBQWIsRUFBdUJzTCxPQUF2QjtBQUNIO0FBTlEsQ0FBYjs7QUFTQS9KLEtBQUtDLE9BQU9DLE1BQVAsQ0FBYyxFQUFkLEVBQWtCdkQsSUFBbEIsQ0FBTCxFOzs7OztBQ1ZBLElBQUlGLE1BQU1DLFFBQVY7QUFDQSxJQUFNQyxPQUFPO0FBQ1RVLFVBRFMsb0JBQ0EsQ0FDUixDQUZRO0FBR1RDLFdBSFMscUJBR0MsQ0FDVCxDQUpRO0FBS1RGLFVBTFMsb0JBS0EsQ0FDUjtBQU5RLENBQWI7O0FBU0E0QyxLQUFLQyxPQUFPQyxNQUFQLENBQWMsRUFBZCxFQUFrQnZELElBQWxCLENBQUwsRTs7Ozs7QUNWQSxJQUFJRixNQUFNQyxRQUFWO0FBQ0EsSUFBTUMsT0FBTztBQUNUVSxVQURTLG9CQUNBLENBQ1IsQ0FGUTtBQUdUQyxXQUhTLHFCQUdDLENBQ1QsQ0FKUTtBQUtURixVQUxTLG9CQUtBLENBQ1I7QUFOUSxDQUFiOztBQVNBNEMsS0FBS0MsT0FBT0MsTUFBUCxDQUFjLEVBQWQsRUFBa0J2RCxJQUFsQixDQUFMLEUiLCJmaWxlIjoicGFnZXMuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBpbXBvcnQgc2VhcmNoTGF5b3V0IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL3NlYXJjaExheW91dC9zZWFyY2hMYXlvdXRcIjtcbmltcG9ydCB1c2VyIGZyb20gXCIuLi8uLi9jb21tb24vdXNlci91c2VyXCI7XG5pbXBvcnQgYWN0aW9ucyBmcm9tIFwiLi9hY3Rpb25zL2luZGV4XCI7XG5pbXBvcnQgXyBmcm9tIFwiLi4vLi4vY29tbW9uL3V0aWxzL3V0aWxcIjtcblxuY29uc3QgYXBwID0gZ2V0QXBwKCk7XG5jb25zdCBwYWdlID0ge1xuICAgIGRhdGE6IHtcbiAgICAgICAgbG9hZDogJ25vbmUnLFxuICAgICAgICBiYW5uZXJJbmRleDogMSxcbiAgICAgICAgc2VsZWN0ZWRMaXZlU3VidHlwZUlkOiAwLFxuICAgICAgICAvLyBiYW5uZXI6IFtdLFxuICAgICAgICBjaGFubmVsc19hX290aGVyOiB7fSxcbiAgICAgICAgY2hhbm5lbHNfYV9yb29tTGlzdDogW10sXG4gICAgICAgIGNoYW5uZWxzX2Jfcm9vbUxpc3Q6IFtdLFxuICAgICAgICAvLyBjaGFubmVsczogW11cbiAgICB9LFxuICAgIG9uUHVsbERvd25SZWZyZXNoKCkge1xuICAgICAgICAvLyDkuIvmi4nliLfmlrBcbiAgICAgICAgdGhpcy5vbkxvYWQoKTtcbiAgICB9LFxuICAgIG9uU2hvdygpIHtcbiAgICAgICAgLy8gbGV0IF9jaGFubmVscyA9IHRoaXMuZ2V0RGF0YSgnY2hhbm5lbHMnKTtcbiAgICAgICAgLy8gaWYgKCFfY2hhbm5lbHMpIHtcbiAgICAgICAgLy8gICAgIHRoaXMub25Mb2FkKCk7XG4gICAgICAgIC8vIH1cbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29uU2hvdy4uLicpO1xuICAgIH0sXG4gICAgb25SZWFkeSgpIHtcbiAgICAgICAgLy8gc3dhbi5zaG93VG9hc3QoeyB0aXRsZTogJ29uUmVhZHkgISAnIH0pO1xuICAgICAgICAvLyBjb25zb2xlLmxvZygnb25SZWFkeS4uLicpO1xuICAgIH0sXG4gICAgb25Mb2FkKCkge1xuICAgICAgICAvLyBjb25zb2xlLmVycm9yKEpTT04uc3RyaW5naWZ5KHRoaXMuZGF0YSkpO1xuICAgICAgICAvLyB1c2VyLmluaXQoKTtcbiAgICAgICAgdGhpcy5sb2FkUGFnZSgpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZygnb25Mb2FkLi4uJyk7XG4gICAgfSxcbiAgICBsb2FkUGFnZSgpIHtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICBsZXQgaXNMb2dpbiA9IHVzZXIuaXNMb2dpbigpO1xuICAgICAgICAgICAgYWN0aW9ucy5nZXRJbmRleERhdGEoaXNMb2dpbiwgdGhpcyk7XG4gICAgICAgICAgICB0aGlzLmxvYWRQYWdlID0gKCkgPT4ge1xuICAgICAgICAgICAgICAgIGxldCBpc0xvZ2luID0gdXNlci5pc0xvZ2luKCk7XG4gICAgICAgICAgICAgICAgYWN0aW9ucy5nZXRJbmRleERhdGEoaXNMb2dpbiwgdGhpcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sIDApXG4gICAgfSxcbiAgICBfbG9hZGVkUGFnZShkYXRhKSB7XG4gICAgICAgIC8vIOa4suafk+WQjuWbnuiwg1xuICAgICAgICBzd2FuLnN0b3BQdWxsRG93blJlZnJlc2ggJiYgc3dhbi5zdG9wUHVsbERvd25SZWZyZXNoKCk7XG4gICAgICAgIHN3YW4uaGlkZUxvYWRpbmcoKTtcbiAgICAgICAgXy5zZW8oKTsgLy/pu5jorqQgU0VPXG4gICAgfSxcbiAgICBzd2lwZXJDaGFuZ2UoZXZlbnQpIHtcbiAgICAgICAgY29uc3QgYmFubmVyID0gdGhpcy5nZXREYXRhKCdiYW5uZXInKVtldmVudC5kZXRhaWwuY3VycmVudF07XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdiYW5uZXInLCBiYW5uZXIpO1xuICAgICAgICAvLyDngrnkuq4gc3dpcGVyLWRvdFxuICAgICAgICB0aGlzLnNldERhdGEoe1xuICAgICAgICAgICAgYmFubmVySW5kZXg6IGV2ZW50LmRldGFpbC5jdXJyZW50ICsgMVxuICAgICAgICB9KVxuICAgIH0sXG4gICAgc2VsZWN0ZWRCdG5Sb29tKGV2ZW50KSB7XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LmN1cnJlbnRUYXJnZXQ7XG4gICAgICAgIC8vIHN3YW4uc2hvd1RvYXN0KHsgdGl0bGU6IHRhcmdldC5kYXRhc2V0LmxpdmVTdWJ0eXBlTmFtZSB9KTtcbiAgICAgICAgdGhpcy5zZXREYXRhKCdzZWxlY3RlZExpdmVTdWJ0eXBlSWQnLCB0YXJnZXQuZGF0YXNldC5saXZlU3VidHlwZUlkKTtcbiAgICB9LFxuICAgIHJlZGlyZWN0Q2F0ZU1vcmUoZXZlbnQpIHtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gZXZlbnQuY3VycmVudFRhcmdldDtcbiAgICAgICAgY29uc3Qgb2JqID0gdGFyZ2V0LmRhdGFzZXQub2JqO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhvYmoubGl2ZUNoYW5uZWxOYW1lLCBvYmouY2hhbm5lbFR5cGUsIG9iai5saXZlVHlwZUlkKTtcbiAgICAgICAgYXBwLmdsb2JhbERhdGEudGFiQ2F0ZWdvcnkgPSB7XG4gICAgICAgICAgICBsaXZlVHlwZUlkOiBvYmoubGl2ZVR5cGVJZCxcbiAgICAgICAgICAgIGxpdmVDaGFubmVsTmFtZTogb2JqLmxpdmVDaGFubmVsTmFtZSxcbiAgICAgICAgICAgIGNoYW5uZWxUeXBlOiBvYmouY2hhbm5lbFR5cGUsXG4gICAgICAgICAgICBsaXZlU3ViVHlwZUlkOiBvYmoubGl2ZVN1YlR5cGVJZCB8fCAwXG4gICAgICAgIH07XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGFwcC5nbG9iYWxEYXRhLnRhYkNhdGVnb3J5KTtcbiAgICAgICAgXy5qdW1wKCcvcGFnZXMvY2F0ZWdvcnkvY2F0ZWdvcnknKTtcbiAgICB9LFxuICAgIHBsYXlWaWRlbyhldmVudCkge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgICAgICBjb25zdCByb29tSWQgPSB0YXJnZXQuZGF0YXNldC5yb29tSWQ7XG4gICAgICAgIGNvbnN0IGxpdmVUeXBlID0gdGFyZ2V0LmRhdGFzZXQubGl2ZVR5cGU7XG4gICAgICAgIC8vIGNvbnN0IG9iaiA9IHRhcmdldC5kYXRhc2V0Lm9iajtcbiAgICAgICAgLy8gY29uc29sZS5sb2cob2JqKTtcbiAgICAgICAgLy8gXy5yZWNvcmQoeyAuLi5vYmosIHJlY29yZFRpbWU6IG5ldyBEYXRlKCkuZ2V0VGltZSgpIH0pO1xuICAgICAgICBpZiAoIXJvb21JZCkge1xuICAgICAgICAgICAgc3dhbi5zaG93VG9hc3Qoe1xuICAgICAgICAgICAgICAgIGljb246ICdub25lJyxcbiAgICAgICAgICAgICAgICB0aXRsZTogJ+aVsOaNruW8guW4uCdcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IHVybCA9IGBwYWdlcy93L3Jvb20/cm9vbUlkPSR7cm9vbUlkfWA7XG4gICAgICAgIGlmIChsaXZlVHlwZSA9PSAyKSB7XG4gICAgICAgICAgICB1cmwgPSBgcGFnZXMvcy9yb29tP3Jvb21JZD0ke3Jvb21JZH1gO1xuICAgICAgICB9XG4gICAgICAgIF8uanVtcCh1cmwpO1xuICAgIH0sXG4gICAgdXBkYXRlVmVyc2lvbigpIHtcbiAgICAgICAgLy8gY29uc3QgdXBkYXRlTWFuYWdlciA9IHN3YW4uZ2V0VXBkYXRlTWFuYWdlcigpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyh1cGRhdGVNYW5hZ2VyKTtcbiAgICAgICAgLy8gdXBkYXRlTWFuYWdlci5vbkNoZWNrRm9yVXBkYXRlKGZ1bmN0aW9uKHJlcykge1xuICAgICAgICAvLyAgICAgLy8g6K+35rGC5a6M5paw54mI5pys5L+h5oGv55qE5Zue6LCDXG4gICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhyZXMpO1xuICAgICAgICAvLyAgICAgY29uc29sZS5sb2cocmVzLmhhc1VwZGF0ZSk7XG4gICAgICAgIC8vICAgICBzd2FuLnNob3dNb2RhbCh7IHRpdGxlOiAn5pu05paw5o+Q56S6JywgY29udGVudDogSlNPTi5zdHJpbmdpZnkocmVzKSB9KTtcbiAgICAgICAgLy8gfSk7XG4gICAgICAgIC8vIHVwZGF0ZU1hbmFnZXIub25VcGRhdGVSZWFkeShmdW5jdGlvbihyZXMpIHtcbiAgICAgICAgLy8gICAgIHN3YW4uc2hvd01vZGFsKHtcbiAgICAgICAgLy8gICAgICAgICB0aXRsZTogJ+abtOaWsOaPkOekuicsXG4gICAgICAgIC8vICAgICAgICAgY29udGVudDogJ+aWsOeJiOacrOW3sue7j+WHhuWkh+Wlve+8jOaYr+WQpumHjeWQr+W6lOeUqO+8nycsXG4gICAgICAgIC8vICAgICAgICAgc3VjY2VzcyhyZXMpIHtcbiAgICAgICAgLy8gICAgICAgICAgICAgY29uc29sZS5sb2cocmVzKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgaWYgKHJlcy5jb25maXJtKSB7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAvLyDmlrDnmoTniYjmnKzlt7Lnu4/kuIvovb3lpb3vvIzosIPnlKggYXBwbHlVcGRhdGUg5bqU55So5paw54mI5pys5bm26YeN5ZCvXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB1cGRhdGVNYW5hZ2VyLmFwcGx5VXBkYXRlKCk7XG4gICAgICAgIC8vICAgICAgICAgICAgIH1cbiAgICAgICAgLy8gICAgICAgICB9XG4gICAgICAgIC8vICAgICB9KTtcblxuICAgICAgICAvLyB9KTtcbiAgICAgICAgLy8gdXBkYXRlTWFuYWdlci5vblVwZGF0ZUZhaWxlZChmdW5jdGlvbihyZXMpIHtcbiAgICAgICAgLy8gICAgIC8vIOaWsOeahOeJiOacrOS4i+i9veWksei0pVxuICAgICAgICAvLyAgICAgY29uc29sZS5sb2cocmVzKTtcbiAgICAgICAgLy8gfSk7XG4gICAgfVxufVxuXG5cblBhZ2UoT2JqZWN0LmFzc2lnbih7fSwgcGFnZSkpXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC9Vc2Vycy9ob3ViaW5nYmluZy9jb2RlL2lxaXlpL3FsaXZlX21pbmlwcm9ncmFtL2JhaWR1L3BhZ2VzL2hvbWUvaG9tZS5qcyIsImltcG9ydCBhY3Rpb25zIGZyb20gXCIuL2FjdGlvbnMvaW5kZXhcIjtcbmltcG9ydCB1c2VyIGZyb20gXCIuLi8uLi9jb21tb24vdXNlci91c2VyXCI7XG5pbXBvcnQgXyBmcm9tIFwiLi4vLi4vY29tbW9uL3V0aWxzL3V0aWxcIjtcbmltcG9ydCBzd2l0Y2hDYXRlQ29udHJvbCBmcm9tIFwiLi9hY3Rpb25zL3N3aXRjaENhdGVBY3Rpb25cIlxuaW1wb3J0IFByb21pc2UgZnJvbSBcIi4uLy4uL2NvbW1vbi9wb2x5ZmlsbC9wcm9taXNlXCI7XG5cbmNvbnN0IGFwcCA9IGdldEFwcCgpOyAvLyBnbG9iYWwgb2JqZWN0XG5jb25zdCBwYWdlID0ge1xuICAgIGRhdGE6IHtcbiAgICAgICAgbGlzdDogW10sXG4gICAgICAgIGhvdFN1Ykxpc3Q6IFtdLC8vIGhvdCDliY3lh6DkuKrng63pl6jliIbnsbtcbiAgICAgICAgY2F0ZWdvcnlMaXN0OiBbXSwgLy8g5omA5pyJOuS4gOS6jOe6p+aAu+WIhuexuyBcbiAgICAgICAgY3VycmVudFBhZ2U6IDAsXG4gICAgICAgIGN1cnJPcHRpb246IHtcbiAgICAgICAgICAgIGxpdmVUeXBlSWQ6IDQsXG4gICAgICAgICAgICBsaXZlQ2hhbm5lbE5hbWU6ICfmuLjmiI/nm7Tmkq0nLFxuICAgICAgICAgICAgbGl2ZVN1YlR5cGVJZDogMFxuICAgICAgICB9LFxuICAgICAgICBvcGVuQ2F0ZVN0YXR1czogMCwgLy8g5omT5byA5YiG57G75oyJ6ZKuIDAgOuacquaJk+W8gDsgMTog5omT5byAXG4gICAgICAgIGNoYW5nZVNlYXJjaFN0YXR1czogZmFsc2UsIC8vIOaYr+WQpuaUueWPmOS6huWIhuexu+afpeivouadoeS7tiDnoa7lrprmmK/lkKbku47nrKzkuIDpobXliqDovb1cbiAgICAgICAgcHVsbERvd25SZWZyZXNoU3RhdHVzOiBmYWxzZSAvLyDkuIvmi4nliLfmlrDnirbmgIEgZmFsc2UgOumdnuS4i+aLieWIt+aWsCAgdHJ1ZSA6IOaYr+S4i+aLieWIt+aWsFxuICAgIH0sXG4gICAgX2dldEdsb2JhbFNlbGVjdENhdGUoKSB7XG4gICAgICAgIC8vIDo6IOWwj+eoi+W6j+ebtOaOpeWIsOW9k+WJjemhtemdouaXtizlj6/og73kvJrmnIkgY2F0ZWdvcnlMaXN0IOacquiOt+WPluWIsCzpnIDopoHkuozmrKHojrflj5Yg6Ziy5q2i5bu26L+f5a+86Ie055qE5pWw5o2u5LiN5pi+56S6XG4gICAgICAgIGxldCBjYXRlZ29yeUxpc3QgPSBhcHAuZ2xvYmFsRGF0YS5jYXRlZ29yeUxpc3Q7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKG5ldyBEYXRlKCkuZ2V0VGltZSgpKTtcbiAgICAgICAgaWYoY2F0ZWdvcnlMaXN0ICYmIGNhdGVnb3J5TGlzdC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGAke2NhdGVnb3J5TGlzdC5sZW5ndGh9IOadoeWIhuexu+aVsOaNrmApO1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7ICdjYXRlZ29yeUxpc3QnOiBjYXRlZ29yeUxpc3QgfSwgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXNvbHZlKCdzdWNjZXNzJyk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgICAgICBhcHAuX2dldENhdGVnb3J5KGZhbHNlLCAoY2F0ZWdvcnlMaXN0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGAke2NhdGVnb3J5TGlzdC5sZW5ndGh9IOadoeWIhuexu+aVsOaNriAg5LqM5qyh6K+35rGCYCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7ICdjYXRlZ29yeUxpc3QnOiBjYXRlZ29yeUxpc3QgfSwgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZSgnc3VjY2VzcycpO1xuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9KVxuICAgICAgICB9XG4gICAgfSxcbiAgICBfc2V0UXVlcnkoKSB7XG4gICAgICAgIC8vIOiOt+WPluacgOaWsOWPguaVsFxuICAgICAgICB0aGlzLnNldERhdGEoe1xuICAgICAgICAgICAgJ3F1ZXJ5JzogYXBwLmdsb2JhbERhdGEudGFiQ2F0ZWdvcnlcbiAgICAgICAgfSk7XG4gICAgfSxcbiAgICAvLyBvblB1bGxEb3duUmVmcmVzaCgpIHtcbiAgICAvLyAgICAgdGhpcy5kYXRhLnB1bGxEb3duUmVmcmVzaFN0YXR1cyA9IHRydWU7XG4gICAgLy8gICAgIHRoaXMub25TaG93KCk7XG4gICAgLy8gfSxcbiAgICBvblNob3coKSB7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdvblNob3c9PScpO1xuICAgICAgICAvLyBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgLy8gICAgIC8vIOetm+mAieW9k+WJjeWFqOWxgCBjYXRlIOeahCB0eXBlXG4gICAgICAgIC8vICAgICB0aGlzLl9nZXRHbG9iYWxTZWxlY3RDYXRlKCk7XG4gICAgICAgIC8vICAgICBsZXQgZ2xvYkNhdGVPcHRpb24gPSBhcHAuZ2xvYmFsRGF0YS50YWJDYXRlZ29yeTtcbiAgICAgICAgLy8gICAgIGxldCBjdXJyT3B0aW9uID0gdGhpcy5kYXRhLmN1cnJPcHRpb247XG4gICAgICAgIC8vICAgICBpZihjdXJyT3B0aW9uLmxpdmVUeXBlSWQgIT09IGdsb2JDYXRlT3B0aW9uLmxpdmVUeXBlSWQgfHwgY3Vyck9wdGlvbi5saXZlU3ViVHlwZUlkICE9PSBnbG9iQ2F0ZU9wdGlvbi5saXZlU3ViVHlwZUlkIHx8IHRoaXMuZGF0YS5wdWxsRG93blJlZnJlc2hTdGF0dXMpIHtcbiAgICAgICAgLy8gICAgICAgICB0aGlzLmRhdGEucHVsbERvd25SZWZyZXNoU3RhdHVzID0gZmFsc2U7IC8vIOaBouWkjeS4i+aLieWIt+aWsOeahOeKtuaAgeS4uiBmYWxzZVxuICAgICAgICAvLyAgICAgICAgIHRoaXMuZGF0YS5jaGFuZ2VTZWFyY2hTdGF0dXMgPSB0cnVlO1xuICAgICAgICAvLyAgICAgICAgIHRoaXMuZGF0YS5jdXJyZW50UGFnZSA9IDA7XG4gICAgICAgIC8vICAgICAgICAgdGhpcy5sb2FkUGFnZSgpO1xuICAgICAgICAvLyAgICAgfVxuICAgICAgICAvLyB9LCAxMDAwKTtcbiAgICAgICAgaWYodGhpcy5zd2l0Y2hDYXRlQ29tcG9uZW50cyAmJiB0aGlzLnN3aXRjaENhdGVDb21wb25lbnRzLmluaXRTdGF0dXMpIHtcbiAgICAgICAgICAgIC8vIOe7hOS7tuWIneWni+WMluWQjiDmiafooYxcbiAgICAgICAgICAgIHRoaXMuc3dpdGNoU3ViQ2F0ZUhhbmRsZSgpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICBteUNhdGNoVG91Y2goZSkge1xuICAgICAgICBpZih0aGlzLmRhdGEub3BlbkNhdGVTdGF0dXMgPT09IDEpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgX3NldFNjcm9sbFRvcCgpIHtcbiAgICAgICAgc3dhbi5wYWdlU2Nyb2xsVG8oe1xuICAgICAgICAgICAgc2Nyb2xsVG9wOiAwLFxuICAgICAgICAgICAgZHVyYXRpb246IDMwMFxuICAgICAgICB9KTtcbiAgICB9LFxuICAgIG9uUmVhZHkoKSB7XG4gICAgfSxcbiAgICBvbkhpZGUoKSB7XG4gICAgfSxcbiAgICBvblRhYkl0ZW1UYXAoaXRlbSkge1xuICAgICAgICBjb25zb2xlLmxvZygnb25UYWJJdGVtVGFwOlxcdCcsIGl0ZW0pO1xuICAgIH0sXG4gICAgb25Mb2FkKCkge1xuICAgICAgICBfLnNlbygpO1xuICAgICAgICB0aGlzLnN3aXRjaENhdGVDb21wb25lbnRzID0gbmV3IHN3aXRjaENhdGVDb250cm9sKHRoaXMpO1xuICAgICAgICAvLyBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgLy8gICAgIHRoaXMuc3dpdGNoQ2F0ZUNvbXBvbmVudHMgPSBuZXcgc3dpdGNoQ2F0ZUNvbnRyb2wodGhpcyk7XG4gICAgICAgIC8vIH0sIDIwMClcbiAgICB9LFxuICAgIGxvYWRQYWdlKCkge1xuICAgICAgICBsZXQgaXNMb2dpbiA9IHVzZXIuaXNMb2dpbigpO1xuICAgICAgICBhY3Rpb25zLmdldEluZGV4RGF0YSh0aGlzLCBpc0xvZ2luKTtcbiAgICAgICAgdGhpcy5sb2FkUGFnZSA9ICgpID0+IHtcbiAgICAgICAgICAgIHN3YW4uc2hvd0xvYWRpbmcoeyB0aXRsZTogYOWKoOi9veS4rS4uYCwgbWFzazogdHJ1ZSB9KTtcbiAgICAgICAgICAgIGxldCBpc0xvZ2luID0gdXNlci5pc0xvZ2luKCk7XG4gICAgICAgICAgICBhY3Rpb25zLmdldEluZGV4RGF0YSh0aGlzLCBpc0xvZ2luKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgX2xvYWRlZFBhZ2UoZGF0YSkge1xuICAgICAgICB0aGlzLnVwZGF0ZUNhdGVPcHRpb24oKTtcbiAgICAgICAgdGhpcy5kYXRhLmNoYW5nZVNlYXJjaFN0YXR1cyA9IGZhbHNlO1xuICAgICAgICBzd2FuLmhpZGVMb2FkaW5nKCk7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdfbG9hZGVkUGFnZTpcXHQnLCBkYXRhLmxpc3RbMF0pO1xuICAgIH0sXG4gICAgdXBkYXRlQ2F0ZU9wdGlvbigpIHtcbiAgICAgICAgbGV0IGNhdGVPcHRpb24gPSB7XG4gICAgICAgICAgICBsaXZlVHlwZUlkOiBhcHAuZ2xvYmFsRGF0YS50YWJDYXRlZ29yeS5saXZlVHlwZUlkLFxuICAgICAgICAgICAgbGl2ZUNoYW5uZWxOYW1lOiBhcHAuZ2xvYmFsRGF0YS50YWJDYXRlZ29yeS5saXZlQ2hhbm5lbE5hbWUsXG4gICAgICAgICAgICBsaXZlU3ViVHlwZUlkOiBhcHAuZ2xvYmFsRGF0YS50YWJDYXRlZ29yeS5saXZlU3ViVHlwZUlkXG4gICAgICAgIH07XG4gICAgICAgIHRoaXMuc2V0RGF0YSh7XG4gICAgICAgICAgICBjdXJyT3B0aW9uOiBjYXRlT3B0aW9uXG4gICAgICAgIH0pO1xuICAgIH0sXG4gICAgYmluZHNjcm9sbHRvbG93ZXIoKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdiaW5kc2Nyb2xsdG9sb3dlcicpO1xuICAgICAgICBsZXQgaXNMb2dpbiA9IHVzZXIuaXNMb2dpbigpO1xuICAgICAgICBhY3Rpb25zLmdldEluZGV4RGF0YSh0aGlzLCBpc0xvZ2luKTtcbiAgICB9LFxuICAgIG9uUmVhY2hCb3R0b20oKSB7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdvblJlYWNoQm90dG9tJyk7XG4gICAgICAgIGxldCBpc0xvZ2luID0gdXNlci5pc0xvZ2luKCk7XG4gICAgICAgIGlmKHRoaXMuZGF0YS5vcGVuQ2F0ZVN0YXR1cyA9PT0gMSkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgYWN0aW9ucy5nZXRJbmRleERhdGEodGhpcywgaXNMb2dpbik7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIG9wZW5DYXRlSGFuZGxlKHN0YXR1cykge1xuICAgICAgICBsZXQgX29wZW5DYXRlU3RhdHVzID0gdGhpcy5nZXREYXRhKCdvcGVuQ2F0ZVN0YXR1cycpO1xuICAgICAgICB0aGlzLnNldERhdGEoJ29wZW5DYXRlU3RhdHVzJywgT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHN0YXR1cykgPT09ICdbb2JqZWN0IE51bWJlcl0nID8gc3RhdHVzIDogKF9vcGVuQ2F0ZVN0YXR1cyA9PT0gMSA/IDAgOiAxKSk7XG4gICAgfSxcbiAgICBwbGF5VmlkZW8oZXZlbnQpIHtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gZXZlbnQuY3VycmVudFRhcmdldDtcbiAgICAgICAgY29uc3Qgcm9vbUlkID0gdGFyZ2V0LmRhdGFzZXQucm9vbUlkO1xuICAgICAgICBpZighcm9vbUlkKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IHVybCA9IGBwYWdlcy93L3Jvb20/cm9vbUlkPSR7cm9vbUlkfWA7XG4gICAgICAgIF8uanVtcCh1cmwpO1xuICAgIH1cbn1cblxuUGFnZShPYmplY3QuYXNzaWduKHt9LCBwYWdlKSlcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvY2F0ZWdvcnkvY2F0ZWdvcnkuanMiLCJpbXBvcnQgYWN0aW9ucyBmcm9tIFwiLi9hY3Rpb25zL2luZGV4XCI7XG5pbXBvcnQgdXNlciBmcm9tIFwiLi4vLi4vY29tbW9uL3VzZXIvdXNlclwiO1xuaW1wb3J0IF8gZnJvbSBcIi4uLy4uL2NvbW1vbi91dGlscy91dGlsXCI7XG5cbmNvbnN0IGFwcCA9IGdldEFwcCgpOyAvLyBnbG9iYWwgb2JqZWN0XG5jb25zdCBwYWdlID0ge1xuICAgIGRhdGE6IHtcbiAgICAgICAgZGF0YUxpc3Q6IFtdLFxuICAgICAgICByYW5rVHlwZUxpc3Q6IFtdLFxuICAgICAgICBjdXJyT3B0aW9uOiB7XG4gICAgICAgICAgICByYW5rVHlwZUlkOiAwLFxuICAgICAgICAgICAgdGl0bGU6ICcnXG4gICAgICAgIH1cbiAgICB9LFxuICAgIG9uU2hvdygpIHtcbiAgICAgICAgbGV0IHJhbmtUeXBlTGlzdCA9IHRoaXMuZGF0YS5yYW5rVHlwZUxpc3Q7XG4gICAgICAgIGNvbnN0IHJhbmtUeXBlSWQgPSB0aGlzLmRhdGEuY3Vyck9wdGlvbi5yYW5rVHlwZUlkO1xuICAgICAgICBpZiAocmFua1R5cGVMaXN0ICYmIHJhbmtUeXBlSWQgIT0gMCkge1xuICAgICAgICAgICAgdGhpcy5zZXREYXRhKCdjdXJyT3B0aW9uLnJhbmtUeXBlSWQnLCAwKTtcbiAgICAgICAgICAgIHRoaXMubG9hZFBhZ2UoKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgb25UYWJJdGVtVGFwOiBmdW5jdGlvbihpdGVtKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGl0ZW0pO1xuICAgIH0sXG4gICAgb25Mb2FkKCkge1xuICAgICAgICB0aGlzLmxvYWRUeXBlKCk7XG4gICAgICAgIHRoaXMubG9hZFBhZ2UoKTtcbiAgICB9LFxuICAgIGxvYWRUeXBlKCkge1xuICAgICAgICBsZXQgaXNMb2dpbiA9IHVzZXIuaXNMb2dpbigpO1xuICAgICAgICBhY3Rpb25zLmdldFJhbmtUeXBlRGF0YSh0aGlzLCBpc0xvZ2luKTtcblxuICAgIH0sXG4gICAgbG9hZFBhZ2UoKSB7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgc3dhbi5zaG93TG9hZGluZyh7IHRpdGxlOiBg5Yqg6L295LitLi5gIH0pO1xuICAgICAgICAgICAgbGV0IGlzTG9naW4gPSB1c2VyLmlzTG9naW4oKTtcbiAgICAgICAgICAgIGFjdGlvbnMuZ2V0SW5kZXhEYXRhKHRoaXMsIGlzTG9naW4pO1xuICAgICAgICAgICAgXy5zZW8oKTsvL+esrOS4gOasoeWKoOi9vSDkvb/nlKjkuIDmrKHlsLHlpJ/kuoZcbiAgICAgICAgICAgIHRoaXMubG9hZFBhZ2UgPSAoKSA9PiB7XG4gICAgICAgICAgICAgICAgc3dhbi5zaG93TG9hZGluZyh7IHRpdGxlOiBg5Yqg6L295LitLi5gIH0pO1xuICAgICAgICAgICAgICAgIGxldCBpc0xvZ2luID0gdXNlci5pc0xvZ2luKCk7XG4gICAgICAgICAgICAgICAgYWN0aW9ucy5nZXRJbmRleERhdGEodGhpcywgaXNMb2dpbik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sIDApO1xuXG4gICAgfSxcbiAgICBfbG9hZGVkUGFnZShkYXRhKSB7XG4gICAgICAgIHRoaXMuc2V0RGF0YSh7XG4gICAgICAgICAgICAnZGF0YUxpc3QnOiBkYXRhLmRhdGFMaXN0LFxuICAgICAgICAgICAgJ2N1cnJPcHRpb24udGl0bGUnOiBkYXRhLmRhdGFMaXN0WzBdLnRpdGxlXG4gICAgICAgIH0pO1xuICAgICAgICBzd2FuLmhpZGVMb2FkaW5nKCk7XG4gICAgfSxcbiAgICBfbG9hZGVkUmFua1R5cGUoZGF0YSkge1xuICAgICAgICB0aGlzLnNldERhdGEoJ3JhbmtUeXBlTGlzdCcsIGRhdGEpO1xuICAgIH0sXG4gICAgc3dpdGNoUmFua0hhbmRsZShldmVudCkge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgICAgICB0aGlzLnNldERhdGEoJ2N1cnJPcHRpb24ucmFua1R5cGVJZCcsIHRhcmdldC5kYXRhc2V0LnJhbmtUeXBlSWQpO1xuICAgICAgICB0aGlzLmxvYWRQYWdlKCk7XG4gICAgfSxcbiAgICBzd2l0Y2hUaXRsZUhhbmRsZShldmVudCkge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgICAgICB0aGlzLnNldERhdGEoJ2N1cnJPcHRpb24udGl0bGUnLCB0YXJnZXQuZGF0YXNldC50aXRsZSk7XG4gICAgfSxcbiAgICBwbGF5VmlkZW8oZXZlbnQpIHtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gZXZlbnQuY3VycmVudFRhcmdldDtcbiAgICAgICAgY29uc3Qgcm9vbUlkID0gdGFyZ2V0LmRhdGFzZXQucm9vbUlkO1xuICAgICAgICBpZiAoIXJvb21JZCkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGxldCB1cmwgPSBgcGFnZXMvdy9yb29tP3Jvb21JZD0ke3Jvb21JZH1gO1xuICAgICAgICBfLmp1bXAodXJsKTtcbiAgICB9XG59XG5cblBhZ2UoT2JqZWN0LmFzc2lnbih7fSwgcGFnZSkpXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC9Vc2Vycy9ob3ViaW5nYmluZy9jb2RlL2lxaXlpL3FsaXZlX21pbmlwcm9ncmFtL2JhaWR1L3BhZ2VzL3JhbmsvcmFuay5qcyIsImltcG9ydCAqIGFzIHVzZXIgZnJvbSAnLi4vLi4vY29tbW9uL3VzZXIvdXNlckluZm8nO1xuaW1wb3J0IF8gZnJvbSBcIi4uLy4uL2NvbW1vbi91dGlscy91dGlsXCJcbmltcG9ydCByZXEgZnJvbSBcIi4vc2VydmljZS9yZXFTZXJ2aWNlXCI7XG5pbXBvcnQgc2Vzc2lvbiBmcm9tIFwiLi4vLi4vY29tbW9uL2xvZ2luL3Nlc3Npb25cIjtcblxuXG5sZXQgYXBwID0gZ2V0QXBwKCk7XG5sZXQgZ2xvYmFsRGF0YSA9IGFwcC5nbG9iYWxEYXRhO1xuY29uc3Qgb3JpZ2luSWNvbiA9ICcuLi8uLi9hc3NldHMvbXkvYXZhdGFyLTE0NC5wbmcnO1xuY29uc3QgcGFnZSA9IHtcbiAgICBkYXRhOiB7XG4gICAgICAgIGxvYWQ6ICdub25lJyxcbiAgICAgICAgcmVjb3JkczogW10sXG4gICAgICAgIG9wdGlvbnM6IHtcbiAgICAgICAgICAgIG5lZWRMb2dpbjogZmFsc2UsLy/pobXpnaLmiZPlvIDlkI7mmK/lkKbpnIDopoHnmbvlvZXlkJc/XG4gICAgICAgICAgICBhdXRoQ29va2llOiAnJ1xuICAgICAgICB9LFxuICAgICAgICBsb2dpbkluZm86IHtcbiAgICAgICAgICAgIGlzTG9naW46IGZhbHNlLFxuICAgICAgICAgICAgdXNlcjoge1xuICAgICAgICAgICAgICAgIGljb246IG9yaWdpbkljb24sXG4gICAgICAgICAgICAgICAgbmlja25hbWU6ICcnLFxuICAgICAgICAgICAgICAgIGlzVmlwOiBmYWxzZVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcbiAgICBvblNob3coKSB7XG4gICAgICAgIHRoaXMubG9hZFBhZ2UoKTtcbiAgICAgICAgLy8gdGhpcy5fZ2V0VXNlckluZm8oJzkxbExxYnJsYTN2ZTlXa0ZmNWt1QVhla0p4WlFaYTdqbmxNa2ZWb3FaanZlV1BNbk10Zm5sd1BkcFltMnpnakRDZE41YycpOy8vVE9ETyB0ZXN0IERFTEVURVxuICAgICAgICBpZihnbG9iYWxEYXRhLm5lZWRMb2dpbikge1xuICAgICAgICAgICAgLy8gc3dhbi5zaG93VG9hc3QoeyB0aXRsZTogYCR7YXBwLmdsb2JhbERhdGEubmVlZExvZ2lufX5+JHthcHAuZ2xvYmFsRGF0YS5hdXRoQ29va2llfWAgfSk7XG4gICAgICAgICAgICB0aGlzLmRhdGEub3B0aW9ucy5uZWVkTG9naW4gPSBhcHAuZ2xvYmFsRGF0YS5uZWVkTG9naW47Ly9UT0RPIOeUseS6jiBzd2FuLnN3aXRjaFRhYiAg6Lez6L2s5Lyg5Y+C5Lya5a+86Ie06aG16Z2i5oql6ZSZ5YGH5q27IOWwseWGmeWFpeWFqOWxgOWPmOmHj+S4reaJp+ihjFxuICAgICAgICAgICAgdGhpcy5kYXRhLm9wdGlvbnMuYXV0aENvb2tpZSA9IGFwcC5nbG9iYWxEYXRhLmF1dGhDb29raWU7XG5cbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YSgnbG9naW5JbmZvLmlzTG9naW4nLCBmYWxzZSk7XG4gICAgICAgICAgICB0aGlzLl9uZWVkTG9naW4oKTtcbiAgICAgICAgfSBlbHNlIGlmKGdsb2JhbERhdGEuYXV0aENvb2tpZS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZVVzZXJJbmZvKCk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgLy8gVE9ET1xuICAgICAgICAvLyBnbG9iYWxEYXRhLm5lZWRMb2dpbiA9IDE7XG4gICAgICAgIC8vIGdsb2JhbERhdGEuYXV0aENvb2tpZSA9ICdCQXRWQ0JTM1hkN2xvUHVOSjcwYlI1bTNESXF6cFpQZFNBU2xlSWFtM1dtMzFvT1RFbDdXM2ViVFpFRmNHNWNZckVGOUpadlVCMFNETndCbTFRd3p4dEE0QU14NWd0Q011NDBoUU1mUlhpWlNWZHFyVkhDTnpxbTFGVWcnO1xuICAgIH0sXG4gICAgaW5pdFVwZGF0ZURhdGEoKSB7XG4gICAgICAgIHRoaXMuZGF0YS5vcHRpb25zLm5lZWRMb2dpbiA9IGdsb2JhbERhdGEuYXV0aENvb2tpZTtcbiAgICB9LFxuICAgIF9uZWVkTG9naW4oKSB7XG4gICAgICAgIGxldCBhdXRoQ29va2llID0gdGhpcy5kYXRhLm9wdGlvbnMuYXV0aENvb2tpZTsvL+iOt+WPliBvcHRpb25zXG5cbiAgICAgICAgaWYoYXV0aENvb2tpZSAmJiBhdXRoQ29va2llICE9PSAnJykge1xuICAgICAgICAgICAgdGhpcy5fZ2V0VXNlckluZm8oYXV0aENvb2tpZSlcbiAgICAgICAgICAgIHRoaXMuZGF0YS5vcHRpb25zLm5lZWRMb2dpbiA9IGZhbHNlO1xuICAgICAgICAgICAgYXBwLmdsb2JhbERhdGEubmVlZExvZ2luID0gZmFsc2U7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLl91cGRhdGVVc2VySW5mbygpO1xuICAgICAgICAgICAgc3dhbi5zaG93VG9hc3QoeyB0aXRsZTogJ+ivt+eCueWHu+eZu+W9lScgfSk7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhg5pyq55m75b2VYCk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIF9nZXRVc2VySW5mbyhhdXRoQ29va2llKSB7XG4gICAgICAgIGxldCBnZXRVc2VySW5mbyA9IHVzZXIuZ2V0VXNlckluZm8oKTtcbiAgICAgICAgLy8gY29uc29sZS5sb2coZ2V0VXNlckluZm8pO1xuICAgICAgICBpZihnZXRVc2VySW5mbyAmJiBPYmplY3Qua2V5cyhnZXRVc2VySW5mbykubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coZ2V0VXNlckluZm8pO1xuICAgICAgICB9XG5cbiAgICAgICAgcmVxLmdldFVzZXJJbmZvKHsgYXV0aGNvb2tpZTogYXV0aENvb2tpZSB9KS50aGVuKChkYXRhKSA9PiB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oYOeZu+W9lSDmiJDlip8hYCk7XG4gICAgICAgICAgICB0aGlzLl91cGRhdGVVc2VySW5mbyhkYXRhLCBhdXRoQ29va2llKTtcbiAgICAgICAgfSwgKGVycikgPT4ge1xuICAgICAgICAgICAgdGhpcy5sb2dpbk91dCgpO1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xuICAgICAgICB9KVxuICAgIH0sXG4gICAgbG9naW5PdXQoKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9LFxuICAgIF91cGRhdGVVc2VySW5mbyhkYXRhLCBhdXRoQ29va2llKSB7XG4gICAgICAgIGlmKCFkYXRhKSB7Ly/nmbvlh7pcbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YSgnbG9naW5JbmZvLmlzTG9naW4nLCBmYWxzZSk7XG4gICAgICAgICAgICB0aGlzLnNldERhdGEoJ2xvZ2luSW5mby51c2VyLmljb24nLCBvcmlnaW5JY29uKTtcbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YSgnbG9naW5JbmZvLnVzZXIubmlja25hbWUnLCAnJyk7XG4gICAgICAgICAgICB0aGlzLnNldERhdGEoJ2xvZ2luSW5mby51c2VyLmlzVmlwJywgZmFsc2UpO1xuICAgICAgICAgICAgc2Vzc2lvbi5TZXNzaW9uLmNsZWFyKCk7XG5cbiAgICAgICAgfSBlbHNlIHsvLyDnmbvlvZUgc3VjY2Vzc1xuICAgICAgICAgICAgbGV0IHsgbmlja25hbWUsIGljb24gfSA9IGRhdGEudXNlcmluZm87XG4gICAgICAgICAgICBsZXQgaXNWaXAgPSAoZGF0YS5xaXlpX3ZpcF9pbmZvIHx8IHt9KS5sZXZlbCA+IDE7XG4gICAgICAgICAgICAvLyBbaXNWaXBdID0gcWl5aV92aXBfaW5mby5sZXZlbCA+IDFcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKG5pY2tuYW1lLCBpY29uKTtcbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YSgnbG9naW5JbmZvLmlzTG9naW4nLCB0cnVlKTtcbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YSgnbG9naW5JbmZvLnVzZXIuaWNvbicsIGljb24pO1xuICAgICAgICAgICAgdGhpcy5zZXREYXRhKCdsb2dpbkluZm8udXNlci5uaWNrbmFtZScsIG5pY2tuYW1lKTtcbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YSgnbG9naW5JbmZvLnVzZXIuaXNWaXAnLCBpc1ZpcCB8fCBmYWxzZSk7XG5cbiAgICAgICAgICAgIHNlc3Npb24uU2Vzc2lvbi5zZXQoc2Vzc2lvbi5TRVNTSU9OX0FVVEhfS0VZLCBhdXRoQ29va2llKTtcbiAgICAgICAgICAgIHNlc3Npb24uU2Vzc2lvbi5zZXQoc2Vzc2lvbi5TRVNTSU9OX0lORk9fS0VZLCBkYXRhKTtcbiAgICAgICAgICAgIHN3YW4uc2hvd1RvYXN0KHsgdGl0bGU6IGDnmbvlvZXmiJDlip9gIH0pO1xuICAgICAgICB9XG4gICAgfSxcbiAgICBsb2FkUGFnZSgpIHtcbiAgICAgICAgLy8gXy5qdW1wKCdzdWJQYWNrYWdlL3BhZ2VzL215L2Fib3V0Jyk7XG4gICAgICAgIC8vIF8uanVtcCgnc3ViUGFja2FnZS9wYWdlcy9teS9wbGF5TG9nJyk7XG4gICAgICAgIF8ucmVjb3JkKCkudGhlbigoZGF0YSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5zZXREYXRhKHsgJ3JlY29yZHMnOiBkYXRhICYmIGRhdGEucmV2ZXJzZSgpLnNwbGljZSgwLCA0KSB9KTtcbiAgICAgICAgfSlcblxuICAgIH0sXG4gICAgX2xvYWRlZFBhZ2UoZGF0YSkge1xuICAgICAgICAvLyDmuLLmn5PlkI7lm57osINcbiAgICAgICAgXy5zZW8oKTsgLy/pu5jorqQgU0VPIFxuICAgIH0sXG4gICAganVtcChldmVudCkge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgICAgICBjb25zdCB1cmwgPSB0YXJnZXQuZGF0YXNldC51cmw7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHRhcmdldCk7XG4gICAgICAgIF8uanVtcCh1cmwpO1xuICAgIH0sXG4gICAgcGxheVZpZGVvKGV2ZW50KSB7XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LmN1cnJlbnRUYXJnZXQ7XG4gICAgICAgIGNvbnN0IHJvb21JZCA9IHRhcmdldC5kYXRhc2V0LnJvb21JZDtcbiAgICAgICAgY29uc3QgbGl2ZVR5cGUgPSB0YXJnZXQuZGF0YXNldC5saXZlVHlwZTtcbiAgICAgICAgaWYoIXJvb21JZCkge1xuICAgICAgICAgICAgc3dhbi5zaG93VG9hc3Qoe1xuICAgICAgICAgICAgICAgIGljb246ICdub25lJyxcbiAgICAgICAgICAgICAgICB0aXRsZTogJ+aVsOaNruW8guW4uCdcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IHVybCA9IGBwYWdlcy93L3Jvb20/cm9vbUlkPSR7cm9vbUlkfWA7XG4gICAgICAgIGlmKGxpdmVUeXBlID09IDIpIHtcbiAgICAgICAgICAgIHVybCA9IGBwYWdlcy9zL3Jvb20/cm9vbUlkPSR7cm9vbUlkfWA7XG4gICAgICAgIH1cbiAgICAgICAgXy5qdW1wKHVybCk7XG4gICAgfSxcbiAgICBjbGVhclJlY29yZChldmVudCkge1xuICAgICAgICBzd2FuLnNob3dNb2RhbCh7XG4gICAgICAgICAgICB0aXRsZTogJ+aPkOekuicsXG4gICAgICAgICAgICBjb250ZW50OiAn5Yig6Zmk6KeC55yL5Y6G5Y+yJyxcbiAgICAgICAgICAgIGNhbmNlbENvbG9yOiAnIzk5OTk5OScsXG4gICAgICAgICAgICBjb25maXJtQ29sb3I6ICcjMDA5OWNjJyxcbiAgICAgICAgICAgIHN1Y2Nlc3M6IChyZXMpID0+IHtcbiAgICAgICAgICAgICAgICBpZihyZXMuY29uZmlybSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygn5Yig6Zmk6KeC55yL6K6w5b2VIHN0b3J5YWdlJyk7XG4gICAgICAgICAgICAgICAgICAgIHN3YW4uc2hvd1RvYXN0KHsgdGl0bGU6ICfliKDpmaTmiJDlip8nIH0pO1xuICAgICAgICAgICAgICAgICAgICBfLnJlY29yZChbXSkudGhlbigocmVzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRQYWdlKCk7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZihyZXMuY2FuY2VsKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCfnlKjmiLfngrnlh7vkuoblj5bmtognKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbn1cblxuXG5QYWdlKE9iamVjdC5hc3NpZ24oe30sIHBhZ2UpKVxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAvVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9wYWdlcy9teS9teS5qcyIsImltcG9ydCAqIGFzIHJvb20gZnJvbSAnLi9hY3Rpb25zL3Jvb21BY3Rpb24uanMnO1xuaW1wb3J0ICogYXMgcmVxIGZyb20gJy4vc2VydmljZS9yZXFTZXJ2aWNlJztcbmltcG9ydCBQbGF5ZXJDb250cm9sIGZyb20gJy4vYWN0aW9ucy9wbGF5ZXJBY3Rpb24nO1xuaW1wb3J0IE1lc3NhZ2VCb3ggZnJvbSAnLi9hY3Rpb25zL21zZ0FjdGlvbic7XG5pbXBvcnQgU2VuZEJveCBmcm9tICcuL2FjdGlvbnMvc2VuZE1zZ0FjdGlvbic7XG5pbXBvcnQgKiBhcyB1dGlscyBmcm9tIFwiLi9jb21tb24vdXRpbHNcIjtcbmltcG9ydCBfIGZyb20gXCIuLi8uLi9jb21tb24vdXRpbHMvdXRpbFwiO1xuaW1wb3J0IEVtaXR0ZXIgZnJvbSAnLi4vLi4vY29tbW9uL2VtaXR0ZXIvRW1pdHRlcic7XG5pbXBvcnQgU2Vuc29yIGZyb20gJy4uLy4uL2NvbW1vbi9zZW5zb3IvanNTZW5zb3InO1xuaW1wb3J0ICogYXMgdXNlciBmcm9tICcuL2NvbW1vbi91c2VyJztcbi8vIGltcG9ydCBtdXRpQWNjb3VudCBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL211dGlBY2NvdW50L211dGlBY2NvdW50J1xuXG5jb25zdCBhcHAgPSBnZXRBcHAoKTtcblxuY29uc3QgcGFnZSA9IHtcbiAgICAvKipcbiAgICAgKiDpobXpnaLnmoTliJ3lp4vmlbDmja5cbiAgICAgKi9cbiAgICBkYXRhOiB7XG4gICAgICAgIGVycm9yVGlwOiB0cnVlLFxuICAgICAgICBhY3RpdmVUYWI6IFwiY2hhdFwiLFxuICAgICAgICByb29tSWQ6IG51bGwsXG4gICAgICAgIGhvc3RJbmZvOiBudWxsLFxuICAgICAgICBtc2dMaXN0OiBbe1xuICAgICAgICAgICAgdHlwZTogMCxcbiAgICAgICAgICAgIGNvbnRlbnQ6IFwi5q2j5Zyo5YeG5aSH5by55bmVXCJcbiAgICAgICAgfV0sXG4gICAgICAgIHNjcm9sbEhlaWdodDogMTAwLFxuICAgICAgICBzY3JvbGxIaWRlTG9hZE1vcmU6IHRydWUsXG4gICAgICAgIHNjcm9sbEFuaW1hdGlvbjogZmFsc2UsXG4gICAgICAgIGlucHV0Rm9jdXM6IGZhbHNlLFxuICAgICAgICBpbnB1dFRleHQ6IFwiXCIsXG4gICAgICAgIGlucHV0QXZhaWxhYmxlOiBcIlwiLFxuICAgICAgICBzaG93S2V5Ym9hcmQ6IFwiXCIsXG4gICAgICAgIHZpZGVvQm9keVRvcDogMCxcbiAgICAgICAgdmlkZW86IHtcbiAgICAgICAgICAgIG5lZWRWSVA6IGZhbHNlLFxuICAgICAgICAgICAgbmVlZExvZ2luOiBmYWxzZSxcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgb2ZmbGluZTogZmFsc2VcbiAgICAgICAgfSxcbiAgICAgICAgcHJldmlld0NvdmVyOiAnaHR0cDovL3d3dy5pcWl5aXBpYy5jb20vY29tbW9uL2ZpeC93eC1pcWl5aS9wbGF5ZXItdGlwLWJnLmpwZycsXG4gICAgICAgIHJvb21TdGF0dXM6IDAsXG4gICAgICAgIGZvbGxvd2VkOiBmYWxzZSxcbiAgICAgICAgcmVjb21tZW5kTGlzdDogW10sXG4gICAgICAgIHRhYjoge1xuICAgICAgICAgICAgaG9zdDogZmFsc2UsXG4gICAgICAgICAgICBjaGF0OiBmYWxzZVxuICAgICAgICB9LFxuICAgICAgICBrZXlib2FyZEhlaWdodDogMFxuICAgIH0sXG5cbiAgICBjbGlja1Nob3dIb3N0OiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy5zZXREYXRhKHtcbiAgICAgICAgICAgIGFjdGl2ZVRhYjogXCJob3N0XCJcbiAgICAgICAgfSk7XG4gICAgICAgIHJvb20uZ2V0UmVjb21tZW5kTGlzdCh0aGlzKTtcbiAgICB9LFxuXG4gICAgY2xpY2tTaG93Q2hhdDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMuc2V0RGF0YSh7XG4gICAgICAgICAgICBhY3RpdmVUYWI6IFwiY2hhdFwiXG4gICAgICAgIH0pO1xuICAgIH0sXG5cbiAgICBjbGlja0ZvbGxvdygpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ+aaguaXtuS4jeiDveiuoumYhSEnKTtcbiAgICAgICAgc3dhbi5zaG93VG9hc3QoeyB0aXRsZTogJ+iuoumYheaIkOWKnycgfSk7XG4gICAgICAgIHRoaXMuY2xpY2tGb2xsb3cgPSAoKSA9PiB7XG4gICAgICAgICAgICBzd2FuLnNob3dUb2FzdCh7IHRpdGxlOiAn5bey6K6i6ZiFJyB9KTtcbiAgICAgICAgfVxuICAgICAgICAvLyByb29tLmNsaWNrRm9sbG93KHRoaXMpO1xuICAgIH0sXG5cbiAgICBjbGlja1JlY29tbWVuZDogZnVuY3Rpb24oZSkge1xuICAgICAgICByb29tLnJlZGlyZWN0VG8oZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQpO1xuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiDnlKjmiLfngrnlh7vlj7PkuIrop5LliIbkuqtcbiAgICAgKi9cbiAgICBvblNoYXJlQXBwTWVzc2FnZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIGxldCBzaGFyZURhdGEgPSB7XG4gICAgICAgICAgICB0aXRsZTogdGhpcy5yb29tSW5mby5zaGFyZUluZm8ucHJvZ3JhbU5hbWUsXG4gICAgICAgICAgICBpbWFnZVVybDogdGhpcy5yb29tSW5mby5zaGFyZUluZm8uY292ZXIucmVwbGFjZShcIl80ODBfMjcwXCIsIFwiXzQ4MF8zNjBcIiksXG4gICAgICAgICAgICBwYXRoOiAncGFnZXMvdy9yb29tP3Jvb21JZD0nICsgdGhpcy5yb29tSW5mby5yb29tSWRcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc2hhcmVEYXRhO1xuICAgIH0sXG5cbiAgICBvbkNsaWNrU2hhcmU6IGZ1bmN0aW9uKCkge1xuICAgICAgICBsZXQgc2hhcmVEYXRhID0ge1xuICAgICAgICAgICAgdGl0bGU6IHRoaXMucm9vbUluZm8uc2hhcmVJbmZvLnByb2dyYW1OYW1lLFxuICAgICAgICAgICAgY29udGVudDogdGhpcy5yb29tSW5mby5zaGFyZUluZm8uZGVzY3JpcHRpb24sXG4gICAgICAgICAgICBpbWFnZVVybDogdGhpcy5yb29tSW5mby5zaGFyZUluZm8uY292ZXIucmVwbGFjZShcIl80ODBfMjcwXCIsIFwiXzQ4MF8zNjBcIiksXG4gICAgICAgICAgICBwYXRoOiAncGFnZXMvdy9yb29tP3Jvb21JZD0nICsgdGhpcy5yb29tSW5mby5yb29tSWRcbiAgICAgICAgfVxuICAgICAgICBzd2FuLm9wZW5TaGFyZShzaGFyZURhdGEpO1xuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiDnlJ/lkb3lkajmnJ/lh73mlbAtLeebkeWQrOmhtemdouWKoOi9vVxuICAgICAqL1xuICAgIHN0b3JlOiB7XG4gICAgICAgIGRpc3BhdGNoOiBmdW5jdGlvbigpIHt9XG4gICAgfSxcbiAgICAvLyBpc011bHRpQWNjb3VudDogbXV0aUFjY291bnQuaXNNdWx0aUFjY291bnQsXG4gICAgc2VvKCkge1xuICAgICAgICBfLnNlbyh7XG4gICAgICAgICAgICBkZXNjOiBgJHt0aGlzLnJvb21JbmZvLmFuY2hvck5pY2tuYW1lfV8ke3RoaXMucm9vbUluZm8ucm9vbVRpdGxlIH1fJHt0aGlzLnJvb21JbmZvLnN1YlRpdGxlfeebtOaSrV/niLHlpYfoibrnm7Tmkq0t54ix5aWH6Im6YCxcbiAgICAgICAgICAgIGtleXdvcmRzOiBgJHt0aGlzLnJvb21JbmZvLmFuY2hvck5pY2tuYW1lfSwke3RoaXMucm9vbUluZm8uYW5jaG9yTmlja25hbWV955u05pKtLCR7dGhpcy5yb29tSW5mby5hbmNob3JOaWNrbmFtZX3nm7Tmkq3pl7QsJHt0aGlzLnJvb21JbmZvLmFuY2hvck5pY2tuYW1lfeebtOaSreWcsOWdgO+8jCR7dGhpcy5yb29tSW5mby5hbmNob3JOaWNrbmFtZX0gJHt0aGlzLnJvb21JbmZvLnN1YlRpdGxlfe+8jCR7dGhpcy5yb29tSW5mby5hbmNob3JOaWNrbmFtZX0gJHt0aGlzLnJvb21JbmZvLnN1YlRpdGxlfeebtOaSre+8jCR7dGhpcy5yb29tSW5mby5hbmNob3JOaWNrbmFtZX0gJHt0aGlzLnJvb21JbmZvLnN1YlRpdGxlfeinhumikWAsXG4gICAgICAgICAgICB0aXRsZTogYCR7dGhpcy5yb29tSW5mby5hbmNob3JOaWNrbmFtZSB9XyR7dGhpcy5yb29tSW5mby5yb29tVGl0bGUgfV8ke3RoaXMucm9vbUluZm8uc3ViVGl0bGUgfeebtOaSrV/niLHlpYfoibrnm7Tmkq0t54ix5aWH6Im6YCxcbiAgICAgICAgICAgIHZpZGVvOntcbiAgICAgICAgICAgICAgICB1cmw6J3BhZ2VzL3cvcm9vbT9yb29tSWQ9JyArIHRoaXMucm9vbUluZm8ucm9vbUlkLFxuICAgICAgICAgICAgICAgIGR1cmF0aW9uOjM2MDAsXG4gICAgICAgICAgICAgICAgaW1hZ2U6dGhpcy5yb29tSW5mby5zaGFyZUluZm8uY292ZXIucmVwbGFjZShcIl80ODBfMjcwXCIsIFwiXzQ4MF8zNjBcIiksXG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0sXG4gICAgb25Mb2FkKG9wdCkge1xuICAgICAgICB0aGlzLnRyaWdnZXIgPSBuZXcgRW1pdHRlcigpO1xuICAgICAgICB0aGlzLnJvb21JbmZvID0ge307XG4gICAgICAgIHRoaXMuY29tcG9uZW50cyA9IHt9O1xuICAgICAgICB0aGlzLnNldERhdGEoe1xuICAgICAgICAgICAgXCJyb29tSWRcIjogb3B0LnJvb21JZCxcbiAgICAgICAgICAgIFwicmVxU3VjY2Vzc1wiOiBmYWxzZVxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5zZW5zb3IgPSB7fTtcbiAgICAgICAgdGhpcy5zZW5zb3JJbml0KCk7XG4gICAgICAgIHRoaXMucmVxSW5pdCgpO1xuICAgIH0sXG4gICAgc2Vuc29ySW5pdCgpIHtcbiAgICAgICAgbGV0IGdsb2JhbERhdGEgPSBnZXRBcHAoKS5nbG9iYWxEYXRhO1xuICAgICAgICB0aGlzLnNlbnNvciA9IG5ldyBTZW5zb3Ioe1xuICAgICAgICAgICAgcGw6IGdsb2JhbERhdGEucGwgfHwgJzJfMjRfMjAwXzMnLFxuICAgICAgICAgICAgdDogZ2xvYmFsRGF0YS50bCB8fCAnYmRfaW9zJyxcbiAgICAgICAgICAgIHZlcnNpb246IGdsb2JhbERhdGEudmVyc2lvbiB8fCAnMi4wMS4wNScsIC8vYmFpZHUgbWluaSBwcm8gdmVyc2lvbiBcbiAgICAgICAgICAgIGRldmljZV9pZDogdXNlci5nZXREZXZpY2VJZCgpIHx8ICcnLFxuICAgICAgICAgICAgdXNlcklkOiAnJyxcbiAgICAgICAgICAgIHVybDogJy92MS9saXZlL2luaXRpYWwnLFxuICAgICAgICAgICAgcm9vbUlkOiB0aGlzLmRhdGEucm9vbUlkLFxuICAgICAgICB9LCBzd2FuKTtcbiAgICB9LFxuICAgIHJlcUluaXQoKSB7XG4gICAgICAgIGxldCBjb25TdGFydCA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xuICAgICAgICByZXEuZ2V0Um9vbUluZm8odGhpcy5kYXRhLnJvb21JZCkudGhlbihyZXMgPT4ge1xuICAgICAgICAgICAgdGhpcy5zZXREYXRhKHtcbiAgICAgICAgICAgICAgICBcInJlcVN1Y2Nlc3NcIjogdHJ1ZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBsZXQgY29uRW5kID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICAgICAgICB0aGlzLnNlbnNvci5wdXNoKHRoaXMuc2Vuc29yLkNPREUuUk9PTV9JTklUSUFMX1NVQ0NFU1MsIHJlcy5jb2RlLCBjb25FbmQgLSBjb25TdGFydCwgMCwgJycsIGAke3Jlcy5tc2d9YCk7XG5cbiAgICAgICAgICAgIGlmIChyZXMuY29kZSA9PT0gXCJBMDAwMDBcIikge1xuICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8gPSByZXMuZGF0YTtcbiAgICAgICAgICAgICAgICB0aGlzLnJvb21JbmZvLnFwSWQgPSByZXMuZGF0YS5wcm9ncmFtSW5mby5xaXB1SWQ7XG4gICAgICAgICAgICAgICAgdGhpcy5yb29tSW5mby5yb29tU3RhdHVzID0gcmVzLmRhdGEucHJvZ3JhbUluZm8ucGxheVN0YXR1cztcbiAgICAgICAgICAgICAgICB0aGlzLnJvb21JbmZvLnJvb21JZCA9IHJlcy5kYXRhLnByb2dyYW1JbmZvLnJvb21JZDtcbiAgICAgICAgICAgICAgICB0aGlzLnJvb21JbmZvLmxpdmVUeXBlSWQgPSByZXMuZGF0YS5wcm9ncmFtSW5mby5saXZlVHlwZUlkO1xuICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8ubGl2ZVN1YlR5cGVJZCA9IHJlcy5kYXRhLnByb2dyYW1JbmZvLmxpdmVTdWJUeXBlSWQ7XG4gICAgICAgICAgICAgICAgdGhpcy5yb29tSW5mby5jaGF0Um9vbUlkID0gcmVzLmRhdGEuY2hhdEluZm8uY2hhdFJvb21JZDtcblxuICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8uYW5jaG9yTmlja25hbWUgPSByZXMuZGF0YS5hbmNob3JJbmZvLmFuY2hvck5pY2tOYW1lO1xuICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8ucm9vbVRpdGxlID0gcmVzLmRhdGEucHJvZ3JhbUluZm8ucHJvZ3JhbU5hbWU7XG4gICAgICAgICAgICAgICAgdGhpcy5yb29tSW5mby5zdWJUaXRsZSA9IHJlcy5kYXRhLnByb2dyYW1JbmZvLmxpdmVUeXBlTmFtZTtcblxuICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8uc2hhcmVJbmZvID0gcmVzLmRhdGEuc2hhcmVJbmZvO1xuXG4gICAgICAgICAgICAgICAgdGhpcy5fdGFiRGlzcGxheShyZXMuZGF0YS50YWJDb250cm9sKTtcbiAgICAgICAgICAgICAgICAvL+a3u+WKoOWIsOacrOWcsOe8k+WtmOWOhuWPsuiusOW9lVxuICAgICAgICAgICAgICAgIF8ucmVjb3JkKHtcbiAgICAgICAgICAgICAgICAgICAgcm9vbUlkOiByZXMuZGF0YS5wcm9ncmFtSW5mby5yb29tSWQsXG4gICAgICAgICAgICAgICAgICAgIHFpcHVJZDogcmVzLmRhdGEucHJvZ3JhbUluZm8ucWlwdUlkLFxuICAgICAgICAgICAgICAgICAgICBjb3ZlckltYWdlVXJsOiByZXMuZGF0YS5wcm9ncmFtSW5mby5jb3ZlckltYWdlVXJsIHx8IHJlcy5kYXRhLnNoYXJlSW5mby5jb3Zlci5yZXBsYWNlKFwiXzQ4MF8yNzBcIiwgXCJfNDgwXzM2MFwiKSxcbiAgICAgICAgICAgICAgICAgICAgbGl2ZVR5cGU6IDEsXG4gICAgICAgICAgICAgICAgICAgIHBsYXlOdW1iZXI6IHJlcy5kYXRhLnByb2dyYW1JbmZvLnBsYXlOdW1iZXIsXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlOiByZXMuZGF0YS5wcm9ncmFtSW5mby5wcm9ncmFtTmFtZSB8fCByZXMuZGF0YS5wcm9ncmFtSW5mby5kZXNjcmlwdGlvbixcbiAgICAgICAgICAgICAgICAgICAgbmlja25hbWU6IHJlcy5kYXRhLmFuY2hvckluZm8uYW5jaG9yTmlja05hbWUsXG4gICAgICAgICAgICAgICAgICAgIHJlY29yZFRpbWU6IG5ldyBEYXRlKCkuZ2V0VGltZSgpXG4gICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xuICAgICAgICAgICAgICAgICAgICByb29tVGl0bGU6IHJlcy5kYXRhLnByb2dyYW1JbmZvLnByb2dyYW1OYW1lLFxuICAgICAgICAgICAgICAgICAgICByb29tU3RhdHVzOiByZXMuZGF0YS5wcm9ncmFtSW5mby5wbGF5U3RhdHVzLCAvLzA6IOacquefpSwgMe+8muacquW8gOWni++8jDLvvJrnm7Tmkq3vvIwzOuWbnueci+S4rSw0OuWbnueci+e7k+adnyDvvIjmlrDlop7vvIksNTrova7mkq3kuK0sIC0xIOemgeaSreS4rSAgIyMjIOWvueW6lOWQiOW5tiBcInJvb21TdGF0dXNcIjogMSwgLy8gMC7lgZzmkq3kuK0gMS7nm7Tmkq3kuK0gMuemgeaSreS4rSAz6L2u5pKt5LitLFxuICAgICAgICAgICAgICAgICAgICBmb2xsb3dlZDogcmVzLmRhdGEuYW5jaG9ySW5mby5pc0ZvbGxvd2VkLFxuICAgICAgICAgICAgICAgICAgICBmb2xsb3dOdW06IHV0aWxzLnNob3J0TnVtKHJlcy5kYXRhLmFuY2hvckluZm8uYW5jaG9yRm9sbG93ZXJOdW0pLFxuICAgICAgICAgICAgICAgICAgICBsaXZlVHlwZU5hbWU6IHJlcy5kYXRhLnByb2dyYW1JbmZvLmxpdmVUeXBlTmFtZSxcbiAgICAgICAgICAgICAgICAgICAgbGl2ZVN1YlR5cGVOYW1lOiByZXMuZGF0YS5wcm9ncmFtSW5mby5saXZlU3ViVHlwZU5hbWUsXG4gICAgICAgICAgICAgICAgICAgIGhvc3RJbmZvOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBcImFuY2hvckljb25cIjogcmVzLmRhdGEuYW5jaG9ySW5mby5hbmNob3JJY29uLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJuaWNrbmFtZVwiOiByZXMuZGF0YS5hbmNob3JJbmZvLmFuY2hvck5pY2tOYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gXCJ3YWxsZXRcIjogdXRpbHMuc2hvcnROdW0ocmVzLmRhdGEud2FsbGV0KSwvLyDouqvku7dcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFwicG9wdWxhdHlcIjogdXRpbHMuc2hvcnROdW0ocmVzLmRhdGEucG9wdWxhdHkpLCAvLyDng63luqZcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiaW5mb1wiOiByZXMuZGF0YS5wcm9ncmFtSW5mby5kZXNjcmlwdGlvblxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB0aGlzLnNlbygpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YShwYXJhbXMpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7ICdwcmV2aWV3Q292ZXInOiByZXMuZGF0YS5wcm9ncmFtSW5mby5jb3ZlckltYWdlVXJsIHx8ICdodHRwOi8vd3d3LmlxaXlpcGljLmNvbS9jb21tb24vZml4L3d4LWlxaXlpL3BsYXllci10aXAtYmcuanBnJyB9KVxuICAgICAgICAgICAgICAgIHN3YW4uc2V0TmF2aWdhdGlvbkJhclRpdGxlKHtcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU6IHJlcy5kYXRhLnByb2dyYW1JbmZvLnByb2dyYW1OYW1lXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgdGhpcy5jb21wb25lbnRzLnBsYXllckNvbnRyb2wgPSBuZXcgUGxheWVyQ29udHJvbCh0aGlzKTtcbiAgICAgICAgICAgICAgICAvLyDmi4nlj5bmnIDlkI7lh6DmnaHogYrlpKnorrDlvZVcbiAgICAgICAgICAgICAgICByZXEuZ2V0TGF0ZXN0TXNnKHRoaXMucm9vbUluZm8uY2hhdFJvb21JZClcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4oKGRhdGEpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8ubGF0ZXN0TXNnID0gZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29tcG9uZW50cy5zZW5kQm94ID0gbmV3IFNlbmRCb3godGhpcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbXBvbmVudHMubXNnQm94ID0gbmV3IE1lc3NhZ2VCb3godGhpcywgcmVzLmRhdGEuY2hhdEluZm8uY2hhdFJvb21JZCk7XG4gICAgICAgICAgICAgICAgICAgIH0pLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgdGhpcy5ldmVudFRlc3RlcihcImNhbnBsYXl0aHJvdWdoXCIsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2NhbnBsYXl0aHJvdWdoJyk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGlmIChyZXMuY29kZSA9PT0gXCJBMDAwMDVcIikge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGDpnIDopoHmipXpgJLnmoRgLCByZXMubXNnKTsgLy8gVE9ETyDmipXpgJJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZW5zb3IucHVzaCh0aGlzLnNlbnNvci5DT0RFLlJPT01fSU5JVElBTF9FUlIsIHJlcy5jb2RlLCBjb25FbmQgLSBjb25TdGFydCwgMCwgJycsIGAke3Jlcy5tc2d9YCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRoaXMuY29tcG9uZW50cy5wbGF5ZXJDb250cm9sID0gbmV3IFBsYXllckNvbnRyb2wodGhpcyk7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgZXJyUm9vbTogdHJ1ZSwgLy/miL/pl7TplJnor69cbiAgICAgICAgICAgICAgICAgICAgdmlkZW86IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JJbmZvOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JNc2c6IHJlcy5tc2cgfHwgJ+inhumikeS4jeiDveaSreaUvidcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgcHJldmlld0NvdmVyOiAnaHR0cDovL3d3dy5pcWl5aXBpYy5jb20vY29tbW9uL2ZpeC93eC1pcWl5aS9wbGF5ZXItdGlwLWJnLmpwZydcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfVxuICAgICAgICB9LCByZXMgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2cocmVzKTtcbiAgICAgICAgfSk7XG4gICAgfSxcblxuICAgIG90aGVyU21hcnRQcm9ncmFtKCkge1xuICAgICAgICBzd2FuLm5hdmlnYXRlVG9TbWFydFByb2dyYW0oe1xuICAgICAgICAgICAgYXBwS2V5OiAnRlNUb2R1MFVpQTVNR1U1Q1VwMzFXeXZtWnR4dDkwNVknLCAvLyDopoHmiZPlvIDnmoTlsI/nqIvluo8gQXBwIEtleVxuICAgICAgICAgICAgcGF0aDogJ3BhZ2VzL3cvcm9vbT9yb29tSWQ9JyArIHRoaXMucm9vbUluZm8ucm9vbUlkLFxuICAgICAgICAgICAgLy8gcGF0aDogJycsIC8vIOaJk+W8gOeahOmhtemdoui3r+W+hO+8jOWmguaenOS4uuepuuWImeaJk+W8gOmmlumhtVxuICAgICAgICAgICAgZXh0cmFEYXRhOiB7XG4gICAgICAgICAgICAgICAgLy8gcm9vbUlkOiA1MjU4MVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHN1Y2Nlc3M6IGZ1bmN0aW9uKHJlcykge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlcyk7XG4gICAgICAgICAgICAgICAgLy8g5omT5byA5oiQ5YqfXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgY29tcGxldGU6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIHN3YW4uc2hvd01vZGFsKHsgdGl0bGU6ICcxMjMzMjEnIH0pO1xuICAgICAgICAgICAgICAgIC8vIOaJk+W8gOaIkOWKn1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9LFxuICAgIF90YWJEaXNwbGF5KHRhYkxpc3QpIHtcbiAgICAgICAgdGFiTGlzdC5mb3JFYWNoKChpdGVtKSA9PiB7XG4gICAgICAgICAgICBpZiAoaXRlbS5kaXNwbGF5TmFtZSA9PT0gJ+S4u+aSrScgJiYgaXRlbS5lbmFibGUpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmRhdGEudGFiLmhvc3QgPSB0cnVlO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChpdGVtLmRpc3BsYXlOYW1lID09PSAn6IGK5aSpJyAmJiBpdGVtLmVuYWJsZSkge1xuICAgICAgICAgICAgICAgIHRoaXMuZGF0YS50YWIuY2hhdCA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnNldERhdGEoeyB0YWI6IHRoaXMuZGF0YS50YWIgfSk7XG4gICAgICAgIH0pO1xuICAgICAgICBpZiAoIXRoaXMuZGF0YS50YWIuY2hhdCAmJiB0aGlzLmRhdGEudGFiLmhvc3QpIHtcbiAgICAgICAgICAgIHRoaXMuZGF0YS5hY3RpdmVUYWIgPSAnaG9zdCc7XG4gICAgICAgICAgICB0aGlzLnNldERhdGEoeyBhY3RpdmVUYWI6ICdob3N0JyB9KTtcbiAgICAgICAgICAgIHJvb20uZ2V0UmVjb21tZW5kTGlzdCh0aGlzKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgZXZlbnRUZXN0ZXI6IGZ1bmN0aW9uKGUsIGV2ZW50SGFubGVyKSB7XG4gICAgICAgIGxldCBNZWRpYSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd2aWRlb0lkJyk7XG4gICAgICAgIE1lZGlhLmFkZEV2ZW50TGlzdGVuZXIoZSwgZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICBldmVudEhhbmxlciAmJiBldmVudEhhbmxlcigpO1xuICAgICAgICAgICAgb3V0LmRlYnVnKChuZXcgRGF0ZSgpKS5nZXRUaW1lKCksIGUpXG4gICAgICAgIH0sIGZhbHNlKTtcbiAgICB9LFxuXG4gICAgYWZ0ZXJMb2dpblRyaWdnZXI6IGZ1bmN0aW9uKCkge1xuICAgICAgICBzd2FuLnNob3dUb2FzdCh7XG4gICAgICAgICAgICB0aXRsZTogYOeZu+W9leaIkOWKn2AsXG4gICAgICAgICAgICBpY29uOiAnbm9uZSdcbiAgICAgICAgfSk7XG4gICAgICAgIHJvb20ucmVmcmVzaEluZm8odGhpcyk7XG4gICAgICAgIHRoaXMudHJpZ2dlci5lbWl0KFwiYWZ0ZXJMb2dpblN1Y2Nlc3NcIik7XG4gICAgfSxcblxuICAgIGFmdGVyTG9nb3V0VHJpZ2dlcjogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJvb20ucmVzZXRGb2xsb3dCdG4odGhpcyk7XG4gICAgICAgIHRoaXMudHJpZ2dlci5lbWl0KFwiYWZ0ZXJMb2dvdXRTdWNjZXNzXCIpO1xuICAgIH0sXG5cbiAgICBsb2dpblN1Y2Nlc3M6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLnRyaWdnZXIuZW1pdChcImFmdGVyR2V0VXNlckluZm9cIik7XG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIOeUn+WRveWRqOacn+WHveaVsC0t55uR5ZCs6aG16Z2i5Yid5qyh5riy5p+T5a6M5oiQXG4gICAgICovXG4gICAgb25SZWFkeTogZnVuY3Rpb24oKSB7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdvblJlYWR5Jyk7XG4gICAgICAgIGxldCBwYWdlID0gdGhpcztcbiAgICAgICAgLy8gdGhpcy5zZXREYXRhKHtcbiAgICAgICAgLy8gICAgIHNjcm9sbEhlaWdodDogcm9vbS5nZXRTY3JvbGxIZWlnaHQoKSxcbiAgICAgICAgLy8gICAgIHJvb21JbmZvSGVpZ2h0OiByb29tLmdldFJvb21JbmZvSGVpZ2h0KCksXG4gICAgICAgIC8vICAgICBpbnB1dEZpdENsYXNzOiByb29tLmdldElucHV0Rml0Q2xhc3MoKVxuICAgICAgICAvLyB9KTtcbiAgICAgICAgcm9vbS5nZXRTY3JvbGxIZWlnaHQocGFnZSk7XG4gICAgICAgIHJvb20uZ2V0Um9vbUluZm9IZWlnaHQocGFnZSk7XG4gICAgICAgIHJvb20uZ2V0SW5wdXRGaXRDbGFzcyhwYWdlKTtcbiAgICAgICAgLy8gZ2V0QXBwKCkuZW1pdHRlci5vbihcImFmdGVyTG9naW5TdWNjZXNzXCIsIHRoaXMuYWZ0ZXJMb2dpblRyaWdnZXIpO1xuICAgICAgICAvLyBnZXRBcHAoKS5lbWl0dGVyLm9uKFwiYWZ0ZXJMb2dvdXRTdWNjZXNzXCIsIHRoaXMuYWZ0ZXJMb2dvdXRUcmlnZ2VyKTtcbiAgICB9LFxuXG4gICAgLyoqXG4gICAgICog55Sf5ZG95ZGo5pyf5Ye95pWwLS3nm5HlkKzpobXpnaLmmL7npLpcbiAgICAgKi9cbiAgICBvblNob3c6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLnRyaWdnZXIuZW1pdChcInNob3dQYWdlXCIpO1xuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiDnlJ/lkb3lkajmnJ/lh73mlbAtLeebkeWQrOmhtemdoumakOiXj1xuICAgICAqL1xuICAgIG9uSGlkZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIC8vIGdldEFwcCgpLmVtaXR0ZXIuZW1pdChcImhpZGVQYWdlXCIpO1xuICAgICAgICB0aGlzLnRyaWdnZXIuZW1pdChcImhpZGVQYWdlXCIpO1xuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiDnlJ/lkb3lkajmnJ/lh73mlbAtLeebkeWQrOmhtemdouWNuOi9vVxuICAgICAqL1xuICAgIG9uVW5sb2FkOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy50cmlnZ2VyLmVtaXQoXCJwYWdlVW5sb2FkXCIpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyh0aGlzLnRyaWdnZXIpO1xuICAgICAgICB0aGlzLnRyaWdnZXIub2ZmKCk7XG4gICAgICAgIHRoaXMuc2V0RGF0YSh7XG4gICAgICAgICAgICBlcnJvclRpcDogdHJ1ZSxcbiAgICAgICAgICAgIGFjdGl2ZVRhYjogXCJjaGF0XCIsXG4gICAgICAgICAgICAvLyByb29tSWQ6IG51bGwsXG4gICAgICAgICAgICBob3N0SW5mbzogbnVsbCxcbiAgICAgICAgICAgIC8vIG1zZ0xpc3Q6IFt7XG4gICAgICAgICAgICAvLyAgICAgdHlwZTogMCxcbiAgICAgICAgICAgIC8vICAgICBjb250ZW50OiBcIuato+WcqOWHhuWkh+W8ueW5lVwiXG4gICAgICAgICAgICAvLyB9XSxcbiAgICAgICAgICAgIHNjcm9sbEhlaWdodDogMTAwLFxuICAgICAgICAgICAgc2Nyb2xsSGlkZUxvYWRNb3JlOiB0cnVlLFxuICAgICAgICAgICAgc2Nyb2xsQW5pbWF0aW9uOiBmYWxzZSxcbiAgICAgICAgICAgIGlucHV0Rm9jdXM6IGZhbHNlLFxuICAgICAgICAgICAgaW5wdXRUZXh0OiBcIlwiLFxuICAgICAgICAgICAgaW5wdXRBdmFpbGFibGU6IFwiXCIsXG4gICAgICAgICAgICBzaG93S2V5Ym9hcmQ6IFwiXCIsXG4gICAgICAgICAgICB2aWRlb0JvZHlUb3A6IDAsXG4gICAgICAgICAgICBrZXlib2FyZEhlaWdodDogMCxcbiAgICAgICAgICAgIHZpZGVvOiB7XG4gICAgICAgICAgICAgICAgbmVlZFZJUDogZmFsc2UsXG4gICAgICAgICAgICAgICAgbmVlZExvZ2luOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBzaG93OiBmYWxzZSxcbiAgICAgICAgICAgICAgICBvZmZsaW5lOiBmYWxzZSxcbiAgICAgICAgICAgICAgICB1cmw6IFwiXCJcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIC8vIGdldEFwcCgpLmVtaXR0ZXIub2ZmKFwiYWZ0ZXJMb2dpblN1Y2Nlc3NcIiwgdGhpcy5hZnRlckxvZ2luVHJpZ2dlcik7XG4gICAgICAgIC8vIGdldEFwcCgpLmVtaXR0ZXIub2ZmKFwiYWZ0ZXJMb2dvdXRTdWNjZXNzXCIsIHRoaXMuYWZ0ZXJMb2dvdXRUcmlnZ2VyKTtcbiAgICB9XG59XG5QYWdlKE9iamVjdC5hc3NpZ24oe30sIHBhZ2UpKVxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAvVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9wYWdlcy93L3Jvb20uanMiLCJpbXBvcnQgKiBhcyByb29tIGZyb20gJy4vYWN0aW9ucy9yb29tQWN0aW9uLmpzJztcbmltcG9ydCAqIGFzIHJlcSBmcm9tICcuL3NlcnZpY2UvcmVxU2VydmljZSc7XG4vLyBpbXBvcnQgUGxheWVyQ29udHJvbCBmcm9tICcuL2FjdGlvbnMvcGxheWVyQWN0aW9uJztcbmltcG9ydCBQbGF5ZXJDb250cm9sIGZyb20gJy4vYWN0aW9ucy9wbGF5ZXJBY3Rpb24nO1xuaW1wb3J0IE1lc3NhZ2VCb3ggZnJvbSAnLi9hY3Rpb25zL21zZ0FjdGlvbic7XG5pbXBvcnQgU2VuZEJveCBmcm9tICcuL2FjdGlvbnMvc2VuZE1zZ0FjdGlvbic7XG5pbXBvcnQgcHJhaXNlQ29udHJvbCBmcm9tICcuL2FjdGlvbnMvcHJhaXNlQWN0aW9uJztcbmltcG9ydCAqIGFzIHV0aWxzIGZyb20gXCIuL2NvbW1vbi91dGlsc1wiO1xuaW1wb3J0IF8gZnJvbSBcIi4uLy4uL2NvbW1vbi91dGlscy91dGlsXCI7XG5pbXBvcnQgRW1pdHRlciBmcm9tICcuLi8uLi9jb21tb24vZW1pdHRlci9FbWl0dGVyJztcbmltcG9ydCBTZW5zb3IgZnJvbSAnLi4vLi4vY29tbW9uL3NlbnNvci9qc1NlbnNvcic7XG5pbXBvcnQgKiBhcyB1c2VyIGZyb20gJy4vY29tbW9uL3VzZXInO1xuLy8gaW1wb3J0IG11dGlBY2NvdW50IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvbXV0aUFjY291bnQvbXV0aUFjY291bnQnXG5cbmNvbnN0IGFwcCA9IGdldEFwcCgpO1xuY29uc3QgcGFnZSA9IHtcbiAgICAvKipcbiAgICAgKiDpobXpnaLnmoTliJ3lp4vmlbDmja5cbiAgICAgKi9cbiAgICBkYXRhOiB7XG4gICAgICAgIGVycm9yVGlwOiB0cnVlLFxuICAgICAgICBhY3RpdmVUYWI6IFwiY2hhdFwiLFxuICAgICAgICByb29tSWQ6IG51bGwsXG4gICAgICAgIGhvc3RJbmZvOiBudWxsLFxuICAgICAgICBtc2dMaXN0OiBbe1xuICAgICAgICAgICAgdHlwZTogMCxcbiAgICAgICAgICAgIGNvbnRlbnQ6IFwi5q2j5Zyo6ZO+5o6l6IGK5aSp5a6kLi4uLi4uXCJcbiAgICAgICAgfV0sXG4gICAgICAgIHNjcm9sbEhlaWdodDogMTAwLFxuICAgICAgICBzY3JvbGxIaWRlTG9hZE1vcmU6IHRydWUsXG4gICAgICAgIHNjcm9sbEFuaW1hdGlvbjogZmFsc2UsXG4gICAgICAgIGlucHV0Rm9jdXM6IGZhbHNlLFxuICAgICAgICBpbnB1dFRleHQ6IFwiXCIsXG4gICAgICAgIGlucHV0QXZhaWxhYmxlOiBcIlwiLFxuICAgICAgICBzaG93S2V5Ym9hcmQ6IFwiXCIsXG4gICAgICAgIHZpZGVvQm9keVRvcDogMCxcbiAgICAgICAgdmlkZW86IHtcbiAgICAgICAgICAgIG5lZWRWSVA6IGZhbHNlLFxuICAgICAgICAgICAgbmVlZExvZ2luOiBmYWxzZSxcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgb2ZmbGluZTogZmFsc2VcbiAgICAgICAgfSxcbiAgICAgICAgcHJldmlld0NvdmVyOiAnJyxcbiAgICAgICAgcm9vbVN0YXR1czogMCxcbiAgICAgICAgZm9sbG93ZWQ6IGZhbHNlLFxuICAgICAgICByZWNvbW1lbmRMaXN0OiBbXSxcbiAgICAgICAga2V5Ym9hcmRIZWlnaHQ6IDAsXG4gICAgICAgIG9wZW46IGZhbHNlLFxuICAgICAgICBlcnJSb29tOiBmYWxzZSwgLy/miL/pl7QgaW5pdCBlcnJvciBcbiAgICAgICAgY2FuUHJhaXNlOiBmYWxzZSAvLyDmmK/lkKblj6/ku6XngrnotZ4gXG4gICAgfSxcbiAgICBjbGlja0ZvbGxvdzogZnVuY3Rpb24oKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCfkuI3og73orqLpmIUhJyk7XG4gICAgICAgIHJldHVybjtcbiAgICAgICAgcm9vbS5jbGlja0ZvbGxvdyh0aGlzKTtcbiAgICB9LFxuICAgIGNsaWNrUmVjb21tZW5kOiBmdW5jdGlvbihlKSB7XG4gICAgICAgIHJvb20ucmVkaXJlY3RUbyhlLmN1cnJlbnRUYXJnZXQuZGF0YXNldCk7XG4gICAgfSxcbiAgICBkZXN0cm95ZWQoKSB7XG4gICAgICAgIC8vIOmUgOavgSDlrprml7blmajkuovku7ZcbiAgICAgICAgdGhpcy5jb21wb25lbnRzLnBsYXllckNvbnRyb2wgJiYgdGhpcy5jb21wb25lbnRzLnBsYXllckNvbnRyb2wuZGVzdHJveWVkICYmIHRoaXMuY29tcG9uZW50cy5wbGF5ZXJDb250cm9sLmRlc3Ryb3llZCgpO1xuICAgICAgICB0aGlzLmNvbXBvbmVudHMubXNnQm94ICYmIHRoaXMuY29tcG9uZW50cy5tc2dCb3guZGVzdHJveWVkICYmIHRoaXMuY29tcG9uZW50cy5tc2dCb3guZGVzdHJveWVkKCk7XG4gICAgfSxcbiAgICBjbGlja011bHRpTGl2ZTogZnVuY3Rpb24oZSkge1xuICAgICAgICB0aGlzLmRlc3Ryb3llZCgpO1xuICAgICAgICBsZXQgZGF0YXNldCA9IGUuY3VycmVudFRhcmdldC5kYXRhc2V0O1xuICAgICAgICBpZiAoZGF0YXNldC5yb29taWQgPT0gdGhpcy5kYXRhLnJvb21JZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIF8uanVtcChgL3BhZ2VzL3Mvcm9vbT9yb29tSWQ9JHtkYXRhc2V0LnJvb21pZH1gKVxuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiDnlKjmiLfngrnlh7vlj7PkuIrop5LliIbkuqtcbiAgICAgKi9cbiAgICBvblNoYXJlQXBwTWVzc2FnZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIGxldCBzaGFyZURhdGEgPSB7XG4gICAgICAgICAgICB0aXRsZTogdGhpcy5yb29tSW5mby5zaGFyZUluZm8ucHJvZ3JhbU5hbWUsXG4gICAgICAgICAgICBjb250ZW50OiB0aGlzLnJvb21JbmZvLnNoYXJlSW5mby5kZXNjcmlwdGlvbixcbiAgICAgICAgICAgIGltYWdlVXJsOiB0aGlzLnJvb21JbmZvLnNoYXJlSW5mby5jb3Zlci5yZXBsYWNlKFwiXzQ4MF8yNzBcIiwgXCJfNDgwXzM2MFwiKSxcbiAgICAgICAgICAgIHBhdGg6ICdwYWdlcy9zL3Jvb20/cm9vbUlkPScgKyB0aGlzLnJvb21JbmZvLnJvb21JZFxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzaGFyZURhdGE7XG4gICAgfSxcblxuICAgIG9uQ2xpY2tTaGFyZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIGxldCBzaGFyZURhdGEgPSB7XG4gICAgICAgICAgICB0aXRsZTogdGhpcy5yb29tSW5mby5zaGFyZUluZm8ucHJvZ3JhbU5hbWUsXG4gICAgICAgICAgICBjb250ZW50OiB0aGlzLnJvb21JbmZvLnNoYXJlSW5mby5kZXNjcmlwdGlvbixcbiAgICAgICAgICAgIGltYWdlVXJsOiB0aGlzLnJvb21JbmZvLnNoYXJlSW5mby5jb3Zlci5yZXBsYWNlKFwiXzQ4MF8yNzBcIiwgXCJfNDgwXzM2MFwiKSxcbiAgICAgICAgICAgIHBhdGg6ICdwYWdlcy9zL3Jvb20/cm9vbUlkPScgKyB0aGlzLnJvb21JbmZvLnJvb21JZFxuICAgICAgICB9XG4gICAgICAgIHN3YW4ub3BlblNoYXJlKHNoYXJlRGF0YSk7XG4gICAgfSxcbiAgICAvKipcbiAgICAgKiDnlJ/lkb3lkajmnJ/lh73mlbAtLeebkeWQrOmhtemdouWKoOi9vVxuICAgICAqL1xuICAgIHN0b3JlOiB7XG4gICAgICAgIGRpc3BhdGNoOiBmdW5jdGlvbigpIHt9XG4gICAgfSxcbiAgICAvLyBpc011bHRpQWNjb3VudDogbXV0aUFjY291bnQuaXNNdWx0aUFjY291bnQsXG4gICAgc2VvKCkge1xuICAgICAgICBfLnNlbyh7XG4gICAgICAgICAgICBkZXNjOiBgJHt0aGlzLnJvb21JbmZvLnJvb21UaXRsZSB9X+ebtOaSrV/niLHlpYfoibrnm7Tmkq0t54ix5aWH6Im6YCxcbiAgICAgICAgICAgIGtleXdvcmRzOiBgJHt0aGlzLnJvb21JbmZvLnJvb21UaXRsZSB9LCR7dGhpcy5yb29tSW5mby5yb29tVGl0bGUgfV/nm7Tmkq0sJHt0aGlzLnJvb21JbmZvLnJvb21UaXRsZSB955u05pKt6Ze0LCR7dGhpcy5yb29tSW5mby5yb29tVGl0bGUgfeebtOaSreWcsOWdgO+8jCR7dGhpcy5yb29tSW5mby5yb29tVGl0bGUgfeebtOaSre+8jCR7dGhpcy5yb29tSW5mby5yb29tVGl0bGUgfeinhumikWAsXG4gICAgICAgICAgICB0aXRsZTogYCR7dGhpcy5yb29tSW5mby5yb29tVGl0bGUgfV/nm7Tmkq1f54ix5aWH6Im655u05pKtLeeIseWlh+iJumBcbiAgICAgICAgfSk7XG4gICAgfSxcbiAgICBzZW5zb3JJbml0KCkge1xuICAgICAgICBsZXQgZ2xvYmFsRGF0YSA9IGdldEFwcCgpLmdsb2JhbERhdGE7XG4gICAgICAgIHRoaXMuc2Vuc29yID0gbmV3IFNlbnNvcih7XG4gICAgICAgICAgICBwbDogZ2xvYmFsRGF0YS5wbCB8fCAnMl8yNF8yMDBfMycsXG4gICAgICAgICAgICB0OiBnbG9iYWxEYXRhLnRsIHx8ICdiZF9pb3MnLFxuICAgICAgICAgICAgdmVyc2lvbjogZ2xvYmFsRGF0YS52ZXJzaW9uIHx8ICcyLjAxLjA1JywgLy9iYWlkdSBtaW5pIHBybyB2ZXJzaW9uIFxuICAgICAgICAgICAgZGV2aWNlX2lkOiB1c2VyLmdldERldmljZUlkKCkgfHwgJycsXG4gICAgICAgICAgICB1c2VySWQ6ICcnLFxuICAgICAgICAgICAgdXJsOiAnL3YxL2xpdmUvaW5pdGlhbCcsXG4gICAgICAgICAgICByb29tSWQ6IHRoaXMuZGF0YS5yb29tSWQsXG4gICAgICAgIH0sIHN3YW4pO1xuICAgIH0sXG4gICAgY2FuUHJhaXNlSGFuZGxlcihib29sKSB7XG4gICAgICAgIHRoaXMuc2V0RGF0YSh7XG4gICAgICAgICAgICBcImNhblByYWlzZVwiOiBib29sIHx8IGZhbHNlXG4gICAgICAgIH0pO1xuICAgIH0sXG4gICAgb25Mb2FkKG9wdCkge1xuICAgICAgICAvLyBjb25zb2xlLmxvZygnb3B0OlxcdCcsIG9wdCk7XG4gICAgICAgIC8vIG9wdC5yb29tSWQgPSAnMzc1NDInO1xuICAgICAgICBvcHQgPSB7IHJvb21JZDogb3B0ICYmIG9wdC5yb29tSWQgfHwgdGhpcy5yb29tSW5mbyAmJiB0aGlzLnJvb21JbmZvLnFpcHVJZCB8fCAnJyB9O1xuICAgICAgICB0aGlzLnRyaWdnZXIgPSBuZXcgRW1pdHRlcigpO1xuICAgICAgICBnZXRBcHAoKS5lbWl0dGVyID0gdGhpcy50cmlnZ2VyO1xuICAgICAgICB0aGlzLnJvb21JbmZvID0ge307XG4gICAgICAgIHRoaXMuY29tcG9uZW50cyA9IHt9O1xuICAgICAgICB0aGlzLnNldERhdGEoe1xuICAgICAgICAgICAgXCJyb29tSWRcIjogb3B0LnJvb21JZCxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuY2FuUHJhaXNlSGFuZGxlcigpOyAvL+m7mOiupOS4jeiDveeCuei1nlxuICAgICAgICBpZiAob3B0LmVudikge1xuICAgICAgICAgICAgcmVxLnNldEVOVihcInRlc3RcIik7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zZW5zb3IgPSB7fTtcbiAgICAgICAgdGhpcy5zZW5zb3JJbml0KCk7XG4gICAgICAgIHRoaXMucmVxSW5pdChvcHQpO1xuICAgIH0sXG4gICAgcmVxSW5pdChvcHQpIHtcbiAgICAgICAgbGV0IGNvblN0YXJ0ID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICAgIHJlcS5nZXRSb29tSW5mbyhvcHQucm9vbUlkKS50aGVuKHJlcyA9PiB7XG4gICAgICAgICAgICBsZXQgY29uRW5kID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICAgICAgICB0aGlzLnNlbnNvci5wdXNoKHRoaXMuc2Vuc29yLkNPREUuUk9PTV9JTklUSUFMX1NVQ0NFU1MsIHJlcy5jb2RlLCBjb25FbmQgLSBjb25TdGFydCwgMCwgJycsIGAke3Jlcy5tc2d9YCk7XG5cbiAgICAgICAgICAgIGlmIChyZXMuY29kZSA9PT0gXCJBMDAwMDBcIikge1xuICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8gPSByZXMuZGF0YTtcbiAgICAgICAgICAgICAgICB0aGlzLnJvb21JbmZvLnJvb21JZCA9IHJlcy5kYXRhLnByb2dyYW1JbmZvLnFpcHVJZDtcbiAgICAgICAgICAgICAgICB0aGlzLnJvb21JbmZvLnFwSWQgPSByZXMuZGF0YS5wcm9ncmFtSW5mby5xaXB1SWQ7XG4gICAgICAgICAgICAgICAgdGhpcy5yb29tSW5mby5xaXB1SWQgPSByZXMuZGF0YS5wcm9ncmFtSW5mby5xaXB1SWQ7XG4gICAgICAgICAgICAgICAgdGhpcy5yb29tSW5mby5saXZlQ2hhbm5lbElkID0gcmVzLmRhdGEucHJvZ3JhbUluZm8ubGl2ZUNoYW5uZWxJZDtcbiAgICAgICAgICAgICAgICB0aGlzLnJvb21JbmZvLnJvb21TdGF0dXMgPSByZXMuZGF0YS5wcm9ncmFtSW5mby5wbGF5U3RhdHVzO1xuICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8ucGxheVN0YXR1cyA9IHJlcy5kYXRhLnByb2dyYW1JbmZvLnBsYXlTdGF0dXM7XG4gICAgICAgICAgICAgICAgLy8gdGhpcy5yb29tSW5mby5yb29tSWQgPSByZXMuZGF0YS5wcm9ncmFtSW5mby5yb29tSWQ7Ly9wZ2Mg54us5pyJXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5yb29tSW5mby5saXZlVHlwZUlkID0gcmVzLmRhdGEucHJvZ3JhbUluZm8ubGl2ZVR5cGVJZDsvL3BnYyDni6zmnIlcbiAgICAgICAgICAgICAgICAvLyB0aGlzLnJvb21JbmZvLmxpdmVTdWJUeXBlSWQgPSByZXMuZGF0YS5wcm9ncmFtSW5mby5saXZlU3ViVHlwZUlkOy8vcGdjIOeLrOaciVxuICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8uY2hhdFJvb21JZCA9IHJlcy5kYXRhLmNoYXRJbmZvLmNoYXRSb29tSWQ7XG4gICAgICAgICAgICAgICAgdGhpcy5yb29tSW5mby5zdGFydFBsYXlUaW1lID0gcmVzLmRhdGEuY2hhdEluZm8uY2hhdFJvb21JZDtcblxuICAgICAgICAgICAgICAgIC8vIHRoaXMucm9vbUluZm8uYW5jaG9yTmlja25hbWUgPSByZXMuZGF0YS5hbmNob3JJbmZvLmFuY2hvck5pY2tOYW1lOy8vcGdjIOeLrOaciVxuICAgICAgICAgICAgICAgIC8vIHRoaXMucm9vbUluZm8uc3ViVGl0bGUgPSByZXMuZGF0YS5wcm9ncmFtSW5mby5saXZlVHlwZU5hbWU7Ly9wZ2Mg54us5pyJXG5cbiAgICAgICAgICAgICAgICB0aGlzLnJvb21JbmZvLnNoYXJlSW5mbyA9IHJlcy5kYXRhLnNoYXJlSW5mbztcbiAgICAgICAgICAgICAgICBsZXQgcmVjb3JkT2JqID0ge1xuICAgICAgICAgICAgICAgICAgICByb29tSWQ6IHJlcy5kYXRhLnByb2dyYW1JbmZvLnJvb21JZCB8fCByZXMuZGF0YS5wcm9ncmFtSW5mby5xaXB1SWQsXG4gICAgICAgICAgICAgICAgICAgIHFpcHVJZDogcmVzLmRhdGEucHJvZ3JhbUluZm8ucWlwdUlkIHx8IHJlcy5kYXRhLnByb2dyYW1JbmZvLnJvb21JZCxcbiAgICAgICAgICAgICAgICAgICAgY292ZXJJbWFnZVVybDogcmVzLmRhdGEucHJvZ3JhbUluZm8uY292ZXJJbWFnZVVybCB8fCByZXMuZGF0YS5zaGFyZUluZm8uY292ZXIucmVwbGFjZShcIl80ODBfMjcwXCIsIFwiXzQ4MF8zNjBcIiksXG4gICAgICAgICAgICAgICAgICAgIGxpdmVUeXBlOiAyLFxuICAgICAgICAgICAgICAgICAgICBwbGF5TnVtYmVyOiByZXMuZGF0YS5wcm9ncmFtSW5mby5wbGF5TnVtYmVyLFxuICAgICAgICAgICAgICAgICAgICB0aXRsZTogcmVzLmRhdGEucHJvZ3JhbUluZm8ucHJvZ3JhbU5hbWUgfHwgcmVzLmRhdGEucHJvZ3JhbUluZm8uZGVzY3JpcHRpb24sXG4gICAgICAgICAgICAgICAgICAgIC8vIG5pY2tuYW1lOiByZXMuZGF0YS5hbmNob3JJbmZvLmFuY2hvck5pY2tOYW1lLC8v5LiN6IO95re75Yqg6L+Z5Liq5a2X5q61IOWboOS4uui/meS4quWtl+auteeahOWvueixoeS4jeWtmOWcqCDkvJrlr7zoh7TlkI7nu63ku6PnoIHltKnmuoMg5YGc5q2i5omn6KGMXG4gICAgICAgICAgICAgICAgICAgIHJlY29yZFRpbWU6IG5ldyBEYXRlKCkuZ2V0VGltZSgpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIF8ucmVjb3JkKHJlY29yZE9iaik7XG4gICAgICAgICAgICAgICAgbGV0IHBhcmFtcyA9IHtcbiAgICAgICAgICAgICAgICAgICAgcWlwdUlkOiByZXMuZGF0YS5wcm9ncmFtSW5mby5xaXB1SWQsXG4gICAgICAgICAgICAgICAgICAgIHJvb21UaXRsZTogcmVzLmRhdGEucHJvZ3JhbUluZm8ucHJvZ3JhbU5hbWUgfHwgcmVzLmRhdGEucHJvZ3JhbUluZm8uZGVzY3JpcHRpb24sXG4gICAgICAgICAgICAgICAgICAgIHJvb21TdGF0dXM6IHJlcy5kYXRhLnByb2dyYW1JbmZvLnBsYXlTdGF0dXMsIC8vMDog5pyq55+lLCAx77ya5pyq5byA5aeL77yMMu+8muebtOaSre+8jDM65Zue55yL5LitLDQ65Zue55yL57uT5p2fIO+8iOaWsOWinu+8iSw1Oui9ruaSreS4rSwgLTEg56aB5pKt5LitICAjIyMg5a+55bqU5ZCI5bm2IFwicm9vbVN0YXR1c1wiOiAxLCAvLyAwLuWBnOaSreS4rSAxLuebtOaSreS4rSAy56aB5pKt5LitIDPova7mkq3kuK0sXG4gICAgICAgICAgICAgICAgICAgIC8vIGZvbGxvd2VkOiByZXMuZGF0YS5hbmNob3JJbmZvLmlzRm9sbG93ZWQsLy9wZ2Mg54us5pyJXG4gICAgICAgICAgICAgICAgICAgIC8vIGZvbGxvd051bTogdXRpbHMuc2hvcnROdW0ocmVzLmRhdGEuYW5jaG9ySW5mby5hbmNob3JGb2xsb3dlck51bSksLy9wZ2Mg54us5pyJXG4gICAgICAgICAgICAgICAgICAgIC8vIGxpdmVUeXBlTmFtZTogcmVzLmRhdGEucHJvZ3JhbUluZm8ubGl2ZVR5cGVOYW1lLC8vcGdjIOeLrOaciVxuICAgICAgICAgICAgICAgICAgICAvLyBsaXZlU3ViVHlwZU5hbWU6IHJlcy5kYXRhLnByb2dyYW1JbmZvLmxpdmVTdWJUeXBlTmFtZSwvL3BnYyDni6zmnIlcbiAgICAgICAgICAgICAgICAgICAgaG9zdEluZm86IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFwiYW5jaG9ySWNvblwiOiByZXMuZGF0YS5hbmNob3JJbmZvLmFuY2hvckljb24sLy9wZ2Mg54us5pyJXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBcIm5pY2tuYW1lXCI6IHJlcy5kYXRhLmFuY2hvckluZm8uYW5jaG9yTmlja05hbWUsLy9wZ2Mg54us5pyJXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBcIndhbGxldFwiOiB1dGlscy5zaG9ydE51bShyZXMuZGF0YS53YWxsZXQpLC8vIOi6q+S7t1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gXCJwb3B1bGF0eVwiOiB1dGlscy5zaG9ydE51bShyZXMuZGF0YS5wb3B1bGF0eSksIC8vIOeDreW6plxuICAgICAgICAgICAgICAgICAgICAgICAgXCJpbmZvXCI6IHJlcy5kYXRhLnByb2dyYW1JbmZvLmRlc2NyaXB0aW9uIHx8IHJlcy5kYXRhLnByb2dyYW1JbmZvLnByb2dyYW1OYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJob3RcIjogcmVzLmRhdGEucHJvZ3JhbUluZm8ucGxheU51bWJlclxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBtdWx0aUxpdmVJbmZvOiByZXMuZGF0YS5tdWx0aUxpdmVJbmZvLCAvLyDlpJrmnLrkvY3mlbDmja5cbiAgICAgICAgICAgICAgICAgICAgY2hhdFNob3VsZERpc3BsYXk6IHJlcy5kYXRhLmNoYXRJbmZvLnNob3VsZERpc3BsYXksXG4gICAgICAgICAgICAgICAgICAgIHN3aXRjaGVyOiByZXMuZGF0YS5zd2l0Y2hlciwgLy/lvojlpJrlvIDlhbMgIOWMheaLrCDngrnotZ7mgLvlvIDlhbNcbiAgICAgICAgICAgICAgICAgICAgLy8gc3RhcnRQbGF5VGltZTogXy50aW1lLmZvcm1hdChyZXMuZGF0YS5wcm9ncmFtSW5mby5zdGFydFBsYXlUaW1lLCAneXl5eS1NTS1kZCBoaDptbScpXG4gICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgIGxldCBzdGFydFBsYXlUaW1lID0gbmV3IERhdGUocmVzLmRhdGEucHJvZ3JhbUluZm8gJiYgcmVzLmRhdGEucHJvZ3JhbUluZm8uc3RhcnRQbGF5VGltZSB8fCBudWxsKTtcbiAgICAgICAgICAgICAgICBwYXJhbXNbJ3N0YXJ0UGxheVRpbWUnXSA9IF8udGltZS5mb3JtYXQoc3RhcnRQbGF5VGltZSwgJ01NLWRkIGhoOm1tJyk7XG5cbiAgICAgICAgICAgICAgICB0aGlzLnNlbygpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YShwYXJhbXMpO1xuXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5zZXREYXRhKHsgJ3ByZXZpZXdDb3Zlcic6IHJlcy5kYXRhLnByb2dyYW1JbmZvLmNvdmVySW1hZ2VVcmwgfHwgJ2h0dHA6Ly93d3cuaXFpeWlwaWMuY29tL2NvbW1vbi9maXgvd3gtaXFpeWkvcGxheWVyLXRpcC1iZy5qcGcnIH0pXG4gICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKHsgJ3ByZXZpZXdDb3Zlcic6IHJlcy5kYXRhLnNoYXJlSW5mby5jb3ZlciB8fCAnaHR0cDovL3d3dy5pcWl5aXBpYy5jb20vY29tbW9uL2ZpeC93eC1pcWl5aS9wbGF5ZXItdGlwLWJnLmpwZycgfSlcbiAgICAgICAgICAgICAgICBzd2FuLnNldE5hdmlnYXRpb25CYXJUaXRsZSh7XG4gICAgICAgICAgICAgICAgICAgIHRpdGxlOiByZXMuZGF0YS5wcm9ncmFtSW5mby5wcm9ncmFtTmFtZVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHRoaXMuY29tcG9uZW50cy5wcmFpc2VDb250cm9sID0gbmV3IHByYWlzZUNvbnRyb2wodGhpcywgcmVzLmRhdGEucHJhaXNlSW5mbyk7XG4gICAgICAgICAgICAgICAgdGhpcy5jb21wb25lbnRzLnBsYXllckNvbnRyb2wgPSBuZXcgUGxheWVyQ29udHJvbCh0aGlzKTtcbiAgICAgICAgICAgICAgICAvLyDmi4nlj5bmnIDlkI7lh6DmnaHogYrlpKnorrDlvZVcbiAgICAgICAgICAgICAgICAvLyDogYrlpKnnmoTmmK/lkKbpnIDopoHlsZXnpLog5LiN5bGV56S6IOS5n+mcgOimgSBXUyDpk77mjqVcbiAgICAgICAgICAgICAgICByZXEuZ2V0TGF0ZXN0TXNnKHRoaXMucm9vbUluZm8uY2hhdFJvb21JZClcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4oKGRhdGEpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucm9vbUluZm8ubGF0ZXN0TXNnID0gZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29tcG9uZW50cy5zZW5kQm94ID0gbmV3IFNlbmRCb3godGhpcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbXBvbmVudHMubXNnQm94ID0gbmV3IE1lc3NhZ2VCb3godGhpcywgcmVzLmRhdGEuY2hhdEluZm8uY2hhdFJvb21JZCk7XG4gICAgICAgICAgICAgICAgICAgIH0pLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwYXJhbXMubXVsdGlMaXZlSW5mbykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3djaE9wZW4oKTsgLy8g5omT5byA5aSa5py65L2NXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHRoaXMuZXZlbnRUZXN0ZXIoXCJjYW5wbGF5dGhyb3VnaFwiLCBmdW5jdGlvbihlKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdjYW5wbGF5dGhyb3VnaCcpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBpZiAocmVzLmNvZGUgPT09IFwiQTAwMDA1XCIpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihg6ZyA6KaB5oqV6YCS55qEYCwgcmVzLm1zZyk7IC8vIFRPRE8g5oqV6YCSXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2Vuc29yLnB1c2godGhpcy5zZW5zb3IuQ09ERS5ST09NX0lOSVRJQUxfRVJSLCByZXMuY29kZSwgY29uRW5kIC0gY29uU3RhcnQsIDAsICcnLCBgJHtyZXMubXNnfWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB0aGlzLmNvbXBvbmVudHMucGxheWVyQ29udHJvbCA9IG5ldyBQbGF5ZXJDb250cm9sKHRoaXMpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7XG4gICAgICAgICAgICAgICAgICAgIGVyclJvb206IHRydWUsIC8v5oi/6Ze06ZSZ6K+vXG4gICAgICAgICAgICAgICAgICAgIHZpZGVvOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93OiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9ySW5mbzogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yTXNnOiByZXMubXNnIHx8ICfop4bpopHkuI3og73mkq3mlL4nXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHByZXZpZXdDb3ZlcjogJ2h0dHA6Ly93d3cuaXFpeWlwaWMuY29tL2NvbW1vbi9maXgvd3gtaXFpeWkvcGxheWVyLXRpcC1iZy5qcGcnXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgcmVzID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlcyk7XG4gICAgICAgIH0pO1xuICAgIH0sXG4gICAgZXZlbnRUZXN0ZXI6IGZ1bmN0aW9uKGUsIGV2ZW50SGFubGVyKSB7XG4gICAgICAgIGxldCBNZWRpYSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd2aWRlb0lkJyk7XG4gICAgICAgIE1lZGlhLmFkZEV2ZW50TGlzdGVuZXIoZSwgZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICBldmVudEhhbmxlciAmJiBldmVudEhhbmxlcigpO1xuICAgICAgICAgICAgb3V0LmRlYnVnKChuZXcgRGF0ZSgpKS5nZXRUaW1lKCksIGUpXG4gICAgICAgIH0sIGZhbHNlKTtcbiAgICB9LFxuICAgIHN3Y2hPcGVuKCkge1xuICAgICAgICAvLyDliIfmjaLmnLrkvY3mmL7npLpcbiAgICAgICAgdGhpcy5zZXREYXRhKHsgJ29wZW4nOiAhdGhpcy5kYXRhLm9wZW4gfSwgKCkgPT4ge1xuICAgICAgICAgICAgaWYgKHRoaXMuZGF0YS5tdWx0aUxpdmVJbmZvKSB7XG4gICAgICAgICAgICAgICAgaWYgKCF0aGlzLmRhdGEub3Blbikge1xuICAgICAgICAgICAgICAgICAgICByb29tLmdldFJvb21JbmZvSGVpZ2h0KHRoaXMsIGZhbHNlKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByb29tLmdldFJvb21JbmZvSGVpZ2h0KHRoaXMsIHRydWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcm9vbS5nZXRSb29tSW5mb0hlaWdodCh0aGlzKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICB9KTtcbiAgICB9LFxuICAgIGFmdGVyTG9naW5UcmlnZ2VyOiBmdW5jdGlvbigpIHtcbiAgICAgICAgc3dhbi5zaG93VG9hc3Qoe1xuICAgICAgICAgICAgdGl0bGU6IGDnmbvlvZXmiJDlip9gLFxuICAgICAgICAgICAgaWNvbjogJ25vbmUnXG4gICAgICAgIH0pO1xuICAgICAgICByb29tLnJlZnJlc2hJbmZvKHRoaXMpO1xuICAgICAgICB0aGlzLnRyaWdnZXIuZW1pdChcImFmdGVyTG9naW5TdWNjZXNzXCIpO1xuICAgIH0sXG5cbiAgICBhZnRlckxvZ291dFRyaWdnZXI6IGZ1bmN0aW9uKCkge1xuICAgICAgICByb29tLnJlc2V0Rm9sbG93QnRuKHRoaXMpO1xuICAgICAgICB0aGlzLnRyaWdnZXIuZW1pdChcImFmdGVyTG9nb3V0U3VjY2Vzc1wiKTtcbiAgICB9LFxuXG4gICAgbG9naW5TdWNjZXNzOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy50cmlnZ2VyLmVtaXQoXCJhZnRlckdldFVzZXJJbmZvXCIpO1xuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiDnlJ/lkb3lkajmnJ/lh73mlbAtLeebkeWQrOmhtemdouWIneasoea4suafk+WujOaIkFxuICAgICAqL1xuICAgIG9uUmVhZHk6IGZ1bmN0aW9uKCkge1xuICAgICAgICBsZXQgcGFnZSA9IHRoaXM7XG4gICAgICAgIC8vIHRoaXMuc2V0RGF0YSh7XG4gICAgICAgIC8vICAgICBzY3JvbGxIZWlnaHQ6IHJvb20uZ2V0U2Nyb2xsSGVpZ2h0KCksXG4gICAgICAgIC8vICAgICByb29tSW5mb0hlaWdodDogcm9vbS5nZXRSb29tSW5mb0hlaWdodCgpLFxuICAgICAgICAvLyAgICAgaW5wdXRGaXRDbGFzczogcm9vbS5nZXRJbnB1dEZpdENsYXNzKClcbiAgICAgICAgLy8gfSk7XG4gICAgICAgIHJvb20uZ2V0U2Nyb2xsSGVpZ2h0KHBhZ2UpO1xuICAgICAgICByb29tLmdldFJvb21JbmZvSGVpZ2h0KHBhZ2UpO1xuICAgICAgICByb29tLmdldElucHV0Rml0Q2xhc3MocGFnZSk7XG4gICAgICAgIC8vIGdldEFwcCgpLmVtaXR0ZXIub24oXCJhZnRlckxvZ2luU3VjY2Vzc1wiLCB0aGlzLmFmdGVyTG9naW5UcmlnZ2VyKTtcbiAgICAgICAgLy8gZ2V0QXBwKCkuZW1pdHRlci5vbihcImFmdGVyTG9nb3V0U3VjY2Vzc1wiLCB0aGlzLmFmdGVyTG9nb3V0VHJpZ2dlcik7XG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIOeUn+WRveWRqOacn+WHveaVsC0t55uR5ZCs6aG16Z2i5pi+56S6XG4gICAgICovXG4gICAgb25TaG93OiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy50cmlnZ2VyLmVtaXQoXCJzaG93UGFnZVwiKTtcbiAgICB9LFxuXG4gICAgLyoqXG4gICAgICog55Sf5ZG95ZGo5pyf5Ye95pWwLS3nm5HlkKzpobXpnaLpmpDol49cbiAgICAgKi9cbiAgICBvbkhpZGU6IGZ1bmN0aW9uKCkge1xuICAgICAgICBnZXRBcHAoKS5lbWl0dGVyLmVtaXQoXCJoaWRlUGFnZVwiKTtcbiAgICAgICAgdGhpcy50cmlnZ2VyLmVtaXQoXCJoaWRlUGFnZVwiKTtcbiAgICB9LFxuXG4gICAgb25FcnJvcihhYWEpIHtcbiAgICAgICAgY29uc29sZS53YXJuKGFhYSk7XG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIOeUn+WRveWRqOacn+WHveaVsC0t55uR5ZCs6aG16Z2i5Y246L29XG4gICAgICovXG4gICAgb25VbmxvYWQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLnRyaWdnZXIuZW1pdChcInBhZ2VVbmxvYWRcIik7XG4gICAgICAgIHRoaXMudHJpZ2dlci5vZmYoKTtcbiAgICAgICAgdGhpcy5zZXREYXRhKHtcbiAgICAgICAgICAgIGVycm9yVGlwOiB0cnVlLFxuICAgICAgICAgICAgYWN0aXZlVGFiOiBcImNoYXRcIixcbiAgICAgICAgICAgIHJvb21JZDogbnVsbCxcbiAgICAgICAgICAgIGhvc3RJbmZvOiBudWxsLFxuICAgICAgICAgICAgbXNnTGlzdDogW3tcbiAgICAgICAgICAgICAgICB0eXBlOiAwLFxuICAgICAgICAgICAgICAgIGNvbnRlbnQ6IFwi5q2j5Zyo6ZO+5o6l6IGK5aSp5a6kLi4uLi4uXCJcbiAgICAgICAgICAgIH1dLFxuICAgICAgICAgICAgc2Nyb2xsSGVpZ2h0OiAxMDAsXG4gICAgICAgICAgICBzY3JvbGxIaWRlTG9hZE1vcmU6IHRydWUsXG4gICAgICAgICAgICBzY3JvbGxBbmltYXRpb246IGZhbHNlLFxuICAgICAgICAgICAgaW5wdXRGb2N1czogZmFsc2UsXG4gICAgICAgICAgICBpbnB1dFRleHQ6IFwiXCIsXG4gICAgICAgICAgICBpbnB1dEF2YWlsYWJsZTogXCJcIixcbiAgICAgICAgICAgIHNob3dLZXlib2FyZDogXCJcIixcbiAgICAgICAgICAgIHZpZGVvQm9keVRvcDogMCxcbiAgICAgICAgICAgIGtleWJvYXJkSGVpZ2h0OiAwLFxuICAgICAgICAgICAgdmlkZW86IHtcbiAgICAgICAgICAgICAgICBuZWVkVklQOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBuZWVkTG9naW46IGZhbHNlLFxuICAgICAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgICAgIG9mZmxpbmU6IGZhbHNlLFxuICAgICAgICAgICAgICAgIHVybDogXCJcIlxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgLy8gZ2V0QXBwKCkuZW1pdHRlci5vZmYoXCJhZnRlckxvZ2luU3VjY2Vzc1wiLHRoaXMuYWZ0ZXJMb2dpblRyaWdnZXIpO1xuICAgICAgICAvLyBnZXRBcHAoKS5lbWl0dGVyLm9mZihcImFmdGVyTG9nb3V0U3VjY2Vzc1wiLCB0aGlzLmFmdGVyTG9nb3V0VHJpZ2dlcik7XG4gICAgfVxufVxuUGFnZShPYmplY3QuYXNzaWduKHt9LCBwYWdlKSlcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvcy9yb29tLmpzIiwiaW1wb3J0ICogYXMgdXNlciBmcm9tIFwiLi4vLi4vY29tbW9uL3VzZXIvdXNlckluZm9cIlxuLy8gaW1wb3J0IGFjdGlvbnMgZnJvbSBcIi4vYWN0aW9ucy9pbmRleFwiXG5pbXBvcnQgXyBmcm9tIFwiLi4vLi4vY29tbW9uL3V0aWxzL3V0aWxcIlxuaW1wb3J0IHBob25lbnVtYmVyTGliIGZyb20gJy4uLy4uL2NvbW1vbi91dGlscy9waG9uZW51bWJlckxpYidcbmltcG9ydCAqIGFzIHJlcSBmcm9tIFwiLi9zZXJ2aWNlL3JlcVNlcnZpY2VcIjtcbmltcG9ydCByc2FVdGlsIGZyb20gXCIuLi8uLi9jb21tb24vdXRpbHMvUlNBL3JzYVV0aWxcIjtcbmltcG9ydCBzZXNzaW9uIGZyb20gXCIuLi8uLi9jb21tb24vbG9naW4vc2Vzc2lvblwiO1xuXG5cbmNvbnN0IGFwcCA9IGdldEFwcCgpO1xuXG5jb25zdCBpc1Bob25lID0gKHVzZXJuYW1lKSA9PiB7XG4gICAgdmFyIGZvbnQgPSAvW1xcdTRFMDAtXFx1OUZBNV0vXG4gICAgdmFyIGNoYXIgPSAvW0EtWmEtel0vXG4gICAgcmV0dXJuICEoY2hhci50ZXN0KHVzZXJuYW1lKSB8fCBmb250LnRlc3QodXNlcm5hbWUpKVxufVxuXG5jb25zdCBwYWdlID0ge1xuICAgIGRhdGE6IHtcbiAgICAgICAgYXJlYV9pZHg6IDAsXG4gICAgICAgIGFyZWFfcmFuZ2U6IHJlcS5nZXREZWZhdWx0QXJlYSgpLFxuICAgICAgICBjdXJwYWdlOiAnc3dhbl96aGxvZ2luJyxcbiAgICAgICAgZXJyb3I6IHtcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgbXNnOiAnJ1xuICAgICAgICB9LFxuICAgICAgICBsb2dpbl9kaXNhYmxlZDogdHJ1ZSxcbiAgICAgICAgdXNlcm5hbWU6ICcnLC8vMTc2MjEwMzcwODlcbiAgICAgICAgaW1nX2NvZGU6IHtcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgY29kZTogJycsXG4gICAgICAgICAgICB2YWx1ZTogJydcbiAgICAgICAgfSxcbiAgICAgICAgdXNlckluZm86IHt9XG4gICAgfSxcblxuICAgIG9uU2hvdygpIHtcblxuICAgIH0sXG4gICAgb25SZWFkeSgpIHtcbiAgICB9LFxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5sb2FkUGFnZSgpO1xuICAgIH0sXG4gICAgbG9hZFBhZ2UoKSB7XG4gICAgICAgIHRoaXMuX2dldEFyZWFJbmZvKHsgbG9jYWw6IDEsIGVuYWJsZV9vdmVyc2VhOiAxIH0pO1xuICAgIH0sXG4gICAgX2xvYWRlZFBhZ2UoZGF0YSkge1xuICAgICAgICAvLyDmuLLmn5PlkI7lm57osINcbiAgICAgICAgXy5zZW8oKTsgLy/pu5jorqQgU0VPXG4gICAgfSxcbiAgICBqdW1wKGV2ZW50KSB7XG4gICAgICAgIC8vIHN3YW4uc3dpdGNoVGFiKHt1cmw6Jy9wYWdlcy9teS9teSd9KTtcbiAgICAgICAgLy8gXy5qdW1wKGBwYWdlcy9teS9teWApO1xuICAgICAgICAvLyByZXR1cm47XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LmN1cnJlbnRUYXJnZXQ7XG4gICAgICAgIGNvbnN0IHVybCA9IHRhcmdldC5kYXRhc2V0LnVybDtcbiAgICAgICAgXy5qdW1wKHVybCk7XG4gICAgfSxcbiAgICAvLyBpbml0IGFyZWEgcmFuZ2VcbiAgICBfZ2V0QXJlYUluZm86IGZ1bmN0aW9uIChwYXJhbXMpIHtcbiAgICAgICAgcmVxLmdldEFyZWFDb2RlKHBhcmFtcykudGhlbihkYXRhID0+IHtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHJlcS5mb3JtYXRBcmVhKGRhdGEpKTtcbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7IC4uLnJlcS5mb3JtYXRBcmVhKGRhdGEpIH0sICgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnZhbGlkYXRlKClcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0pXG4gICAgfSxcbiAgICAvLyBoYW5sZSBhcmVhIGNoYW5nZVxuICAgIGFyZWFDaGFuZ2U6IGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIGxldCB7IGRldGFpbDogeyB2YWx1ZTogYXJlYV9pZHggfSB9ID0gZVxuICAgICAgICB0aGlzLnNldERhdGEoeyBhcmVhX2lkeCB9KVxuICAgIH0sXG4gICAgLy8gaGFuZGxlIGlucHV0IGNoYW5nZVxuICAgIGlucHV0Q2hhbmdlOiBmdW5jdGlvbiAoZSkge1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgbGV0IHsgY3VycmVudFRhcmdldDogeyBkYXRhc2V0OiB7IHR5cGUgfSB9LCBkZXRhaWw6IHsgdmFsdWUgPSAnJyB9IH0gPSBlXG4gICAgICAgIGxldCB7IGVycm9yIH0gPSB0aGlzLmRhdGFcbiAgICAgICAgLy8g6L6T5YWl5pe25Y+W5raI6ZSZ6K+v5o+Q56S6XG4gICAgICAgIGVycm9yLnNob3cgJiYgKGVycm9yLnNob3cgPSBmYWxzZSlcbiAgICAgICAgdGhpcy5zZXREYXRhKHsgW3R5cGVdOiB2YWx1ZSwgZXJyb3IgfSlcbiAgICAgICAgdGhpcy52YWxpZGF0ZSgpXG4gICAgfSxcbiAgICAvLyBoYW5kbGUgaW5wdXQgYmx1clxuICAgIGlucHV0Qmx1cjogZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgbGV0IHsgZXJyb3IsIGxvZ2luX2Rpc2FibGVkIH0gPSB0aGlzLmRhdGFcbiAgICAgICAgaWYoIWxvZ2luX2Rpc2FibGVkKSByZXR1cm5cbiAgICAgICAgZXJyb3Iuc2hvdyA9IHRydWVcbiAgICAgICAgdGhpcy5zZXREYXRhKHsgZXJyb3IgfSlcbiAgICB9LFxuICAgIC8vIHZhbGlkYXRlIHVzZXJuYW1lICYgcHdkXG4gICAgdmFsaWRhdGU6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgbGV0IHsgdXNlcm5hbWUsIGFyZWFfcmFuZ2UsIGFyZWFfaWR4LCBlcnJvciB9ID0gdGhpcy5kYXRhXG4gICAgICAgIGxldCB7IGFjb2RlIH0gPSBhcmVhX3JhbmdlW2FyZWFfaWR4XVxuICAgICAgICBsZXQgbG9naW5fZGlzYWJsZWQgPSBmYWxzZVxuXG4gICAgICAgIGlmKCF1c2VybmFtZSkge1xuICAgICAgICAgICAgbG9naW5fZGlzYWJsZWQgPSB0cnVlXG4gICAgICAgICAgICBlcnJvci5tc2cgPSAn5omL5py65Y+35LiN6IO95Li656m6J1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYoaXNQaG9uZSh1c2VybmFtZSkpIHtcbiAgICAgICAgICAgICAgICBsZXQgeyByZWFzb24sIGlzUG9zc2libGUsIGlzTnVtYmVyVmFsaWQgfSA9IHBob25lbnVtYmVyTGliLnBob25lTnVtYmVyUGFyc2VyKHVzZXJuYW1lLnJlcGxhY2UoL1teMC05XSsvZywgJycpLCBhY29kZSlcbiAgICAgICAgICAgICAgICBpZighIXJlYXNvbiB8fCAhaXNQb3NzaWJsZSB8fCAhaXNOdW1iZXJWYWxpZCkge1xuICAgICAgICAgICAgICAgICAgICBsb2dpbl9kaXNhYmxlZCA9IHRydWVcbiAgICAgICAgICAgICAgICAgICAgZXJyb3IubXNnID0gJ+aJi+acuuWPt+agvOW8j+mUmeivryzor7fph43mlrDovpPlhaUnXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHRoaXMuc2V0RGF0YSh7IGVycm9yLCBsb2dpbl9kaXNhYmxlZCB9KVxuICAgICAgICByZXR1cm4geyBlcnJvciwgbG9naW5fZGlzYWJsZWQgfVxuICAgIH0sXG4gICAgLy8gZ290byBsb2dpblxuICAgIGdldE1lc3NhZ2U6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgbGV0IHsgdXNlcm5hbWUsIGFyZWFfcmFuZ2UsIGFyZWFfaWR4LCBlcnJvciB9ID0gdGhpcy5kYXRhXG4gICAgICAgIGxldCB7IGFjb2RlIH0gPSBhcmVhX3JhbmdlW2FyZWFfaWR4XTtcblxuICAgICAgICBjb25zdCB0b2tlbnMgPSB0aGlzLmRhdGEudG9rZW5zIHx8ICcnO1xuICAgICAgICBjb25zdCBwYWdlZnJvbSA9IHRoaXMuZGF0YS5wYWdlZnJvbSB8fCAnJztcbiAgICAgICAgY29uc3QgZGVsdGEgPSB0aGlzLmRhdGEuZGVsdGEgfHwgJyc7XG5cbiAgICAgICAgbGV0IHBob25lTnVtID0gdGhpcy5kYXRhLnVzZXJuYW1lIHx8ICcnO1xuXG4gICAgICAgIGNvbnN0IGxvZ2luX2Rpc2FibGVkID0gdGhpcy5kYXRhLmxvZ2luX2Rpc2FibGVkO1xuXG4gICAgICAgIGlmKGxvZ2luX2Rpc2FibGVkKSB7XG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBwaG9uZVR5cGUgPSB0aGlzLmRhdGEucGhvbmVUeXBlIHx8ICcnXG4gICAgICAgIGxldCByZXF1ZXN0VHlwZSA9IDIyO1xuICAgICAgICBsZXQgcGFyYW1zID0ge1xuICAgICAgICAgICAgcmVxdWVzdFR5cGU6IHJlcXVlc3RUeXBlLFxuICAgICAgICAgICAgLy8gcWRfc2M6Ly8g5Yqg5a+G5Ye95pWwXG4gICAgICAgICAgICAvLyBhZ2VudHR5cGVcbiAgICAgICAgICAgIC8vIHB0aWRcbiAgICAgICAgICAgIGNlbGxwaG9uZU51bWJlcjogcnNhVXRpbC5SU0FFbmNyeXB0aW9uKHBob25lTnVtKSxcbiAgICAgICAgICAgIGFyZWFfY29kZTogYWNvZGUsXG4gICAgICAgICAgICBzZXJ2aWNlSWQ6IDEsXG4gICAgICAgICAgICBkZnA6IHVzZXIuZ2V0RGV2aWNlSWQoKSxcbiAgICAgICAgICAgIFFDMDA1OiB1c2VyLmdldERldmljZUlkKCksXG4gICAgICAgICAgICBucjogMVxuICAgICAgICB9O1xuXG4gICAgICAgIGlmKHRoaXMuZ2V0TWVzc2FnZS5yZXF1ZXN0aW5nKSB7XG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgfVxuICAgICAgICB0aGlzLmdldE1lc3NhZ2UucmVxdWVzdGluZyA9IHRydWU7XG5cbiAgICAgICAgaWYoc3dhbi5zaG93TG9hZGluZykge1xuICAgICAgICAgICAgc3dhbi5zaG93TG9hZGluZyh7XG4gICAgICAgICAgICAgICAgdGl0bGU6ICfliqDovb3kuK0nLFxuICAgICAgICAgICAgICAgIG1hc2s6IHRydWVcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgbGV0IG1lc3NhZ2VDb2RlSW5wdXRVcmwgPSBgcGFnZXMvbWVzc2FnZUNvZGVJbnB1dC9tZXNzYWdlQ29kZUlucHV0P3Rva2Vucz0ke3Rva2Vuc30mYXJlYV9jb2RlPSR7YWNvZGV9JnBob25lPSR7cGhvbmVOdW19JnJlcXVlc3RUeXBlPSR7cmVxdWVzdFR5cGV9JnBhZ2Vmcm9tPSR7cGFnZWZyb219JmRlbHRhPSR7ZGVsdGF9JnBob25lVHlwZT0ke3Bob25lVHlwZX1gO1xuXG4gICAgICAgIC8vIHN3YW4uaGlkZUxvYWRpbmcoKTsvL1RPRE8g5rWL6K+V5LiN6I635Y+W6aqM6K+B56CBIOebtOaOpei3s+i9rOi/h+WOu1xuICAgICAgICAvLyBfLmp1bXAobWVzc2FnZUNvZGVJbnB1dFVybClcbiAgICAgICAgLy8gcmV0dXJuO1xuXG4gICAgICAgIHJlcS5nZXRQaG9uZUNvZGVJbmZvKHBhcmFtcykudGhlbigoZGF0YSkgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2coZGF0YSk7XG4gICAgICAgICAgICBpZihzd2FuLmhpZGVMb2FkaW5nKSB7XG4gICAgICAgICAgICAgICAgc3dhbi5oaWRlTG9hZGluZygpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZihkYXRhLmNvZGUgPT09ICdBMDAwMDAnKSB7XG4gICAgICAgICAgICAgICAgXy5qdW1wKG1lc3NhZ2VDb2RlSW5wdXRVcmwpXG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGlmKGRhdGEuY29kZSA9PT0gJ1AwMDIyMycpIHtcbiAgICAgICAgICAgICAgICAgICAgc3dhbi5zaG93VG9hc3Qoe1xuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IGDotKblj7flrZjlnKjlronlhajpo47pmanvvIzor7flsL3lv6vpgIDnmbvlhbbku5borr7lpIfmiJbnq4vljbPkv67mlLnlr4bnoIFgLFxuICAgICAgICAgICAgICAgICAgICAgICAgaWNvbjogJ25vbmUnXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHN3YW4uc2hvd1RvYXN0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBgJHtkYXRhLm1zZ31gLFxuICAgICAgICAgICAgICAgICAgICAgICAgaWNvbjogJ25vbmUnXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy/mlLnlj5jmjInpkq7nirbmgIFcbiAgICAgICAgICAgIHRoaXMuZGF0YS5sb2dpbl9kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgICAgICAgdGhpcy5zZXREYXRhKHsgbG9naW5fZGlzYWJsZWQ6IHRoaXMuZGF0YS5sb2dpbl9kaXNhYmxlZCB9KVxuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5nZXRNZXNzYWdlLnJlcXVlc3RpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgIH0sIDApXG4gICAgICAgIH0sIChlcnJvcikgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgICAgICAgICB0aGlzLmdldE1lc3NhZ2UucmVxdWVzdGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgc3dhbi5zaG93VG9hc3Qoe1xuICAgICAgICAgICAgICAgIHRpdGxlOiBgJHtlcnJvci5tc2d9YCxcbiAgICAgICAgICAgICAgICBpY29uOiAnbm9uZSdcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgLy/mlLnlj5jmjInpkq7nirbmgIFcbiAgICAgICAgICAgIHRoaXMuZGF0YS5sb2dpbl9kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgICAgICAgdGhpcy5zZXREYXRhKHsgbG9naW5fZGlzYWJsZWQ6IHRoaXMuZGF0YS5sb2dpbl9kaXNhYmxlZCB9KVxuICAgICAgICB9KVxuICAgIH1cblxuXG59XG5cblxuUGFnZShPYmplY3QuYXNzaWduKHt9LCBwYWdlKSlcblxuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC9Vc2Vycy9ob3ViaW5nYmluZy9jb2RlL2lxaXlpL3FsaXZlX21pbmlwcm9ncmFtL2JhaWR1L3BhZ2VzL2xvZ2luL2xvZ2luLmpzIiwiaW1wb3J0IHNlc3Npb24gZnJvbSBcIi4uLy4uL2NvbW1vbi9sb2dpbi9zZXNzaW9uXCI7XG5pbXBvcnQgXyBmcm9tIFwiLi4vLi4vY29tbW9uL3V0aWxzL3V0aWxcIlxuXG5cbmxldCBhcHAgPSBnZXRBcHAoKTtcbmxldCBnbG9iYWxEYXRhID0gYXBwLmdsb2JhbERhdGE7XG5jb25zdCBvcmlnaW5JY29uID0gJ2h0dHBzOi8vd3d3LmlxaXlpcGljLmNvbS9jb21tb24vZml4L2hlYWRpY29ucy9tYWxlLTEzMC5wbmcnO1xuXG5jb25zdCBwYWdlID0ge1xuICAgIGRhdGE6IHt9LFxuICAgIG9uU2hvdygpIHtcbiAgICB9LFxuICAgIGxvZ2luT3V0KCkge1xuICAgICAgICBjb25zb2xlLmxvZyhnbG9iYWxEYXRhKTtcbiAgICAgICAgc3dhbi5zaG93TW9kYWwoe1xuICAgICAgICAgICAgdGl0bGU6ICfpgIDlh7rnmbvlvZUnLFxuICAgICAgICAgICAgY2FuY2VsQ29sb3I6ICcjOTk5OTk5JyxcbiAgICAgICAgICAgIGNvbmZpcm1Db2xvcjogJyMwMDk5Y2MnLFxuICAgICAgICAgICAgc3VjY2VzczogKHJlcykgPT4ge1xuICAgICAgICAgICAgICAgIGlmKHJlcy5jb25maXJtKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCfnlKjmiLfngrnlh7vkuobnoa7lrponKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlVXNlckluZm8oKTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYocmVzLmNhbmNlbCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygn55So5oi354K55Ye75LqG5Y+W5raIJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9LFxuICAgIF91cGRhdGVVc2VySW5mbygpIHtcbiAgICAgICAgdGhpcy5zZXREYXRhKCdsb2dpbkluZm8uaXNMb2dpbicsIGZhbHNlKTtcbiAgICAgICAgdGhpcy5zZXREYXRhKCdsb2dpbkluZm8udXNlci5pY29uJywgb3JpZ2luSWNvbik7XG4gICAgICAgIHRoaXMuc2V0RGF0YSgnbG9naW5JbmZvLnVzZXIubmlja25hbWUnLCAnJyk7XG4gICAgICAgIHRoaXMuc2V0RGF0YSgnbG9naW5JbmZvLnVzZXIuaXNWaXAnLCBmYWxzZSk7XG4gICAgICAgIGdsb2JhbERhdGEuYXV0aENvb2tpZSA9ICcnO1xuICAgICAgICBzZXNzaW9uLlNlc3Npb24uY2xlYXIoKTtcbiAgICAgICAgXy5qdW1wKHsndHlwZSc6J2JhY2snfSk7XG4gICAgfSxcbiAgICBqdW1wKGV2ZW50KSB7XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LmN1cnJlbnRUYXJnZXQ7XG4gICAgICAgIGNvbnN0IHVybCA9IHRhcmdldC5kYXRhc2V0LnVybDtcbiAgICAgICAgLy8gY29uc29sZS5sb2codGFyZ2V0KTtcbiAgICAgICAgXy5qdW1wKHVybCk7XG4gICAgfSxcbiAgICBvblJlYWR5KCkge1xuICAgIH0sXG4gICAgb25Mb2FkKCkge1xuICAgICAgICAvLyB1c2VyLmluaXQoKTtcbiAgICB9XG59XG5cblxuUGFnZShPYmplY3QuYXNzaWduKHt9LCBwYWdlKSlcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvY29uZmlnL2NvbmZpZy5qcyIsImltcG9ydCBfIGZyb20gJy4uLy4uL2NvbW1vbi91dGlscy91dGlsJ1xuaW1wb3J0IHJ1bk1hY2luZSBmcm9tICcuLi8uLi9jb21tb24vdXRpbHMvcnVuTWFjaW5lJztcbmltcG9ydCBqdW1wIGZyb20gXCIuLi8uLi9jb21tb24vdXRpbHMvanVtcFwiO1xuaW1wb3J0ICogYXMgdXNlciBmcm9tIFwiLi4vLi4vY29tbW9uL3VzZXIvdXNlckluZm9cIjtcbmltcG9ydCByc2FVdGlsIGZyb20gXCIuLi8uLi9jb21tb24vdXRpbHMvUlNBL3JzYVV0aWxcIjtcbmltcG9ydCAqIGFzIHNlcnZpY2VBcGkgZnJvbSAnLi4vLi4vY29tbW9uL3NlcnZpY2VBcGkvc2VydmljZUFwaSdcbmltcG9ydCBzZXNzaW9uIGZyb20gXCIuLi8uLi9jb21tb24vbG9naW4vc2Vzc2lvblwiO1xuaW1wb3J0ICogYXMgb2JqZWN0IGZyb20gXCIuLi8uLi9jb21tb24vdXRpbHMvb2JqZWN0XCI7XG5cbmNvbnN0IGFwcCA9IGdldEFwcCgpO1xuY29uc3QgQ0VMTFBIT05FX0xPR0lOX1VSTCA9IGAke18uT1VURVJIT1NULlBBU1NQT1JUfS9hcGlzL3JlZ2xvZ2luL2NlbGxwaG9uZV9hdXRoY29kZV9sb2dpbi5hY3Rpb25gO1xuY29uc3QgcGFnZSA9IHtcbiAgICBkYXRhOiB7XG4gICAgICAgIG9wdGlvbnM6IHt9LFxuICAgICAgICBpbmZvOiB7XG4gICAgICAgICAgICBhcmVhX2NvZGU6IDg2LFxuICAgICAgICAgICAgcGhvbmU6ICcxMzg5OTk5Nzc3NycsXG4gICAgICAgICAgICBzaG93UGhvbmU6ICcxMzgqKioqNzc3NycsXG4gICAgICAgICAgICBwaG9uZWNvZGU6ICcnLFxuICAgICAgICAgICAgcmVzZW5kOiBmYWxzZVxuICAgICAgICB9LFxuICAgICAgICBpc0ZvY3VzOiB0cnVlXG4gICAgfSxcbiAgICBvblNob3coZXZlbnQpIHtcbiAgICAgICAgLy8gdGhpcy5sb2FkUGFnZSgpO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuc2V0X0ZvY3VzKCk7XG4gICAgICAgIH0sIDIwMClcbiAgICB9LFxuICAgIG9uUmVhZHkoKSB7XG4gICAgfSxcbiAgICBvbkxvYWQob3B0aW9ucykge1xuICAgICAgICB0aGlzLmRhdGEub3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgICAgIGNvbnNvbGUubG9nKG9wdGlvbnMpO1xuICAgICAgICB0aGlzLmluaXQoKTtcbiAgICB9LFxuICAgIGxvYWRQYWdlKCkge1xuICAgICAgICBjb25zb2xlLmxvZygxMjMzMyk7XG4gICAgfSxcbiAgICBfbG9hZGVkUGFnZShkYXRhKSB7XG5cbiAgICB9LFxuICAgIGluaXQoKSB7XG4gICAgICAgIGxldCB7IHRva2VucywgYXJlYV9jb2RlLCBwaG9uZSwgcmVxdWVzdFR5cGUsIHBhZ2Vmcm9tLCBkZWx0YSwgcGhvbmVUeXBlIH0gPSB0aGlzLmRhdGEub3B0aW9ucztcbiAgICAgICAgbGV0IHNob3dQaG9uZSA9IHBob25lO1xuICAgICAgICBpZigoYXJlYV9jb2RlICsgJycpID09PSAnODYnKSB7XG4gICAgICAgICAgICBzaG93UGhvbmUgPSBwaG9uZS5zdWJzdHJpbmcoMCwgMykgKyAnKioqKicgKyBwaG9uZS5zdWJzdHJpbmcoNyk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5kYXRhLnNob3dwaG9uZSA9IHBob25lO1xuICAgICAgICB0aGlzLnNldERhdGEoJ2luZm8uYXJlYV9jb2RlJywgYXJlYV9jb2RlKTtcbiAgICAgICAgdGhpcy5zZXREYXRhKCdpbmZvLnBob25lJywgcGhvbmUpO1xuICAgICAgICB0aGlzLnNldERhdGEoJ2luZm8uc2hvd1Bob25lJywgc2hvd1Bob25lKTtcbiAgICAgICAgdGhpcy5zZXREYXRhKCdpbmZvLnJlcXVlc3RUeXBlJywgcmVxdWVzdFR5cGUpO1xuICAgICAgICB0aGlzLnNldERhdGEoJ2luZm8udG9rZW5zJywgdG9rZW5zKTtcbiAgICAgICAgdGhpcy5zZXREYXRhKCdpbmZvLnJlc2VuZCcsIGZhbHNlKTtcbiAgICAgICAgdGhpcy5jb3VudERvd24oKTtcbiAgICB9LFxuICAgIGNvdW50RG93bigpIHtcbiAgICAgICAgY29uc3QgdGltZSA9IDU7XG4gICAgICAgIGlmKHRoaXMucnVuT2JqKSB7XG4gICAgICAgICAgICB0aGlzLnNldERhdGEoJ2luZm8ucmVzZW5kJywgdHJ1ZSk7XG4gICAgICAgICAgICBydW5NYWNpbmUuY2xlYXIodGhpcy5ydW5PYmopO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZGF0YS5jb3VudHMgPSB0aW1lO1xuICAgICAgICB0aGlzLnJ1bk9iaiA9IHJ1bk1hY2luZS5ydW4oKCkgPT4ge1xuICAgICAgICAgICAgaWYodGhpcy5kYXRhLmNvdW50cyA8PSAxKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5kYXRhLmNvdW50cyA9IDA7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKCdpbmZvLnJlc2VuZCcsIHRydWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5kYXRhLmNvdW50cy0tO1xuICAgICAgICAgICAgdGhpcy5zZXREYXRhKHsgY291bnRzOiB0aGlzLmRhdGEuY291bnRzIH0pO1xuICAgICAgICB9LCAxMDAwLCB0aW1lKTtcbiAgICB9LFxuICAgIHJlc2VuZCgpIHtcbiAgICAgICAgXy5qdW1wKHsgdHlwZTogJ2JhY2snIH0pO1xuICAgIH0sXG4gICAgc2V0X0ZvY3VzKCkgeyAvL+iBmueEpmlucHV0XG4gICAgICAgIHRoaXMuc2V0RGF0YSh7IGlzRm9jdXM6IHRydWUgfSlcbiAgICAgICAgY29uc29sZS5sb2coJ+iBmueEpicpO1xuICAgIH0sXG4gICAgc2V0X25vdEZvY3VzKCkgeyAvL+WkseWOu+eEpueCuVxuICAgICAgICB0aGlzLnNldERhdGEoeyBpc0ZvY3VzOiBmYWxzZSB9KVxuICAgICAgICBjb25zb2xlLmVycm9yKCflpLHljrvnhKbngrkhJyk7XG4gICAgfSxcbiAgICBzZXRfcGhvbmVjb2RlKGV2ZW50KSB7XG4gICAgICAgIGxldCB2YWx1ZSA9IGV2ZW50LmRldGFpbC52YWx1ZTtcbiAgICAgICAgaWYodGhpcy52ZXJpZnkucmVxdWVzdGluZykge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZGF0YS5pbmZvLnBob25lY29kZSA9IHZhbHVlICsgJyc7XG4gICAgICAgIHRoaXMuc2V0RGF0YSgnaW5mby5waG9uZWNvZGUnLCB2YWx1ZSlcbiAgICAgICAgaWYodmFsdWUgJiYgdmFsdWUubGVuZ3RoID09PSA2KSB7XG4gICAgICAgICAgICB0aGlzLnNldF9ub3RGb2N1cygpO1xuICAgICAgICAgICAgdGhpcy52ZXJpZnkodmFsdWUpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICB2ZXJpZnkodmFsdWUpIHtcbiAgICAgICAgbGV0IHN0YXRlID0gdGhpcy5kYXRhO1xuICAgICAgICBsZXQgYXJlYV9jb2RlID0gc3RhdGUuaW5mby5hcmVhX2NvZGUgfHwgJyc7XG4gICAgICAgIGxldCBhdXRoQ29kZSA9IHN0YXRlLmluZm8ub3JpZ2luY29kZTtcbiAgICAgICAgbGV0IHBob25lID0gc3RhdGUuaW5mby5waG9uZTtcbiAgICAgICAgbGV0IHJlcXVlc3RUeXBlID0gc3RhdGUuaW5mby5yZXF1ZXN0VHlwZSB8fCAnJztcbiAgICAgICAgbGV0IHRva2VucyA9IHN0YXRlLmluZm8udG9rZW5zIHx8ICcnO1xuXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XG4gICAgICAgICAgICAvLyBxZF9zYzonJ1xuICAgICAgICAgICAgYWdlbnR0eXBlOiBhcHAuZ2xvYmFsRGF0YS5hZ2VudHR5cGUsXG4gICAgICAgICAgICBwdGlkOiBhcHAuZ2xvYmFsRGF0YS5wdGlkLFxuICAgICAgICAgICAgY2VsbHBob25lTnVtYmVyOiBwaG9uZSxcbiAgICAgICAgICAgIGFyZWFfY29kZTogYXJlYV9jb2RlLFxuICAgICAgICAgICAgc2VydmljZUlkOiAxLFxuICAgICAgICAgICAgZGV2aWNlX2lkOiB1c2VyLmdldERldmljZUlkKCksXG4gICAgICAgICAgICBkZnA6IHVzZXIuZ2V0RGV2aWNlSWQoKSxcbiAgICAgICAgICAgIGF1dGhDb2RlOiB2YWx1ZSwvL+mqjOivgeeggVxuICAgICAgICAgICAgcmVxdWVzdFR5cGU6IHJlcXVlc3RUeXBlLFxuICAgICAgICAgICAgUUMwMDU6IHVzZXIuZ2V0RGV2aWNlSWQoKVxuICAgICAgICB9O1xuXG4gICAgICAgIHBhcmFtcy5xZF9zYyA9IHJzYVV0aWwuZ2V0UWl5aVF0c2MocGFyYW1zKTtcblxuICAgICAgICBpZih0aGlzLnZlcmlmeS5yZXF1ZXN0aW5nKSB7XG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgfVxuICAgICAgICB0aGlzLnZlcmlmeS5yZXF1ZXN0aW5nID0gdHJ1ZTtcblxuICAgICAgICBpZihzd2FuLnNob3dMb2FkaW5nKSB7XG4gICAgICAgICAgICBzd2FuLnNob3dMb2FkaW5nKHtcbiAgICAgICAgICAgICAgICB0aXRsZTogJ+WKoOi9veS4rScsXG4gICAgICAgICAgICAgICAgbWFzazogdHJ1ZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBsZXQgcmVzID0ge1xuICAgICAgICAvLyAgICAgYXV0aGNvb2tpZTogXCI5ZFBZUDRpUkhLVGxtM3N5RTRpOWNXZk9lRnlySzhlRXhPTGpwRW5vbTF4Zm0ycVB0VjZBOE1EaXc2N25YWVNtMmt6bTNDMzE0XCIsXG4gICAgICAgIC8vICAgICBpc05ld1VzZXI6IGZhbHNlXG4gICAgICAgIC8vIH1cbiAgICAgICAgLy8gdGhpcy52ZXJpZnlTdWNjZXNzSGFuZGxlKHJlcyk7XG4gICAgICAgIC8vIHJldHVybjtcblxuXG4gICAgICAgIGlmKHJlcXVlc3RUeXBlID09IDIyKSB7XG4gICAgICAgICAgICBzZXJ2aWNlQXBpLmNvbW1vblBvc3RSZXF1ZXN0KHtcbiAgICAgICAgICAgICAgICB1cmw6IENFTExQSE9ORV9MT0dJTl9VUkwsXG4gICAgICAgICAgICAgICAgcmVxUGFyYW1zOiBwYXJhbXNcbiAgICAgICAgICAgIH0sIHRydWUpLnRoZW4oKGRhdGEpID0+IHtcbiAgICAgICAgICAgICAgICBpZihkYXRhLmNvZGUgPT09ICdBMDAwMDAnKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdsb2dpbiBzdWNjZXNzJyk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YSgnaW5mby5waG9uZWNvZGUnLCAnJyk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YSgnaW5mby5vcmlnaW5jb2RlJywgJycpO1xuXG4gICAgICAgICAgICAgICAgICAgIC8vIHNlc3Npb24uU2Vzc2lvbi5zZXQoc2Vzc2lvbi5TRVNTSU9OX1BIT05FX05VTUJFUiwgcGhvbmUpOy8v5YaZ5YWl5omL5py65Y+356CBXG5cbiAgICAgICAgICAgICAgICAgICAgbGV0IHJlcyA9IGRhdGEuZGF0YSB8fCB7fTtcblxuICAgICAgICAgICAgICAgICAgICAvLyBsZXQgdGVtcEF1dGhDb29raWUgPSAnOWRQWVA0aVJIS1RsbTNzeUU0aTljV2ZPZUZ5cks4ZUV4T0xqcEVub20xeGZtMnFQdFY2QThNRGl3NjduWFlTbTJrem0zQzMxNCc7Ly9UT0RPIFRFU1QgYXV0aENvb2tpZVxuICAgICAgICAgICAgICAgICAgICAvLyBsZXQgYXV0aENvb2tpZSA9IHJlcyAmJiByZXMuYXV0aGNvb2tpZSA/IHJlcy5hdXRoY29va2llIDogdGVtcEF1dGhDb29raWU7XG4gICAgICAgICAgICAgICAgICAgIC8vIGh0dHA6Ly93aWtpLnFpeWkuZG9tYWluL3BhZ2VzL3ZpZXdwYWdlLmFjdGlvbj9wYWdlSWQ9MTc2MTUyMjQ1I2lkLSVFNSVBNCVBNyVFNyU5QiVCNCVFNiU5MiVBREVkZ2UlRTYlOEUlQTUlRTUlOEYlQTMoVjEpLTIwJUU0JUI4JUFBJUU0JUJBJUJBJUU0JUI4JUFEJUU1JUJGJTgzXG5cbiAgICAgICAgICAgICAgICAgICAgaWYoIXJlcy5pc05ld3VzZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGDogIHnlKjmiLdgKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGDmiJHmmK/mlrDnlKjmiLdgKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBsZXQgYXBwID0gZ2V0QXBwKCk7XG4gICAgICAgICAgICAgICAgICAgIGFwcC5nbG9iYWxEYXRhLm5lZWRMb2dpbiA9IDE7XG4gICAgICAgICAgICAgICAgICAgIGFwcC5nbG9iYWxEYXRhLmF1dGhDb29raWUgPSByZXMgJiYgcmVzLmF1dGhjb29raWUgfHwgJyc7XG4gICAgICAgICAgICAgICAgICAgIGFwcC5nbG9iYWxEYXRhLnBob25lID0gcGhvbmU7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGFwcC5nbG9iYWxEYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgLy8gc3dhbi5zd2l0Y2hUYWIoeyB1cmw6ICcvcGFnZXMvbXkvbXknIH0pOy8v6Lez6L2s5Yiw5Liq5Lq66aG16Z2iID9uZWVkTG9naW49MSZhdXRoQ29va2llPSR7cmVzICYmIHJlcy5hdXRoY29va2llfSZpc05ld3VzZXI9JHtyZXMgJiYgcmVzLmlzTmV3dXNlcn1cbiAgICAgICAgICAgICAgICAgICAgXy5qdW1wKGBwYWdlcy9teS9teWApO1xuXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgc3dhbi5zaG93VG9hc3QoeyB0aXRsZTogYCR7ZGF0YS5tc2d9YCwgaWNvbjogJ25vbmUnIH0pO1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRhLm1zZyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzd2FuLmhpZGVMb2FkaW5nICYmIHN3YW4uaGlkZUxvYWRpbmcoKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy52ZXJpZnkucmVxdWVzdGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIH0sIDApXG4gICAgICAgICAgICB9LCAoZXJyKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYoc3dhbi5oaWRlTG9hZGluZykge1xuICAgICAgICAgICAgICAgICAgICBzd2FuLmhpZGVMb2FkaW5nKClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgICAgICAgICBpZihlcnIuY29kZSA9PT0gJ0ZFQzAwMCcpIHtcbiAgICAgICAgICAgICAgICAgICAgc3dhbi5zaG93VG9hc3QoeyB0aXRsZTogYOe9kee7nOW8guW4uGAsIGljb246ICdub25lJyB9KTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBzd2FuLnNob3dUb2FzdCh7IHRpdGxlOiBlcnIubXNnIHx8IGDmnI3liqHlvILluLhgLCBpY29uOiAnbm9uZScgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRoaXMudmVyaWZ5LnJlcXVlc3RpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0gZWxzZSBpZihyZXF1ZXN0VHlwZSA9PSAyNikge1xuICAgICAgICAgICAgcGhvbmVTZXJ2aWNlLnZlcmlmeVBob25lQ29kZUluZm8ocGFyYW1zKS50aGVuKChkYXRhKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYoc3dhbi5oaWRlTG9hZGluZykge1xuICAgICAgICAgICAgICAgICAgICBzd2FuLmhpZGVMb2FkaW5nKClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKCdpbmZvLnBob25lY29kZScsICcnKTtcbiAgICAgICAgICAgICAgICB0aGlzLnNldERhdGEoJ2luZm8ub3JpZ2luY29kZScsICcnKTtcbiAgICAgICAgICAgICAgICBpZihkYXRhLmNvZGUgPT09ICdBMDAwMDAnKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMudmVyaWZ5U3VjY2Vzc0hhbmRsZShkYXRhLCB2YWx1ZSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgc3dhbi5zaG93VG9hc3Qoe1xuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IGAke2RhdGEubXNnfWAsXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uOiAnbm9uZSdcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnZlcmlmeS5yZXF1ZXN0aW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfSwgMClcbiAgICAgICAgICAgIH0sIChlcnJvcikgPT4ge1xuICAgICAgICAgICAgICAgIGlmKHN3YW4uaGlkZUxvYWRpbmcpIHtcbiAgICAgICAgICAgICAgICAgICAgc3dhbi5oaWRlTG9hZGluZygpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHN3YW4uc2hvd1RvYXN0KHtcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU6IGDmnI3liqHlvILluLhgLFxuICAgICAgICAgICAgICAgICAgICBpY29uOiAnbm9uZSdcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB0aGlzLnZlcmlmeS5yZXF1ZXN0aW5nID0gZmFsc2U7XG4gICAgICAgICAgICB9KVxuICAgICAgICB9IGVsc2UgaWYocmVxdWVzdFR5cGUgPT0gMzApIHtcbiAgICAgICAgICAgIGxldCBkZXZpY2VJZCA9IHVzZXIuZ2V0QW5vbnltb3VzVWlkKCk7XG4gICAgICAgICAgICBwYXJhbXMgPSBPYmplY3QuYXNzaWduKHt9LCBwYXJhbXMsIHtcbiAgICAgICAgICAgICAgICBkZXZpY2VfaWQ6IGRldmljZUlkLFxuICAgICAgICAgICAgICAgIGF1dGhjb29raWU6IHRoaXMuYXBwLmdsb2JhbERhdGEubXV0aUF1dGhjb29raWUsXG4gICAgICAgICAgICAgICAgY2VsbHBob25lTnVtYmVyOiByc2FVdGlsLlJTQUVuY3J5cHRpb24ocGhvbmUpXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgaWYoc3dhbi5zaG93TG9hZGluZykge1xuICAgICAgICAgICAgICAgIHN3YW4uc2hvd0xvYWRpbmcoe1xuICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ+WKoOi9veS4rSdcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMudmVyaWZ5TG9naW4ocGFyYW1zKS50aGVuKChkYXRhID0ge30pID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgYXV0aGNvb2tpZSA9IF8uaXNPYmplY3QoZGF0YSkgPyBkYXRhLmF1dGhjb29raWUgOiAnJztcbiAgICAgICAgICAgICAgICBsZXQgbmlja25hbWUgPSBfLmlzT2JqZWN0KGRhdGEpID8gKGRhdGEubmlja25hbWUgPyBkYXRhLm5pY2tuYW1lIDogJycpIDogJyc7XG4gICAgICAgICAgICAgICAgaWYoc3dhbi5oaWRlTG9hZGluZykge1xuICAgICAgICAgICAgICAgICAgICBzd2FuLmhpZGVMb2FkaW5nKClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy/mm7TmlrBhdXRoY29va2llXG4gICAgICAgICAgICAgICAgc2Vzc2lvbi5TZXNzaW9uLnNldChzZXNzaW9uLlNFU1NJT05fQVVUSF9LRVksIGF1dGhjb29raWUpXG4gICAgICAgICAgICAgICAgdGhpcy5tdXRpVmVyaWZ5RmxhZyA9IHRydWU7XG5cbiAgICAgICAgICAgICAgICBnZXRBcHAoKS5lbWl0dGVyLmVtaXQoJ2hpZGVNdXRpRGlhbG9nJylcbiAgICAgICAgICAgICAgICAvL3RvYXN05o+Q56S6XG4gICAgICAgICAgICAgICAgdGhpcy5zaG93TXV0aUFjY291bnRUb2FzdCgpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICdtdXRpVXNlck5hbWUnOiBuaWNrbmFtZVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgdGhpcy52ZXJpZnkucmVxdWVzdGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIC8v6L+U5Zue5Y6f6aG16Z2iXG4gICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG5cbiAgICAgICAgICAgICAgICAgICAgc3dhbi5uYXZpZ2F0ZUJhY2soe1xuICAgICAgICAgICAgICAgICAgICAgICAgZGVsdGE6IDJcbiAgICAgICAgICAgICAgICAgICAgfSlcblxuICAgICAgICAgICAgICAgIH0sIDMwMDApXG5cbiAgICAgICAgICAgIH0pLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnZlcmlmeS5yZXF1ZXN0aW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKCdpbmZvLnBob25lY29kZScsICcnKTtcbiAgICAgICAgICAgICAgICB0aGlzLnNldERhdGEoJ2luZm8ub3JpZ2luY29kZScsICcnKTtcbiAgICAgICAgICAgICAgICBpZihzd2FuLmhpZGVMb2FkaW5nKSB7XG4gICAgICAgICAgICAgICAgICAgIHN3YW4uaGlkZUxvYWRpbmcoKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvKuaPkOekuuaWh+ahiCovXG4gICAgICAgICAgICAgICAgbGV0IHRvYXN0TXNnID0gJ+WIh+aNouWksei0pe+8jOivt+mHjeivlSc7XG4gICAgICAgICAgICAgICAgaWYoXy5pc09iamVjdChlcnIpICYmICh0eXBlb2YgZXJyLmNvZGUgPT0gJ3N0cmluZycpICYmIChlcnIuY29kZS5pbmRleE9mKCdGRUMnKSA9PSAtMSkpIHtcbiAgICAgICAgICAgICAgICAgICAgdG9hc3RNc2cgPSBlcnIubXNnID8gZXJyLm1zZyA6IHRvYXN0TXNnO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBzd2FuLmhpZGVUb2FzdCgpO1xuICAgICAgICAgICAgICAgIHN3YW4uc2hvd1RvYXN0KHtcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU6IHRvYXN0TXNnLFxuICAgICAgICAgICAgICAgICAgICBpY29uOiAnbm9uZSdcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICB9LFxuICAgIGp1bXAoZXZlbnQpIHtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gZXZlbnQuY3VycmVudFRhcmdldDtcbiAgICAgICAgY29uc3QgdXJsID0gdGFyZ2V0LmRhdGFzZXQudXJsO1xuICAgICAgICBfLmp1bXAodXJsKTtcbiAgICB9XG59XG5cblxuUGFnZShPYmplY3QuYXNzaWduKHt9LCBwYWdlKSlcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvcGFnZXMvbWVzc2FnZUNvZGVJbnB1dC9tZXNzYWdlQ29kZUlucHV0LmpzIiwiaW1wb3J0IHVzZXIgZnJvbSBcIi4uLy4uLy4uL2NvbW1vbi91c2VyL3VzZXJcIjtcbmltcG9ydCBhY3Rpb25zIGZyb20gXCIuL2FjdGlvbnMvaW5kZXhcIjtcbmltcG9ydCBfIGZyb20gXCIuLi8uLi8uLi9jb21tb24vdXRpbHMvdXRpbFwiO1xuXG5jb25zdCBhcHAgPSBnZXRBcHAoKTtcbmNvbnN0IHBhZ2UgPSB7XG4gICAgZGF0YToge1xuICAgICAgICBsb2FkOiAnbm9uZScsXG4gICAgICAgIHJlY29yZDoge1xuICAgICAgICAgICAgZWRpdGU6IHRydWUsXG4gICAgICAgICAgICBzaG93RGVsZXRlOiB0cnVlLFxuICAgICAgICAgICAgdG90YWw6IDEwLFxuICAgICAgICAgICAgbGlzdDogW11cbiAgICAgICAgfSxcbiAgICB9LFxuICAgIG9uUHVsbERvd25SZWZyZXNoKCkge1xuICAgICAgICAvLyDkuIvmi4nliLfmlrBcbiAgICAgICAgdGhpcy5vbkxvYWQoKTtcbiAgICB9LFxuICAgIG9uU2hvdygpIHtcbiAgICAgICAgdGhpcy5sb2FkUGFnZSgpO1xuICAgIH0sXG4gICAgb25SZWFkeSgpIHt9LFxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5sb2FkUGFnZSgpO1xuICAgIH0sXG4gICAgbG9hZFBhZ2UoKSB7XG4gICAgICAgIC8vIF8ucmVjb3JkKHRoaXMuZGF0YS5yZWNvcmRzKTtcbiAgICAgICAgXy5yZWNvcmQoKS50aGVuKChkYXRhKSA9PiB7XG4gICAgICAgICAgICBsZXQgZm9ybWF0ZVJlY29yZCA9IGFjdGlvbnMuZ2V0Rm9ybWF0ZVJlY29yZChkYXRhKTtcbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7IHJlY29yZHM6IGZvcm1hdGVSZWNvcmQgfSk7XG4gICAgICAgICAgICB0aGlzLnNldERhdGEoeyAncmVjb3JkLmxpc3QnOiBkYXRhLCAncmVjb3JkLnRvdGFsJzogZGF0YS5sZW5ndGggfSk7XG4gICAgICAgIH0pXG4gICAgfSxcbiAgICBfbG9hZGVkUGFnZShkYXRhKSB7XG4gICAgICAgIF8uc2VvKCk7IC8v6buY6K6kIFNFTyBcbiAgICB9LFxuICAgIHBsYXlWaWRlbyhldmVudCkge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgICAgICBjb25zdCByb29tSWQgPSB0YXJnZXQuZGF0YXNldC5yb29tSWQ7XG4gICAgICAgIGNvbnN0IGxpdmVUeXBlID0gdGFyZ2V0LmRhdGFzZXQubGl2ZVR5cGU7XG4gICAgICAgIGlmICghcm9vbUlkKSB7XG4gICAgICAgICAgICBzd2FuLnNob3dUb2FzdCh7XG4gICAgICAgICAgICAgICAgaWNvbjogJ25vbmUnLFxuICAgICAgICAgICAgICAgIHRpdGxlOiAn5pWw5o2u5byC5bi4J1xuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgdXJsID0gYHBhZ2VzL3cvcm9vbT9yb29tSWQ9JHtyb29tSWR9YDtcbiAgICAgICAgaWYgKGxpdmVUeXBlID09IDIpIHtcbiAgICAgICAgICAgIHVybCA9IGBwYWdlcy9zL3Jvb20/cm9vbUlkPSR7cm9vbUlkfWA7XG4gICAgICAgIH1cbiAgICAgICAgXy5qdW1wKHVybCk7XG4gICAgfSxcbn1cblxuXG5QYWdlKE9iamVjdC5hc3NpZ24oe30sIHBhZ2UpKVxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAvVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9zdWJQYWNrYWdlL3BhZ2VzL215L3BsYXlMb2cuanMiLCJsZXQgYXBwID0gZ2V0QXBwKCk7XG5jb25zdCBwYWdlID0ge1xuICAgIG9uU2hvdygpIHt9LFxuICAgIG9uUmVhZHkoKSB7fSxcbiAgICBvbkxvYWQoKSB7XG4gICAgICAgIGxldCB2ZXJzaW9uID0gYXBwLmdsb2JhbERhdGEudmVyc2lvbjtcbiAgICAgICAgdGhpcy5zZXREYXRhKCd2ZXJzaW9uJyx2ZXJzaW9uKTtcbiAgICB9LFxufVxuXG5QYWdlKE9iamVjdC5hc3NpZ24oe30sIHBhZ2UpKVxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAvVXNlcnMvaG91YmluZ2JpbmcvY29kZS9pcWl5aS9xbGl2ZV9taW5pcHJvZ3JhbS9iYWlkdS9zdWJQYWNrYWdlL3BhZ2VzL215L2Fib3V0LmpzIiwibGV0IGFwcCA9IGdldEFwcCgpO1xuY29uc3QgcGFnZSA9IHtcbiAgICBvblNob3coKSB7XG4gICAgfSxcbiAgICBvblJlYWR5KCkge1xuICAgIH0sXG4gICAgb25Mb2FkKCkge1xuICAgIH1cbn1cblxuUGFnZShPYmplY3QuYXNzaWduKHt9LCBwYWdlKSlcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvc3ViUGFja2FnZS9wYWdlcy9sb2dpbi9sb2dpblByb3RvY29sLmpzIiwibGV0IGFwcCA9IGdldEFwcCgpO1xuY29uc3QgcGFnZSA9IHtcbiAgICBvblNob3coKSB7XG4gICAgfSxcbiAgICBvblJlYWR5KCkge1xuICAgIH0sXG4gICAgb25Mb2FkKCkge1xuICAgIH1cbn1cblxuUGFnZShPYmplY3QuYXNzaWduKHt9LCBwYWdlKSlcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gL1VzZXJzL2hvdWJpbmdiaW5nL2NvZGUvaXFpeWkvcWxpdmVfbWluaXByb2dyYW0vYmFpZHUvc3ViUGFja2FnZS9wYWdlcy9sb2dpbi9wcml2YXRlSDUuanMiXSwic291cmNlUm9vdCI6IiJ9